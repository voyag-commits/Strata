# Coder Tasks for v0.6

## Task 1: Bring up the WSL package

Definition of done:

- `npm install` completes inside WSL.
- `npm run build` completes.
- `npm run strata -- init` creates `.strata/`.
- No `node_modules`, `dist`, or local secrets are committed into the worktree.

## Task 2: Copy the portable Codex CLI + DeepSeek bridge module into WSL

Definition of done:

- Codex CLI command is available from the WSL shell.
- The DeepSeek bridge can be started from WSL.
- Codex CLI is configured to call the local OpenAI-compatible bridge endpoint.
- No raw API key is written into Strata ledgers, packets, docs, or committed config.

## Task 3: Launch a live tmux Codex session

Definition of done:

- A named tmux session exists, for example `STRATA-CODER-A0601`.
- Codex CLI is visible/running in that session.
- `strata sessions create ...` records `.strata/sessions/tmux/*.json`.
- `.strata/ledgers/backend_loop_ledger.jsonl` contains `DUTY_REGISTERED` or a precise blocked state.

## Task 4: Dispatch one Work Dispatch Packet

Definition of done:

- `strata dispatch create ...` writes a packet under `.strata/dispatches/work_dispatch_packets/`.
- `strata dispatch send ...` sends the packet notice into the live tmux session.
- tmux capture evidence is written under `.strata/evidence/tmux_dispatch/`.
- backend loop ledger records `WORK_PASSED` or `DISPATCH_BLOCKED`.

## Task 5: Worker returns by file

Definition of done:

- Worker writes the required report file.
- Worker writes one Worker Return Packet under `.strata/returns/{assignment_id}/{agent_id}/`.
- Return packet nonce matches the dispatch nonce.
- No chat-only completion is accepted.

## Task 6: Backend classification and review

Definition of done:

- `strata returns scan ...` records `RETURN_FILE_DETECTED` and `RETURN_PACKET_CLASSIFIED`.
- `REPORT_READY` creates an Agent Report Ledger candidate.
- Reviewer accepts or rejects through `strata report review ...`.
- Accepted reports enter ClassB; rejected or malformed reports do not.
