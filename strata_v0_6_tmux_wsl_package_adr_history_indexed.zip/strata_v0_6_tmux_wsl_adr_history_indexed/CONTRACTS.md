# Strata v0.6 Contracts

## File-first communication

Chat/session text is not a deliverable. It may acknowledge receipt, but the backend only recognizes structured files.

Authoritative worker returns are JSON files under:

```text
.strata/returns/{assignment_id}/{agent_id}/
```

## Worker Return Packet

Allowed `return_kind` values:

```text
ACK
QUESTION
BLOCKED
NEEDS_CLARIFICATION
PARTIAL_STATUS
REPORT_READY
FAILED_WITH_DIAGNOSTIC
```

Only `REPORT_READY` creates an Agent Report Ledger candidate. Only a reviewed accepted report can enter ClassB.

## Dispatch evidence

A tmux dispatch must record:

- target tmux session name
- assignment id
- agent id
- role
- packet path
- packet SHA256
- nonce
- dispatch ledger entry
- tmux capture/evidence directory
- backend loop ledger event

## Backend Loop Ledger

Authoritative control-loop log:

```text
.strata/ledgers/backend_loop_ledger.jsonl
```

Human-readable mirror:

```text
.strata/ledgers/backend_loop_ledger.md
```

Controlled event names remain aligned with ADR0601 M1-M3:

```text
DUTY_REGISTERED
DUTY_VERIFIED
WORK_PACKET_CREATED
WORK_PASSED
DISPATCH_BLOCKED
RETURN_FILE_DETECTED
RETURN_FILE_NOT_DETECTED
RETURN_PACKET_CLASSIFIED
ROUTED_TO_IC
ROUTED_TO_REVIEWER
ROUTED_TO_CLASSD
REPORT_LEDGERED
REVIEW_ACCEPTED
REVIEW_REWORK_REQUIRED
CLASSB_IMPORTED
CLASSB_REJECTED_OR_BLOCKED
```

## Acceptance discipline

No offline mock, preflight script, or static self-check may be treated as M1/M2/M3 acceptance. Acceptance means the operator can show the live tmux session behavior and the corresponding backend JSONL ledger chain.
