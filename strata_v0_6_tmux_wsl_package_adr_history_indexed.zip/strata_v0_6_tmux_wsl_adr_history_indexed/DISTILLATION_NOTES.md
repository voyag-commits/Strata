# Distillation Notes

## Base retained

The retained base is the operational backend/bridge kernel from the prior package:

- DeepSeek/OpenAI-compatible bridge mapper/server/config.
- Worker Return Packet classifier.
- Dispatch Ledger.
- Agent Report Ledger.
- ClassB review/admission path.
- Mutation Gate.
- Context ClassA/B/C/D primitives.

## Active v0.6 additions

- `src/backend/tmux_dispatch/`: live tmux launcher/sender/capture layer.
- `src/backend/loop_ledger/`: ADR0601 backend loop JSONL and Markdown mirror.
- `.strata/` project-local runtime layout.
- v0.6 milestone/addendum documents.

## Removed from active implementation

- Windows UIA/Desktop injection source and scripts.
- Windows ConPTY dispatch source and scripts.
- GUI-worker tests and live Windows evidence.
- Placeholder Codex boundary runtime.
- Offline proof CLI as acceptance path.
- Generated `dist/`, `node_modules/`, zip bundles, and historical evidence packages.

## Rationale

Codex CLI plus the DeepSeek bridge has been confirmed as the stable/high-performance route. Windows UIA and ConPTY introduced observation/control problems. The v0.6 package therefore narrows the active implementation to WSL/tmux while preserving the governance contract and file-first evidence discipline.

## ADR history packaging correction

The package now treats v0.5, ADR-HS-2026-06-0601, and the v0.6 addendum as an indexed ADR history rather than loose reference material. They are retained under `reference/adr_history/` with date-prefixed names.

The active implementation remains v0.6 WSL/tmux. Historical ADRs are preserved for lineage and inherited governance, not as competing runtime paths.

Key index files:

```text
docs/ADR_HISTORY_INDEX.md
reference/adr_history/INDEX.md
```
