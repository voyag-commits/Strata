# M1 Goal: Live tmux Codex Dispatch-Return Loop

The first implementation target is a single nonce chain:

```text
WORK_PASSED
-> RETURN_FILE_DETECTED
-> RETURN_PACKET_CLASSIFIED
-> REPORT_LEDGERED or ROUTED_TO_IC/ROUTED_TO_CLASSD
```

For the primary smoke path using `REPORT_READY`, the chain is:

```text
WORK_PASSED
-> RETURN_FILE_DETECTED
-> RETURN_PACKET_CLASSIFIED
-> REPORT_LEDGERED
-> ROUTED_TO_REVIEWER
```

ClassB import is a continuation after review acceptance.

## Required live surfaces

The coder/operator must show:

- VS Code terminal with the tmux session.
- Codex CLI running inside that session.
- `.strata/ledgers/backend_loop_ledger.jsonl` entries.
- `.strata/dispatches/...` packet file.
- `.strata/returns/...` Worker Return Packet file.
- `.strata/ledgers/agent_report_ledger/...` or coordination/ClassD route.

## Not sufficient

The following do not satisfy M1:

- Mock tmux tests.
- Preflight scripts.
- Static self-checks.
- Chat claims that the worker completed the task.
- A return file with a different nonce than the dispatch.
