import fs from "node:fs";
import path from "node:path";
import { execFileSync } from "node:child_process";
import {
  ensureDir,
  ensureGovernanceLayout,
  fileExists,
  hashText,
  isoStamp,
  readJson,
  readText,
  shortId,
  type CommandContext,
  writeJson,
  writeText,
} from "../common.js";
import { gatedMutation } from "../mutation_gate/index.js";
import { recordDispatch, type PacketType } from "../dispatch_ledger/index.js";
import { returnFolderFor } from "../worker_returns/index.js";
import { appendBackendLoopEvent } from "../loop_ledger/index.js";

export type TmuxSessionState = "created" | "active" | "not_found" | "blocked";

export interface TmuxSessionRecord {
  contract_id: "tmux_session.record.v1";
  session_id: string;
  tmux_session_name: string;
  assignment_id: string;
  agent_id: string;
  role: string;
  runtime_name: "CodexCLI";
  cwd: string;
  command: string;
  state: TmuxSessionState;
  evidence_dir: string;
  last_capture_path: string | null;
  created_at: string;
  updated_at: string;
  gate_record_path: string;
}

export interface TmuxSessionIndex {
  contract_id: "tmux_session.index.v1";
  sessions: string[];
  updated_at: string | null;
}

export interface LaunchTmuxInput {
  assignmentId: string;
  agentId: string;
  role: string;
  sessionName?: string;
  cwd?: string;
  command?: string;
  attachIfExists?: boolean;
  actor?: string;
}

export interface LaunchTmuxResult {
  ok: boolean;
  status: "SESSION_CREATED" | "SESSION_ALREADY_EXISTS" | "BLOCKED_TMUX_NOT_AVAILABLE" | "BLOCKED_WITH_DIAGNOSTIC";
  session: TmuxSessionRecord;
  session_path: string;
  index_path: string;
  evidence_dir: string;
  stdout_path: string;
  stderr_path: string;
  diagnostic_path: string | null;
}

export interface TmuxSendInput {
  assignmentId?: string;
  agentId?: string;
  role?: string;
  sessionName: string;
  packetPath: string;
  packetType?: PacketType;
  nonce?: string;
  message?: string;
  messageFile?: string;
  fromRole?: string;
  submit?: boolean;
  actor?: string;
}

export interface TmuxSendResult {
  ok: boolean;
  status: "SUBMITTED_AND_VERIFIED" | "SUBMITTED_NOT_VERIFIED" | "PASTED_NOT_SUBMITTED" | "BLOCKED_SESSION_NOT_FOUND" | "BLOCKED_WITH_DIAGNOSTIC";
  dispatch_id: string;
  dispatch_ledger_path: string | null;
  packet_path: string;
  packet_sha256: string | null;
  nonce: string | null;
  session_name: string;
  evidence_dir: string;
  message_path: string;
  capture_before_path: string | null;
  capture_after_paste_path: string | null;
  capture_after_submit_path: string | null;
  diagnostic_path: string | null;
}

function safe(value: string): string {
  return value.replace(/[^A-Za-z0-9_.-]+/g, "-").replace(/^-+|-+$/g, "") || "item";
}

function defaultSessionName(role: string, assignmentId: string): string {
  return `STRATA-${safe(role).toUpperCase()}-${safe(assignmentId).toUpperCase()}`;
}

function runTmux(args: string[]): string {
  return execFileSync("tmux", args, { encoding: "utf8", stdio: ["ignore", "pipe", "pipe"] });
}

function tmuxExists(): boolean {
  try {
    execFileSync("tmux", ["-V"], { encoding: "utf8", stdio: ["ignore", "pipe", "pipe"] });
    return true;
  } catch {
    return false;
  }
}

function sessionExists(sessionName: string): boolean {
  try {
    runTmux(["has-session", "-t", sessionName]);
    return true;
  } catch {
    return false;
  }
}

function sessionRecordPath(ctx: CommandContext, sessionId: string): string {
  return path.join(ensureGovernanceLayout(ctx.workspaceRoot).tmuxSessions, `${safe(sessionId)}.json`);
}

function upsertSessionIndex(ctx: CommandContext, recordPath: string): string {
  const layout = ensureGovernanceLayout(ctx.workspaceRoot);
  const index = readJson<TmuxSessionIndex>(layout.tmuxSessionIndexPath);
  const sessions = Array.from(new Set([...index.sessions, recordPath])).sort();
  return writeJson(layout.tmuxSessionIndexPath, { ...index, sessions, updated_at: isoStamp(ctx.now) });
}

function parseFrontmatter(text: string): Record<string, string> {
  const match = text.match(/^---\r?\n([\s\S]*?)\r?\n---/);
  if (!match) return {};
  const result: Record<string, string> = {};
  for (const line of match[1].split(/\r?\n/)) {
    const idx = line.indexOf(":");
    if (idx < 0) continue;
    result[line.slice(0, idx).trim()] = line.slice(idx + 1).trim();
  }
  return result;
}

function inferPacket(packetPath: string): { assignmentId?: string; agentId?: string; role?: string; nonce?: string; packetType?: PacketType } {
  if (!fileExists(packetPath)) return {};
  const frontmatter = parseFrontmatter(readText(packetPath));
  const cid = frontmatter.contract_id;
  const packetType: PacketType | undefined = cid === "context_load_packet.v1" || cid === "work_dispatch_packet.v1" ? cid : undefined;
  return {
    assignmentId: frontmatter.assignment_id,
    agentId: frontmatter.agent_id,
    role: frontmatter.role,
    nonce: frontmatter.nonce,
    packetType,
  };
}

function sha(pathname: string): string | null {
  return fileExists(pathname) ? hashText(readText(pathname)) : null;
}

function capture(sessionName: string, outPath: string): string {
  const text = runTmux(["capture-pane", "-p", "-S", "-2000", "-t", sessionName]);
  writeText(outPath, text);
  return outPath;
}

export function launchTmuxDispatch(context: CommandContext, input: LaunchTmuxInput): LaunchTmuxResult {
  const layout = ensureGovernanceLayout(context.workspaceRoot);
  const sessionName = input.sessionName ?? defaultSessionName(input.role, input.assignmentId);
  const command = input.command ?? process.env.CODEX_CLI_COMMAND ?? "codex";
  const cwd = path.resolve(input.cwd ?? context.workspaceRoot);
  const sessionId = `tmux_${safe(input.assignmentId)}_${safe(input.agentId)}_${safe(sessionName)}`;
  const evidenceDir = ensureDir(path.join(layout.evidence, "tmux_dispatch", safe(input.assignmentId), safe(input.agentId), safe(sessionId)));
  const stdoutPath = path.join(evidenceDir, "tmux_stdout.txt");
  const stderrPath = path.join(evidenceDir, "tmux_stderr.txt");
  let status: LaunchTmuxResult["status"] = "SESSION_CREATED";
  let state: TmuxSessionState = "created";
  let diagnosticPath: string | null = null;
  let lastCapturePath: string | null = null;
  let stdout = "";
  let stderr = "";

  try {
    if (!tmuxExists()) throw new Error("tmux executable is not available in PATH.");
    if (sessionExists(sessionName)) {
      status = "SESSION_ALREADY_EXISTS";
      state = "active";
    } else {
      stdout = runTmux(["new-session", "-d", "-s", sessionName, "-c", cwd, command]);
      state = "active";
    }
    lastCapturePath = capture(sessionName, path.join(evidenceDir, "capture_after_launch.txt"));
  } catch (error) {
    status = String(error).includes("tmux executable") ? "BLOCKED_TMUX_NOT_AVAILABLE" : "BLOCKED_WITH_DIAGNOSTIC";
    state = "blocked";
    diagnosticPath = path.join(evidenceDir, "diagnostic.json");
    writeJson(diagnosticPath, { contract_id: "tmux_dispatch.diagnostic.v1", phase: "launch", session_name: sessionName, error: error instanceof Error ? error.message : String(error), created_at: isoStamp(context.now) });
  }
  writeText(stdoutPath, stdout);
  writeText(stderrPath, stderr);

  const recordPath = sessionRecordPath(context, sessionId);
  const gate = gatedMutation(context, {
    actor: input.actor ?? "BOC",
    action: "tmux_dispatch.launch",
    resourceType: "tmux_session",
    resourceId: sessionId,
    reason: "create or register named tmux session for Codex CLI worker dispatch",
    afterPath: recordPath,
    evidencePath: evidenceDir,
    metadata: { assignment_id: input.assignmentId, agent_id: input.agentId, role: input.role, session_name: sessionName, command, cwd, status },
  });
  const session: TmuxSessionRecord = {
    contract_id: "tmux_session.record.v1",
    session_id: sessionId,
    tmux_session_name: sessionName,
    assignment_id: input.assignmentId,
    agent_id: input.agentId,
    role: input.role,
    runtime_name: "CodexCLI",
    cwd,
    command,
    state,
    evidence_dir: evidenceDir,
    last_capture_path: lastCapturePath,
    created_at: isoStamp(context.now),
    updated_at: isoStamp(context.now),
    gate_record_path: gate.gate_record_path,
  };
  writeJson(recordPath, session);
  const indexPath = upsertSessionIndex(context, recordPath);
  appendBackendLoopEvent(context, {
    assignmentId: input.assignmentId,
    event: state === "active" ? "DUTY_REGISTERED" : "DISPATCH_BLOCKED",
    actor: input.actor ?? "BOC",
    to: input.agentId,
    agentId: input.agentId,
    role: input.role,
    targetApp: "CodexCLI",
    sessionName,
    status,
    artifact: recordPath,
    evidence: evidenceDir,
    note: diagnosticPath ? "tmux session launch blocked" : "tmux session registered for live dispatch",
  });
  return { ok: state === "active", status, session, session_path: recordPath, index_path: indexPath, evidence_dir: evidenceDir, stdout_path: stdoutPath, stderr_path: stderrPath, diagnostic_path: diagnosticPath };
}

function messageFor(input: TmuxSendInput, inferred: ReturnType<typeof inferPacket>, ctx: CommandContext): string {
  if (input.messageFile) return readText(path.resolve(input.messageFile));
  if (input.message) return input.message;
  const assignmentId = input.assignmentId ?? inferred.assignmentId ?? "UNKNOWN_ASSIGNMENT";
  const agentId = input.agentId ?? inferred.agentId ?? "UNKNOWN_AGENT";
  const nonce = input.nonce ?? inferred.nonce ?? "UNKNOWN_NONCE";
  const returnFolder = returnFolderFor(ctx, assignmentId, agentId);
  return [
    "STRATA WORK DISPATCH v1",
    "",
    `Assignment: ${assignmentId}`,
    `Agent: ${agentId}`,
    `Read packet: ${path.resolve(input.packetPath)}`,
    "",
    "Chat text is not the deliverable channel.",
    "When work is complete or blocked, write a Worker Return Packet JSON file to:",
    returnFolder,
    "",
    `Nonce: ${nonce}`,
  ].join("\n");
}

export function sendTmuxDispatch(context: CommandContext, input: TmuxSendInput): TmuxSendResult {
  const layout = ensureGovernanceLayout(context.workspaceRoot);
  const packetPath = path.resolve(input.packetPath);
  const inferred = inferPacket(packetPath);
  const assignmentId = input.assignmentId ?? inferred.assignmentId ?? "UNKNOWN_ASSIGNMENT";
  const agentId = input.agentId ?? inferred.agentId ?? "UNKNOWN_AGENT";
  const role = input.role ?? inferred.role ?? "worker";
  const nonce = input.nonce ?? inferred.nonce ?? null;
  const packetType = input.packetType ?? inferred.packetType ?? "work_dispatch_packet.v1";
  const dispatchId = shortId(`tmux_dispatch_${safe(assignmentId)}_${safe(agentId)}`, context.now);
  const evidenceDir = ensureDir(path.join(layout.evidence, "tmux_dispatch", safe(assignmentId), safe(agentId), safe(dispatchId)));
  const messagePath = path.join(evidenceDir, "dispatch_message.md");
  const captureBeforePath = path.join(evidenceDir, "capture_before.txt");
  const captureAfterPastePath = path.join(evidenceDir, "capture_after_paste.txt");
  const captureAfterSubmitPath = path.join(evidenceDir, "capture_after_submit.txt");
  const diagnosticPath = path.join(evidenceDir, "diagnostic.json");
  const commandLogPath = path.join(evidenceDir, "tmux_command_log.json");
  let status: TmuxSendResult["status"] = "SUBMITTED_AND_VERIFIED";
  let ledgerPath: string | null = null;
  let capBefore: string | null = null;
  let capAfterPaste: string | null = null;
  let capAfterSubmit: string | null = null;
  let finalDiagnosticPath: string | null = null;

  const message = messageFor(input, inferred, context);
  writeText(messagePath, message.endsWith("\n") ? message : `${message}\n`);

  try {
    if (!fileExists(packetPath)) throw new Error(`packet_path does not exist: ${packetPath}`);
    if (!tmuxExists()) throw new Error("tmux executable is not available in PATH.");
    if (!sessionExists(input.sessionName)) {
      status = "BLOCKED_SESSION_NOT_FOUND";
      throw new Error(`tmux session not found: ${input.sessionName}`);
    }
    capBefore = capture(input.sessionName, captureBeforePath);
    const bufferName = `${safe(dispatchId)}_buffer`;
    runTmux(["load-buffer", "-b", bufferName, messagePath]);
    runTmux(["paste-buffer", "-t", input.sessionName, "-b", bufferName]);
    capAfterPaste = capture(input.sessionName, captureAfterPastePath);
    const verifyNeedle = nonce ?? packetPath;
    const visible = readText(captureAfterPastePath).includes(verifyNeedle);
    if (input.submit !== false) {
      runTmux(["send-keys", "-t", input.sessionName, "Enter"]);
      capAfterSubmit = capture(input.sessionName, captureAfterSubmitPath);
      status = visible ? "SUBMITTED_AND_VERIFIED" : "SUBMITTED_NOT_VERIFIED";
    } else {
      status = "PASTED_NOT_SUBMITTED";
    }
    writeJson(commandLogPath, { contract_id: "tmux_dispatch.command_log.v1", session_name: input.sessionName, packet_path: packetPath, message_path: messagePath, submit: input.submit !== false, nonce, visible_after_paste: visible, created_at: isoStamp(context.now) });
    const dispatch = recordDispatch(context, {
      dispatchId,
      assignmentId,
      fromRole: input.fromRole ?? "BOC",
      toAgentId: agentId,
      targetApp: "CodexCLI",
      sessionName: input.sessionName,
      packetType,
      packetPath,
      nonce: nonce ?? "UNKNOWN_NONCE",
      pasteStatus: visible ? "PASTED_AND_VERIFIED" : "BLOCKED_VERIFICATION_FAILED",
      submitStatus: status === "SUBMITTED_AND_VERIFIED" ? "SUBMITTED_AND_VERIFIED" : status === "SUBMITTED_NOT_VERIFIED" ? "SUBMITTED_NOT_VERIFIED" : "NOT_SUBMITTED",
      verificationStatus: visible ? "VISIBLE_NONCE_VERIFIED" : "VISIBLE_NONCE_NOT_VERIFIED",
      evidenceDir,
      diagnosticPath: visible ? null : commandLogPath,
      actor: input.actor ?? "BOC",
    });
    ledgerPath = dispatch.entry_path;
  } catch (error) {
    if (status !== "BLOCKED_SESSION_NOT_FOUND") status = "BLOCKED_WITH_DIAGNOSTIC";
    finalDiagnosticPath = diagnosticPath;
    writeJson(diagnosticPath, { contract_id: "tmux_dispatch.diagnostic.v1", phase: "send", session_name: input.sessionName, packet_path: packetPath, error: error instanceof Error ? error.message : String(error), created_at: isoStamp(context.now) });
  }

  const ok = status === "SUBMITTED_AND_VERIFIED" || status === "PASTED_NOT_SUBMITTED";
  appendBackendLoopEvent(context, {
    assignmentId,
    event: status === "SUBMITTED_AND_VERIFIED" ? "WORK_PASSED" : "DISPATCH_BLOCKED",
    actor: "tmux_dispatch.v0.6",
    from: input.fromRole ?? "BOC",
    to: agentId,
    agentId,
    role,
    targetApp: "CodexCLI",
    sessionName: input.sessionName,
    nonce,
    status,
    artifact: packetPath,
    evidence: evidenceDir,
    note: ok ? "tmux dispatch submitted to live Codex CLI session" : "tmux dispatch did not reach acceptance state",
    metadata: { dispatch_id: dispatchId, dispatch_ledger_path: ledgerPath },
  });

  const result: TmuxSendResult = {
    ok,
    status,
    dispatch_id: dispatchId,
    dispatch_ledger_path: ledgerPath,
    packet_path: packetPath,
    packet_sha256: sha(packetPath),
    nonce,
    session_name: input.sessionName,
    evidence_dir: evidenceDir,
    message_path: messagePath,
    capture_before_path: capBefore,
    capture_after_paste_path: capAfterPaste,
    capture_after_submit_path: capAfterSubmit,
    diagnostic_path: finalDiagnosticPath,
  };
  writeJson(path.join(evidenceDir, "tmux_dispatch_result.json"), result);
  return result;
}

export function captureTmuxDispatchSession(context: CommandContext, sessionName: string): { ok: boolean; status: string; session_name: string; capture_path: string; text: string } {
  const layout = ensureGovernanceLayout(context.workspaceRoot);
  const evidenceDir = ensureDir(path.join(layout.evidence, "tmux_captures", safe(sessionName)));
  const capturePath = path.join(evidenceDir, `capture_${safe(shortId("tmux", context.now))}.txt`);
  try {
    const text = runTmux(["capture-pane", "-p", "-S", "-2000", "-t", sessionName]);
    writeText(capturePath, text);
    return { ok: true, status: "CAPTURED", session_name: sessionName, capture_path: capturePath, text };
  } catch (error) {
    const text = error instanceof Error ? error.message : String(error);
    writeText(capturePath, text);
    return { ok: false, status: "BLOCKED_WITH_DIAGNOSTIC", session_name: sessionName, capture_path: capturePath, text };
  }
}

export function listTmuxDispatchSessions(context: CommandContext): { records: TmuxSessionRecord[]; live_tmux_sessions: string[] } {
  const layout = ensureGovernanceLayout(context.workspaceRoot);
  const index = readJson<TmuxSessionIndex>(layout.tmuxSessionIndexPath);
  const records = index.sessions.filter(fileExists).map((item) => readJson<TmuxSessionRecord>(item));
  let liveTmuxSessions: string[] = [];
  try {
    const out = runTmux(["list-sessions", "-F", "#{session_name}"]);
    liveTmuxSessions = out.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  } catch {
    liveTmuxSessions = [];
  }
  return { records, live_tmux_sessions: liveTmuxSessions };
}

export function tmuxDispatchStatus(context: CommandContext, sessionName: string): { ok: boolean; session_name: string; exists: boolean; capture_path: string | null; status: string } {
  ensureGovernanceLayout(context.workspaceRoot);
  const exists = sessionExists(sessionName);
  if (!exists) return { ok: false, session_name: sessionName, exists: false, capture_path: null, status: "SESSION_NOT_FOUND" };
  const captureResult = captureTmuxDispatchSession(context, sessionName);
  return { ok: captureResult.ok, session_name: sessionName, exists: true, capture_path: captureResult.capture_path, status: captureResult.status };
}
