import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";

export interface ContextLayout {
  root: string;
  aContract: string;
  bLedger: string;
  cPool: string;
  dTrace: string;
  assignments: string;
  results: string;
  testReports: string;
  appserverEvents: string;
  workerLogs: string;
  secretScans: string;
  runsIndexPath: string;
}

export interface GovernanceLayout {
  root: string;
  sessions: string;
  tmuxSessions: string;
  tmuxSessionIndexPath: string;
  dispatches: string;
  ledgers: string;
  evidence: string;
  quarantine: string;
  agents: string;
  agentSessions: string;
  agentMessages: string;
  agentMessageInbox: string;
  agentMessageOutbox: string;
  agentMessageDelivered: string;
  agentRetirements: string;
  assignments: string;
  assignmentPackages: string;
  classA: string;
  classB: string;
  classBEntries: string;
  classBQuarantine: string;
  classBIndexPath: string;
  classC: string;
  classD: string;
  contextCuts: string;
  contextDeliveryProofs: string;
  deliveredMessages: string;
  dloPackets: string;
  icCursors: string;
  icHandoffs: string;
  milestones: string;
  reviews: string;
  runtimeRuns: string;
  templates: string;
  validations: string;
  contextExports: string;
  stateTransitions: string;
  mutationGate: string;
  contextLoadPackets: string;
  workDispatchPackets: string;
  returnRoot: string;
  workerReturns: string;
  workerReturnEvents: string;
  workerReturnClassifications: string;
  coordinationThreads: string;
  coordinationThreadsIndexPath: string;
  dispatchLedger: string;
  dispatchLedgerIndexPath: string;
  agentReportLedger: string;
  agentReportLedgerIndexPath: string;
  reportReviews: string;
  archivedAdapters: string;
  codexBoundary: string;
  codexSessions: string;
  codexHistory: string;
  codexCaptures: string;
  projections: string;
  panelSnapshots: string;
  backendLoopLedgerJsonl: string;
  backendLoopLedgerMarkdown: string;
}

export interface CommandContext {
  projectRoot: string;
  workspaceRoot: string;
  now: Date;
}

export function createCommandContext(projectRoot = process.cwd(), workspaceRoot?: string): CommandContext {
  return {
    projectRoot: path.resolve(projectRoot),
    workspaceRoot: path.resolve(workspaceRoot ?? projectRoot),
    now: new Date(),
  };
}

export function ensureDir(targetPath: string): string {
  fs.mkdirSync(targetPath, { recursive: true });
  return targetPath;
}

export function fileExists(targetPath: string): boolean {
  return fs.existsSync(targetPath);
}

export function readText(targetPath: string): string {
  return fs.readFileSync(targetPath, "utf8");
}

export function writeText(targetPath: string, content: string): string {
  ensureDir(path.dirname(targetPath));
  fs.writeFileSync(targetPath, content, "utf8");
  return targetPath;
}

export function writeJson(targetPath: string, content: unknown): string {
  return writeText(targetPath, `${JSON.stringify(content, null, 2)}\n`);
}

export function readJson<T>(targetPath: string): T {
  return JSON.parse(readText(targetPath)) as T;
}

export function isoStamp(date: Date): string {
  return date.toISOString();
}

export function fileStamp(date: Date): string {
  return date.toISOString().replace(/[:.]/g, "-").replace("T", "_");
}

export function shortId(prefix: string, date: Date = new Date()): string {
  return `${prefix}_${fileStamp(date)}`;
}

export function ensureContextLayout(root: string): ContextLayout {
  const resolvedRoot = path.resolve(root);
  const contextRoot = ensureDir(path.join(resolvedRoot, "context"));
  const aContract = ensureDir(path.join(contextRoot, "A_contract"));
  const bLedger = ensureDir(path.join(contextRoot, "B_ledger"));
  const cPool = ensureDir(path.join(contextRoot, "C_pool"));
  const dTrace = ensureDir(path.join(contextRoot, "D_trace"));
  const assignments = ensureDir(path.join(bLedger, "assignments"));
  const results = ensureDir(path.join(bLedger, "results"));
  const testReports = ensureDir(path.join(bLedger, "test_reports"));
  const appserverEvents = ensureDir(path.join(dTrace, "appserver_events"));
  const workerLogs = ensureDir(path.join(dTrace, "worker_logs"));
  const secretScans = ensureDir(path.join(dTrace, "secret_scans"));
  const runsIndexPath = path.join(dTrace, "runs_index.json");
  if (!fileExists(runsIndexPath)) writeJson(runsIndexPath, []);
  return { root: contextRoot, aContract, bLedger, cPool, dTrace, assignments, results, testReports, appserverEvents, workerLogs, secretScans, runsIndexPath };
}

export function ensureGovernanceLayout(root: string): GovernanceLayout {
  const resolvedRoot = path.resolve(root);
  const strataRoot = ensureDir(path.join(resolvedRoot, ".strata"));
  const sessions = ensureDir(path.join(strataRoot, "sessions"));
  const tmuxSessions = ensureDir(path.join(sessions, "tmux"));
  const dispatches = ensureDir(path.join(strataRoot, "dispatches"));
  const returns = ensureDir(path.join(strataRoot, "returns"));
  const ledgers = ensureDir(path.join(strataRoot, "ledgers"));
  const evidence = ensureDir(path.join(strataRoot, "evidence"));
  const quarantine = ensureDir(path.join(strataRoot, "quarantine"));

  const agents = ensureDir(path.join(sessions, "agents"));
  const agentSessions = ensureDir(path.join(sessions, "agent_sessions"));
  const agentMessages = ensureDir(path.join(sessions, "messages"));
  const agentMessageInbox = ensureDir(path.join(agentMessages, "inbox"));
  const agentMessageOutbox = ensureDir(path.join(agentMessages, "outbox"));
  const agentMessageDelivered = ensureDir(path.join(agentMessages, "delivered"));
  const agentRetirements = ensureDir(path.join(sessions, "retirements"));

  const assignments = ensureDir(path.join(dispatches, "assignments"));
  const assignmentPackages = ensureDir(path.join(dispatches, "assignment_packages"));
  const contextLoadPackets = ensureDir(path.join(dispatches, "context_load_packets"));
  const workDispatchPackets = ensureDir(path.join(dispatches, "work_dispatch_packets"));

  const classA = ensureDir(path.join(strataRoot, "class_a"));
  const classB = ensureDir(path.join(ledgers, "class_b"));
  const classBEntries = ensureDir(path.join(classB, "entries"));
  const classBQuarantine = ensureDir(path.join(quarantine, "class_b"));
  const classBIndexPath = path.join(classB, "index.json");
  const classC = ensureDir(path.join(strataRoot, "class_c"));
  const classD = ensureDir(path.join(evidence, "class_d"));

  const contextCuts = ensureDir(path.join(dispatches, "context_cuts"));
  const contextDeliveryProofs = ensureDir(path.join(evidence, "context_delivery_proofs"));
  const deliveredMessages = ensureDir(path.join(dispatches, "delivered_messages"));
  const dloPackets = ensureDir(path.join(dispatches, "dlo_packets"));
  const icCursors = ensureDir(path.join(ledgers, "ic_cursors"));
  const icHandoffs = ensureDir(path.join(dispatches, "ic_handoffs"));
  const milestones = ensureDir(path.join(ledgers, "milestones"));
  const reviews = ensureDir(path.join(ledgers, "reviews"));
  const runtimeRuns = ensureDir(path.join(evidence, "runtime_runs"));
  const templates = ensureDir(path.join(dispatches, "templates"));
  const validations = ensureDir(path.join(ledgers, "validations"));
  const contextExports = ensureDir(path.join(evidence, "context_exports"));
  const stateTransitions = ensureDir(path.join(ledgers, "state_transitions"));
  const mutationGate = ensureDir(path.join(ledgers, "mutation_gate"));

  const returnRoot = returns;
  const workerReturns = ensureDir(path.join(ledgers, "worker_returns"));
  const workerReturnEvents = ensureDir(path.join(workerReturns, "events"));
  const workerReturnClassifications = ensureDir(path.join(workerReturns, "classifications"));
  const coordinationThreads = ensureDir(path.join(ledgers, "coordination_threads"));
  const coordinationThreadsIndexPath = path.join(coordinationThreads, "index.json");
  const dispatchLedger = ensureDir(path.join(ledgers, "dispatch_ledger"));
  const dispatchLedgerIndexPath = path.join(dispatchLedger, "index.json");
  const agentReportLedger = ensureDir(path.join(ledgers, "agent_report_ledger"));
  const agentReportLedgerIndexPath = path.join(agentReportLedger, "index.json");
  const reportReviews = ensureDir(path.join(ledgers, "report_reviews"));
  const archivedAdapters = ensureDir(path.join(evidence, "archived_runtime_paths"));
  const codexBoundary = ensureDir(path.join(archivedAdapters, "codex_boundary_diagnostic_only"));
  const codexSessions = ensureDir(path.join(codexBoundary, "sessions"));
  const codexHistory = ensureDir(path.join(codexBoundary, "history"));
  const codexCaptures = ensureDir(path.join(codexBoundary, "captures"));
  const projections = ensureDir(path.join(ledgers, "projections"));
  const panelSnapshots = ensureDir(path.join(evidence, "panel_snapshots"));
  const tmuxSessionIndexPath = path.join(tmuxSessions, "index.json");
  const backendLoopLedgerJsonl = path.join(ledgers, "backend_loop_ledger.jsonl");
  const backendLoopLedgerMarkdown = path.join(ledgers, "backend_loop_ledger.md");

  if (!fileExists(classBIndexPath)) {
    writeJson(classBIndexPath, { index_format: "class_b_index.v1", latest_b_index: 0, ordered_entries: [], active_entries: [], superseded_entries: [], obsolete_entries: [], outdated_entries: [] });
  }
  if (!fileExists(coordinationThreadsIndexPath)) writeJson(coordinationThreadsIndexPath, { contract_id: "coordination_threads.index.v1", threads: [], updated_at: null });
  if (!fileExists(dispatchLedgerIndexPath)) writeJson(dispatchLedgerIndexPath, { contract_id: "dispatch_ledger.index.v1", dispatches: [], updated_at: null });
  if (!fileExists(agentReportLedgerIndexPath)) writeJson(agentReportLedgerIndexPath, { contract_id: "agent_report_ledger.index.v1", reports: [], updated_at: null });
  if (!fileExists(tmuxSessionIndexPath)) writeJson(tmuxSessionIndexPath, { contract_id: "tmux_session.index.v1", sessions: [], updated_at: null });
  if (!fileExists(backendLoopLedgerJsonl)) writeText(backendLoopLedgerJsonl, "");
  if (!fileExists(backendLoopLedgerMarkdown)) writeText(backendLoopLedgerMarkdown, "# Backend Loop Ledger\n\n");

  return {
    root: strataRoot,
    sessions,
    tmuxSessions,
    tmuxSessionIndexPath,
    dispatches,
    ledgers,
    evidence,
    quarantine,
    agents,
    agentSessions,
    agentMessages,
    agentMessageInbox,
    agentMessageOutbox,
    agentMessageDelivered,
    agentRetirements,
    assignments,
    assignmentPackages,
    classA,
    classB,
    classBEntries,
    classBQuarantine,
    classBIndexPath,
    classC,
    classD,
    contextCuts,
    contextDeliveryProofs,
    deliveredMessages,
    dloPackets,
    icCursors,
    icHandoffs,
    milestones,
    reviews,
    runtimeRuns,
    templates,
    validations,
    contextExports,
    stateTransitions,
    mutationGate,
    contextLoadPackets,
    workDispatchPackets,
    returnRoot,
    workerReturns,
    workerReturnEvents,
    workerReturnClassifications,
    coordinationThreads,
    coordinationThreadsIndexPath,
    dispatchLedger,
    dispatchLedgerIndexPath,
    agentReportLedger,
    agentReportLedgerIndexPath,
    reportReviews,
    archivedAdapters,
    codexBoundary,
    codexSessions,
    codexHistory,
    codexCaptures,
    projections,
    panelSnapshots,
    backendLoopLedgerJsonl,
    backendLoopLedgerMarkdown,
  };
}

export function collectFiles(root: string): string[] {
  const resolved = path.resolve(root);
  const results: string[] = [];
  if (!fileExists(resolved)) return results;
  const stats = fs.statSync(resolved);
  if (stats.isFile()) return [resolved];
  for (const entry of fs.readdirSync(resolved, { withFileTypes: true })) {
    const fullPath = path.join(resolved, entry.name);
    if (entry.isDirectory()) results.push(...collectFiles(fullPath));
    else if (entry.isFile()) results.push(fullPath);
  }
  return results.sort();
}

export function hashFiles(paths: string[]): string {
  const hash = crypto.createHash("sha256");
  for (const filePath of paths) {
    hash.update(filePath);
    hash.update("\n");
    hash.update(fs.readFileSync(filePath));
    hash.update("\n");
  }
  return hash.digest("hex");
}

export function hashText(content: string): string {
  return crypto.createHash("sha256").update(content).digest("hex");
}

export function formatTable(rows: string[][]): string {
  if (rows.length === 0) return "";
  const widths = rows[0].map((_, col) => Math.max(...rows.map((row) => row[col].length)));
  return rows
    .map((row, rowIndex) => {
      const line = row.map((cell, col) => cell.padEnd(widths[col], " ")).join("  ");
      if (rowIndex === 0) {
        const divider = widths.map((width) => "-".repeat(width)).join("  ");
        return `${line}\n${divider}`;
      }
      return line;
    })
    .join("\n");
}
