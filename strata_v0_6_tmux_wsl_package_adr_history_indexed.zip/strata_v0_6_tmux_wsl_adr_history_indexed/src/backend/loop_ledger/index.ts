import fs from "node:fs";
import path from "node:path";
import { ensureGovernanceLayout, isoStamp, type CommandContext, writeJson } from "../common.js";

export type BackendLoopEventName =
  | "DUTY_REGISTERED"
  | "DUTY_VERIFIED"
  | "WORK_PACKET_CREATED"
  | "WORK_PASSED"
  | "DISPATCH_BLOCKED"
  | "RETURN_FILE_DETECTED"
  | "RETURN_FILE_NOT_DETECTED"
  | "RETURN_PACKET_CLASSIFIED"
  | "ROUTED_TO_IC"
  | "ROUTED_TO_REVIEWER"
  | "ROUTED_TO_CLASSD"
  | "REPORT_LEDGERED"
  | "REVIEW_ACCEPTED"
  | "REVIEW_REWORK_REQUIRED"
  | "CLASSB_IMPORTED"
  | "CLASSB_REJECTED_OR_BLOCKED";

export interface BackendLoopEventInput {
  assignmentId: string;
  event: BackendLoopEventName;
  actor: string;
  from?: string | null;
  to?: string | null;
  agentId?: string | null;
  role?: string | null;
  targetApp?: string | null;
  sessionName?: string | null;
  nonce?: string | null;
  status: string;
  artifact?: string | null;
  evidence?: string | null;
  note?: string | null;
  metadata?: Record<string, unknown>;
}

export interface BackendLoopEventRecord {
  ts: string;
  loop_id: string;
  assignment_id: string;
  event: BackendLoopEventName;
  actor: string;
  from: string | null;
  to: string | null;
  agent_id: string | null;
  role: string | null;
  target_app: string | null;
  session_name: string | null;
  nonce: string | null;
  status: string;
  artifact: string | null;
  evidence: string | null;
  note: string | null;
  metadata: Record<string, unknown>;
}

function nextLoopId(jsonlPath: string): string {
  if (!fs.existsSync(jsonlPath)) return "0001";
  const text = fs.readFileSync(jsonlPath, "utf8").trim();
  if (!text) return "0001";
  const count = text.split(/\r?\n/).filter(Boolean).length + 1;
  return String(count).padStart(4, "0");
}

function mdLine(record: BackendLoopEventRecord): string {
  const parts = [
    record.ts,
    `loop=${record.loop_id}`,
    `event=${record.event}`,
    `assignment=${record.assignment_id}`,
    `actor=${record.actor}`,
  ];
  if (record.from) parts.push(`from=${record.from}`);
  if (record.to) parts.push(`to=${record.to}`);
  if (record.agent_id) parts.push(`worker=${record.agent_id}`);
  if (record.role) parts.push(`role=${record.role}`);
  if (record.session_name) parts.push(`session=${record.session_name}`);
  if (record.nonce) parts.push(`nonce=${record.nonce}`);
  parts.push(`status=${record.status}`);
  if (record.artifact) parts.push(`artifact=${record.artifact}`);
  if (record.evidence) parts.push(`evidence=${record.evidence}`);
  if (record.note) parts.push(`note=${record.note.replace(/\s+/g, " ").slice(0, 180)}`);
  return parts.join(" ");
}

export function appendBackendLoopEvent(context: CommandContext, input: BackendLoopEventInput): BackendLoopEventRecord {
  const layout = ensureGovernanceLayout(context.workspaceRoot);
  const record: BackendLoopEventRecord = {
    ts: isoStamp(context.now),
    loop_id: nextLoopId(layout.backendLoopLedgerJsonl),
    assignment_id: input.assignmentId,
    event: input.event,
    actor: input.actor,
    from: input.from ?? null,
    to: input.to ?? null,
    agent_id: input.agentId ?? null,
    role: input.role ?? null,
    target_app: input.targetApp ?? null,
    session_name: input.sessionName ?? null,
    nonce: input.nonce ?? null,
    status: input.status,
    artifact: input.artifact ?? null,
    evidence: input.evidence ?? null,
    note: input.note ?? null,
    metadata: input.metadata ?? {},
  };
  fs.appendFileSync(layout.backendLoopLedgerJsonl, `${JSON.stringify(record)}\n`, "utf8");
  fs.appendFileSync(layout.backendLoopLedgerMarkdown, `${mdLine(record)}\n`, "utf8");
  writeJson(path.join(layout.ledgers, "backend_loop_latest_event.json"), record);
  return record;
}

export function readBackendLoopEvents(context: CommandContext): BackendLoopEventRecord[] {
  const layout = ensureGovernanceLayout(context.workspaceRoot);
  if (!fs.existsSync(layout.backendLoopLedgerJsonl)) return [];
  return fs
    .readFileSync(layout.backendLoopLedgerJsonl, "utf8")
    .split(/\r?\n/)
    .filter(Boolean)
    .map((line) => JSON.parse(line) as BackendLoopEventRecord);
}
