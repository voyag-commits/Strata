#!/usr/bin/env node
import path from "node:path";
import { buildBridgeGate, renderBridgeGatePowerShell } from "../backend/bridge_gate/index.js";
import { addContextRecord, bootstrapContext, contextSummary, listContextRecords, type ContextClass } from "../backend/context/index.js";
import { createCommandContext, formatTable, readText } from "../backend/common.js";
import { createContextLoadPacket, createWorkDispatchPacket, writeWorkerReturnPacketTemplate, type WorkDispatchKind } from "../backend/packets/index.js";
import { classifyWorkerReturnPacket, scanWatchedReturnFolders, watchReturnFolders, type ClassifyWorkerReturnResult, type WorkerReturnKind } from "../backend/worker_returns/index.js";
import { reviewAgentReport, listAgentReports, type AgentReportValidatedStatus } from "../backend/agent_report_ledger/index.js";
import { gateMutation, latestGateDigest, listGateRecords } from "../backend/mutation_gate/index.js";
import { initWorkspace } from "../backend/workspace/index.js";
import { runSecretScan } from "../backend/secret_scan/index.js";
import { appendBackendLoopEvent, readBackendLoopEvents } from "../backend/loop_ledger/index.js";
import { captureTmuxDispatchSession, launchTmuxDispatch, listTmuxDispatchSessions, sendTmuxDispatch, tmuxDispatchStatus } from "../backend/tmux_dispatch/index.js";
import type { PacketType } from "../backend/dispatch_ledger/index.js";

interface ParsedArgs {
  positionals: string[];
  flags: Record<string, string | boolean>;
}

function parseArgs(argv: string[]): ParsedArgs {
  const positionals: string[] = [];
  const flags: Record<string, string | boolean> = {};
  for (let index = 0; index < argv.length; index += 1) {
    const token = argv[index];
    if (!token.startsWith("--")) {
      positionals.push(token);
      continue;
    }
    const key = token.slice(2);
    const next = argv[index + 1];
    if (!next || next.startsWith("--")) {
      flags[key] = true;
      continue;
    }
    flags[key] = next;
    index += 1;
  }
  return { positionals, flags };
}

function optionalString(value: string | boolean | undefined): string | undefined {
  return typeof value === "string" ? value : undefined;
}

function requiredString(flags: Record<string, string | boolean>, key: string): string {
  const value = flags[key];
  if (typeof value !== "string" || !value.trim()) throw new Error(`Missing --${key}.`);
  return value;
}

function splitList(value: string | boolean | undefined): string[] {
  if (!value || typeof value !== "string") return [];
  return value.split(";").map((item) => item.trim()).filter(Boolean);
}

function parseContextClass(value: string | boolean | undefined): ContextClass {
  if (value === "A" || value === "B" || value === "C" || value === "D") return value;
  throw new Error("--class must be one of A, B, C, or D.");
}

function parsePacketType(value: string | boolean | undefined): PacketType {
  if (value === "context_load_packet.v1" || value === "work_dispatch_packet.v1") return value;
  throw new Error("--packet-type must be context_load_packet.v1 or work_dispatch_packet.v1.");
}

function boolFlag(value: string | boolean | undefined, defaultValue: boolean): boolean {
  if (value === undefined) return defaultValue;
  if (value === true) return true;
  if (value === false) return false;
  return !["0", "false", "no", "off"].includes(value.toLowerCase());
}

function emitReturnLoopEvents(context: ReturnType<typeof createCommandContext>, result: ClassifyWorkerReturnResult): void {
  const packet = result.packet;
  if (!packet) {
    appendBackendLoopEvent(context, {
      assignmentId: "UNKNOWN_ASSIGNMENT",
      event: "RETURN_PACKET_CLASSIFIED",
      actor: "worker_return_classifier",
      status: "invalid_return_packet",
      artifact: result.classification.packet_path,
      evidence: result.classification.class_d_diagnostic_path ?? result.event_record_path,
      note: result.classification.errors.join("; "),
    });
    appendBackendLoopEvent(context, {
      assignmentId: "UNKNOWN_ASSIGNMENT",
      event: "ROUTED_TO_CLASSD",
      actor: "worker_return_classifier",
      status: "invalid_return_packet",
      artifact: result.classification.packet_path,
      evidence: result.classification.class_d_diagnostic_path ?? result.event_record_path,
    });
    return;
  }

  appendBackendLoopEvent(context, {
    assignmentId: packet.assignment_id,
    event: "RETURN_FILE_DETECTED",
    actor: "return_scan",
    agentId: packet.agent_id,
    role: packet.role,
    nonce: packet.nonce,
    status: "detected",
    artifact: result.classification.packet_path,
    evidence: packet.evidence_path ?? result.event_record_path,
  });

  appendBackendLoopEvent(context, {
    assignmentId: packet.assignment_id,
    event: "RETURN_PACKET_CLASSIFIED",
    actor: "worker_return_classifier",
    agentId: packet.agent_id,
    role: packet.role,
    nonce: packet.nonce,
    status: packet.return_kind,
    artifact: result.classification.packet_path,
    evidence: packet.evidence_path ?? result.classification_record_path,
    metadata: { routing_decision: result.classification.routing_decision },
  });

  if (packet.return_kind === "REPORT_READY") {
    appendBackendLoopEvent(context, {
      assignmentId: packet.assignment_id,
      event: "REPORT_LEDGERED",
      actor: "agent_report_ledger",
      from: "worker_return_classifier",
      to: "reviewer",
      agentId: packet.agent_id,
      role: packet.role,
      nonce: packet.nonce,
      status: "pending_review",
      artifact: result.classification.agent_report_ledger_path ?? packet.report_path,
      evidence: packet.evidence_path ?? result.classification_record_path,
    });
    appendBackendLoopEvent(context, {
      assignmentId: packet.assignment_id,
      event: "ROUTED_TO_REVIEWER",
      actor: "worker_return_classifier",
      from: packet.agent_id,
      to: "reviewer",
      agentId: packet.agent_id,
      role: packet.role,
      nonce: packet.nonce,
      status: "pending_review",
      artifact: packet.report_path,
      evidence: packet.evidence_path ?? result.classification_record_path,
    });
    return;
  }

  if (result.classification.class_d_diagnostic_path) {
    appendBackendLoopEvent(context, {
      assignmentId: packet.assignment_id,
      event: "ROUTED_TO_CLASSD",
      actor: "worker_return_classifier",
      agentId: packet.agent_id,
      role: packet.role,
      nonce: packet.nonce,
      status: packet.return_kind,
      artifact: result.classification.class_d_diagnostic_path,
      evidence: packet.evidence_path ?? result.classification_record_path,
    });
  }

  if (result.classification.coordination_thread_path) {
    appendBackendLoopEvent(context, {
      assignmentId: packet.assignment_id,
      event: "ROUTED_TO_IC",
      actor: "worker_return_classifier",
      from: packet.agent_id,
      to: "IC",
      agentId: packet.agent_id,
      role: packet.role,
      nonce: packet.nonce,
      status: packet.return_kind,
      artifact: result.classification.coordination_thread_path,
      evidence: packet.evidence_path ?? result.classification_record_path,
    });
  }
}

function helpText(): string {
  return [
    "Strata v0.6 CLI - WSL/tmux + Codex CLI + DeepSeek bridge",
    "",
    "Usage:",
    "  strata init [--workspace <path>]",
    "  strata bridge gate [--api-key-file <path>] [--proxy <url>] [--proxy-auth-key <value|auto>] [--format json|powershell]",
    "  strata context bootstrap [--workspace <path>]",
    "  strata context add --class A|B|C|D --title <text> (--body <text>|--source-file <path>) [--director-approved]",
    "  strata context list [--class A|B|C|D] [--workspace <path>]",
    "  strata context summary [--workspace <path>]",
    "  strata packet context-load --assignment-id <id> --agent-id <id> --role <role> [--session-name <tmux-name>]",
    "  strata packet work-dispatch --assignment-id <id> --agent-id <id> --role <role> --kind <kind> --action <text> [--body <text>]",
    "  strata packet return-template --assignment-id <id> --agent-id <id> --role <role> --kind <kind> --nonce <nonce>",
    "  strata sessions create --assignment-id <id> --agent-id <id> --role <role> [--session-name <name>] [--cwd <path>] [--command <codex-command>]",
    "  strata sessions list [--workspace <path>]",
    "  strata sessions status --session-name <name> [--workspace <path>]",
    "  strata dispatch create --assignment-id <id> --agent-id <id> --role <role> --kind <kind> --action <text> [--body <text>]",
    "  strata dispatch send --session-name <name> --packet <path> [--message-file <path>] [--no-submit]",
    "  strata tmux-dispatch launch --assignment-id <id> --agent-id <id> --role <role> [--session-name <name>] [--cwd <path>] [--command <codex-command>]",
    "  strata tmux-dispatch send --session-name <name> --packet <path> [--message-file <path>] [--no-submit]",
    "  strata tmux-dispatch capture --session-name <name> [--workspace <path>]",
    "  strata returns classify --packet <path> [--workspace <path>]",
    "  strata returns scan [--assignment-id <id>] [--agent-id <id>] [--workspace <path>]",
    "  strata returns watch [--workspace <path>]",
    "  strata report list [--workspace <path>]",
    "  strata report review --report-id <id> --reviewer-id <id> --decision accepted|rework_required|quarantined|invalid_return_packet [--notes <text>]",
    "  strata loop-ledger show [--workspace <path>]",
    "  strata gate evaluate --actor <role> --action <name> --resource-type <type> --reason <text> [--director-approved]",
    "  strata gate list [--workspace <path>] [--limit <n>]",
    "  strata gate digest [--workspace <path>]",
    "  strata secret-scan [--workspace <path>] [--secret-file <path>]",
    "",
    "Acceptance is live observation in VS Code/tmux plus backend JSONL logs. This CLI intentionally does not provide mock tmux acceptance scripts.",
  ].join("\n");
}

async function main(): Promise<void> {
  const { positionals, flags } = parseArgs(process.argv.slice(2));
  const command = positionals[0];
  const subcommand = positionals[1];
  const workspace = path.resolve(optionalString(flags.workspace) ?? process.cwd());
  const context = createCommandContext(process.cwd(), workspace);

  if (!command || command === "help" || flags.help) {
    console.log(helpText());
    return;
  }

  if (command === "init") {
    console.log(JSON.stringify(initWorkspace(context), null, 2));
    return;
  }

  if (command === "bridge" && subcommand === "gate") {
    const format = flags.format === "powershell" ? "powershell" : "json";
    const result = buildBridgeGate({
      apiKeyFile: optionalString(flags["api-key-file"]),
      apiKeyEnv: optionalString(flags["api-key-env"]),
      proxy: optionalString(flags.proxy),
      noProxy: optionalString(flags["no-proxy"]),
      proxyAuthKey: optionalString(flags["proxy-auth-key"]),
      enableThinking: flags["disable-thinking"] ? false : flags["enable-thinking"] ? true : undefined,
      reasoningEffort: optionalString(flags["reasoning-effort"]),
      maxOutputTokens: typeof flags["max-output-tokens"] === "string" ? Number(flags["max-output-tokens"]) : undefined,
      modelContextWindow: typeof flags["model-context-window"] === "string" ? Number(flags["model-context-window"]) : undefined,
      port: typeof flags.port === "string" ? Number(flags.port) : undefined,
      format,
    });
    if (format === "powershell") console.log(renderBridgeGatePowerShell(result, { apiKeyFile: optionalString(flags["api-key-file"]), proxyAuthKey: optionalString(flags["proxy-auth-key"]) }));
    else console.log(JSON.stringify({ ...result, env: result.redactedEnv }, null, 2));
    if (!result.ok) process.exitCode = 1;
    return;
  }

  if (command === "context" && subcommand === "bootstrap") {
    console.log(JSON.stringify(bootstrapContext(context), null, 2));
    return;
  }
  if (command === "context" && subcommand === "add") {
    const bodyPath = optionalString(flags["source-file"]);
    const result = addContextRecord(context, {
      klass: parseContextClass(flags.class),
      title: requiredString(flags, "title"),
      kind: optionalString(flags.kind),
      body: optionalString(flags.body),
      sourcePath: bodyPath ? path.resolve(bodyPath) : undefined,
      actor: optionalString(flags.actor),
      tags: splitList(flags.tags),
      approvedByDirector: Boolean(flags["director-approved"]),
    });
    console.log(JSON.stringify(result, null, 2));
    return;
  }
  if (command === "context" && subcommand === "list") {
    const klass = flags.class ? parseContextClass(flags.class) : undefined;
    console.log(JSON.stringify(listContextRecords(context, klass), null, 2));
    return;
  }
  if (command === "context" && subcommand === "summary") {
    console.log(JSON.stringify(contextSummary(context), null, 2));
    return;
  }

  if (command === "packet" && subcommand === "context-load") {
    const result = createContextLoadPacket(context, {
      assignmentId: requiredString(flags, "assignment-id"),
      agentId: requiredString(flags, "agent-id"),
      role: requiredString(flags, "role"),
      runtimeName: optionalString(flags["runtime-name"]) ?? "CodexCLI/tmux",
      sessionName: optionalString(flags["session-name"]),
      roleContract: optionalString(flags["role-contract"]),
      assignmentFrame: optionalString(flags["assignment-frame"]),
    });
    appendBackendLoopEvent(context, { assignmentId: result.assignment_id, event: "WORK_PACKET_CREATED", actor: "BOC", to: result.agent_id, agentId: result.agent_id, role: result.role, targetApp: "CodexCLI", sessionName: optionalString(flags["session-name"]), nonce: result.nonce, status: "context_load_packet_created", artifact: result.packet_path, evidence: result.record_path });
    console.log(JSON.stringify(result, null, 2));
    return;
  }
  if ((command === "packet" && subcommand === "work-dispatch") || (command === "dispatch" && subcommand === "create")) {
    const result = createWorkDispatchPacket(context, {
      assignmentId: requiredString(flags, "assignment-id"),
      agentId: requiredString(flags, "agent-id"),
      role: requiredString(flags, "role"),
      dispatchKind: requiredString(flags, "kind") as WorkDispatchKind,
      action: requiredString(flags, "action"),
      body: optionalString(flags.body),
      referencedFiles: splitList(flags.files),
      fromRole: optionalString(flags["from-role"]),
    });
    appendBackendLoopEvent(context, { assignmentId: result.assignment_id, event: "WORK_PACKET_CREATED", actor: optionalString(flags["from-role"]) ?? "IC", to: result.agent_id, agentId: result.agent_id, role: result.role, targetApp: "CodexCLI", nonce: result.nonce, status: "work_dispatch_packet_created", artifact: result.packet_path, evidence: result.record_path });
    console.log(JSON.stringify(result, null, 2));
    return;
  }
  if (command === "packet" && subcommand === "return-template") {
    const result = writeWorkerReturnPacketTemplate(context, {
      assignmentId: requiredString(flags, "assignment-id"),
      agentId: requiredString(flags, "agent-id"),
      role: requiredString(flags, "role"),
      returnKind: requiredString(flags, "kind") as WorkerReturnKind,
      nonce: requiredString(flags, "nonce"),
      reportPath: optionalString(flags["report-path"]),
      questionPath: optionalString(flags["question-path"]),
      messagePath: optionalString(flags["message-path"]),
      diagnosticPath: optionalString(flags["diagnostic-path"]),
      evidencePath: optionalString(flags["evidence-path"]),
    });
    console.log(JSON.stringify(result, null, 2));
    return;
  }

  if ((command === "tmux-dispatch" && subcommand === "launch") || (command === "sessions" && subcommand === "create")) {
    const result = launchTmuxDispatch(context, {
      assignmentId: requiredString(flags, "assignment-id"),
      agentId: requiredString(flags, "agent-id"),
      role: requiredString(flags, "role"),
      sessionName: optionalString(flags["session-name"]),
      cwd: optionalString(flags.cwd),
      command: optionalString(flags.command),
      actor: optionalString(flags.actor) ?? "BOC",
    });
    console.log(JSON.stringify(result, null, 2));
    if (!result.ok) process.exitCode = 1;
    return;
  }

  if ((command === "tmux-dispatch" && subcommand === "send") || (command === "dispatch" && subcommand === "send")) {
    const result = sendTmuxDispatch(context, {
      sessionName: requiredString(flags, "session-name"),
      packetPath: requiredString(flags, "packet"),
      packetType: flags["packet-type"] ? parsePacketType(flags["packet-type"]) : undefined,
      assignmentId: optionalString(flags["assignment-id"]),
      agentId: optionalString(flags["agent-id"]),
      role: optionalString(flags.role),
      nonce: optionalString(flags.nonce),
      message: optionalString(flags.message),
      messageFile: optionalString(flags["message-file"]),
      fromRole: optionalString(flags["from-role"]),
      submit: !boolFlag(flags["no-submit"], false),
      actor: optionalString(flags.actor) ?? "BOC",
    });
    console.log(JSON.stringify(result, null, 2));
    if (!result.ok) process.exitCode = 1;
    return;
  }

  if ((command === "tmux-dispatch" && subcommand === "list") || (command === "sessions" && subcommand === "list")) {
    console.log(JSON.stringify(listTmuxDispatchSessions(context), null, 2));
    return;
  }
  if ((command === "tmux-dispatch" && subcommand === "status") || (command === "sessions" && subcommand === "status")) {
    console.log(JSON.stringify(tmuxDispatchStatus(context, requiredString(flags, "session-name")), null, 2));
    return;
  }
  if (command === "tmux-dispatch" && subcommand === "capture") {
    console.log(JSON.stringify(captureTmuxDispatchSession(context, requiredString(flags, "session-name")), null, 2));
    return;
  }

  if (command === "returns" && subcommand === "classify") {
    const result = classifyWorkerReturnPacket(context, requiredString(flags, "packet"));
    emitReturnLoopEvents(context, result);
    console.log(JSON.stringify(result, null, 2));
    return;
  }
  if (command === "returns" && subcommand === "scan") {
    const results = scanWatchedReturnFolders(context, { assignmentId: optionalString(flags["assignment-id"]), agentId: optionalString(flags["agent-id"]) });
    for (const result of results) emitReturnLoopEvents(context, result);
    console.log(JSON.stringify(results, null, 2));
    if (results.length === 0 && flags["assignment-id"]) {
      appendBackendLoopEvent(context, { assignmentId: String(flags["assignment-id"]), event: "RETURN_FILE_NOT_DETECTED", actor: "return_scan", agentId: optionalString(flags["agent-id"]), status: "absent", artifact: null, evidence: null, note: "No Worker Return Packet JSON files found for requested path." });
    }
    return;
  }
  if (command === "returns" && subcommand === "watch") {
    console.error("Watching .strata/returns. Stop with Ctrl+C.");
    watchReturnFolders(context, (result) => {
      emitReturnLoopEvents(context, result);
      console.log(JSON.stringify(result, null, 2));
    });
    await new Promise(() => undefined);
    return;
  }

  if (command === "report" && subcommand === "list") {
    console.log(JSON.stringify(listAgentReports(context), null, 2));
    return;
  }
  if (command === "report" && subcommand === "review") {
    const result = reviewAgentReport(context, {
      reportId: requiredString(flags, "report-id"),
      reviewerId: requiredString(flags, "reviewer-id"),
      decision: requiredString(flags, "decision") as AgentReportValidatedStatus,
      notes: optionalString(flags.notes),
    });
    appendBackendLoopEvent(context, {
      assignmentId: result.review.assignment_id,
      event: result.review.decision === "accepted" ? "REVIEW_ACCEPTED" : "REVIEW_REWORK_REQUIRED",
      actor: result.review.reviewer_id,
      to: result.entry.agent_id,
      agentId: result.entry.agent_id,
      role: result.entry.role,
      status: result.review.decision,
      artifact: result.review.class_b_entry_path ?? result.entry.report_path,
      evidence: result.review_path,
      metadata: { report_id: result.review.report_id, validation_record_path: result.review.validation_record_path },
    });
    if (result.review.class_b_entry_path) {
      appendBackendLoopEvent(context, { assignmentId: result.review.assignment_id, event: "CLASSB_IMPORTED", actor: result.review.reviewer_id, agentId: result.entry.agent_id, role: result.entry.role, status: "accepted", artifact: result.review.class_b_entry_path, evidence: result.review.validation_record_path ?? result.review_path });
    }
    console.log(JSON.stringify(result, null, 2));
    return;
  }

  if (command === "loop-ledger" && subcommand === "show") {
    const events = readBackendLoopEvents(context);
    if (flags.format === "table") {
      const rows = [["loop", "event", "assignment", "actor", "worker", "status", "artifact"]];
      for (const event of events) rows.push([event.loop_id, event.event, event.assignment_id, event.actor, event.agent_id ?? "", event.status, event.artifact ?? ""]);
      console.log(formatTable(rows));
    } else {
      console.log(JSON.stringify(events, null, 2));
    }
    return;
  }

  if (command === "gate" && subcommand === "evaluate") {
    const result = gateMutation(context, {
      actor: requiredString(flags, "actor"),
      action: requiredString(flags, "action"),
      resourceType: requiredString(flags, "resource-type"),
      resourceId: optionalString(flags["resource-id"]),
      reason: requiredString(flags, "reason"),
      evidencePath: optionalString(flags["evidence-path"]),
      approvedByDirector: Boolean(flags["director-approved"]),
      requiresDirector: Boolean(flags["requires-director"]),
    });
    console.log(JSON.stringify(result, null, 2));
    if (result.decision !== "allowed") process.exitCode = 1;
    return;
  }
  if (command === "gate" && subcommand === "list") {
    console.log(JSON.stringify(listGateRecords(context, typeof flags.limit === "string" ? Number(flags.limit) : 50), null, 2));
    return;
  }
  if (command === "gate" && subcommand === "digest") {
    console.log(JSON.stringify(latestGateDigest(context), null, 2));
    return;
  }

  if (command === "secret-scan") {
    const result = runSecretScan(context, { secretFile: optionalString(flags["secret-file"]) });
    console.log(JSON.stringify(result, null, 2));
    if (result.status === "FAIL") process.exitCode = 1;
    return;
  }

  console.log(helpText());
}

main().catch((error) => {
  console.error(error instanceof Error ? error.message : String(error));
  process.exit(1);
});
