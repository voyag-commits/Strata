import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import test from "node:test";
import { buildBridgeGate, renderBridgeGatePowerShell } from "../src/backend/bridge_gate/index.js";

test("bridge gate accepts API key file, proxy, and thinking budget settings", () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "bridge-gate-test-"));
  const keyPath = path.join(dir, "deepseek.key");
  fs.writeFileSync(keyPath, "test-secret-key", "utf8");

  const result = buildBridgeGate({
    apiKeyFile: keyPath,
    proxy: "http://127.0.0.1:17891",
    proxyAuthKey: "auto",
    enableThinking: true,
    reasoningEffort: "max",
    maxOutputTokens: 65536,
    modelContextWindow: 1000000,
  }, {});

  assert.equal(result.ok, true);
  assert.equal(result.apiKeySource, "file");
  assert.equal(result.proxyConfigured, true);
  assert.equal(result.env.HTTPS_PROXY, "http://127.0.0.1:17891");
  assert.equal(result.env.DEEPSEEK_ENABLE_THINKING, "1");
  assert.equal(result.env.DEEPSEEK_REASONING_EFFORT, "max");
  assert.equal(result.env.DEEPSEEK_MAX_OUTPUT_TOKENS, "65536");
  assert.equal(result.redactedEnv.DEEPSEEK_API_KEY, "<redacted>");
  assert.equal(result.redactedEnv.PROXY_AUTH_KEY, "<redacted>");
});

test("bridge gate fails when API key source is absent", () => {
  const result = buildBridgeGate({}, {});
  assert.equal(result.ok, false);
  assert.match(result.errors.join("\n"), /DeepSeek API key missing/);
});

test("bridge gate PowerShell output references key file without embedding secret", () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "bridge-gate-test-"));
  const keyPath = path.join(dir, "deepseek.key");
  fs.writeFileSync(keyPath, "test-secret-key", "utf8");
  const result = buildBridgeGate({ apiKeyFile: keyPath, proxyAuthKey: "auto" }, {});
  const rendered = renderBridgeGatePowerShell(result, { apiKeyFile: keyPath, proxyAuthKey: "auto" });
  assert.match(rendered, /Get-Content -Raw/);
  assert.doesNotMatch(rendered, /test-secret-key/);
  assert.match(rendered, /PROXY_AUTH_KEY/);
});
