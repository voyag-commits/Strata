import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import test from "node:test";
import { createCommandContext, fileExists, readJson } from "../src/backend/common.js";
import { initWorkspace } from "../src/backend/workspace/index.js";
import { createWorkDispatchPacket, writeWorkerReturnPacketTemplate } from "../src/backend/packets/index.js";
import { classifyWorkerReturnPacket } from "../src/backend/worker_returns/index.js";

function makeWorkspace(): string {
  return fs.mkdtempSync(path.join(os.tmpdir(), "strata-v06-test-"));
}

test("workspace init creates project-local .strata runtime directories", () => {
  const workspace = makeWorkspace();
  const context = createCommandContext(workspace, workspace);
  const result = initWorkspace(context);
  assert.equal(result.governance.root, path.join(workspace, ".strata"));
  assert.ok(fileExists(path.join(workspace, ".strata", "sessions")));
  assert.ok(fileExists(path.join(workspace, ".strata", "dispatches")));
  assert.ok(fileExists(path.join(workspace, ".strata", "returns")));
  assert.ok(fileExists(path.join(workspace, ".strata", "ledgers")));
  assert.ok(fileExists(path.join(workspace, ".strata", "evidence")));
  assert.ok(fileExists(path.join(workspace, ".strata", "quarantine")));
});

test("work packet and Worker Return Packet use file-first return folders", () => {
  const workspace = makeWorkspace();
  const context = createCommandContext(workspace, workspace);
  initWorkspace(context);
  const packet = createWorkDispatchPacket(context, {
    assignmentId: "A0601",
    agentId: "coder_01",
    role: "coder",
    dispatchKind: "TASK_ASSIGNMENT",
    action: "Create the tiny smoke report file.",
  });
  assert.ok(packet.packet_path.includes(path.join(".strata", "dispatches", "work_dispatch_packets")));
  assert.ok(packet.return_folder.includes(path.join(".strata", "returns", "A0601", "coder_01")));
  assert.match(packet.short_dispatch_message, /Worker Return Packet/);

  const reportPath = path.join(workspace, "reports", "A0601", "tiny.md");
  fs.mkdirSync(path.dirname(reportPath), { recursive: true });
  fs.writeFileSync(reportPath, "---\ntemplate_id: worker_final_report\ntemplate_version: 1.1\nassignment_id: A0601\nrun_id: run_01\nworker_role: coder\nprogress_comment: smoke\n---\n\nbody\n", "utf8");
  const ret = writeWorkerReturnPacketTemplate(context, {
    assignmentId: "A0601",
    agentId: "coder_01",
    role: "coder",
    returnKind: "REPORT_READY",
    nonce: packet.nonce,
    reportPath,
  });
  const classified = classifyWorkerReturnPacket(context, ret.packet_path);
  assert.equal(classified.packet?.return_kind, "REPORT_READY");
  assert.equal(classified.classification.routing_decision, "REPORT_READY_LEDGERED_PENDING_REVIEW");
  assert.ok(classified.classification.agent_report_ledger_path);
  assert.equal(readJson<any>(classified.classification.agent_report_ledger_path!).validated_status, "pending_review");
});
