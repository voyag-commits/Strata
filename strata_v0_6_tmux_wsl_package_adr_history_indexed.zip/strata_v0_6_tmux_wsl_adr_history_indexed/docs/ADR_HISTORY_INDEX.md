# ADR History Index

This index preserves carefully distilled ADR states from different points in the Harness/Strata architecture timeline.

The active implementation package remains **Strata v0.6 WSL/tmux Live Implementation Package**. The historical ADRs are retained as decision lineage, not as parallel active implementation directions.

## Active decision pointer

```text
Active runtime: WSL/Linux + tmux
Active sender: tmux_dispatch launcher/sender
Worker runtime: Codex CLI inside named tmux sessions
Model route: portable Codex CLI + DeepSeek bridge copied into WSL
Evidence root: .strata/
Acceptance surface: live VS Code/tmux observation plus backend JSONL ledgers
```

Where historical ADRs conflict with the active v0.6 tmux runtime migration, v0.6 controls implementation.

## Indexed ADR lineage

| Order | Document set | Status in this package | Location | Meaning |
|---:|---|---|---|---|
| 1 | v0.5 Adapter Reinstatement ADR Bundle | Retained governance baseline | `reference/adr_history/2026-06-05_v0_5_adapter_reinstatement_bundle/` | Preserves core governance, role authority, ClassB validated operational memory, report contracts, backend scope, and live-proof lineage. |
| 2 | ADR-HS-2026-06-0601 GUI Worker Dispatch, Active Duty Registry, and File-Based Worker Return Protocol | Historical approved ADR; superseded for active runtime by v0.6 | `reference/adr_history/2026-06-06_ADR-HS-2026-06-0601_gui_worker_dispatch/` | Preserves the GUI-worker/Reasonix/UIA decision moment, Active Agent Duty Registry language, file-based Worker Return Packet protocol, IC/BOC split, and ClassB admission discipline. |
| 3 | ADR0601 v0.6 tmux/WSL runtime migration addendum and live tmux milestone revision | Active runtime override | `reference/adr_history/2026-06-08_v0_6_tmux_wsl_runtime_migration/` and `docs/` | Migrates active runtime to WSL/tmux + Codex CLI + portable DeepSeek bridge while preserving major ADR0601 milestone structure and governance invariants. |

## Version relationship

```text
v0.5 = governance and architecture baseline retained by inheritance
ADR-HS-2026-06-0601 = GUI-worker historical decision state; retained as lineage
v0.6 = active runtime migration to WSL/tmux Codex CLI + portable DeepSeek bridge
```

## What is active vs historical

Active in v0.6:

```text
WSL/Linux runtime
VS Code Remote-WSL supervision
tmux sessions
Codex CLI workers
portable DeepSeek bridge copied into WSL
tmux_dispatch launcher/sender
file-first Worker Return Packets
backend JSONL ledgers
review-before-ClassB admission
```

Historical/reference only in v0.6:

```text
Windows ConPTY dispatch
Windows GUI/UIA injection
Reasonix GUI-worker routing
Desktop UI Injection Adapter implementation
Terminal Session Adapter claims from earlier branches
mock/preflight acceptance scripts
```

## Naming rule

Historical ADR files are kept under `reference/adr_history/` with date-prefixed folders. Original document names are preserved where possible inside those folders. This avoids treating prior ADRs as active code paths while still keeping their decision context available to coders and reviewers.

## Coder instruction

When implementing v0.6, coders should use this precedence order:

```text
1. README.md and M1_GOAL.md for active package intent
2. docs/ADR0601_v0_6_ADDENDUM_TO_v0_5.md for runtime override
3. docs/ADR0601_IMMUTABLE_LIVE_TMUX_MILESTONES_v0_6.md for milestone acceptance
4. CONTRACTS.md and CODER_TASKS.md for implementation contracts
5. reference/adr_history/ for historical rationale only
```

Do not implement GUI/UIA or ConPTY as active v0.6 runtime work unless the Human Director explicitly opens a new ADR.
