# ADR0601 Milestone File Compatibility Alias

The original file name `ADR0601_IMMUTABLE_LIVE_WINDOWS_UIA_MILESTONES.md` is retained only as a migration anchor.

For v0.6 active implementation, use:

```text
docs/ADR0601_IMMUTABLE_LIVE_TMUX_MILESTONES_v0_6.md
```

The Windows UIA implementation path is excluded from active v0.6 code. The milestone sequence is surgically preserved and retargeted to WSL/tmux Codex CLI dispatch.
