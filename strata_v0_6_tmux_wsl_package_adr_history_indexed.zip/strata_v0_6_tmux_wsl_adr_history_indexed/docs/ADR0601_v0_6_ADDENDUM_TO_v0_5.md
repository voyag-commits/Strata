# ADR0601 v0.6 Addendum to v0.5 Adapter Reinstatement Bundle

**Status:** Active v0.6 addendum  
**Supersedes for active implementation:** v0.5 runtime adapter direction where it conflicts with WSL/tmux Codex CLI dispatch  
**Does not supersede:** core governance, role authority, ClassB validated operational memory, Worker Return Packet discipline, review-before-ClassB admission

## Decision

The active v0.6 runtime path is:

```text
WSL/tmux -> Codex CLI -> portable DeepSeek bridge -> DeepSeek API
```

The tmux runtime path replaces Windows ConPTY and GUI/UIA injection for the v0.6 implementation package.

## Confirmed basis

The Codex CLI + DeepSeek API bridge path is confirmed stable and high performance in the Windows-native setup. To avoid cross-boundary complexity, the portable module will be copied into WSL rather than leaving the bridge on Windows.

## Runtime ownership

Strata owns:

- tmux session records
- packet creation
- tmux dispatch mechanics
- backend JSONL ledgers
- Worker Return Packet classification
- report review and ClassB admission

The portable Codex CLI + DeepSeek bridge module may be copied into WSL and operated beside Strata. Strata does not need to deeply own that module in this package.

## Exclusions

The following are excluded from v0.6 active implementation:

- Windows ConPTY dispatch.
- Windows GUI/UIA injection.
- Desktop GUI app control.
- Mock/preflight tmux acceptance scripts.

GUI/UIA remains a future candidate only. The other major forward candidate is a deeper VS Code approach.

## Milestone preservation

The ADR0601 milestone sequence remains:

```text
M1_BOC_DISPATCH_TO_SELECTED_APP_SESSION
M2_WORKER_TASK_AND_FILE_RETURN
M3_BACKEND_CLASSIFICATION_AND_ROUTING
```

The meaning is surgically updated from selected GUI session to selected tmux/Codex CLI session. The evidence rule remains unchanged: milestone completion requires backend state, artifact paths, status, and evidence paths.
