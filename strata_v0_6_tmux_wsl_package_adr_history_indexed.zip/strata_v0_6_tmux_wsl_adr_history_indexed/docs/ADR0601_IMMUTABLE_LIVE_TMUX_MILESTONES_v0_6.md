# ADR0601 Immutable Live tmux Milestones v0.6

**Document status:** Immutable test-control baseline for v0.6  
**Project:** Strata ADR0601 live tmux/Codex CLI worker path  
**Scope:** WSL/tmux dispatch, Codex CLI worker file return, backend routing, and state-ledger presentation  
**Operator for current phase:** Backend Operations Coordinator (BOC)  
**Date:** 2026-06-08  
**Surgical revision of:** `ADR0601_IMMUTABLE_LIVE_WINDOWS_UIA_MILESTONES.md`

## 1. Purpose

This document defines the live test milestones for the ADR0601 tmux/Codex CLI layer.

The objective is to test whether the backend can route work into a selected named tmux session running Codex CLI, receive a Worker Return Packet from the monitored backend folder, and route that return to the correct backend owner: IC, reviewer, ClassD diagnostics, or ClassB admission flow.

This document is intentionally narrow. It does not replace the ADR, the governance kernel, the ClassB admission contract, or raw evidence files. It defines the operational milestone sequence and the required state-ledger presentation for human review.

## 2. Fixed Language

Use the following terms consistently.

| Term | Definition |
| --- | --- |
| Human Director (HD) | Person who sets project direction, approves ClassA changes, and selects the live runtime direction. |
| Backend Operations Coordinator (BOC) | Current tester and backend operator. BOC performs tmux session setup, dispatch execution, return scan/classification, evidence collection, and issue resolution. |
| Incident Commander (IC) | Assignment coordinator. IC receives worker questions, blockers, clarification needs, and routing items within assignment authority. |
| Reviewer | Role that reviews `REPORT_READY` outputs before ClassB admission. |
| Worker | The assigned Codex CLI session in tmux for a role and assignment. |
| tmux session name | The routing anchor in WSL/tmux, following `STRATA-{ROLE}-{ASSIGNMENT_ID}` unless explicitly overridden. |
| tmux_dispatch | The v0.6 launcher/sender that creates or targets tmux sessions, pastes dispatch messages, submits them, captures pane evidence, and records backend JSONL events. |
| Worker Return Packet | The only backend-recognized worker return file. Chat/session output is not a deliverable. |
| Backend Loop Ledger | Append-only control-loop record showing backend state transitions and routing decisions. |
| Portable DeepSeek bridge | The stable Codex CLI + DeepSeek/OpenAI-compatible bridge module copied into WSL and used by Codex CLI. |

## 3. Required Revisions from Prior Milestone Draft

### Revision 1: BOC is the tester for the current phase

For the current live WSL/tmux phase, BOC is the tester and operator.

BOC owns:

- tmux session creation, targeting, verify, and correction.
- tmux_dispatch execution.
- Context Load Packet or Work Dispatch Packet delivery.
- Watched return folder scan or watcher operation.
- Worker Return Packet classifier execution.
- Coordination Thread, Agent Report Ledger, ClassD, and ClassB routing observation.
- Evidence collection.
- Blocker diagnosis and local resolution where possible.

HD remains responsible for the active roadmap decision and authority boundaries. IC and reviewer roles remain part of backend routing, but BOC may simulate or operate the test workflow when the purpose is backend integration testing.

### Revision 2: Avoid the word "proof" in milestone status language

Milestone language must use operational terms:

- `test`
- `validate`
- `observe`
- `record`
- `route`
- `resolve`
- `acceptance state`
- `blocked state`
- `evidence`

Do not use success phrases such as:

- `works`
- `sent`
- `done`
- `passed everything`
- `live proof`
- `Codex works`

A milestone is complete only when the required backend state, worker/session target, artifact path, status code, and evidence path are recorded.

### Revision 3: No mock tmux acceptance

Offline tests may validate schemas and bridge mapping, but they do not satisfy ADR0601 live milestones.

M1, M2, and M3 acceptance requires live VS Code/tmux observation and backend JSONL ledger entries under:

```text
.strata/ledgers/backend_loop_ledger.jsonl
```

## 4. Live Milestones

The current live test has three mandatory milestones. They are ordered and should not be collapsed.

---

## M1_BOC_DISPATCH_TO_SELECTED_APP_SESSION

### Definition

BOC operates the backend and sends a short dispatch message into one selected application-specific session.

For v0.6, the selected session is a named tmux session running Codex CLI. The milestone tests backend-to-Codex routing through the tmux_dispatch sender.

### Required starting state

- The portable Codex CLI + DeepSeek bridge module has been copied into WSL or otherwise made available in WSL.
- The DeepSeek bridge can be started in WSL and Codex CLI is configured to use it.
- BOC has created or selected a tmux worker session.
- The session name follows the required pattern: `STRATA-{ROLE}-{ASSIGNMENT_ID}`, unless explicitly overridden.
- The tmux session is visible through VS Code terminal/tmux attachment.
- Codex CLI is running or launchable inside the tmux session.
- The session record is treated as operational routing state, not as confirmation that the worker completed any task.

### Test action

BOC sends a brief Context Load Packet or Work Dispatch Packet notice to the selected tmux session.

The message must include:

- assignment id
- worker/agent id or role
- packet path
- return folder path
- nonce
- instruction that worker return must be by Worker Return Packet file

### Required acceptance state

The backend records:

- selected runtime: `CodexCLI`
- selected `session_name`
- selected `agent_id`
- selected `assignment_id`
- dispatch packet path
- dispatch packet SHA256
- nonce
- tmux_dispatch status
- dispatch ledger entry
- evidence directory
- tmux pane capture path

The tmux_dispatch sender reaches:

- tmux session exists
- dispatch message written to evidence path
- tmux buffer loaded
- tmux buffer pasted into selected session
- nonce or packet path observed in tmux capture where available
- message submitted to the session unless explicitly using `--no-submit`

If nonce verification is implemented for the session, it must also record:

- `VISIBLE_NONCE_VERIFIED`

### Blocked state handling

If the milestone blocks, BOC must record one precise state:

- `BLOCKED_TMUX_NOT_AVAILABLE`
- `BLOCKED_SESSION_NOT_FOUND`
- `BLOCKED_CODEX_NOT_READY`
- `BLOCKED_BRIDGE_NOT_READY`
- `BLOCKED_VERIFICATION_FAILED`
- `BLOCKED_WITH_DIAGNOSTIC`

BOC should resolve local blockers where possible, including:

- install or start tmux
- create the exact named tmux session
- start Codex CLI inside the session
- start or configure the DeepSeek bridge in WSL
- correct packet/session metadata
- rerun tmux_dispatch after correcting the local issue

### Backend Loop Ledger event

M1 must emit one of:

- `WORK_PASSED`
- `DISPATCH_BLOCKED`

---

## M2_WORKER_TASK_AND_FILE_RETURN

### Definition

BOC sends a brief task to a specific session. The assigned worker performs a small task and writes a Worker Return Packet into the backend-monitored folder.

This milestone tests tmux/Codex worker task execution and file-based return discipline.

### Required starting state

- M1 completed with `WORK_PASSED`.
- The worker received a brief task notice in the selected tmux/Codex CLI session.
- The task is intentionally small and has an exact file output requirement.

### Test action

The assigned worker creates:

- a small report file under the expected reports path
- one Worker Return Packet under `.strata/returns/{assignment_id}/{agent_id}/`

The Worker Return Packet must declare one allowed `return_kind`:

- `ACK`
- `QUESTION`
- `BLOCKED`
- `NEEDS_CLARIFICATION`
- `PARTIAL_STATUS`
- `REPORT_READY`
- `FAILED_WITH_DIAGNOSTIC`

For the primary smoke run, use `REPORT_READY`.

### Required acceptance state

BOC observes and records:

- Worker Return Packet path
- Worker Return Packet SHA256
- `assignment_id`
- `agent_id`
- `role`
- `return_kind`
- nonce
- report path when `return_kind = REPORT_READY`
- evidence path

The worker must not use chat/session text as the deliverable channel. Chat may acknowledge receipt, but it does not satisfy return requirements.

### Blocked state handling

If no file is written, BOC should instruct the worker to write the Worker Return Packet file. BOC must not infer completion from chat.

If the file is malformed, BOC records the schema or parse failure and keeps the return out of the Agent Report Ledger and ClassB path.

### Backend Loop Ledger event

M2 must emit:

- `RETURN_FILE_DETECTED`

If the expected file is absent after the test window, emit:

- `RETURN_FILE_NOT_DETECTED`

---

## M3_BACKEND_CLASSIFICATION_AND_ROUTING

### Definition

The backend detects the dropped Worker Return Packet, classifies it, and routes it to the correct backend destination.

This milestone tests the backend return loop after file drop.

### Required starting state

- M2 produced a Worker Return Packet or a precise absence/error state.
- The return folder follows `.strata/returns/{assignment_id}/{agent_id}/`.
- The backend watcher or deterministic scan/classify command is active.

### Test action

BOC runs or observes backend classification for the Worker Return Packet.

### Required routing table

| Return kind | Required backend route |
| --- | --- |
| `ACK` | Dispatch Ledger update. |
| `QUESTION` | Coordination Thread routed to IC. |
| `BLOCKED` | Coordination Thread routed to IC or HD. |
| `NEEDS_CLARIFICATION` | Coordination Thread routed to IC. |
| `PARTIAL_STATUS` | Coordination Thread or diagnostics. |
| `FAILED_WITH_DIAGNOSTIC` | ClassD/diagnostics and IC. |
| `REPORT_READY` | Agent Report Ledger candidate. |

Only `REPORT_READY` may create an Agent Report Ledger entry.

Only a reviewed and accepted report may enter ClassB.

### Required acceptance state

For `REPORT_READY`, the backend records:

- `WORKER_RETURN_PACKET_CLASSIFIED`
- `REPORT_READY_LEDGERED`
- Agent Report Ledger entry
- `validated_status = pending_review`
- no ClassB import before review acceptance

For non-final returns, the backend records the correct Coordination Thread or diagnostic route and does not create ClassB material.

### Blocked state handling

If watcher behavior is inconsistent, BOC may use deterministic scan/classify commands. The Backend Loop Ledger must record whether the event came from watcher or manual scan.

### Backend Loop Ledger events

M3 must emit one or more of:

- `RETURN_PACKET_CLASSIFIED`
- `ROUTED_TO_IC`
- `ROUTED_TO_REVIEWER`
- `ROUTED_TO_CLASSD`
- `REPORT_LEDGERED`
- `REVIEW_ACCEPTED`
- `CLASSB_IMPORTED`

## 5. Backend Loop Ledger Standard

### Required files

Every live run must produce both files:

```text
.strata/ledgers/backend_loop_ledger.jsonl
.strata/ledgers/backend_loop_ledger.md
```

The JSONL file is the authoritative control-loop record. The Markdown file is the human-readable mirror.

### Purpose

The Backend Loop Ledger answers these questions without requiring raw log review:

- What did the backend observe?
- Which worker received the work?
- Which session was targeted?
- Was the tmux dispatch submitted and verified?
- Did the worker return by file?
- How did the backend classify the return?
- Was the return routed to IC, reviewer, ClassD, or ClassB admission flow?

### Event format

Each ledger line must be one backend state transition.

Required fields:

| Field | Requirement |
| --- | --- |
| `ts` | ISO timestamp. |
| `loop_id` | Monotonic loop event id, for example `0001`. |
| `assignment_id` | Assignment id, for example `A0601`. |
| `event` | Controlled event name. |
| `actor` | Backend actor or role that caused the transition. |
| `from` | Source role/component when applicable. |
| `to` | Destination worker/role/component when applicable. |
| `agent_id` | Worker id when applicable. |
| `role` | Worker role when applicable. |
| `target_app` | Runtime target, usually `CodexCLI`. |
| `session_name` | tmux session name when applicable. |
| `nonce` | Dispatch or return nonce when applicable. |
| `status` | Controlled ADR/backend status. |
| `artifact` | Primary file path affected by the event. |
| `evidence` | Evidence directory or evidence file path. |
| `note` | Short reason when blocked or exceptional. |

### Controlled event names

Use these event names unless an ADR update adds more:

- `DUTY_REGISTERED`
- `DUTY_VERIFIED`
- `WORK_PACKET_CREATED`
- `WORK_PASSED`
- `DISPATCH_BLOCKED`
- `RETURN_FILE_DETECTED`
- `RETURN_FILE_NOT_DETECTED`
- `RETURN_PACKET_CLASSIFIED`
- `ROUTED_TO_IC`
- `ROUTED_TO_REVIEWER`
- `ROUTED_TO_CLASSD`
- `REPORT_LEDGERED`
- `REVIEW_ACCEPTED`
- `REVIEW_REWORK_REQUIRED`
- `CLASSB_IMPORTED`
- `CLASSB_REJECTED_OR_BLOCKED`

### JSONL example

```jsonl
{"ts":"2026-06-08T13:12:44Z","loop_id":"0001","assignment_id":"A0601","event":"DUTY_REGISTERED","actor":"BOC","agent_id":"coder_01","role":"coder","target_app":"CodexCLI","session_name":"STRATA-CODER-A0601","status":"SESSION_CREATED","artifact":".strata/sessions/tmux/tmux_A0601_coder_01_STRATA-CODER-A0601.json","evidence":".strata/evidence/tmux_dispatch/A0601/coder_01/"}
{"ts":"2026-06-08T13:14:31Z","loop_id":"0002","assignment_id":"A0601","event":"WORK_PASSED","actor":"tmux_dispatch.v0.6","from":"BOC","to":"coder_01","agent_id":"coder_01","role":"coder","target_app":"CodexCLI","session_name":"STRATA-CODER-A0601","nonce":"STRATA_NONCE_A0601_D_001","status":"SUBMITTED_AND_VERIFIED","artifact":".strata/dispatches/work_dispatch_packets/A0601/smoke_task_001.md","evidence":".strata/evidence/tmux_dispatch/A0601/coder_01/tmux_dispatch_001/"}
{"ts":"2026-06-08T13:17:55Z","loop_id":"0003","assignment_id":"A0601","event":"RETURN_FILE_DETECTED","actor":"return_scan","agent_id":"coder_01","role":"coder","nonce":"STRATA_NONCE_A0601_D_001","status":"detected","artifact":".strata/returns/A0601/coder_01/RETURN_001.report_ready.json","evidence":".strata/evidence/tmux_dispatch/A0601/coder_01/tmux_dispatch_001/"}
```

## 6. Raw Log Policy

Raw logs remain required, but they are not the first review surface.

Raw logs belong under evidence folders and may include:

- tmux pane captures
- dispatch message files
- bridge debug traces
- watcher events
- classifier output
- Mutation Gate records
- ClassB/ClassD materialization output

The Backend Loop Ledger is the required first review surface for HD and IC. Raw logs are opened only when a ledger line is blocked, inconsistent, or under dispute.

## 7. Package Acceptance Rule

A live test package is not ready for review unless it contains:

- this immutable milestone file or a newer HD-approved version
- `.strata/ledgers/backend_loop_ledger.jsonl`
- `.strata/ledgers/backend_loop_ledger.md`
- dispatch ledger entries
- Worker Return Packet files used in the run
- Agent Report Ledger or Coordination Thread output
- ClassB/ClassD output when applicable
- raw evidence folders

The package must label partial runs precisely. If dispatch and worker return use different nonces, the package must not describe the run as one complete dispatch-to-return chain.

## 8. Current Phase Completion Criteria

The current phase is complete only when one single nonce chain records:

```text
WORK_PASSED
-> RETURN_FILE_DETECTED
-> RETURN_PACKET_CLASSIFIED
-> ROUTED_TO_REVIEWER or ROUTED_TO_IC/CLASSD according to return_kind
```

For the primary smoke test using `REPORT_READY`, the complete chain is:

```text
WORK_PASSED
-> RETURN_FILE_DETECTED
-> RETURN_PACKET_CLASSIFIED
-> REPORT_LEDGERED
-> ROUTED_TO_REVIEWER
```

ClassB import is a separate governance continuation and requires accepted review.
