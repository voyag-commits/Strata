# ADR-HS-2026-06-0601: GUI Worker Dispatch, Active Duty Registry, and File-Based Worker Return Protocol

Status: APPROVED

Date: 2026-06-06
Decision Owner: Human Director
Scope: Harness/Strata GUI-worker orchestration, communication precision, session routing, dispatch templates, worker return protocol, report gating, and ClassB admission.

## 1. Context

Harness/Strata previously explored terminal-centered control through a Terminal Session Adapter. That path produced high coordination cost and repeated unverifiable claims of success. Implementation agents frequently reported that bridges or sessions were working while the Human Director could not observe reliable external evidence.

The active direction now shifts to GUI-worker orchestration.

The Human Director manually creates worker sessions in GUI apps, gives them visible names, records their window locations, and places those sessions into the Active Agent Duty Registry. Strata then communicates with those sessions through short UI messages and file-backed packets.

Durable files and ledgers remain authoritative. UI chat is a control surface, not a durable source of truth.

## 2. Decision Summary

Harness/Strata will use a GUI-worker communication architecture based on:

1. Reasonix as one preferred GUI-worker path.
2. Human-created, manually named GUI app sessions.
3. Human-provided session names and window locations.
4. Active Agent Duty Registry for routing live worker sessions.
5. Desktop UI Injection Adapter for locating sessions, activating them, pasting short messages, and collecting evidence.
6. Context Load Packets for formal A/B/C context and role/protocol setup.
7. Work Dispatch Packets for concrete task, revision, review, file-pin, and IC-answer messages.
8. Worker Return Packets as the only accepted worker return mechanism.
9. Coordination Threads for questions, blockers, and non-final worker state.
10. Agent Report Ledger only for `REPORT_READY` Worker Return Packets.
11. ClassB admission only after accepted review of a durable report.

## 3. Superseded Direction

The Terminal Session Adapter is abandoned as the active implementation path for current development.

Consequences:

```text
- no new active work targets terminal/tmux/node-pty/Codex CLI bridge proof unless reopened by Human Director;
- existing terminal-related code may remain archived, frozen, or diagnostic-only;
- terminal sessions are not the main proof target;
- worker orchestration proceeds through GUI app sessions and file-triggered returns.
```

## 4. Preferred GUI Worker Path

Reasonix becomes one preferred GUI-worker path.

The preferred path is:

```text
Human Director manually creates app session
-> Human Director names session
-> Human Director records session name and window location
-> Strata records worker in Active Agent Duty Registry
-> Strata locates visible session
-> Strata activates session
-> Strata pastes short Context Load or Work Dispatch message
-> Worker reads referenced file
-> Worker writes Worker Return Packet into watched backend folder
-> Backend classifies Worker Return Packet
-> Backend routes to IC, reviewer, Human Director, Coordination Thread, or report review
```

Reasonix native transport remains optional and non-governing until it proves stable session routing.

## 5. Human-Created Session Naming

The Human Director manually creates GUI app sessions and assigns visible names.

Required pattern:

```text
STRATA-{ROLE}-{ASSIGNMENT_ID}
```

Examples:

```text
STRATA-IC-A017
STRATA-CODER-A017
STRATA-TESTER-A017
STRATA-REVIEWER-A017
```

The visible session name is the routing anchor for GUI workers.

Hidden app session IDs are not authoritative in this version.

## 6. Active Agent Duty Registry

The Active Agent Duty Registry is the authoritative roster of currently active worker sessions.

Internal name:

```text
duty_registry
```

Purpose:

```text
Record which worker is on duty, which app/session represents that worker, and where Strata should route short UI messages.
```

The Human Director must provide at least:

```text
target_app
session_name
window_location
role
assignment_id
```

Backend may enrich the record with process ID, window ID, accessibility-tree identity, verification status, and evidence paths.

Minimum record:

```json
{
  "duty_id": "duty_A017_coder_reasonix",
  "agent_id": "coder_017",
  "role": "coder",
  "assignment_id": "A017",
  "status": "on_duty",
  "target_app": "Reasonix",
  "session_name": "STRATA-CODER-A017",
  "window_location": {
    "display": 1,
    "x": 120,
    "y": 80,
    "width": 1400,
    "height": 900
  },
  "window_title_hint": "Reasonix - STRATA-CODER-A017",
  "desktop_session_id": "desktop_sess_8f31",
  "last_verified_at": "2026-06-06T00:00:00Z",
  "last_nonce": "STRATA_NONCE_A017_001",
  "evidence_dir": "runs/A017/agents/coder_017/evidence"
}
```

## 7. Desktop UI Injection Adapter

The Desktop UI Injection Adapter is responsible for GUI app communication.

Internal name:

```text
desktop_ui_injection_adapter.v1
```

Primary operations:

```text
desktop.sessions.scan_names
desktop.sessions.find_by_name
desktop.sessions.activate_by_name
desktop.sessions.focus_composer
desktop.sessions.paste_message
desktop.sessions.submit_message
desktop.sessions.verify_visible_nonce
desktop.sessions.capture_evidence
```

Preferred activation order:

```text
1. Accessibility Select / Invoke / Focus
2. DOM click for browser-accessible apps
3. Keyboard search/navigation
4. Bounding-box click from accessibility tree
5. OCR/image coordinate click only as last resort
```

No blind coordinate-click path may report success.

Required statuses:

```text
SESSION_NAME_FOUND
SESSION_NAME_NOT_FOUND
SESSION_NAME_DUPLICATE
SESSION_ACTIVATION_REQUESTED
SESSION_ACTIVATED
ACTIVE_SESSION_VERIFIED
ACTIVE_SESSION_MISMATCH
INPUT_FIELD_FOUND
INPUT_FIELD_NOT_FOUND
PASTED_AND_VERIFIED
SUBMITTED_AND_VERIFIED
SUBMITTED_NOT_VERIFIED
BLOCKED_APP_NOT_FOUND
BLOCKED_WINDOW_NOT_FOUND
BLOCKED_ACTIVATION_FAILED
BLOCKED_INPUT_NOT_FOUND
BLOCKED_VERIFICATION_FAILED
BLOCKED_WITH_DIAGNOSTIC
```

The adapter must not paste unless target app, session name, and active input surface are verified or explicitly marked blocked/manual.

## 8. Messaging Taxonomy

Harness/Strata recognizes three standard message packet types.

| Direction            | Name                 | Contract                  | Purpose                                                      |
| -------------------- | -------------------- | ------------------------- | ------------------------------------------------------------ |
| Backend/IC → session | Context Load Packet  | `context_load_packet.v1`  | Formal A/B/C context, role setup, return protocol            |
| Backend/IC → session | Work Dispatch Packet | `work_dispatch_packet.v1` | Task, revision, review, file pin, IC answer, continue/stop message |
| Session → backend    | Worker Return Packet | `worker_return_packet.v1` | Required structured worker status report for every outcome   |

No other message type should be introduced without Human Director approval.

## 9. Context Load Packet

A Context Load Packet initializes or refreshes a worker session.

Internal contract:

```text
context_load_packet.v1
```

Purpose:

```text
Provide formal context and operating protocol to a worker session.
```

It may include:

```text
ClassA authority/task law/DOD
ClassB accepted operational memory
ClassC source/reference material
role contract
assignment frame
return protocol
watched return folder
```

Example short UI message:

```text
STRATA CONTEXT LOAD v1

Read this context packet:
context/A017/coder_context_load_001.md

This defines your authority, working memory, source references, role, and return protocol.

Your chat messages are not deliverables.
Return only by writing a Worker Return Packet to:
returns/A017/coder_017/

Nonce: STRATA_NONCE_A017_CTX001
```

The full Context Load Packet lives in a file. The UI message only points to the file.

## 10. Work Dispatch Packet

A Work Dispatch Packet sends concrete operational work to an already-loaded worker session.

Internal contract:

```text
work_dispatch_packet.v1
```

Purpose:

```text
Send a specific task, revision, answer, review request, file pin, continuation instruction, or stop/rework instruction.
```

Allowed dispatch kinds:

```text
TASK_ASSIGNMENT
REVISION_SPEC
REVIEW_REQUEST
IC_ANSWER
FILE_PIN
CONTINUE_WORK
STOP_OR_REWORK
```

Example short UI message:

```text
STRATA WORK DISPATCH v1

Assignment: A017
Read: packets/A017/ic_revision_spec_002.md
Action: Review this file and continue work.

Return by writing a Worker Return Packet to:
returns/A017/coder_017/

Nonce: STRATA_NONCE_A017_D002
```

Simplified UI form is allowed when context is already loaded:

```text
Review this file: packets/A017/ic_revision_spec_002.md
Nonce: STRATA_NONCE_A017_D002
Return by Worker Return Packet only.
```

## 11. Worker Return Packet

Worker completion, blocker, question, failure, and partial status detection is file-triggered, not chat-inferred.

All workers must return a Worker Return Packet file.

Internal contract:

```text
worker_return_packet.v1
```

Rule:

```text
Every worker outcome must be expressed as a Worker Return Packet file.
Worker chat messages are not read as deliverables.
Worker chat messages do not trigger completion.
```

Watched folder pattern:

```text
returns/{assignment_id}/{agent_id}/
```

Example file names:

```text
returns/A017/coder_017/RETURN_001.ack.json
returns/A017/coder_017/RETURN_002.question.json
returns/A017/coder_017/RETURN_003.blocked.json
returns/A017/coder_017/RETURN_004.report_ready.json
```

Required schema:

```json
{
  "contract_id": "worker_return_packet.v1",
  "return_id": "ret_A017_coder_017_004",
  "assignment_id": "A017",
  "agent_id": "coder_017",
  "role": "coder",
  "return_kind": "REPORT_READY",
  "status": "ready_for_review",
  "summary": "Completed implementation and wrote evidence.",
  "nonce": "STRATA_NONCE_A017_R004",
  "message_path": null,
  "question_path": null,
  "report_path": "reports/A017/coder_report_001.md",
  "diagnostic_path": null,
  "evidence_path": "runs/A017/coder_017/evidence",
  "created_at": "2026-06-06T00:00:00Z"
}
```

Allowed `return_kind` values:

```text
ACK
QUESTION
BLOCKED
NEEDS_CLARIFICATION
PARTIAL_STATUS
REPORT_READY
FAILED_WITH_DIAGNOSTIC
```

Backend routing:

| `return_kind`            | Backend action                                               |
| ------------------------ | ------------------------------------------------------------ |
| `ACK`                    | Update Dispatch Ledger                                       |
| `QUESTION`               | Create/update Coordination Thread, route to IC               |
| `BLOCKED`                | Create/update Coordination Thread, route to IC or Human Director |
| `NEEDS_CLARIFICATION`    | Create/update Coordination Thread, route to IC               |
| `PARTIAL_STATUS`         | Create/update Coordination Thread or diagnostics             |
| `FAILED_WITH_DIAGNOSTIC` | Route to ClassD/diagnostics and IC                           |
| `REPORT_READY`           | Create Agent Report Ledger candidate                         |

Only `REPORT_READY` can enter the Agent Report Ledger.

Only accepted reviewed reports can enter ClassB.

## 12. Initial Worker Session Instruction

Every worker session must receive the return protocol during context load.

Required wording:

```text
Your chat messages are not read as deliverables.
Do not report completion in chat.
For every outcome, write a Worker Return Packet file into the provided backend return folder.
This includes success, failure, blocker, question, partial status, and report-ready states.
Only Worker Return Packet files are classified by the backend.
```

This instruction must appear in the Context Load Packet.

## 13. Coordination Threads

Coordination Threads track non-final worker communication.

Internal name:

```text
coordination_threads
```

Purpose:

```text
Track questions, blockers, clarifications, partial findings, IC answers, and Human Director escalations before a durable report exists.
```

Required schema:

```json
{
  "thread_id": "coord_A017_coder_001",
  "assignment_id": "A017",
  "agent_id": "coder_017",
  "role": "coder",
  "target_app": "Reasonix",
  "session_name": "STRATA-CODER-A017",
  "state": "QUESTION_RAISED",
  "latest_return_id": "ret_A017_coder_017_002",
  "latest_message_kind": "QUESTION",
  "latest_message_path": "coord/A017/coder/question_001.md",
  "latest_message_excerpt": "Which boundary should own session activation?",
  "requires_ic": true,
  "requires_human_director": false,
  "answered_by": null,
  "answer_path": null,
  "created_at": "2026-06-06T00:00:00Z",
  "updated_at": "2026-06-06T00:00:00Z",
  "evidence_dir": "runs/A017/coord/coder_017/001"
}
```

Allowed states:

```text
ACK_RECEIVED
QUESTION_RAISED
BLOCKER_RAISED
CLARIFICATION_REQUESTED
IC_ANSWERED
REVISION_SPEC_SENT
HUMAN_ESCALATION_REQUIRED
REPORT_READY
NO_RESPONSE_DETECTED
```

## 14. IC Answer and Escalation Rules

IC may answer:

```text
implementation clarification
file location
DOD interpretation already present in ClassA or assignment packet
minor routing/session issue
request to re-read packet
request to write a proper Worker Return Packet file
```

IC must escalate to Human Director for:

```text
scope change
architecture decision
conflict with ADR or ClassA
budget/runtime/tooling decision
ambiguous acceptance criteria
permission to abandon/restart an assignment
worker repeatedly failing protocol
```

Human Director escalation should create or update a Coordination Thread with:

```text
state = HUMAN_ESCALATION_REQUIRED
requires_human_director = true
```

## 15. Dispatch Ledger

The Dispatch Ledger records every short UI message sent to a worker session.

Internal name:

```text
dispatch_ledger
```

Required fields:

```json
{
  "dispatch_id": "disp_A017_coder_002",
  "assignment_id": "A017",
  "from_role": "IC",
  "to_agent_id": "coder_017",
  "target_app": "Reasonix",
  "session_name": "STRATA-CODER-A017",
  "packet_type": "work_dispatch_packet.v1",
  "packet_path": "packets/A017/ic_to_coder_002.md",
  "packet_sha256": "sha256...",
  "nonce": "STRATA_NONCE_A017_002",
  "paste_status": "PASTED_AND_VERIFIED",
  "submit_status": "SUBMITTED_AND_VERIFIED",
  "verification_status": "VISIBLE_NONCE_VERIFIED",
  "evidence_dir": "runs/A017/dispatch/disp_A017_coder_002",
  "created_at": "2026-06-06T00:00:00Z"
}
```

## 16. Agent Report Ledger

The Agent Report Ledger tracks only durable worker reports declared `REPORT_READY`.

Internal name:

```text
agent_report_ledger
```

Only a Worker Return Packet with:

```text
return_kind = REPORT_READY
```

may create an Agent Report Ledger entry.

Required fields:

```json
{
  "report_id": "report_A017_coder_001",
  "assignment_id": "A017",
  "agent_id": "coder_017",
  "role": "coder",
  "return_id": "ret_A017_coder_017_004",
  "report_path": "reports/A017/coder_report_001.md",
  "report_sha256": "sha256...",
  "declared_status": "REPORT_READY",
  "validated_status": "pending_review",
  "reviewer_id": null,
  "evidence_dir": "runs/A017/reports/report_A017_coder_001",
  "created_at": "2026-06-06T00:00:00Z"
}
```

Allowed `validated_status` values:

```text
pending_review
accepted
rework_required
quarantined
invalid_return_packet
```

## 17. ClassB Admission Rule

Only accepted reviewed reports can enter ClassB.

Required path:

```text
Worker Return Packet with return_kind=REPORT_READY
-> Agent Report Ledger entry
-> reviewer/IC review
-> validated_status = accepted
-> Mutation Gate approval
-> ClassB import
```

Not allowed:

```text
chat claim -> ClassB
QUESTION -> ClassB
BLOCKED -> ClassB
PARTIAL_STATUS -> ClassB
FAILED_WITH_DIAGNOSTIC -> ClassB
unreviewed REPORT_READY -> ClassB
```

Questions, blockers, partial statuses, and failed diagnostics belong in Coordination Threads or ClassD/diagnostics, not ClassB.

## 18. Evidence Requirements

Each dispatch, activation, paste, submit, worker return, and report review must write evidence sufficient to prevent unverifiable success claims.

Minimum evidence for UI dispatch:

```text
duty_registry snapshot
dispatch_ledger entry
target app
session name
window location
packet type
packet path
packet sha256
nonce
pre-action screenshot or UI tree when available
post-paste/post-submit evidence when available
verification status
diagnostic file if blocked
```

Minimum evidence for Worker Return Packet handling:

```text
Worker Return Packet file
return packet hash
watched folder event
classification result
routing decision
Coordination Thread or Agent Report Ledger update
diagnostic file if invalid
```

## 19. Prohibited Success Claims

Workers and implementation agents must not report:

```text
works
sent
done
passed everything
integration works
Reasonix works
```

unless the corresponding evidence record exists.

Acceptable claims are state-specific:

```text
CONTEXT_LOAD_SUBMITTED_AND_VERIFIED
WORK_DISPATCH_SUBMITTED_AND_VERIFIED
WORKER_RETURN_PACKET_CLASSIFIED
QUESTION_ROUTED_TO_IC
REPORT_READY_LEDGERED
REPORT_ACCEPTED_AND_IMPORTED_TO_CLASSB
BLOCKED_WITH_DIAGNOSTIC
```

## 20. Consequences

This ADR shifts active project architecture from terminal-centered control to GUI-worker, file-backed orchestration.

Benefits:

```text
less reliance on fragile terminal/Codex bridge claims
Reasonix becomes usable as a preferred GUI-worker path
human-visible session routing
short UI messages are easier to verify
files carry durable task/report content
every worker outcome has one required return packet format
worker questions are supported without pretending they are reports
ClassB remains protected by review
```

Tradeoffs:

```text
Human Director must manually create/name sessions and record window locations
desktop UI automation must handle app/window/session activation
native transports are deferred
chat remains useful but not authoritative for deliverables or completion
backend must implement watched folders and Worker Return Packet classifier
```

## 21. Implementation Tasks

1. Add `duty_registry` schema and report formatting.
2. Add Desktop UI Injection Adapter v1.
3. Add session-name scan/activation/paste/verification operations.
4. Add `context_load_packet.v1` schema and template.
5. Add `work_dispatch_packet.v1` schema and template.
6. Add `worker_return_packet.v1` schema and template.
7. Add required initial worker session instruction.
8. Add Dispatch Ledger.
9. Add watched return folders.
10. Add Worker Return Packet classifier.
11. Add Coordination Thread storage.
12. Add Agent Report Ledger with `REPORT_READY` gate.
13. Add ClassB admission rule requiring accepted reviewed report.
14. Update worker instructions to ignore chat as deliverable channel.
15. Update reviewer instructions to reject chat-only success claims.
16. Mark Terminal Session Adapter as abandoned/deprioritized for active development.

## 22. Final Decision Statement

Harness/Strata will proceed with GUI-worker orchestration using manually named visible app sessions, Human Director-provided session names/window locations, Active Agent Duty Registry routing, Desktop UI Injection Adapter dispatch, Context Load Packets, Work Dispatch Packets, Worker Return Packets, Coordination Threads for non-final states, Agent Report Ledger for report-ready outputs, and reviewed ClassB admission only after acceptance.

Reasonix is one preferred GUI-worker path under this model.

Terminal Session Adapter work is abandoned as the active path unless reopened by Human Director decision.





## ADR Delta: IC / Backend Operations Coordinator Role Split

### Backend Operations Coordinator

Harness/Strata introduces a dedicated **Backend Operations Coordinator**.

Internal role key:

```text
backend_ops
```

Short name:

```text
BOC
```

BOC owns backend/system operations:

```text
Active Agent Duty Registry stage/write/validate
Desktop UI Injection Adapter dispatch execution
Context Load Packet delivery
Work Dispatch Packet delivery
watched return folder monitoring
Worker Return Packet classifier handoff
panel/evidence hygiene
backend diagnostics
blocked dispatch/session diagnostics
```

BOC may enter registry data only from Human Director-provided session information.

BOC-entered registry state is operational state, not proof that a GUI session is reachable. Reachability still requires Desktop UI Injection Adapter verification and evidence.

### Incident Commander

IC owns assignment coordination:

```text
worker task flow
worker questions
revision specs
IC answers within assignment authority
review/rework routing
escalation to Human Director
```

IC does not own routine backend CLI burden, registry mechanics, panel hygiene, or dispatch execution mechanics.

### Human Director

Human Director remains authority for:

```text
manual GUI session creation
visible session naming
window location provision
architecture/scope decisions
authority changes
```

### Role Boundary Rule

```text
Human Director creates/names sessions.
BOC records and verifies operational routing state.
IC coordinates work and decisions.
Reviewer validates report-ready outputs.
Only accepted reviewed reports may enter ClassB.
```