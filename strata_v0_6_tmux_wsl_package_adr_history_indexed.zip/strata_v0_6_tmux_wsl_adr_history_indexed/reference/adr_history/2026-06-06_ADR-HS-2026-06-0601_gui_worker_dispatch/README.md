# ADR-HS-2026-06-0601 Historical Reference

This folder preserves the approved GUI-worker ADR from 2026-06-06.

In Strata v0.6, this document is retained as historical decision lineage. It is not the active implementation path.

Retained concepts that still matter:

```text
Active Agent Duty Registry as a roster/routing concept
Backend Operations Coordinator role
Incident Commander role
file-first Worker Return Packet protocol
Coordination Threads for questions/blockers
Agent Report Ledger only for REPORT_READY
review-before-ClassB admission
prohibited unverifiable success claims
```

Superseded for active v0.6 runtime:

```text
Reasonix as preferred worker path
Desktop UI Injection Adapter as active dispatch mechanism
GUI session/window-location routing
GUI/UIA injection implementation tasks
Terminal Session Adapter abandonment language where it conflicts with v0.6 tmux migration
```

Use this ADR for rationale and terminology lineage. Implement active runtime work from the v0.6 tmux documents.
