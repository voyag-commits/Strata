# v0.6 tmux/WSL Runtime Migration ADR Set

This folder contains the active v0.6 runtime migration documents copied from `docs/`.

Active decision:

```text
WSL/tmux -> Codex CLI -> portable DeepSeek bridge -> DeepSeek API
```

The milestone structure remains ADR0601 M1/M2/M3, surgically revised for tmux sessions instead of GUI/UIA sessions.
