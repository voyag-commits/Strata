# Reference ADR History

This folder contains the retained ADR lineage for Strata v0.6.

## Contents

```text
2026-06-05_v0_5_adapter_reinstatement_bundle/
2026-06-06_ADR-HS-2026-06-0601_gui_worker_dispatch/
2026-06-08_v0_6_tmux_wsl_runtime_migration/
```

## Status

- `2026-06-05_v0_5_adapter_reinstatement_bundle/` is the retained governance baseline.
- `2026-06-06_ADR-HS-2026-06-0601_gui_worker_dispatch/` is historical approved ADR lineage, superseded for active runtime by v0.6.
- `2026-06-08_v0_6_tmux_wsl_runtime_migration/` is the active runtime migration lineage.

Active implementation follows v0.6 WSL/tmux unless a later Human Director ADR changes direction.
