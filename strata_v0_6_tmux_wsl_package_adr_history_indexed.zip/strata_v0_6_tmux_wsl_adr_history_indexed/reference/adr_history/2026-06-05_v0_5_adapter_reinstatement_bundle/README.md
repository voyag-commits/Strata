# Harness / Strata ADR Bundle v0.5 - Adapter Reinstatement

This bundle preserves the v0.4 governance architecture while replacing the v0.4 Reasonix/session-interface runtime substrate with the Codex CLI + DeepSeek runtime adapter.

## Main decision

```text
v0.5 = v0.4 governance preserved
     + Runtime Adapter Boundary restored
     + Codex CLI + DeepSeek adapter reinstated
     - Reasonix as required proof/runtime substrate
```

## Local adapter handoff

Expected local implementation handoff:

```text
C:\Users\hou16\Downloads\FINAL_ADAPTER_BOUNDARY_CLI_GATES_HANDOFF.zip
```

This bundle records the architecture and boundary. It does not include or verify that local archive.

## Entry point

Start with:

```text
canonical_docs/00_CANONICAL_ARCHITECTURE_INDEX_v0.5.md
```

Then read:

```text
canonical_docs/01_ADR-HS-2026-06-005_Runtime_Adapter_Reinstatement_and_v0_4_Governance_Preservation.md
canonical_docs/17_V0_4_CARRY_FORWARD_INVARIANTS_v0.5.md
canonical_docs/06_RUNTIME_ADAPTER_BOUNDARY_SPEC_v0.5.md
canonical_docs/09_LIVE_PROOF_LADDER_v0.5.md
```
