# 06 - Runtime Adapter Boundary Spec v0.5

| Field | Value |
|---|---|
| Document ID | HS-RAB-2026-06-005 |
| Version | v0.5 |
| Issue date | 2026-06-05 |
| Status | Accepted Human Director direction; proposed implementation package |
| Owner | Human Director |
| Scope | Boundary between governance backend and Codex CLI + DeepSeek runtime adapter |
| Supersedes | v0.4 Session Interface Boundary as mainline runtime/proof path |
| Restores | v0.3 runtime-adapter concept, updated under v0.4 Governance Mutation Gate and ClassB rules |
| Local adapter handoff | `C:\Users\hou16\Downloads\FINAL_ADAPTER_BOUNDARY_CLI_GATES_HANDOFF.zip` |

## 1. Boundary definition

The Runtime Adapter Boundary is the contract between the governance backend and the controllable execution substrate.

The boundary is:

```text
backend context packet + adapter run request
-> Codex CLI + DeepSeek adapter launch/target operation
-> backend-governed prompt/context delivery
-> runtime execution using terminal/files/tools/backend CLI as authorized
-> adapter output/transcript/artifact capture
-> adapter run envelope
-> structured report candidate extraction when ClassB impact is intended
-> backend filter/validation/import through Governance Mutation Gate
```

## 2. Layer responsibility

| Layer | Responsibility |
|---|---|
| Governance authority | Human Director decisions, ClassA, policy, templates, milestone acceptance, adapter behavior approval. |
| Governance backend | Context cuts, assignments, packets, adapter run registry, ClassB memory, validation, state transitions, audit, projections. |
| Runtime adapter | Launch/target Codex CLI, configure DeepSeek provider/model, deliver prompt/input, capture run envelope/output/traces/diagnostics/artifacts. |
| Agent runtime | Perform bounded task under packet constraints. |

## 3. Backend output to adapter

An adapter packet contains at minimum:

- operation type: `spawn`, `run`, `deliver_message`, `collect_output`, `retire`, or `status`;
- assignment id;
- role;
- DOD;
- allowed operations;
- target workspace;
- packet path and hash;
- rendered prompt path and hash;
- compact ClassA/B/C context selection;
- full-record paths for optional inspection;
- output directory;
- expected report candidate path or extraction rule;
- explicit authority boundaries;
- approved DeepSeek provider/model configuration reference, without secret values.

## 4. Adapter output to backend

The adapter returns or exposes at minimum:

- operation type;
- assignment id;
- role;
- adapter run id;
- adapter version;
- Codex CLI version when available;
- DeepSeek model/provider metadata without secrets;
- delivery status and delivery proof path when available;
- start/end timestamps;
- terminal state;
- exit status/failure code;
- transcript path;
- stdout/stderr paths;
- artifact paths;
- raw output/report candidate path when available;
- ClassD trace/log/diagnostic paths;
- retirement/termination status when applicable;
- error summary if failed.

## 5. Adapter run-envelope schema

Minimum run envelope:

```yaml
run_id: string
assignment_id: string
role: ic | worker | reviewer | tester | sme | secondary_hand
operation_type: spawn | run | deliver_message | collect_output | retire | status
adapter_version: string
codex_cli_version: string | unknown
model_provider: deepseek
model_name: string
workdir: path
packet_path: path
packet_sha256: string
prompt_path: path
prompt_sha256: string
started_at: timestamp
ended_at: timestamp | null
exit_status: int | null
terminal_state: running | completed | failed | cancelled | unknown
delivery_proof_path: path | null
transcript_path: path | null
stdout_path: path | null
stderr_path: path | null
artifact_paths: [path]
report_candidate_path: path | null
report_candidate_sha256: string | null
diagnostics_path: path | null
error_summary: string | null
```

## 6. Authority boundary

The adapter may execute work and capture evidence.

The adapter may not:

- write ClassA;
- write active ClassB;
- modify governance policy or templates;
- close milestones;
- create or satisfy Human Director approval;
- override validation;
- destructively rewrite governance state;
- silently alter backend-governed packet content.

All authoritative writes go through the backend and Governance Mutation Gate.

## 7. Input integrity rule

The backend computes packet and prompt hashes before handoff. The adapter run envelope records those hashes.

If delivered input differs from the backend-governed prompt/packet, the run is invalid for ClassB import until reviewed.

## 8. Output integrity rule

The adapter captures raw output and report candidate paths. The backend validates raw submitted candidate material. The backend must not synthesize, repair, wrap, or rewrite invalid raw output into a valid ClassB report unless a separate explicit transform record is created. If meaning could change, Human Director approval is required.

## 9. Local adapter handoff

The expected local implementation handoff is:

```text
C:\Users\hou16\Downloads\FINAL_ADAPTER_BOUNDARY_CLI_GATES_HANDOFF.zip
```

This canonical bundle records the interface and governance boundary. The local handoff zip should be copied into the implementation/evidence root when backend/adapter coders need to inspect or execute it.

## 10. Reasonix status

Reasonix is optional/manual/non-governing for v0.5. Reasonix evidence may be stored as ClassD or explicit non-governing reference evidence, but Reasonix session spawn/input/output is not required for the v0.5 live proof ladder.
