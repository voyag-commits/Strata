# 16 - stratactl CLI and IC Operation Spec v0.5

| Field | Value |
|---|---|
| Document ID | HS-STRATACTL-2026-06-005 |
| Version | v0.5 |
| Issue date | 2026-06-05 |
| Status | Accepted Human Director direction; proposed implementation package |
| Owner | Human Director |
| Scope | CLI command surface for IC/backend operation, adapter-run control, and context-volume control |
| Primary source | ADR-HS-2026-06-005 |

## 1. Purpose

`stratactl` is the preferred interface for IC sessions to operate the governance backend.

The CLI should make the backend reachable without making the backend a complex if/else orchestrator.

In v0.5, `stratactl` also exposes controlled adapter-run commands. These commands create records and invoke or inspect the runtime adapter; they do not bypass governance authority.

## 2. Command principles

- Explicit commands over hidden workflow branching.
- Compact output by default.
- Full detail materialized to files.
- Every authoritative write goes through the Governance Mutation Gate.
- Routine updates should be fast.
- Important updates should produce Director decision packets.
- Adapter commands create auditable run/evidence records.

## 3. Minimum commands

```text
stratactl state
stratactl projections list
stratactl projection read <name>

stratactl classb list [--active]
stratactl classb read <id>
stratactl classb synthesize --routine --from <ids> --title <title>
stratactl classb supersede <id> --by <id>

stratactl assignment create --role <role> --title <title> --dod <text>
stratactl assignment read <id>
stratactl assignment route-rework <id> --reason <text>

stratactl packet create --for <role> --assignment <id> [--from <classb_ids>]
stratactl packet read <id>

stratactl adapter run --assignment <id> --packet <packet_id> [--role <role>]
stratactl adapter status <run_id>
stratactl adapter collect <run_id>
stratactl adapter evidence <run_id> [--view brief|standard|full]
stratactl adapter quarantine <run_id> --reason <text>

stratactl report validate <path>
stratactl report import <path>
stratactl report quarantine <path> --reason <text>

stratactl gate check --operation <op> --target <target>
stratactl director decision-packet --reason <text> --sources <ids>

stratactl tx plan <plan.yaml>
stratactl tx inspect <tx_id>
stratactl tx commit <tx_id>
```

## 4. Output modes

```text
--view brief      default, context-safe
--view standard   moderate detail
--view full       writes full detail to file and returns path
--json            machine-readable compact result
```

Default response schema:

```yaml
status: string
operation_id: string
changed_records: [id]
short_summary: string
full_record_path: path
next_recommended_command: string | null
```

## 5. Adapter command response schema

```yaml
status: requested | running | completed | failed | quarantined
operation_id: string
run_id: string
assignment_id: string
packet_id: string
short_summary: string
run_envelope_path: path | null
transcript_path: path | null
report_candidate_path: path | null
validation_status: pending | valid | invalid | quarantined | not_applicable
next_recommended_command: string | null
```

## 6. Transaction batching

To reduce IC context load and backend command chatter, the CLI should support transaction plans:

```text
stratactl tx plan worker-assignment.yaml
stratactl tx inspect TX-000014
stratactl tx commit TX-000014
```

A transaction plan may include assignment creation, packet creation, adapter run request, expected report registration, and projection update. The Governance Mutation Gate evaluates the transaction as one coherent operation.

Transaction commits are all-or-none unless explicitly marked `partial_allowed`.

If any operation requires Human Director approval, the whole transaction becomes `approval_required` unless split.

Repeated commit of the same transaction id must be idempotent.

## 7. Permission tiers

| Tier | Examples | Authority |
|---|---|---|
| Read | state, projection read, classb read, adapter evidence read | IC allowed. |
| Routine write | assignment create, packet create, routine adapter run request, routine report import, routine synthesis | IC allowed through gate. |
| Important write | ClassA, architecture/product synthesis, milestone, policy/template, adapter behavior change affecting proof/security | Human Director required. |
| Destructive/override | delete, rewrite, validation override, evidence suppression | Human Director required with explicit audit. |

## 8. IC prompt rule

IC session prompts should include:

```text
Use stratactl as the source of backend truth.
Prefer brief/projection reads.
Do not request full ClassB replay unless needed.
Use transaction plans for multi-step routine operations.
Use adapter commands for Codex CLI + DeepSeek runtime execution.
Treat adapter output as evidence, not as automatic ClassB.
Escalate meaning-changing or architecture/product-direction updates to Human Director.
```

## 9. Example routine command flow

```text
stratactl state --view brief
stratactl assignment create --role worker --title "Implement report validator" --dod "Tests pass and invalid reports quarantine"
stratactl packet create --for worker --assignment A-000012
stratactl adapter run --assignment A-000012 --packet P-000044 --role worker
stratactl adapter status R-000091
stratactl adapter collect R-000091
stratactl report validate output/report.md
stratactl report import output/report.md
stratactl assignment create --role reviewer --title "Review B-000027" --dod "Review validates scope and tests"
stratactl packet create --for reviewer --assignment A-000013 --from B-000027
```

## 10. Example blocked command flow

```text
stratactl classb synthesize --from B-000027,B-000031 --title "New architecture direction"
```

Expected result:

```yaml
status: approval_required
required_approval: human_director
reason: meaning-changing architecture/product-direction synthesis
next_recommended_command: stratactl director decision-packet --sources B-000027,B-000031
```
