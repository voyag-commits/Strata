# 10 - Historical Document Register v0.5

| Field | Value |
|---|---|
| Document ID | HS-HIST-2026-06-005 |
| Version | v0.5 |
| Issue date | 2026-06-05 |
| Status | Historical/provenance register |
| Owner | Human Director |
| Scope | Traceability for prior Harness / Strata document sets and runtime-boundary changes |
| Primary source | ADR-HS-2026-06-005 |

## 1. Register purpose

This register records the status of prior Harness / Strata materials after v0.5.

v0.5 is not a rollback of v0.4 governance. It is a runtime-substrate correction: v0.4 governance remains, while the main execution boundary returns to the Codex CLI + DeepSeek adapter.

## 2. Prior version status

| Prior material | v0.5 status | Notes |
|---|---|---|
| v0.3 runtime-adapter architecture | Partially restored as runtime substrate reference. | Restored only under v0.5 governance rules. |
| v0.3 DLO mandatory flow | Still superseded. | Secondary-hand communication placeholder remains near IC. |
| v0.3 ClassB/context ledger concepts | Superseded by v0.4/v0.5 ClassB validated operational memory. | Do not use old names where they conflict. |
| v0.4 Governance Mutation Gate | Preserved. | Mandatory for every authoritative write. |
| v0.4 ClassB validated operational memory | Preserved. | Governing name and semantics. |
| v0.4 Session Interface Boundary | Superseded as main runtime/proof substrate. | Reasonix/manual UI may remain optional/non-governing. |
| v0.4 Frozen Adapter Supersession Notice | Superseded. | Replaced by v0.5 Adapter Reinstatement Notice. |
| v0.4 `stratactl` operation model | Preserved and extended. | Adds adapter command surface. |

## 3. Local adapter handoff pointer

The current local adapter implementation handoff is expected at:

```text
C:\Users\hou16\Downloads\FINAL_ADAPTER_BOUNDARY_CLI_GATES_HANDOFF.zip
```

This register records the pointer only. The zip should be copied into the evidence/implementation root when used.

## 4. Use rule

When older documents conflict with v0.5, follow this rule:

```text
Use v0.5 for runtime, proof, authority, ClassB, and backend/adapter boundary.
Use older documents only for provenance or implementation detail explicitly pulled forward by v0.5.
```
