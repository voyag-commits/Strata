# 17 - v0.4 Carry-Forward Invariants v0.5

| Field | Value |
|---|---|
| Document ID | HS-INVARIANTS-2026-06-005 |
| Version | v0.5 |
| Issue date | 2026-06-05 |
| Status | Governing preservation addendum |
| Owner | Human Director |
| Scope | v0.4 decisions that remain invariant across v0.5 and later version changes unless explicitly superseded by ADR |
| Primary source | ADR-HS-2026-06-005 |

## 1. Purpose

v0.5 changes the runtime substrate back to the Codex CLI + DeepSeek adapter. It does not roll back the v0.4 governance decisions.

This document lists the v0.4 decisions that must remain invariant unless a later Human Director-approved ADR explicitly changes them.

## 2. Preserved governance invariants

1. Backend is the deterministic governance kernel.
2. Governance Mutation Gate is mandatory for every authoritative backend write.
3. ClassB means validated operational memory.
4. ClassA/B/C/D class semantics remain governing.
5. Human Director remains final authority for important changes.
6. IC has routine operational autonomy inside approved scope.
7. Routine vs important distinction remains governing.
8. Unknown, ambiguous, or contested semantic classification escalates to `director_required`.
9. Routine synthesis and routine ClassB merge are allowed for IC when they do not change source meaning.
10. Meaning-changing synthesis or merge requires Human Director approval.
11. ClassB is append-oriented; source entries are not rewritten to hide provenance.
12. Projections are generated views, not independent authority.
13. Compact context is the default for CLI/API responses.
14. Cursor/delta discipline prevents full ClassB replay by default.
15. Natural-language output is not automatically ClassB.
16. Structured report candidates require filtering, validation, and gate authorization before import.
17. Assignment state discipline, rework path, and quarantine path remain required.
18. `stratactl` remains the compact IC/backend control surface.
19. Transaction batching remains desirable for reducing IC command chatter.
20. Backend panel remains secondary/operator visibility, not authority.
21. Separate DLO role remains removed from mainline; secondary-hand communication placeholder remains near IC.
22. SRE incident-command remains the core coordination discipline.
23. Scrum is used selectively for bounded work item, DOD, inspect, accept/rework/close.
24. Backend avoids over-orchestration and hidden role intelligence.
25. Document-governance thresholds remain binding.

## 3. Runtime-specific replacements

| v0.4 decision | v0.5 replacement |
|---|---|
| Frozen adapter is fully superseded | Adapter is reinstated as main execution substrate. |
| Session Interface Boundary is main boundary | Runtime Adapter Boundary is restored. |
| Reasonix is main operational surface | Reasonix is optional/manual/non-governing. |
| Strongest proof is Reasonix session creation/chatbox input | Strongest proof is backend packet + adapter run envelope + captured output/report + gate decision. |
| Backend coders should avoid adapter lifecycle control as mainline | Backend coders implement adapter run registry and controlled integration; adapter internals remain below boundary. |
| Logs are only diagnostic proof | Raw logs remain ClassD, but adapter run envelope/transcript/output refs are primary runtime evidence. |

## 4. Preservation rule

When migrating documents or implementation work from v0.4 to v0.5:

```text
Preserve v0.4 governance unless the change is specifically about runtime substrate, proof target, or adapter reinstatement.
```

## 5. Later-version guardrail

A future version may not silently weaken these invariants through implementation work. Any change to these invariants requires an explicit ADR and Human Director approval.
