# 02 - Harness / Strata Architecture Baseline v0.5

| Field | Value |
|---|---|
| Document ID | HS-ARCH-BASE-2026-06-005 |
| Version | v0.5 |
| Issue date | 2026-06-05 |
| Status | Accepted Human Director direction; proposed implementation package |
| Owner | Human Director |
| Maintainer role | Incident Commander prepares updates |
| Scope | Harness / Strata operations governance and backend architecture under Runtime Adapter Boundary |
| Primary source | ADR-HS-2026-06-005 |

## 1. Executive baseline

Harness / Strata coordinates work through durable governance state, compact context packets, bounded assignments, the Codex CLI + DeepSeek runtime adapter, backend CLI operations, report filtering, and authority-gated ClassB updates.

The backend is not the operational brain. It is the durable governance kernel. IC and assigned execution sessions perform operational reasoning and execution while the backend stores, validates, gates, indexes, and projects state.

v0.5 preserves v0.4 governance decisions and changes only the main runtime substrate: Reasonix is demoted from main controllable session interface to optional/manual/non-governing surface; the Codex CLI + DeepSeek adapter is reinstated as the controllable runtime substrate.

## 2. Core architecture principles

| Principle | Baseline rule |
|---|---|
| Durable state | ClassA/B/C/D artifacts and backend records are the operating record. |
| Adapter-first execution | Codex CLI + DeepSeek adapter is the main controllable work surface. |
| Backend as kernel | Backend owns state, validation, packet assembly, mutation gating, audit, and projections. |
| CLI reachability | IC can operate backend through clear stateful `stratactl` commands. |
| Mutation gate | Every authoritative write passes through the Governance Mutation Gate. |
| ClassB memory | ClassB is validated operational memory, not raw logs, transcripts, or chat history. |
| Compact context | Backend responses are brief by default; full records are materialized to files. |
| Human Director authority | Important changes require Human Director approval. |
| Routine autonomy | Routine worker-reviewer-IC updates may proceed without Human Director approval. |
| Append-only discipline | Meaning is preserved by appending derived records rather than rewriting sources. |
| Runtime evidence | Adapter run envelope, transcript/output capture, and artifact capture are primary runtime evidence. |

## 3. Architectural layers

| Layer | Owns |
|---|---|
| Human Director | Final authority for important decisions, ClassA, milestones, policy, templates, validation override, meaning-changing synthesis. |
| IC session | Operational coordination, routine synthesis, assignment routing, backend CLI operation inside approved scope. |
| Secondary-hand communication role | Placeholder near IC for status briefs, Director-facing packets, and communication filtering. Not mandatory as a separate session. |
| Governance backend | State kernel, ClassB memory, context packets, assignments, validation/filtering, projections, audit, panel data. |
| Governance Mutation Gate | Authorization of all writes and prevention of arbitrary/unauthorized backend context changes. |
| Runtime Adapter Boundary | Launch/target Codex CLI, configure DeepSeek, deliver packet/prompt, capture output/transcript/artifacts, emit run envelope. |
| Worker/reviewer/tester/SME sessions | Bounded execution, review, verification, and advisory/implementation tasks through the adapter unless manually assigned otherwise. |
| Reasonix/manual UI surface | Optional human-operated surface only; not authoritative runtime proof. |
| Filesystem/repository/terminal | Work substrate and artifact storage. |

## 4. Context classes

| Class | Name | Baseline behavior |
|---|---|---|
| ClassA | Authoritative operating contract | Accepted architecture/product direction, policy, templates, and milestone authority. |
| ClassB | Validated operational memory | Validated routine and important operational records, indexed and materialized. |
| ClassC | Source pool / durable references | Source documents, package inputs, repo references, external durable material. |
| ClassD | Diagnostic and rejected material | Logs, traces, raw outputs, quarantine artifacts, diagnostic records. |

## 5. Standard operational flow

```text
Human Director / ClassA-C objective
-> IC derives bounded work item
-> IC uses stratactl to create assignment and context packet
-> Governance Mutation Gate authorizes the mutation
-> backend emits compact adapter packet and prompt
-> IC/backend requests adapter run
-> Codex CLI + DeepSeek adapter launches or targets runtime session
-> adapter delivers backend-governed input and captures runtime evidence
-> runtime performs work using terminal/files/tools/backend CLI as authorized
-> adapter returns run envelope, transcript/output, artifacts, and report candidate path when applicable
-> backend filters/validates candidate material
-> Governance Mutation Gate authorizes routine import or requires Human Director approval
-> accepted material updates ClassB: validated operational memory
-> backend updates projections and panel state
```

## 6. Coordination model

The primary coordination model remains SRE incident command. IC coordinates work, uses backend CLI, and maintains operational continuity. Scrum vocabulary remains limited to bounded work control: backlog, ordered item, DOD, inspection, accept/rework/close.

## 7. Implementation invariants

1. IC is the canonical coordinator name.
2. The backend must be reachable from IC session through `stratactl` or equivalent CLI/API.
3. Every authoritative backend write must pass through the Governance Mutation Gate.
4. ClassB means validated operational memory.
5. Routine worker-reviewer-IC loop updates do not require Human Director approval.
6. Important updates require Human Director approval.
7. IC may perform routine synthesis and routine merge.
8. Meaning-changing merge/synthesis requires Human Director approval.
9. ClassB source entries remain append-only; derived synthesis creates new entries with source references.
10. Backend output must be compact by default and link to full materialized files.
11. Codex CLI + DeepSeek adapter is reinstated as the main runtime substrate.
12. Reasonix is optional/manual/non-governing and is not the v0.5 main proof target.
13. DLO is not mandatory; secondary-hand communication remains a placeholder role near IC.
14. Live proof targets backend-governed packet, adapter run envelope, captured runtime output, validated report candidate, and gate-authorized ClassB update.
15. v0.4 governance decisions remain invariant except where explicitly superseded by runtime-adapter reinstatement.

## 8. Current accepted proof state

The v0.5 proof target is adapter-centric. The strongest live proof is backend + IC operations yielding a governed adapter run, Codex CLI + DeepSeek execution, captured output/artifacts, report validation, and gate-authorized ClassB update. Backend panel visibility is secondary proof. Raw logs remain ClassD/diagnostic unless filtered and validated.
