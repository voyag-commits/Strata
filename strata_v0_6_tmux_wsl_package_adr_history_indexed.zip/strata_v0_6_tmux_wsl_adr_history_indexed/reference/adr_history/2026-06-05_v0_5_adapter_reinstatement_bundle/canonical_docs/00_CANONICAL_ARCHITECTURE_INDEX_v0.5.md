# 00 - Canonical Architecture Index v0.5

| Field | Value |
|---|---|
| Document ID | HS-ARCH-IDX-2026-06-005 |
| Version | v0.5 |
| Issue date | 2026-06-05 |
| Status | Accepted Human Director direction; proposed implementation package |
| Document owner | Human Director |
| Maintainer role | Incident Commander prepares updates; Human Director accepts non-trivial changes |
| Scope | Harness / Strata architecture-document hierarchy, supersession, source visibility, runtime-adapter reinstatement, and implementation traceability |
| Applies to | Governance backend, Runtime Adapter Boundary, Governance Mutation Gate, ClassB validated operational memory, IC-operated CLI, Codex CLI + DeepSeek adapter proof |
| Supersedes | v0.4 Session Interface Boundary as main runtime substrate; v0.4 frozen-adapter supersession notice |
| Preserves | v0.4 governance, authority, ClassB, compact-context, `stratactl`, and document-governance decisions |

## 1. Purpose

This index is the controlled entry point for the v0.5 Harness / Strata architecture set.

The v0.5 frame is narrow: preserve the v0.4 governance architecture, but replace the failed Reasonix/session-interface runtime assumption with the controllable local Codex CLI + DeepSeek adapter.

Reasonix is no longer a stable authority-bearing runtime surface because current work shows instability in session spawn, mode change, deterministic input delivery, and output capture. Reasonix may remain optional/manual/non-governing, but it is not the v0.5 main proof target.

## 2. Source precedence

When documents conflict, use this order unless the Human Director gives a later explicit decision:

1. Human Director explicit current decision or accepted ADR.
2. `ADR-HS-2026-06-005` in this bundle.
3. Accepted canonical baseline/spec documents in this bundle.
4. `17_V0_4_CARRY_FORWARD_INVARIANTS_v0.5.md` for preservation rules when migrating between versions.
5. Derived implementation specs that trace to accepted v0.5 architecture.
6. Verification evidence, adapter run evidence, panel evidence, logs, and manifests.
7. v0.4 reference sources and superseded session-interface documents.
8. v0.3 runtime-adapter reference sources.
9. Historical/provenance documents.

## 3. Status taxonomy

| Status | Meaning | Implementation use |
|---|---|---|
| Governing | Accepted architecture or policy authority. | Primary source. |
| Proposed implementation package | Accepted decisions captured for implementation and review. | Usable when explicitly authorized. |
| Derived specification | Implementation spec derived from governing architecture. | Usable when aligned with governing docs. |
| Verification evidence | Adapter run evidence, backend panel evidence, diagnostic logs, manifests. | Proof support. |
| Historical / provenance | Prior architecture, GUI, Reasonix/session-interface, or prototype material retained for traceability. | Reference only. |
| Superseded as runtime substrate | Replaced for v0.5 runtime/proof purposes but may remain reference material. | Do not implement as mainline unless later ADR restores it. |

## 4. Canonical bundle document map

| Doc ID | Path | Title | Status | Purpose |
|---|---|---|---|---|
| HS-ARCH-IDX-2026-06-005 | `00_CANONICAL_ARCHITECTURE_INDEX_v0.5.md` | Canonical Architecture Index | Governing/proposed implementation | Controlled index and precedence. |
| ADR-HS-2026-06-005 | `01_ADR-HS-2026-06-005_Runtime_Adapter_Reinstatement_and_v0_4_Governance_Preservation.md` | Runtime Adapter Reinstatement and v0.4 Governance Preservation ADR | Governing | v0.5 controlling decision. |
| HS-ARCH-BASE-2026-06-005 | `02_HARNESS_STRATA_ARCHITECTURE_BASELINE_v0.5.md` | Architecture Baseline | Governing/proposed implementation | Consolidated architecture baseline. |
| HS-ROLE-2026-06-005 | `03_ROLE_AUTHORITY_MODEL_v0.5.md` | Role Authority Model | Governing/proposed implementation | Authority model for Human Director, IC, backend, gate, adapter, sessions. |
| HS-CLASSB-2026-06-005 | `04_CLASSB_VALIDATED_OPERATIONAL_MEMORY_SPEC_v0.5.md` | ClassB Validated Operational Memory Spec | Governing/proposed implementation | ClassB semantics, routine vs important updates, context-volume controls. |
| HS-BE-2026-06-005 | `05_GOVERNANCE_BACKEND_SPEC_v0.5.md` | Governance Backend Spec | Governing/proposed implementation | Backend kernel objects, services, and mutation control. |
| HS-RAB-2026-06-005 | `06_RUNTIME_ADAPTER_BOUNDARY_SPEC_v0.5.md` | Runtime Adapter Boundary Spec | Governing/proposed implementation | Main runtime boundary using Codex CLI + DeepSeek adapter. |
| HS-STATE-2026-06-005 | `07_ASSIGNMENT_STATE_MACHINE_SPEC_v0.5.md` | Assignment State Machine Spec | Derived/proposed implementation | IC-operated assignment/packet/adapter/report flow. |
| HS-TPL-2026-06-005 | `08_TEMPLATE_AND_REPORT_CONTRACT_v1.3.md` | Template and Report Contract | Derived/proposed implementation | Report filtering and ClassB candidate contract. |
| HS-PROOF-2026-06-005 | `09_LIVE_PROOF_LADDER_v0.5.md` | Live Proof Ladder | Acceptance/proof spec | Proof targets for adapter run envelope, captured output, report candidate, and panel evidence. |
| HS-HIST-2026-06-005 | `10_HISTORICAL_DOCUMENT_REGISTER_v0.5.md` | Historical Document Register | Historical/provenance register | Traceability for v0.3, v0.4, and older materials. |
| HS-DOCGOV-2026-06-005 | `11_CHANGE_CONTROL_AND_DOCUMENT_GOVERNANCE_v0.5.md` | Change Control and Document Governance | Governing process | ADR and document-update process. |
| HS-LAYER-2026-06-005 | `12_LAYER_BOUNDARY_AND_TEAM_CONTRACT_SPEC_v0.5.md` | Layer Boundary and Team Contract Spec | Governing/proposed implementation | Layer split after adapter reinstatement. |
| HS-BACKEND-CODER-2026-06-005 | `13_BACKEND_CODER_IMPLEMENTATION_CONTRACT_v0.5.md` | Backend Coder Implementation Contract | Derived/proposed implementation | Coder instructions for governance kernel, CLI, and adapter integration boundary. |
| HS-ADAPTER-REINSTATE-2026-06-005 | `14_ADAPTER_REINSTATEMENT_NOTICE_v0.5.md` | Adapter Reinstatement Notice | Governing supersession note | Reinstates Codex CLI + DeepSeek adapter as main runtime substrate. |
| HS-BE-SCOPE-2026-06-005 | `15_BACKEND_SCOPE_CLARIFICATION_v0.5.md` | Backend Scope Clarification | Governing addendum | Short backend scope frame. |
| HS-STRATACTL-2026-06-005 | `16_STRATACTL_CLI_AND_IC_OPERATION_SPEC_v0.5.md` | stratactl CLI and IC Operation Spec | Derived/proposed implementation | Compact CLI, permission tiers, and adapter commands. |
| HS-INVARIANTS-2026-06-005 | `17_V0_4_CARRY_FORWARD_INVARIANTS_v0.5.md` | v0.4 Carry-Forward Invariants | Governing preservation addendum | Lists v0.4 decisions preserved across v0.5. |

## 5. Supersession rule

The v0.4 Session Interface Boundary is superseded as the main runtime substrate and proof target.

The v0.4 Governance Mutation Gate, ClassB validated operational memory model, Human Director authority thresholds, IC routine authority, compact context/projection discipline, `stratactl` operation model, and document-governance rules remain governing.

The Codex CLI + DeepSeek adapter is reinstated as the v0.5 main runtime substrate. The local adapter handoff is expected at:

```text
C:\Users\hou16\Downloads\FINAL_ADAPTER_BOUNDARY_CLI_GATES_HANDOFF.zip
```

This bundle records the architecture and interface contract; it does not embed that local zip unless separately copied into the evidence root.
