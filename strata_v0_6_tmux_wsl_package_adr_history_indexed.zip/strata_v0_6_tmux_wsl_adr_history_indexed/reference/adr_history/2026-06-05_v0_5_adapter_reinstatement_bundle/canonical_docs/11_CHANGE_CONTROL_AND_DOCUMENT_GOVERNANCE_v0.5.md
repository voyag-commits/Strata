# 11 - Change Control and Document Governance v0.5

| Field | Value |
|---|---|
| Document ID | HS-DOCGOV-2026-06-005 |
| Version | v0.5 |
| Issue date | 2026-06-05 |
| Status | Accepted Human Director direction; proposed implementation package |
| Owner | Human Director |
| Scope | Document lifecycle, versioning, ADR process, and approval thresholds |
| Primary source | ADR-HS-2026-06-005 |

## 1. Document lifecycle

| Lifecycle state | Meaning |
|---|---|
| Draft | Work in progress. |
| Proposed | Ready for review. |
| Accepted / governing | Human Director accepted; authoritative within scope. |
| Derived | Implementation spec derived from governing docs. |
| Deprecated | Retained for migration and history. |
| Superseded as runtime substrate | Replaced for runtime/proof purposes but retained for provenance. |
| Fully superseded | Replaced and removed from mainline. |
| Archived | Retained for audit. |

## 2. Versioning rule

Use semantic document versioning where practical. v0.5 is a non-trivial architecture revision because it changes runtime substrate and proof target while preserving v0.4 governance decisions.

## 3. ADR requirement

A new ADR or controlled bundle revision is required for changes to:

- Runtime Adapter Boundary;
- Reasonix/session-interface restoration as mainline;
- Governance Mutation Gate policy;
- Human Director vs IC authority threshold;
- ClassA/B/C/D semantics;
- ClassB merge/synthesis policy;
- template/report contract;
- proof ladder;
- security/data-loss/cost/resource posture;
- adapter removal, replacement, or behavior change affecting authority/security/proof;
- mandatory role structure;
- v0.4 carry-forward invariant list.

## 4. Low-risk update path

Maintenance changes may update typos, paths, manifests, checksums, formatting, generated indexes, or non-governing explanatory text without a full ADR.

## 5. Human Director approval requirement

Human Director approval is required for important updates:

- ClassA change/promotion;
- architecture/product direction;
- meaning-changing ClassB synthesis/merge;
- milestone closure;
- governance policy/template changes;
- validation override;
- security, data-loss, or cost/resource posture;
- destructive rewrite/delete;
- adapter behavior change affecting runtime control, input delivery, output capture, security, or proof semantics.

## 6. Routine update path

IC may prepare and apply routine ClassB updates through the Governance Mutation Gate when the gate authorizes the operation and no important-update threshold is crossed.

## 7. Traceability requirement

Every mutation records operation id, actor, target, source refs, gate result, changed records, timestamp, and full record path.

Adapter-linked operations additionally record packet path/hash, prompt path/hash, run id, adapter version, output/transcript/artifact refs, and validation result when applicable.
