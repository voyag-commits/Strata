# 07 - Assignment State Machine Spec v0.5

| Field | Value |
|---|---|
| Document ID | HS-STATE-2026-06-005 |
| Version | v0.5 |
| Issue date | 2026-06-05 |
| Status | Accepted Human Director direction; proposed implementation package |
| Owner | Human Director |
| Scope | Assignment, adapter packet, adapter run, report candidate, ClassB import, and approval state machine |
| Primary source | ADR-HS-2026-06-005 |

## 1. Assignment states

```text
draft
-> proposed
-> active
-> packet_created
-> adapter_run_requested
-> adapter_launching
-> adapter_running
-> adapter_output_captured
-> report_candidate_received
-> validating
-> imported_to_classB | routed_to_rework | director_required | quarantined
-> closed | superseded | cancelled
```

## 2. Packet states

```text
requested
-> built
-> gate_authorized
-> ready_for_adapter_delivery
-> delivered_to_runtime
-> used_by_runtime
-> expired | superseded
```

## 3. Adapter run states

```text
requested
-> authorized
-> launching_or_targeting
-> input_delivered
-> running
-> output_captured
-> envelope_recorded
-> completed | failed | cancelled | terminal_unknown
```

## 4. Report candidate states

```text
received
-> filtered
-> valid_routine | important_requires_director | invalid | unknown_requires_director
-> classB_imported | director_pending | quarantined | rework_requested
```

## 5. Mutation states

```text
requested
-> gate_evaluating
-> allowed | blocked | approval_required
-> committed | rejected | expired
-> audited
```

## 6. Routine loop

Routine worker-reviewer-IC loop:

```text
IC creates assignment
-> backend builds packet
-> MutationGate authorizes packet creation
-> IC/backend requests adapter run
-> adapter receives packet and delivers prompt/input to Codex CLI + DeepSeek runtime
-> runtime completes work
-> adapter captures output/artifacts/run envelope
-> backend receives or extracts report candidate
-> backend validates/filters candidate
-> MutationGate authorizes routine ClassB update
-> projection updates
-> IC routes next work or closure recommendation
```

Human Director approval is not required unless the update is important or classification is unknown/ambiguous.

## 7. Important-update path

If a candidate update is architecture/product-directional, meaning-changing, ClassA-related, template/policy-related, milestone-closing, security/cost/resource-related, override-related, destructive, adapter-behavior-changing, or semantically unknown:

```text
candidate marked director_required
-> backend creates pending Director decision packet
-> no active ClassB mutation occurs until approval
-> Human Director accepts/rejects/redirects
-> MutationGate commits or blocks accordingly
```

## 8. Rework path

If a report is mechanically valid but fails DOD or review:

```text
report candidate
-> routine ClassB record of finding may be created
-> assignment routed_to_rework
-> IC creates revised assignment or packet
```

## 9. Quarantine path

Malformed, invalid, unsafe, out-of-scope, or input-integrity-failing material is stored in ClassD/quarantine. Quarantine records are diagnostic and not active ClassB unless later filtered and approved.

## 10. Allowed transition table

| From | To | Actor | Gate? | Notes |
|---|---|---:|---:|---|
| draft/proposed | active | IC | yes | Routine assignment activation. |
| active | packet_created | IC/backend | yes | Packet creation must be scoped to assignment. |
| packet_created | adapter_run_requested | IC | yes | Routine if within assignment scope. |
| adapter_run_requested | adapter_running | adapter/system | audit | Runtime evidence append only; no ClassB mutation. |
| adapter_running | adapter_output_captured | adapter/system | audit | Captured evidence becomes runtime evidence/ClassD by default. |
| report_candidate_received | validating | backend/system | yes | Mechanical validation and policy filtering. |
| validating | imported_to_classB | IC/backend | yes | Valid routine only. |
| validating | director_required | backend/system | yes/audit | No active ClassB mutation. |
| director_required | imported_to_classB | Human Director | yes | Requires approval_ref. |
| validating | routed_to_rework | IC/backend | yes | Routine DOD failure or review finding. |
| validating | quarantined | IC/backend/system | yes/audit | Invalid, unsafe, malformed, out-of-scope. |
| quarantined | active/imported_to_classB | Human Director | yes | Only through explicit override or approved transform. |
| routed_to_rework | active | IC | yes | Revised assignment or packet. |
| imported_to_classB | closed | IC | yes | Routine closure only; milestone closure still HD. |
