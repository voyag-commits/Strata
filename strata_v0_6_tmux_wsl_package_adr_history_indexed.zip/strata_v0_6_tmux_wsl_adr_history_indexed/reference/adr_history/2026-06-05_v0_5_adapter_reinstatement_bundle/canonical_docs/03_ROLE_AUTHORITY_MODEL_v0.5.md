# 03 - Role Authority Model v0.5

| Field | Value |
|---|---|
| Document ID | HS-ROLE-2026-06-005 |
| Version | v0.5 |
| Issue date | 2026-06-05 |
| Status | Accepted Human Director direction; proposed implementation package |
| Owner | Human Director |
| Scope | Authority boundaries for Human Director, IC, secondary-hand communication, sessions, backend, adapter, and Governance Mutation Gate |
| Primary source | ADR-HS-2026-06-005 |

## 1. Role summary

| Role | Primary responsibility | Authority frame |
|---|---|---|
| Human Director | Final authority for important direction, ClassA, policy, templates, milestones, overrides, and meaning-changing synthesis. | Approves, rejects, supersedes, or redirects important decisions. |
| Incident Commander (IC) | Coordinates work, operates backend CLI, routes assignments, performs routine synthesis/merge, prepares decisions. | Operational authority inside approved scope. |
| Secondary-hand communication role | Placeholder near IC for status briefs, Director-facing packets, escalation prompts, communication cleanup. | Communication role; no independent decision authority by default. |
| Worker session | Executes one bounded assignment. | Output is candidate evidence or report material. |
| Reviewer session | Reviews worker/tester/SME evidence and recommends accept/rework/supersession. | May support routine ClassB status updates when authorized. |
| Tester session | Verifies mechanical correctness. | Mechanical failure blocks routine closure. |
| SME session | Provides bounded specialist judgment or implementation when explicitly assigned. | Advisory by default. |
| Runtime adapter | Launches/targets Codex CLI, configures DeepSeek, delivers backend-governed input, captures evidence. | Execution transport only; no governance mutation authority. |
| Governance backend | Stores state, assembles context, validates/filters reports, indexes ClassB, exposes projections. | Deterministic state kernel. |
| Governance Mutation Gate | Authorizes or blocks every backend mutation. | Enforces authority, approval threshold, validation status, and audit. |
| Reasonix/manual UI surface | Optional human-operated prompt/work interface. | Non-governing; not authoritative storage or required proof. |

## 2. Authority matrix

| Action | Human Director | IC | Secondary hand | Worker/reviewer/tester/SME | Runtime adapter | Backend | Governance Mutation Gate |
|---|---:|---:|---:|---:|---:|---:|---:|
| Approve architecture/product direction | A | R prep | C | C | N | Records | Enforces HD approval |
| Promote/modify ClassA | A | R prep | C | C | N | Records | Requires HD approval |
| Change template/report contract | A | R prep | C | C | N | Records | Requires HD approval |
| Create routine assignment | C | A/R | C | N | N | Records | Authorizes if in scope |
| Create context packet | C | A/R | C | N | N | Records | Authorizes if in scope |
| Request adapter run | C | A/R | C | N | Executes | Records | Authorizes if in scope |
| Deliver packet/prompt to runtime | N | R | N | N | A/R | Records evidence | Authorizes request record if needed |
| Capture runtime evidence | N | R inspect | N | C | A/R | Records evidence | Authorizes evidence record if needed |
| Import valid routine report into ClassB | N | A/R | C | C | N | Records | Authorizes if valid routine update |
| Routine synthesis/merge | N | A/R | C | C | N | Records | Authorizes if non-meaning-changing |
| Meaning-changing synthesis/merge | A | R prep | C | C | N | Records | Requires HD approval |
| Mark routine entry superseded/obsolete | Override | A/R | C | C | N | Records | Authorizes if scoped |
| Override validation failure | A | R prep | C | C | N | Records | Requires HD approval |
| Close milestone | A | R prep | C | C | N | Records | Requires HD approval |
| Delete/destructively rewrite records | A | R prep | C | N | N | Records | Requires HD approval and audit |

Legend: A = accountable/final authority; R = responsible executor/preparer; C = consulted/input; N = no ordinary authority.

## 3. IC authority frame

IC may autonomously perform routine operational coordination:

- create bounded assignments;
- create context packets;
- request adapter runs within approved assignment scope;
- collect adapter evidence;
- validate/import routine reports;
- route rework;
- mark routine implementation entries superseded or obsolete;
- perform routine synthesis and routine ClassB merge;
- update operational projections through backend mechanisms;
- prepare milestone or Director-decision packets.

IC may not autonomously perform:

- ClassA changes;
- architecture/product-direction synthesis;
- meaning-changing ClassB merge;
- template/governance policy changes;
- milestone closure;
- security, data-loss, or cost/resource posture changes;
- validation override;
- destructive rewrite or deletion;
- adapter behavior changes that alter authority, security, or proof semantics.

## 4. Secondary-hand communication role

The prior DLO role is replaced by a secondary-hand communication placeholder near IC.

Default properties:

```yaml
role_name: secondary_hand_communication
near: incident_commander
decision_authority: none_by_default
primary_outputs:
  - status_brief
  - director_packet
  - escalation_prompt
  - communication_cleanup
  - stakeholder_summary
```

This role may later become a session, panel mode, export mode, or IC subroutine. It is not mandatory for v0.5 mainline operation.

## 5. Runtime adapter authority

The adapter is not a governance actor with decision authority. It is an execution transport.

The adapter may:

- launch or target Codex CLI;
- apply approved DeepSeek provider/model configuration;
- deliver backend-governed packet/prompt input;
- capture runtime transcript/output/artifacts/diagnostics;
- report status and run envelope to the backend.

The adapter may not:

- write ClassA or ClassB directly;
- approve, reject, or override validation;
- alter assignment scope or DOD;
- synthesize governance memory;
- mutate templates, policies, milestones, or authority thresholds;
- hide, rewrite, or selectively omit captured evidence without recording that fact.

## 6. Governance Mutation Gate authority

The gate is not a reasoning agent. It is a deterministic authorization layer. It evaluates actor, operation, target, validation state, required approval level, and audit requirements before any authoritative write is committed.
