# 13 - Backend Coder Implementation Contract v0.5

| Field | Value |
|---|---|
| Document ID | HS-BACKEND-CODER-2026-06-005 |
| Version | v0.5 |
| Issue date | 2026-06-05 |
| Status | Accepted Human Director direction; proposed implementation package |
| Owner | Human Director |
| Scope | Backend coder instructions for governance kernel, MutationGate, `stratactl`, adapter run registry, projections, and panel support |
| Primary source | ADR-HS-2026-06-005 |

## 1. Backend coder mandate

Backend coders implement a deterministic governance kernel. The kernel must expose clear stateful commands and enforce authority through the Governance Mutation Gate.

The backend is complete only when IC can operate it without consuming excessive session context, request adapter runs through controlled records, validate captured output, and avoid arbitrary direct edits to governance memory.

## 2. Required implementation objects

- ClassA store;
- ClassB memory store and index;
- ClassC source references;
- ClassD quarantine/diagnostic store;
- assignment records;
- context packet records;
- adapter run request records;
- adapter run envelope/evidence records;
- report candidate records;
- validation records;
- mutation request and gate result records;
- audit records;
- projection files;
- panel state feed.

## 3. Required command surface

Minimum `stratactl` support:

```text
stratactl state
stratactl classb list
stratactl classb read <id>
stratactl assignment create ...
stratactl packet create --for <role> --assignment <id> ...
stratactl adapter run --assignment <id> --packet <packet_id>
stratactl adapter status <run_id>
stratactl adapter collect <run_id>
stratactl adapter evidence <run_id>
stratactl report validate <path>
stratactl report import <path>
stratactl classb synthesize --routine ...
stratactl classb supersede <id> --by <id>
stratactl director decision-packet ...
stratactl gate check ...
```

## 4. Output rule

Default command output must be compact. Full detail should be materialized to file and referenced by path.

Supported modes:

```text
--view brief      default, context-safe
--view standard   moderate detail
--view full       full detail written to file, path returned
--json            machine-readable compact result
```

## 5. MutationGate requirement

No authoritative backend write may bypass the gate. This includes generated projections when the projection update is tied to a committed mutation.

Coder tests must include:

- allowed routine IC update;
- allowed routine adapter run request inside assignment scope;
- adapter evidence append that does not become ClassB automatically;
- blocked meaning-changing merge without approval;
- allowed Human Director-approved important update;
- blocked validation override by IC;
- append-only ClassB synthesis with source refs;
- unknown/ambiguous semantic classification escalates to `director_required`.

## 6. Backend completion criteria

A v0.5 backend change is complete when CLI or tests can demonstrate:

```text
create assignment
-> create context packet
-> gate-authorize routine mutation
-> request adapter run
-> record adapter run envelope/evidence
-> validate/filter report candidate
-> import routine ClassB update
-> block important update pending Human Director approval
-> update projection
-> show panel state
-> reconstruct operation from audit record
```

Credentialed live proof then attaches Codex CLI + DeepSeek adapter execution evidence.

## 7. Exclusions

Backend coders should not implement agent reasoning inside the backend. They should not make adapter outputs authoritative without validation and gate authorization.

Backend coders may implement adapter-run registry commands and integration points, but adapter internals remain below the Runtime Adapter Boundary unless explicitly assigned.

## 8. Secret/redaction rule

Backend code must treat adapter transcripts, stderr, diagnostics, and environment summaries as potential secret-bearing evidence. Exports and panel views must redact secrets or quarantine restricted evidence before display.
