# 08 - Template and Report Contract v1.3

| Field | Value |
|---|---|
| Document ID | HS-TPL-2026-06-005 |
| Version | v1.3 |
| Issue date | 2026-06-05 |
| Status | Accepted Human Director direction; proposed implementation package |
| Owner | Human Director |
| Scope | Adapter/runtime output, structured report candidate, validation/filtering, and ClassB import contract |
| Primary source | ADR-HS-2026-06-005 |

## 1. Purpose

The report contract defines how runtime output becomes a candidate for ClassB: validated operational memory.

A report is not automatically authoritative. It must be filtered, validated, and authorized through the Governance Mutation Gate.

## 2. Output classes

| Output class | Treatment |
|---|---|
| Natural-language response | May guide IC or Human Director; not automatically ClassB. |
| Structured report candidate | Eligible for validation/filtering and ClassB import. |
| Artifact path | Verifiable file reference; may support report candidate. |
| Adapter run envelope | Runtime evidence; not automatically ClassB. |
| Transcript/stdout/stderr | ClassD or runtime evidence by default. |
| Diagnostic log/trace | ClassD by default. |
| Director-decision recommendation | Pending decision material, not active authority. |

## 3. Consolidated report rule

For worker/reviewer/tester/SME/secondary-hand assignments intended to affect ClassB, the run must produce exactly one structured report candidate file per assignment run.

Natural-language responses may accompany the report, but they are not eligible for ClassB import unless extracted into the structured report candidate and validated.

## 4. Minimal structured report candidate

A structured report candidate should include:

```yaml
assignment_id: string
run_id: string | null
role: ic | worker | reviewer | tester | sme | secondary_hand
summary: string
dod_result: pass | fail | partial | not_applicable
routine_or_important: routine | important | unknown
classification_basis: string
classb_update_type: report | review | synthesis | merge | status | blocker | rework | director_recommendation
source_refs: [id_or_path]
artifacts: [path]
risks: [string]
recommended_next_action: string
```

## 5. Validation checks

Backend validation should check:

- assignment id exists;
- run id exists when adapter run evidence is claimed;
- role is allowed;
- required fields exist;
- source references are resolvable when required;
- artifact paths exist when claimed;
- DOD result is explicit;
- routine vs important classification is present;
- unknown or ambiguous classification escalates to `director_required`;
- no prohibited mutation is attempted without approval;
- report does not attempt to rewrite ClassA/ClassB directly;
- report candidate hash matches the captured artifact when derived from adapter output.

## 6. Import rule

A report candidate may become ClassB only when:

```text
filtering passes
and validation passes
and Governance Mutation Gate authorizes the mutation
```

## 7. Runtime-proof relation

Structured report evidence is part of the v0.5 live proof path when the loop claims ClassB impact. The strongest v0.5 proof target is backend + IC operation producing an authorized adapter run, captured runtime output, a structured report candidate, backend validation, and gate-authorized ClassB update.

## 8. Anti-repair rule

The backend must validate the raw submitted report candidate. It must not synthesize, repair, wrap, or rewrite invalid raw output into a valid ClassB report unless a separate explicit transform record is created. If meaning could change, Human Director approval is required.

## 9. Quarantine rule

Malformed, invalid, unsafe, out-of-scope, or input-integrity-failing reports go to ClassD/quarantine with a reason and source path.
