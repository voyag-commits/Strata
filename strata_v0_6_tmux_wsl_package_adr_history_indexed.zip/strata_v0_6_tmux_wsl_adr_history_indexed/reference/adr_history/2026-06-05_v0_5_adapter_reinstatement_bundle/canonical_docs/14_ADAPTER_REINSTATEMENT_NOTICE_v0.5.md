# 14 - Adapter Reinstatement Notice v0.5

| Field | Value |
|---|---|
| Document ID | HS-ADAPTER-REINSTATE-2026-06-005 |
| Version | v0.5 |
| Issue date | 2026-06-05 |
| Status | Governing supersession notice |
| Owner | Human Director |
| Scope | Status of Codex CLI + DeepSeek adapter materials after v0.5 runtime correction |
| Primary source | ADR-HS-2026-06-005 |
| Local adapter handoff | `C:\Users\hou16\Downloads\FINAL_ADAPTER_BOUNDARY_CLI_GATES_HANDOFF.zip` |

## 1. Decision

The Codex CLI + DeepSeek adapter path is reinstated as the mainline runtime substrate.

## 2. Meaning

v0.4 superseded the adapter because Reasonix/session-interface operation appeared to reduce the need for backend-owned runtime orchestration.

Current work shows Reasonix is not stable for spawn, mode change, deterministic input delivery, or output capture. These are required runtime controls.

Therefore v0.5 restores the adapter as the controllable execution boundary while preserving v0.4 governance.

## 3. Current status

| Item | Status |
|---|---|
| Codex CLI + DeepSeek API adapter | Mainline runtime substrate. |
| Runtime Adapter Boundary | Restored and updated for v0.5. |
| Adapter run envelope as primary runtime evidence | Restored. |
| Backend governance kernel | Preserved from v0.4. |
| Governance Mutation Gate | Preserved and mandatory. |
| ClassB validated operational memory | Preserved. |
| Reasonix session-interface proof | Superseded as mainline proof; optional/manual/non-governing. |
| Local adapter handoff zip | External implementation input at the recorded local path. |

## 4. Active replacement for v0.4 session path

The active v0.5 path is:

```text
backend packet + adapter run request
-> Codex CLI + DeepSeek adapter
-> governed prompt/input delivery
-> runtime execution
-> output/transcript/artifact capture
-> adapter run envelope
-> report candidate
-> backend validation/filtering and gated ClassB update
```

## 5. Adapter constraint

The adapter is not an authority layer. It may execute work and capture evidence. It may not commit governance state.

Any adapter behavior change that alters runtime control, input delivery, output capture, security posture, or proof semantics requires Human Director approval and controlled document update.

## 6. Local handoff pointer

Expected local handoff:

```text
C:\Users\hou16\Downloads\FINAL_ADAPTER_BOUNDARY_CLI_GATES_HANDOFF.zip
```

This bundle does not embed or verify that local archive. Implementation work should copy it into the working/evidence root and record its checksum before use.
