# 15 - Backend Scope Clarification v0.5

| Field | Value |
|---|---|
| Document ID | HS-BE-SCOPE-2026-06-005 |
| Version | v0.5 |
| Issue date | 2026-06-05 |
| Status | Accepted Human Director direction; proposed implementation package |
| Owner | Human Director |
| Scope | Compressed backend scope clarification for ADR and coder use |
| Primary source | ADR-HS-2026-06-005 |

## 1. Controlling frame

The backend is a deterministic governance kernel for validated operational memory, context packets, report validation/filtering, authority-gated mutation, projections, audit, and adapter run records.

Codex CLI + DeepSeek adapter is the main controllable runtime substrate.

## 2. Backend owns

```text
state
context packets
ClassB validated operational memory
validation/filtering
Governance Mutation Gate
adapter run registry
projections
panel state
audit
compact CLI/API
```

## 3. Backend does not own

```text
agent intelligence
role reasoning
DeepSeek model behavior
Codex CLI internals
raw transcript as memory
arbitrary merge of unapproved context
adapter direct writes to governance state
Reasonix as mainline proof substrate
```

## 4. Adapter owns

```text
launch or target Codex CLI
apply approved DeepSeek provider/model config
deliver backend-governed prompt/input
capture transcript/stdout/stderr/artifacts/diagnostics
return run envelope
report terminal status
```

## 5. Operating loop

```text
IC asks backend for state/projection
-> IC creates assignment or packet through stratactl
-> MutationGate authorizes write
-> backend emits compact adapter packet
-> IC/backend requests adapter run
-> adapter executes Codex CLI + DeepSeek run
-> adapter captures output/evidence
-> backend filters/validates candidate result
-> MutationGate authorizes routine ClassB update or requires Human Director approval
-> projections update
```

## 6. Implementation test

The v0.5 backend is acceptable when an IC session can operate the backend through compact CLI commands, produce governed adapter packets, record adapter evidence, import routine validated ClassB updates, block important unauthorized mutations, and show state through the backend panel.
