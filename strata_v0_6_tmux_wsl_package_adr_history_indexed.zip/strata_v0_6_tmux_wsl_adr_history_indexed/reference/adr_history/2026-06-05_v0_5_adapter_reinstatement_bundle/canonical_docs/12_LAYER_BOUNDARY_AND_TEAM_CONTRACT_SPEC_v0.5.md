# 12 - Layer Boundary and Team Contract Spec v0.5

| Field | Value |
|---|---|
| Document ID | HS-LAYER-2026-06-005 |
| Version | v0.5 |
| Issue date | 2026-06-05 |
| Status | Accepted Human Director direction; proposed implementation package |
| Owner | Human Director |
| Scope | Layer boundaries after runtime-adapter reinstatement |
| Primary source | ADR-HS-2026-06-005 |

## 1. Decision

The main implementation architecture has five bounded layers:

1. **Governance backend kernel** - state, ClassB memory, validation, packet creation, projections, audit, panel data.
2. **Governance Mutation Gate** - all authoritative write authorization and approval-threshold enforcement.
3. **IC/session operation layer** - IC uses `stratactl` to coordinate work and request adapter runs.
4. **Runtime adapter layer** - Codex CLI + DeepSeek adapter handles controllable execution lifecycle and evidence capture.
5. **Execution runtime layer** - Codex CLI with DeepSeek API performs bounded work under packet constraints.

Reasonix/manual UI is optional/non-governing and not part of the mainline v0.5 proof boundary.

## 2. Backend layer rule

Backend coders implement deterministic state and authority components. The backend does not need to know how to perform the work. It needs to know what was authorized, what was packetized, what runtime evidence was captured, what was validated, what was committed, and what requires Human Director approval.

## 3. IC/session layer rule

IC performs operational coordination and can operate backend commands. IC chooses when to create assignments, route rework, read projections, import routine reports, request adapter runs, or prepare Director packets. IC cannot bypass the gate.

## 4. Runtime adapter rule

The adapter must support:

- launching or targeting Codex CLI;
- applying approved DeepSeek provider/model configuration without leaking secrets;
- delivering backend-governed packet/prompt input;
- preserving packet and prompt hashes;
- capturing transcript/stdout/stderr/artifacts/diagnostics;
- emitting a run envelope;
- reporting terminal status;
- preserving enough evidence to support the live proof target.

The adapter does not own governance decisions.

## 5. Team boundary

| Team / workstream | Owns | Consumes |
|---|---|---|
| Backend governance coder | Stores, MutationGate, validation/filtering, projections, `stratactl`, adapter run registry, panel API. | v0.5 ADR and context/report/adapter contracts. |
| Adapter coder/integration | Codex CLI + DeepSeek launch/target, input delivery, output capture, run envelope, diagnostics. | Backend packet/run request contract. |
| IC/operator workflow | Work routing, backend command use, routine synthesis, Director packet prep, adapter-run requests. | `stratactl`, projections, packets, adapter evidence summaries. |
| UI/panel | Secondary proof and operator visibility. | Backend state/projections/events/adapter evidence. |
| Reasonix/manual workflow | Optional ad hoc work only. | May reference backend state, but is not mainline proof. |

## 6. Acceptance split

Acceptance proceeds in this order:

1. Backend kernel and MutationGate tests.
2. `stratactl` compact IC operation proof.
3. Adapter smoke proof against Codex CLI + DeepSeek.
4. Backend-adapter integration proof.
5. Backend panel secondary-proof view.
6. Worker-reviewer-IC loop through adapter and gate-authorized ClassB updates.

## 7. Conflict rule

Layer conflicts are resolved by source precedence. If the conflict changes authority threshold, boundary, ClassB meaning, proof target, adapter status, or Reasonix status, a Human Director decision is required.
