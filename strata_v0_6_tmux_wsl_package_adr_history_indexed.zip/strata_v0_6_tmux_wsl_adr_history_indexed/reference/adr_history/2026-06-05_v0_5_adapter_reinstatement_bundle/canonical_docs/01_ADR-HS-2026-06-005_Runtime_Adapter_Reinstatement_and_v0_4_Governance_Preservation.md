# 01 - ADR-HS-2026-06-005: Runtime Adapter Reinstatement and v0.4 Governance Preservation

| Field | Value |
|---|---|
| ADR ID | ADR-HS-2026-06-005 |
| Version | v0.5 |
| Issue date | 2026-06-05 |
| Status | Accepted Human Director direction; proposed implementation package |
| Owner | Human Director |
| Scope | Main Harness / Strata runtime substrate, backend authority model, and v0.4 governance preservation |
| Supersedes | ADR-HS-2026-06-004 only where it made Reasonix/session-interface the main runtime boundary or fully superseded the adapter |
| Preserves | ADR-HS-2026-06-004 governance decisions: Governance Mutation Gate, ClassB validated operational memory, Human Director authority thresholds, IC routine authority, compact context/projection discipline, and `stratactl` |

## 1. Context

v0.4 correctly established the governance architecture: backend as deterministic governance kernel, ClassB as validated operational memory, all authoritative writes through the Governance Mutation Gate, compact context packets, `stratactl`, IC routine autonomy, and Human Director authority over important decisions.

However, current implementation work shows that Reasonix is not a stable controllable runtime surface for:

- session spawn;
- mode change;
- deterministic input delivery;
- output capture.

These are core requirements for an execution substrate. Therefore the v0.4 Session Interface Boundary cannot remain the main runtime/proof boundary.

A previous adapter path already exists: a local Codex CLI + DeepSeek API adapter handoff at:

```text
C:\Users\hou16\Downloads\FINAL_ADAPTER_BOUNDARY_CLI_GATES_HANDOFF.zip
```

v0.5 reinstates that adapter as the main controllable runtime substrate while preserving the v0.4 governance layer.

## 2. Decision

Harness / Strata v0.5 adopts the **Runtime Adapter Boundary** as the main execution boundary.

The runtime substrate is:

```text
Codex CLI + DeepSeek API adapter
```

The governance substrate remains:

```text
Governance backend + Governance Mutation Gate + ClassB validated operational memory + stratactl
```

Reasonix is demoted to optional/manual/non-governing status. It may be used for ad hoc human work, but it is not required for v0.5 proof and must not be treated as an authoritative session-control substrate.

## 3. Accepted decisions

| Decision | Accepted rule |
|---|---|
| Runtime substrate | Codex CLI + DeepSeek API adapter is reinstated as mainline. |
| Main boundary | Runtime Adapter Boundary. |
| Reasonix status | Optional/manual/non-governing; not the primary proof target. |
| Backend write-control component | Governance Mutation Gate remains mandatory. |
| ClassB name | ClassB: validated operational memory. |
| IC synthesis authority | IC may perform routine synthesis; architecture/product-direction synthesis requires Human Director approval. |
| ClassB merge policy | Routine merge allowed by IC; meaning-changing merge requires Human Director approval. |
| DLO | Separate DLO role remains removed from mainline; secondary-hand communication placeholder remains near IC. |
| Live proof target | Strongest proof is backend-governed packet -> adapter run envelope -> captured Codex/DeepSeek output -> validated report candidate -> gate-authorized ClassB update. |
| Secondary proof | Backend panel. |
| Logs | ClassD/diagnostic by default; adapter run envelope and captured transcript/output are runtime evidence but not automatically ClassB. |

## 4. Consequences

### 4.1 Backend remains the governance kernel

The backend owns state, validation, context packet creation, ClassB updates, mutation authorization, audit, projections, compact CLI/API responses, and panel data.

The backend does not become the agent brain. It does not own role-specific reasoning or write governance state outside the gate.

### 4.2 Adapter owns controllable execution lifecycle

The adapter is responsible for controlled runtime I/O only:

- launch or target Codex CLI session;
- configure DeepSeek API provider/model via approved runtime configuration;
- deliver backend-rendered packet/prompt;
- capture stdout/stderr/transcript/diagnostics/artifacts;
- capture exit status and terminal state;
- emit an adapter run envelope;
- expose raw report candidates to the backend.

The adapter may not directly mutate ClassA, ClassB, policy, templates, milestones, approvals, projections, or authoritative governance state.

### 4.3 IC remains the operating coordinator

IC may use `stratactl` to inspect state, create assignments, assemble packets, request adapter runs, collect adapter evidence, validate/import routine reports, route rework, and perform routine ClassB synthesis.

IC cannot bypass the Governance Mutation Gate.

### 4.4 Human Director authority remains explicit

Human Director approval is required for:

- ClassA promotion or modification;
- architecture/product-direction changes;
- meaning-changing ClassB synthesis or merge;
- milestone closure;
- governance policy or template changes;
- security, data-loss, cost/resource posture changes;
- validation override;
- deletion, destructive rewrite, or irreversible mutation;
- runtime-adapter behavior changes that alter execution authority, security posture, input/output capture semantics, or proof semantics.

Routine worker-reviewer-IC loop updates do not require Human Director approval unless they cross one of these thresholds.

## 5. New standard loop

```text
Governance backend prepares compact context packet
-> IC requests adapter run through stratactl or approved backend command
-> Runtime Adapter launches/targets Codex CLI with DeepSeek API configuration
-> adapter delivers backend-governed prompt/context packet
-> Codex/DeepSeek session executes using terminal/files/tools/backend CLI as authorized
-> adapter captures transcript, stdout/stderr, artifacts, exit status, and run envelope
-> backend extracts/receives exactly one structured report candidate when ClassB impact is intended
-> backend filters/validates report candidate
-> Governance Mutation Gate authorizes routine mutation or requires Human Director approval
-> accepted result updates ClassB: validated operational memory
-> backend projections update for next IC/adapter operation
```

## 6. Superseded v0.4 behavior

The following v0.4 assumptions are no longer governing:

- Reasonix is the main controllable work surface;
- Reasonix session creation and chatbox input are the strongest live proof target;
- adapter run envelope is superseded as primary proof;
- frozen adapter/Codex CLI + DeepSeek bridge is historical-only;
- backend implementation must avoid adapter lifecycle integration as mainline.

## 7. Preserved v0.4 behavior

The following v0.4 decisions remain governing:

- backend as deterministic governance kernel;
- Governance Mutation Gate for every authoritative write;
- ClassB as validated operational memory;
- ClassA/B/C/D class semantics;
- Human Director authority thresholds;
- IC routine operational autonomy;
- routine vs important classification;
- append-oriented ClassB provenance;
- compact context/projection/cursor discipline;
- structured report validation before import;
- secondary-hand communication placeholder instead of mandatory DLO;
- SRE incident-command coordination model;
- `stratactl` compact command surface;
- document-governance thresholds.

## 8. Implementation direction

Implement or wire `stratactl` adapter commands without giving the adapter governance authority.

Treat adapter evidence as input to backend validation, not as automatic memory.

Use the local adapter handoff zip as runtime implementation input when available:

```text
C:\Users\hou16\Downloads\FINAL_ADAPTER_BOUNDARY_CLI_GATES_HANDOFF.zip
```
