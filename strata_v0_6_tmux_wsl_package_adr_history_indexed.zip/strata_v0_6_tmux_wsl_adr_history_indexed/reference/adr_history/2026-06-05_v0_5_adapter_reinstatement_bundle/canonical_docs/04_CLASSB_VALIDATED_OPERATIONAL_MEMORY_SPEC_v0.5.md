# 04 - ClassB: Validated Operational Memory Spec v0.5

| Field | Value |
|---|---|
| Document ID | HS-CLASSB-2026-06-005 |
| Version | v0.5 |
| Issue date | 2026-06-05 |
| Status | Accepted Human Director direction; proposed implementation package |
| Owner | Human Director |
| Scope | ClassA/B/C/D semantics, ClassB memory, update authority, runtime evidence, and context-volume control |
| Primary source | ADR-HS-2026-06-005 |

## 1. Definition

**ClassB: validated operational memory** is the durable, indexed, materialized memory of operational facts, reports, reviews, synthesis records, status changes, and accepted routine updates.

ClassB is not raw chat history. ClassB is not arbitrary logs. ClassB is not raw adapter transcript. ClassB is not uncontrolled notes. ClassB entries are created only after validation/filtering and Governance Mutation Gate authorization.

## 2. Storage model

| Object | Purpose |
|---|---|
| ClassB entry file | Human-readable durable memory record. |
| ClassB JSON index | Machine-readable index for selection, status, source refs, tags, cursoring. |
| Derived synthesis entry | New appended record summarizing or merging source entries. |
| Projection file | Compact current-state view generated from ClassB and active records. |
| Runtime evidence record | Adapter run envelope, transcript/output refs, artifact refs, and capture metadata. |
| Quarantine / ClassD record | Rejected, malformed, raw, or diagnostic material. |

## 3. ClassB statuses

| Status | Meaning |
|---|---|
| candidate | Submitted material not yet validated/imported. |
| active | Validated memory currently usable for context. |
| routine_synthesis | IC-created routine synthesis with source references. |
| director_required | Material cannot become active without Human Director approval. |
| superseded | Replaced by newer active or accepted derived entry. |
| obsolete | Retained for history but not included in normal context packets. |
| suspended | Temporarily withheld pending review. |
| promoted_to_classA | Source or derived content promoted into authoritative ClassA by Human Director. |
| quarantined | Invalid, malformed, rejected, or diagnostic-only material. |

## 4. Routine vs important updates

### Routine updates

Routine updates may be imported or synthesized by IC when mechanically valid and in scope:

- worker report within an accepted assignment;
- reviewer findings inside assignment scope;
- tester result;
- routine IC status summary;
- routine implementation merge summary;
- supersession of implementation detail;
- rework routing;
- artifact validation result;
- adapter run/evidence status when it does not change architecture, policy, authority, security, or proof semantics.

### Important updates

Important updates require Human Director approval:

- architecture or product direction;
- ClassA promotion/change;
- milestone closure;
- policy/template/report-contract change;
- security, data-loss, or cost/resource posture;
- validation override;
- meaning-changing ClassB synthesis or merge;
- deletion, destructive rewrite, or irreversible mutation;
- adapter behavior change that affects authority, security, runtime control, input delivery, output capture, or proof semantics.

If routine-vs-important classification is absent, ambiguous, contested, or touches architecture/product/policy/template/security/cost/milestone semantics, default to `director_required`.

## 5. Merge and synthesis policy

ClassB is append-oriented. Source entries are not rewritten to hide provenance.

Routine merge rule:

```text
IC may create a new routine synthesis ClassB entry that references source entries and does not change their meaning.
```

Meaning-changing merge rule:

```text
If the merge changes architecture/product meaning, reverses prior direction, or makes a higher-authority conclusion, it requires Human Director approval before becoming active.
```

## 6. Runtime evidence relation

Adapter run envelopes, transcripts, stdout/stderr, diagnostics, screenshots, and raw artifacts are runtime evidence. They are stored as evidence records or ClassD references by default.

Runtime evidence becomes ClassB only when:

```text
extracted material is structured as a report candidate
and filtering passes
and validation passes
and the Governance Mutation Gate authorizes import
```

## 7. Context-volume control for IC

IC backend use must not consume large session context.

Backend CLI/API responses are compact by default and return:

```yaml
status: string
operation_id: string
changed_records: [id]
short_summary: string
full_record_path: path
next_recommended_command: string | null
```

Full records are materialized to files. IC reads them only when needed.

## 8. Projections

Backend maintains compact projection files for frequent IC use:

```text
active_state.md
open_assignments.md
latest_classb_delta.md
current_blockers.md
next_actions.md
pending_director_decisions.md
adapter_runs.md
```

Projections are generated views, not independent authority. If a projection conflicts with source ClassA/ClassB records, the source record controls until corrected.

## 9. Cursor and delta rule

IC should receive deltas, not replay the full ClassB memory. Each IC operation records a cursor. The backend can produce:

```text
latest delta since cursor
active projection
selected packet for assignment
adapter run summary since cursor
full record path on demand
```

## 10. Diagnostic logs

Logs belong to ClassD unless filtered and validated into ClassB. Adapter logs are useful proof support, but raw logs are not validated operational memory by themselves.
