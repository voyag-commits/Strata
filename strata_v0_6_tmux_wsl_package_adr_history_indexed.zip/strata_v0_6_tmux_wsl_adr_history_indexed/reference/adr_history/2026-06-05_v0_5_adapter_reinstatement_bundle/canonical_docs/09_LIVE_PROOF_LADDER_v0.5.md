# 09 - Live Proof Ladder v0.5

| Field | Value |
|---|---|
| Document ID | HS-PROOF-2026-06-005 |
| Version | v0.5 |
| Issue date | 2026-06-05 |
| Status | Accepted Human Director direction; proposed implementation package |
| Owner | Human Director |
| Scope | Proof levels after Runtime Adapter Boundary reinstatement |
| Primary source | ADR-HS-2026-06-005 |

## 1. Proof posture

v0.5 replaces Reasonix/session-interface proof with runtime-adapter proof.

The strongest live proof target is:

```text
backend-governed packet
+ authorized adapter run request
+ Codex CLI + DeepSeek execution
+ captured transcript/output/artifacts
+ adapter run envelope
+ structured report candidate
+ backend validation
+ Governance Mutation Gate decision
+ ClassB import or quarantine/rework/director_required outcome
```

The backend panel is secondary proof. Raw logs are diagnostic evidence by default, but the adapter run envelope is primary runtime evidence.

## 2. Proof levels

| Level | Name | Required proof |
|---|---|---|
| L1 | Backend kernel offline proof | State stores, MutationGate, validation/filtering, ClassB import, projections, and `stratactl` work locally. |
| L2 | IC CLI operation proof | IC can use compact CLI commands to create assignment, create packet, validate/import routine report, and trigger gate decisions. |
| L3 | Adapter smoke proof | One Codex CLI + DeepSeek adapter run launches/targets runtime, receives governed input, returns captured output and run envelope. |
| L4 | Backend-adapter integration proof | Backend creates governed packet, requests adapter run, records run envelope/evidence, validates report candidate, and gates outcome. |
| L5 | Live operational loop proof | IC uses backend CLI plus adapter runs to run worker-reviewer-IC routine loop with gate-authorized ClassB updates. |
| L6 | Product sign-off proof | Evidence is replayable/readable, security posture is acceptable, Director accepts final live loop. |

## 3. L1 backend kernel proof

Required evidence:

- clean backend state root;
- ClassA/B/C/D stores;
- MutationGate policy tests;
- routine and important mutation examples;
- report validation/filtering tests;
- ClassB append and projection update;
- compact CLI output;
- audit record creation.

## 4. L2 IC CLI operation proof

Required evidence:

- `stratactl assignment create`;
- `stratactl packet create`;
- `stratactl report validate`;
- `stratactl report import` for routine update;
- blocked or approval-required important mutation;
- compact output plus full materialized record paths.

## 5. L3 adapter smoke proof

Required evidence:

1. Adapter can launch or target one Codex CLI runtime.
2. DeepSeek API configuration is used through approved runtime/environment configuration.
3. Backend-governed prompt/input can be delivered.
4. Runtime produces output.
5. Adapter captures stdout/stderr/transcript/diagnostics/artifacts as applicable.
6. Adapter emits run envelope with packet/prompt hashes and terminal state.
7. Secrets are not written into exported logs or run envelopes.

## 6. L4 backend-adapter integration proof

Required evidence:

1. IC/backend operation creates a governed assignment and packet.
2. Governance Mutation Gate authorizes packet/run request where required.
3. Adapter receives exact packet/prompt path and hash.
4. Adapter run envelope records launch/target, input delivery, output capture, terminal state, and artifact paths.
5. Backend records adapter run evidence.
6. Backend receives or extracts exactly one structured report candidate when ClassB impact is intended.
7. Backend validates or quarantines the candidate without hidden repair.
8. MutationGate authorizes routine ClassB update or blocks/escalates.

## 7. L5 live operational loop proof

Required evidence:

1. IC creates a worker assignment and packet.
2. Adapter run executes worker through Codex CLI + DeepSeek with governed input.
3. Worker run completes response/report candidate and adapter captures evidence.
4. Backend validates or filters the candidate.
5. MutationGate authorizes routine ClassB update or blocks/escalates.
6. Reviewer packet is created from selected ClassB context.
7. Adapter run executes reviewer through governed input.
8. IC performs routine synthesis/merge or creates Human Director decision packet when required.
9. Backend panel reflects the sequence.

## 8. L6 final sign-off proof

Required evidence:

- end-to-end live proof can be reconstructed from audit records and file paths;
- adapter run envelopes and hashes are consistent;
- ClassB entries trace to validated candidates and source evidence;
- quarantine/rework/director_required paths are demonstrated;
- security posture covers secret redaction and evidence retention;
- Human Director accepts final live loop.

## 9. Reasonix/manual evidence

Reasonix evidence may support debugging or manual review, but it is not required for v0.5 proof levels and must not replace adapter run envelope proof for mainline claims.
