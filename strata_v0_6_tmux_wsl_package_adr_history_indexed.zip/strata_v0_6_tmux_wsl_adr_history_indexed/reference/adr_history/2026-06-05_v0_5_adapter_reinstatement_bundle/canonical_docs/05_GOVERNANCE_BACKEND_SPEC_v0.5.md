# 05 - Governance Backend Spec v0.5

| Field | Value |
|---|---|
| Document ID | HS-BE-2026-06-005 |
| Version | v0.5 |
| Issue date | 2026-06-05 |
| Status | Accepted Human Director direction; proposed implementation package |
| Owner | Human Director |
| Scope | Governance backend kernel, mutation gate, context packets, adapter run records, validation, CLI/API, projections, and panel state |
| Primary source | ADR-HS-2026-06-005 |

## 1. Backend mandate

The governance backend is a deterministic governance kernel. It owns durable state, context packet creation, validation/filtering, ClassB memory, mutation authorization, audit, projections, adapter run records, and backend panel data.

It does not encode agent intelligence as large workflow if/else logic. It exposes clear stateful commands so IC sessions can operate it directly.

The backend governs the adapter. The adapter does not govern the backend.

## 2. Required backend subsystems

| Subsystem | Responsibility |
|---|---|
| ClassA store | Authoritative architecture/product/policy/template/milestone state. |
| ClassB memory store | Validated operational memory files and JSON index. |
| ClassC source store | Durable source references. |
| ClassD diagnostic/quarantine store | Raw logs, rejected reports, diagnostics, quarantine. |
| Assignment store | Work-item records and DOD. |
| Context packet builder | Compact prompt/adapter packets for IC/worker/reviewer/tester/SME runs. |
| Adapter run registry | Run requests, run envelopes, transcript/output/artifact refs, terminal status. |
| Report filter/validator | Mechanical and policy checks before ClassB import. |
| Governance Mutation Gate | Mandatory write authorization layer. |
| Audit log | Append-only record of operations, actor, input refs, result, and approval. |
| Projection builder | Compact generated views for IC and panel. |
| Backend panel API | Read-oriented visibility and secondary proof. |
| `stratactl` CLI | Compact command interface for IC/backend operation. |

## 3. Governance Mutation Gate

Every authoritative write must pass through the gate.

Gate input:

```yaml
actor: human_director | ic | secondary_hand | worker | reviewer | tester | sme | adapter | system
operation: string
target_class: classA | classB | classC | classD | assignment | packet | adapter_run | projection | policy | template | milestone
mutation_kind: routine | important | destructive | override
validation_status: valid | invalid | not_applicable
semantic_scope: routine | important | unknown
source_refs: [id_or_path]
requested_change_summary: string
approval_ref: id_or_null
```

Gate output:

```yaml
allowed: true | false
operation_id: string
required_approval: none | ic | human_director
reason: string
changed_records: [id]
audit_record_path: path
```

## 4. Gate policy summary

| Mutation | Default authority |
|---|---|
| Routine assignment creation | IC allowed. |
| Routine context packet creation | IC allowed. |
| Routine adapter run request inside assignment scope | IC allowed. |
| Adapter evidence record append | IC/system allowed if tied to authorized run. |
| Valid routine report import | IC allowed. |
| Routine synthesis/merge | IC allowed. |
| Unknown/ambiguous semantic classification | Human Director required. |
| Meaning-changing synthesis/merge | Human Director required. |
| ClassA change/promotion | Human Director required. |
| Policy/template change | Human Director required. |
| Milestone closure | Human Director required. |
| Validation override | Human Director required. |
| Adapter behavior change affecting authority/security/proof | Human Director required. |
| Destructive rewrite/delete | Human Director required with explicit audit. |

## 5. Backend command philosophy

Commands should be explicit, small, and stateful. The backend should return compact results and store full detail in materialized files.

Example response shape:

```yaml
status: imported
operation_id: OP-000184
changed_records:
  - B-000027
short_summary: Worker implemented parser and tests.
full_record_path: .harness/governance/class_b/entries/B-000027.md
next_recommended_command: stratactl packet create --for reviewer --assignment A-000013 --from B-000027
```

## 6. Backend must avoid

- arbitrary direct edits to ClassB outside the gate;
- silent merge of unapproved meaning-changing context;
- treating raw logs, adapter transcript, or chat transcript as ClassB;
- forcing every workflow into backend-coded if/else logic;
- requiring full ClassB replay for routine IC operations;
- depending on Reasonix/session-interface evidence as mainline proof;
- letting the adapter write authoritative governance state directly.

## 7. Panel role

The backend panel is secondary proof and operator visibility. It should show:

- current ClassA summary;
- active ClassB memory projection;
- open assignments;
- pending Director decisions;
- recent mutation operations;
- quarantine/ClassD status;
- packets created;
- adapter run requests, run envelopes, transcript/output/artifact refs, validation status;
- Reasonix/manual session evidence only when explicitly recorded as non-governing evidence.

## 8. Adapter run record schema

Minimum adapter run record:

```yaml
run_id: string
assignment_id: string
role: ic | worker | reviewer | tester | sme | secondary_hand
adapter_version: string
codex_cli_version: string
model_provider: deepseek
model_name: string
workdir: path
packet_path: path
packet_sha256: string
prompt_path: path
prompt_sha256: string
started_at: timestamp
ended_at: timestamp | null
exit_status: int | null
terminal_state: running | completed | failed | cancelled | unknown
transcript_path: path | null
stdout_path: path | null
stderr_path: path | null
artifact_paths: [path]
report_candidate_path: path | null
report_candidate_sha256: string | null
validation_status: pending | valid | invalid | quarantined | not_applicable
```
