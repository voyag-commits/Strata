# Changelog - Harness / Strata ADR Bundle v0.5

## v0.5 - 2026-06-05

### Changed

- Reinstated Codex CLI + DeepSeek adapter as the main runtime substrate.
- Superseded v0.4 Session Interface Boundary as main runtime/proof path.
- Demoted Reasonix to optional/manual/non-governing status.
- Updated proof ladder to use adapter run envelope, captured output, report candidate validation, and gate decision.
- Added adapter run registry and evidence concepts to backend spec.
- Added `stratactl adapter ...` command surface.
- Strengthened structured report contract with exactly-one-report-candidate rule.
- Added explicit v0.4 carry-forward invariants document.

### Preserved

- Governance Mutation Gate.
- ClassB validated operational memory.
- Human Director authority thresholds.
- IC routine authority.
- Routine vs important distinction.
- Compact context/projection/cursor discipline.
- Append-oriented ClassB provenance.
- SRE incident-command coordination model.
- Secondary-hand communication placeholder; no mandatory DLO.
- Document-governance thresholds.
