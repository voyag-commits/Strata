# v0.5 ADR Bundle Historical Status

This folder is a retained copy of the v0.5 Adapter Reinstatement ADR bundle.

Status in v0.6:

```text
Retained governance baseline.
Runtime-adapter direction overridden where it conflicts with WSL/tmux Codex CLI dispatch.
```

Use this bundle for inherited governance, ClassB, role authority, report contract, and backend discipline. Use v0.6 documents for active runtime implementation.
