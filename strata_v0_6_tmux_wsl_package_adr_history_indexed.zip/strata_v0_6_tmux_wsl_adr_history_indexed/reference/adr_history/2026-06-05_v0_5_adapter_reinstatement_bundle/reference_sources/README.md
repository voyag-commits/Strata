# Reference Sources

This directory contains reference pointers and selected prior-version materials relevant to v0.5.

v0.5 is not a full rollback to v0.3. It restores the v0.3-style runtime adapter only under the v0.4/v0.5 governance architecture.

Local adapter handoff pointer:

```text
C:\Users\hou16\Downloads\FINAL_ADAPTER_BOUNDARY_CLI_GATES_HANDOFF.zip
```

The local zip is not embedded in this generated bundle. Copy it into the implementation/evidence root and record SHA-256 before use.
