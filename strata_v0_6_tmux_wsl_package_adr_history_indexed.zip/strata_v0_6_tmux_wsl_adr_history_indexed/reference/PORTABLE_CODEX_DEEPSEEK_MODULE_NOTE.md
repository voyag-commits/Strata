# Portable Codex CLI + DeepSeek Bridge Module Note

The stable runtime module is external to this clean Strata package unless intentionally copied in by the operator.

Expected migration:

1. Copy the working Windows-native Codex CLI + DeepSeek bridge module into WSL.
2. Keep bridge secrets in environment or local ignored files only.
3. Confirm Codex CLI can call the local OpenAI-compatible bridge from WSL.
4. Use Strata only for session dispatch, file returns, ledgers, review, and ClassB admission.

Recommended local placement examples:

```text
~/portable-codex-deepseek/
~/strata-runtime/codex-deepseek-bridge/
```

Do not commit the copied portable runtime module into this package unless the Human Director explicitly changes repository ownership boundaries.
