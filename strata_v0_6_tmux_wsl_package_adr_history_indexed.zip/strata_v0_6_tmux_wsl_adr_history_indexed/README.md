# Strata v0.6 WSL/tmux Live Implementation Package

This package is the clean starting point for the current Strata runtime direction:

```text
Codex CLI inside WSL/tmux
-> portable DeepSeek/OpenAI-compatible bridge copied into WSL
-> file-backed Worker Return Packets
-> backend JSONL ledgers
-> reviewed ClassB admission
```

The active runtime path is **tmux dispatch**, not Windows ConPTY and not GUI/UIA injection.

## Active decisions

- Runtime target: WSL/Linux, operated through VS Code Remote-WSL and tmux.
- Worker runtime: Codex CLI launched inside named tmux sessions.
- Model route: Codex CLI uses the portable DeepSeek bridge copied into WSL.
- Dispatch mechanism: `tmux_dispatch` launcher/sender.
- Evidence root: project-local `.strata/`.
- Communication rule: chat text is not a deliverable. Completed work must be returned by Worker Return Packet files.
- Acceptance rule: live observation in VS Code/tmux plus `.strata/ledgers/backend_loop_ledger.jsonl`. No mock tmux acceptance scripts are included.


## ADR history included

The retained ADR lineage is indexed under:

```text
docs/ADR_HISTORY_INDEX.md
reference/adr_history/
```

This package preserves three decision layers:

```text
v0.5 Adapter Reinstatement ADR Bundle = inherited governance baseline
ADR-HS-2026-06-0601 GUI Worker Dispatch = historical approved GUI-worker decision state
v0.6 tmux/WSL addendum = active runtime migration and implementation override
```

v0.6 controls active implementation where runtime direction conflicts. v0.5 and ADR-HS-2026-06-0601 remain retained decision history and governance context, not competing active runtime paths.

## Runtime directory layout

```text
.strata/
  sessions/      # tmux session records
  dispatches/    # Context Load Packets and Work Dispatch Packets
  returns/       # Worker Return Packets written by workers
  ledgers/       # dispatch ledger, report ledger, backend loop JSONL, mutation gate
  evidence/      # tmux captures, bridge traces, diagnostics
  quarantine/    # invalid or rejected material
```

## Install in WSL

```bash
npm install
npm run build
```

Node 22+ is expected. The package does not include `node_modules`.

## Portable Codex CLI + DeepSeek bridge module

The stable Windows module is expected to be copied into WSL as a portable runtime component. This package does not need to own that module deeply. It only needs the bridge endpoint/configuration and the Codex CLI command to be available in the WSL environment.

Typical environment shape:

```bash
export DEEPSEEK_API_KEY='<redacted>'
export PORT=38441
export CODEX_CLI_COMMAND='codex'
export BRIDGE_DEBUG_TRACE_DIR='.strata/evidence/bridge_debug_trace'
```

Start the bridge:

```bash
npm run start
```

Then point Codex CLI at the local OpenAI-compatible bridge according to the portable module's own config.

## Minimal live loop

Create runtime folders:

```bash
npm run strata -- init
```

Create or register a live Codex worker session:

```bash
npm run strata -- sessions create \
  --assignment-id A0601 \
  --agent-id coder_01 \
  --role coder \
  --session-name STRATA-CODER-A0601 \
  --cwd "$PWD" \
  --command "$CODEX_CLI_COMMAND"
```

Create a Work Dispatch Packet:

```bash
npm run strata -- dispatch create \
  --assignment-id A0601 \
  --agent-id coder_01 \
  --role coder \
  --kind TASK_ASSIGNMENT \
  --action 'Create the requested report file and return by Worker Return Packet.'
```

Send the packet notice into the live tmux session:

```bash
npm run strata -- dispatch send \
  --session-name STRATA-CODER-A0601 \
  --packet .strata/dispatches/work_dispatch_packets/A0601/<packet-file>.md
```

Watch tmux directly in VS Code:

```bash
tmux attach -t STRATA-CODER-A0601
```

Inspect backend events:

```bash
npm run strata -- loop-ledger show --format table
cat .strata/ledgers/backend_loop_ledger.jsonl
```

Classify worker returns:

```bash
npm run strata -- returns scan --assignment-id A0601 --agent-id coder_01
```

Review report candidates:

```bash
npm run strata -- report list
npm run strata -- report review --report-id <report_id> --reviewer-id reviewer_01 --decision accepted
```

## Important exclusions

The following are not active in v0.6:

- Windows ConPTY dispatch.
- Windows GUI/UIA injection.
- Reasonix/Claude desktop GUI-worker routing.
- Offline backend proof scripts as runtime acceptance.
- Mock tmux acceptance harnesses.

They may remain as historical reference in older bundles, but this clean package should not route active work through them.
