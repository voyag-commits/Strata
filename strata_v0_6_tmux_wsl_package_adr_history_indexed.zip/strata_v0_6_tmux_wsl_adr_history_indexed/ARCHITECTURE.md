# Strata v0.6 Architecture

## Primary live path

```text
Human Director
  -> BOC / IC creates packet
  -> tmux_dispatch sends notice into Codex CLI session
  -> Codex CLI uses portable DeepSeek bridge
  -> worker writes Worker Return Packet under .strata/returns
  -> backend classifies return
  -> report candidate enters Agent Report Ledger
  -> reviewer accepts/reworks
  -> accepted report enters ClassB
```

## Roles

| Role | Active v0.6 responsibility |
| --- | --- |
| Human Director | Final authority for roadmap and ClassA changes. |
| BOC | Backend Operations Coordinator; operates tmux sessions, dispatch, logs, and return scans. |
| IC | Assignment coordinator; receives questions, blockers, and rework needs. |
| Worker | Codex CLI worker inside a named tmux session. |
| Reviewer | Reviews `REPORT_READY` outputs before ClassB admission. |

## Context classes

| Class | v0.6 treatment |
| --- | --- |
| ClassA | Stable authority/header context. Director controlled. |
| ClassB | Primary runtime delta. Only reviewed accepted outputs enter here. |
| ClassC | Stable source/reference context. |
| ClassD | Evidence, diagnostics, raw captures, blocked states. |

## Runtime boundary

The tmux sender is not a reasoning layer. It only performs live terminal dispatch mechanics and records evidence. It does not decide task validity, review quality, or ClassB admission.

The DeepSeek bridge is treated as a portable runtime component. Strata records configuration and health expectations but does not require the bridge implementation to be in this package.

## Active source modules

```text
src/config.ts
src/server.ts
src/mapper.ts
src/debugTrace.ts
src/log.ts
src/types.ts
src/backend/bridge_gate/
src/backend/tmux_dispatch/
src/backend/packets/
src/backend/worker_returns/
src/backend/dispatch_ledger/
src/backend/agent_report_ledger/
src/backend/coordination_threads/
src/backend/context/
src/backend/mutation_gate/
src/backend/governance/
src/backend/loop_ledger/
src/backend/workspace/
src/backend/secret_scan/
```

## Inactive paths

Windows ConPTY and GUI/UIA injection are excluded from v0.6 implementation. The remaining forward candidates after this package are:

1. VS Code approach.
2. GUI/UIA injection as a future candidate only, with no v0.6 implementation ownership.
