# SCTL Contracts v0.9.3

## Class B Report

Class B authority is a validated Markdown report under `.strata/context/B/` plus the SCTL context Git commit.

Required frontmatter:

```yaml
contract_id: strata.class_b.file.v1
class: B
id: <id>
title: <title>
scope: actionable_report
assignment_id: <assignment_id>
agent_id: <sender_id>
role: <sender_role>
status: ready
evidence: included
loaded_context_epoch: <epoch>
created_at: <ISO-8601>
```

Required sections:

```text
## Operational Summary
## Progress Delta
## Trunk Integration
## Verification
## Evidence
## Risks / Blockers
## Next Action
```

Invalid Class B submissions create a denied result and an error dispatch. The invalid report file remains outside the accepted Class B commit.

## Class C Team Message

Class C team messages are intentional role-to-role communication artifacts.

Required frontmatter:

```yaml
contract_id: strata.class_c.team_message.v1
class: C
message_id: <message_id>
thread_id: <thread_id>
assignment_id: <assignment_id>
from_role: <role>
from_id: <id>
to_role: <role>
to_id: <id>
message_kind: qc_review_request
status: open
requires_response: true
related_class_b: .strata/context/B/<report>.md
created_at: <ISO-8601>
```

Required sections:

```text
## Message
## Requested Handling
```

## Class C Context Notice

Every accepted Class B update queues a context notice for active sessions in the current assignment.

```yaml
contract_id: strata.class_c.context_notice.v1
class: C
notice_kind: class_b_update
assignment_id: <assignment_id>
target_role: <role>
target_id: <session_id>
context_epoch: <epoch>
context_revision: <revision>
class_b_updates_since_full_refresh: <count>
refresh_required: false
status: pending
```

The next targeted dispatch to that session merges the pending notice at the top of the paste-ready packet and marks it `merged_to_dispatch`.

## Worker Return Packet

Accepted return kinds:

```text
ACK
QUESTION
OPERATIONAL_REPORT_READY
BLOCKED
FAILED_WITH_DIAGNOSTIC
NEEDS_CLARIFICATION
PARTIAL_STATUS
```

`OPERATIONAL_REPORT_READY` requires a mechanically valid operational report file. Worker Return Packets remain routing and ledger artifacts. Class B updates happen through strict Class B report commits.

Evidence belongs inside operational report and Class B report sections.
