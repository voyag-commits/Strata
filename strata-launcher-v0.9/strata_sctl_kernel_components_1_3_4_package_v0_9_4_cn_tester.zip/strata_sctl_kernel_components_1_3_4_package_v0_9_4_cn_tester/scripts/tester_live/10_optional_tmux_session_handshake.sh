#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"

if ! command -v tmux >/dev/null 2>&1; then
  cat <<MSG
当前环境未发现 tmux。测试员可在本地 WSL 安装 tmux 后执行本脚本。
仍可通过 cat 查看 dispatch packet，并手动复制到目标 chatbox。
MSG
  exit 0
fi

for session in sctl_change_author_001 sctl_reviewer_001 sctl_tech_lead_001 sctl_tooling_operator; do
  if ! tmux has-session -t "$session" 2>/dev/null; then
    tmux new-session -d -s "$session"
  fi
done

cat <<MSG
已准备 tmux 会话：
  sctl_change_author_001
  sctl_reviewer_001
  sctl_tech_lead_001
  sctl_tooling_operator

如已生成 latest_dispatch_packet_path.txt，可执行：
  PACKET="\$(cat $SCTL_RESULTS/latest_dispatch_packet_path.txt)"
  tmux load-buffer "\$PACKET"
  tmux paste-buffer -t sctl_reviewer_001
  tmux send-keys -t sctl_reviewer_001 C-m
MSG
