#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PKG_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
export SCTL_WORKSPACE="${SCTL_WORKSPACE:-$PKG_ROOT/.tester_runs/live_workspace}"
export SCTL_RESULTS="${SCTL_RESULTS:-$PKG_ROOT/.tester_runs/results}"
export SCTL_FIXTURE_WORKSPACE="${SCTL_FIXTURE_WORKSPACE:-$PKG_ROOT/.tester_runs/fixture_workspace}"
rm -rf "$PKG_ROOT/.tester_runs"
mkdir -p "$SCTL_RESULTS"

(
  cd "$PKG_ROOT"
  npm test
) > "$SCTL_RESULTS/npm_test.log" 2>&1

(
  cd "$PKG_ROOT"
  npm run secret-scan
) > "$SCTL_RESULTS/secret_scan.log" 2>&1

SCTL_RESET=1 bash "$SCRIPT_DIR/00_prepare_workspace.sh"
bash "$SCRIPT_DIR/01_verify_cli_tool_registry.sh"
bash "$SCRIPT_DIR/02_verify_classc_notice_merge.sh"
bash "$SCRIPT_DIR/03_verify_classb_invalid_denial.sh"
bash "$SCRIPT_DIR/04_verify_classb_drift_threshold.sh"
bash "$SCRIPT_DIR/05_verify_classa_epoch_update.sh"
bash "$SCRIPT_DIR/06_run_fixture_scenes.sh"
bash "$SCRIPT_DIR/99_collect_dod_evidence.sh"

echo "live-all complete. See $SCTL_RESULTS/FINAL_DOD_REPORT.md"
