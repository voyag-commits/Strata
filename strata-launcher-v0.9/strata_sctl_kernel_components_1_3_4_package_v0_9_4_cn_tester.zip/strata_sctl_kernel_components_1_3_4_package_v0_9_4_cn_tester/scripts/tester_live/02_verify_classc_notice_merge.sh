#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
ensure_prepared

run_sctl classb put \
  --id B_A100_OPERATIONAL_READY \
  --title "A100 operational ready" \
  --assignment-id A100 \
  --agent-id change_author_001 \
  --role "Change Author" \
  --scope actionable_report \
  --summary "Change Author completed the bounded workflow." \
  --progress-delta "Progress delta is recorded in Class B." \
  --trunk-integration "Trunk-based template references are used for this test." \
  --verification "SCTL Class B validation and commit path passed." \
  --risks "No active blocker in this test case." \
  --next-action "Reviewer receives Class C review request." \
  > "$SCTL_RESULTS/02_classb_put.json"
json_assert_ok "$SCTL_RESULTS/02_classb_put.json"

queued_count=$(node - "$SCTL_RESULTS/02_classb_put.json" <<'NODE'
const fs = require('fs');
const obj = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
console.log((obj.result.queued_notices || []).length);
NODE
)
if [ "$queued_count" -lt 1 ]; then
  echo "expected at least one queued notice" >&2
  exit 1
fi

run_sctl message send \
  --assignment-id A100 \
  --thread-id THREAD_A100_REVIEW \
  --message-id TM_A100_REVIEW_REQUEST \
  --from-role "Change Author" \
  --from-id change_author_001 \
  --to-role "Reviewer / QC Engineer" \
  --to-id reviewer_001 \
  --message-kind qc_review_request \
  --related-class-b .strata/context/B/b_a100_operational_ready.md \
  --body "Please review the Class B report and return QC feedback or a review outcome." \
  > "$SCTL_RESULTS/02_message_send.json"
json_assert_ok "$SCTL_RESULTS/02_message_send.json"

run_sctl dispatch record \
  --assignment-id A100 \
  --nonce A100_N1 \
  --from-role "Change Author" \
  --from-id change_author_001 \
  --target-role "Reviewer / QC Engineer" \
  --target-id reviewer_001 \
  --summary "Review request with pending notice." \
  --message-file .strata/context/C/threads/thread_a100_review/tm_a100_review_request.md \
  --related-class-b .strata/context/B/b_a100_operational_ready.md \
  --dispatch-kind TEAM_MESSAGE \
  > "$SCTL_RESULTS/02_dispatch_record.json"
json_assert_ok "$SCTL_RESULTS/02_dispatch_record.json"

packet_path=$(json_value "$SCTL_RESULTS/02_dispatch_record.json" result.outbox.packetMdPath)
echo "$packet_path" > "$SCTL_RESULTS/latest_dispatch_packet_path.txt"
assert_contains "$packet_path" "Pending Context Notice"
assert_contains "$packet_path" "Class C Team Message"
assert_contains "$packet_path" "Related Class B Delta"
assert_contains "$packet_path" "Delivery: paste this packet under existing session content and press Enter."

notice_count=$(json_value "$SCTL_RESULTS/02_dispatch_record.json" result.notice_count)
if [ "$notice_count" -lt 1 ]; then
  echo "expected merged notice count >= 1" >&2
  exit 1
fi

{
  echo "Class C notice merge 验证通过。"
  echo "queued_notice_count=$queued_count"
  echo "merged_notice_count=$notice_count"
  echo "packet=$packet_path"
} | tee "$SCTL_RESULTS/02_notice_merge_summary.txt"
