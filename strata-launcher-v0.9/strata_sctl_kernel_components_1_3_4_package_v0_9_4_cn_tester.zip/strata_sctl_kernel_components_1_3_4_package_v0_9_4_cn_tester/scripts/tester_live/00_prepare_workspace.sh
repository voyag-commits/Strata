#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"

if [ "${SCTL_RESET:-0}" = "1" ]; then
  rm -rf "$SCTL_WORKSPACE"
  mkdir -p "$SCTL_WORKSPACE"
fi
mkdir -p "$SCTL_RESULTS"

run_sctl context bootstrap > "$SCTL_RESULTS/00_context_bootstrap.json"
json_assert_ok "$SCTL_RESULTS/00_context_bootstrap.json"

run_sctl sessions register --assignment-id A100 --role "Change Author" --id change_author_001 > "$SCTL_RESULTS/00_session_change_author.json"
json_assert_ok "$SCTL_RESULTS/00_session_change_author.json"

run_sctl sessions register --assignment-id A100 --role "Reviewer / QC Engineer" --id reviewer_001 > "$SCTL_RESULTS/00_session_reviewer.json"
json_assert_ok "$SCTL_RESULTS/00_session_reviewer.json"

run_sctl sessions register --assignment-id A100 --role "Tech Lead / Coordination Owner" --id tech_lead_001 > "$SCTL_RESULTS/00_session_tech_lead.json"
json_assert_ok "$SCTL_RESULTS/00_session_tech_lead.json"

run_sctl sessions list > "$SCTL_RESULTS/00_sessions_list.json"
json_assert_ok "$SCTL_RESULTS/00_sessions_list.json"

run_sctl context repo-status > "$SCTL_RESULTS/00_repo_status.json"
json_assert_ok "$SCTL_RESULTS/00_repo_status.json"

{
  echo "SCTL_WORKSPACE=$SCTL_WORKSPACE"
  echo "SCTL_RESULTS=$SCTL_RESULTS"
  echo "准备完成。活动会话已登记。"
} > "$SCTL_RESULTS/00_prepare_summary.txt"
cat "$SCTL_RESULTS/00_prepare_summary.txt"
