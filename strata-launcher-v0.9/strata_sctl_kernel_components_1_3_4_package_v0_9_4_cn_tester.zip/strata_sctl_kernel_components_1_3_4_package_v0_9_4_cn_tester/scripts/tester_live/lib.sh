#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PKG_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
SCTL_WORKSPACE="${SCTL_WORKSPACE:-$PKG_ROOT/.tester_runs/live_workspace}"
SCTL_RESULTS="${SCTL_RESULTS:-$PKG_ROOT/.tester_runs/results}"
SCTL_FIXTURE_WORKSPACE="${SCTL_FIXTURE_WORKSPACE:-$PKG_ROOT/.tester_runs/fixture_workspace}"
mkdir -p "$SCTL_WORKSPACE" "$SCTL_RESULTS"

run_sctl() {
  node "$PKG_ROOT/src/cli.js" "$@" --workspace "$SCTL_WORKSPACE"
}

json_assert_ok() {
  node - "$1" <<'NODE'
const fs = require('fs');
const file = process.argv[2];
const obj = JSON.parse(fs.readFileSync(file, 'utf8'));
if (!obj.ok) {
  console.error(`expected ok=true for ${file}`);
  console.error(JSON.stringify(obj, null, 2));
  process.exit(1);
}
NODE
}

json_assert_not_ok() {
  node - "$1" <<'NODE'
const fs = require('fs');
const file = process.argv[2];
const obj = JSON.parse(fs.readFileSync(file, 'utf8'));
if (obj.ok) {
  console.error(`expected ok=false for ${file}`);
  console.error(JSON.stringify(obj, null, 2));
  process.exit(1);
}
NODE
}

json_value() {
  node - "$1" "$2" <<'NODE'
const fs = require('fs');
const file = process.argv[2];
const pathExpr = process.argv[3];
const obj = JSON.parse(fs.readFileSync(file, 'utf8'));
let cur = obj;
for (const key of pathExpr.split('.')) cur = cur == null ? undefined : cur[key];
if (Array.isArray(cur) || (cur && typeof cur === 'object')) console.log(JSON.stringify(cur));
else console.log(cur ?? '');
NODE
}

assert_contains() {
  local file="$1"
  local needle="$2"
  if ! grep -Fq "$needle" "$file"; then
    echo "missing expected text: $needle" >&2
    echo "file: $file" >&2
    exit 1
  fi
}

ensure_prepared() {
  if [ ! -f "$SCTL_WORKSPACE/.strata/context/D_trace/context_state.json" ]; then
    bash "$SCRIPT_DIR/00_prepare_workspace.sh"
  fi
}

context_git_log() {
  git -C "$SCTL_WORKSPACE/.strata/context" log --oneline --all || true
}
