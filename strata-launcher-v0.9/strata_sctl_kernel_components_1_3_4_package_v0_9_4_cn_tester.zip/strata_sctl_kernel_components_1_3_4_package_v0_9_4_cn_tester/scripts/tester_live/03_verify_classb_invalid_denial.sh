#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
ensure_prepared

bad_file="$SCTL_WORKSPACE/.strata/context/B/invalid_classb_missing_sections.md"
mkdir -p "$(dirname "$bad_file")"
cat > "$bad_file" <<'BAD'
---
contract_id: strata.class_b.file.v1
class: B
id: INVALID_CLASSB_MISSING_SECTIONS
title: Invalid Class B fixture
scope: actionable_report
assignment_id: A100
agent_id: change_author_001
role: Change Author
status: ready
evidence: included
loaded_context_epoch: 1
created_at: 2026-06-11T00:00:00.000Z
---

# Invalid fixture

This file intentionally lacks the required report sections.
BAD

run_sctl classb commit --file .strata/context/B/invalid_classb_missing_sections.md --message "invalid class B should be denied" > "$SCTL_RESULTS/03_invalid_classb_commit.json" || true
json_assert_not_ok "$SCTL_RESULTS/03_invalid_classb_commit.json"

node - "$SCTL_RESULTS/03_invalid_classb_commit.json" <<'NODE'
const fs = require('fs');
const obj = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
if (obj.result.commit_denied !== true) throw new Error('commit_denied expected true');
if (!obj.result.error_dispatch) throw new Error('error dispatch expected');
NODE

echo "无效 Class B 提交拒绝验证通过。" | tee "$SCTL_RESULTS/03_invalid_classb_summary.txt"
