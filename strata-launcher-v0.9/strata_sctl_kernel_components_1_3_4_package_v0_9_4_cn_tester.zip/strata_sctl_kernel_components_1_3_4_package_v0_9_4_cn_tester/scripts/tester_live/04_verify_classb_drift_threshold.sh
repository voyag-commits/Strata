#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
ensure_prepared

run_sctl sessions register --assignment-id A200 --role "Change Author" --id change_author_200 > "$SCTL_RESULTS/04_session_change_author_200.json"
json_assert_ok "$SCTL_RESULTS/04_session_change_author_200.json"
run_sctl sessions register --assignment-id A200 --role "Reviewer / QC Engineer" --id reviewer_200 > "$SCTL_RESULTS/04_session_reviewer_200.json"
json_assert_ok "$SCTL_RESULTS/04_session_reviewer_200.json"

for i in $(seq -w 1 11); do
  run_sctl classb put \
    --id "B_A200_DRIFT_$i" \
    --title "A200 drift update $i" \
    --assignment-id A200 \
    --agent-id change_author_200 \
    --role "Change Author" \
    --scope actionable_report \
    --summary "Drift threshold update $i." \
    --verification "Class B strict validation passed for drift update $i." \
    --next-action "Continue drift threshold verification." \
    > "$SCTL_RESULTS/04_classb_drift_$i.json"
  json_assert_ok "$SCTL_RESULTS/04_classb_drift_$i.json"
done

run_sctl context repo-status > "$SCTL_RESULTS/04_repo_status_after_drift.json"
json_assert_ok "$SCTL_RESULTS/04_repo_status_after_drift.json"
node - "$SCTL_RESULTS/04_repo_status_after_drift.json" <<'NODE'
const fs = require('fs');
const obj = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const state = obj.result.state;
if (state.refresh_required !== true) throw new Error('refresh_required expected true');
if (Number(state.class_b_updates_since_full_refresh) <= 10) throw new Error('Class B update count expected > 10');
NODE

echo "Class B drift threshold 验证通过：refresh_required=true。" | tee "$SCTL_RESULTS/04_drift_summary.txt"
