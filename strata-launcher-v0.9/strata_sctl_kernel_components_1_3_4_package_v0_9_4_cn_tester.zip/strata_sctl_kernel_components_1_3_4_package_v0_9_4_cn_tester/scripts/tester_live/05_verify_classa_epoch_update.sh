#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
ensure_prepared

run_sctl context repo-status > "$SCTL_RESULTS/05_repo_status_before_classa.json"
json_assert_ok "$SCTL_RESULTS/05_repo_status_before_classa.json"
before_epoch=$(json_value "$SCTL_RESULTS/05_repo_status_before_classa.json" result.state.context_epoch)

run_sctl context put \
  --class A \
  --id contract_update_cn_tester \
  --title "中文测试员合约更新" \
  --body "Class A update fixture for epoch verification." \
  > "$SCTL_RESULTS/05_classa_put.json"
json_assert_ok "$SCTL_RESULTS/05_classa_put.json"

run_sctl context repo-status > "$SCTL_RESULTS/05_repo_status_after_classa.json"
json_assert_ok "$SCTL_RESULTS/05_repo_status_after_classa.json"
node - "$SCTL_RESULTS/05_repo_status_after_classa.json" "$before_epoch" <<'NODE'
const fs = require('fs');
const obj = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const before = Number(process.argv[3]);
const state = obj.result.state;
if (Number(state.context_epoch) <= before) throw new Error('context_epoch expected to increase');
if (state.refresh_required !== true) throw new Error('refresh_required expected true after Class A update');
NODE

echo "Class A epoch update 验证通过。" | tee "$SCTL_RESULTS/05_classa_epoch_summary.txt"
