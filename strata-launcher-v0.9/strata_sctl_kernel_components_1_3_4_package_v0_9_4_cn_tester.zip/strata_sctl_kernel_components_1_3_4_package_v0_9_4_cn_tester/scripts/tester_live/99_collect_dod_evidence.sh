#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
ensure_prepared

REPORT="$SCTL_RESULTS/FINAL_DOD_REPORT.md"
latest_packet=""
if [ -f "$SCTL_RESULTS/latest_dispatch_packet_path.txt" ]; then
  latest_packet="$(cat "$SCTL_RESULTS/latest_dispatch_packet_path.txt")"
fi

{
  echo "# SCTL v0.9.4-cn-tester Final DoD Report"
  echo
  echo "## Workspace"
  echo
  echo '```text'
  echo "$SCTL_WORKSPACE"
  echo '```'
  echo
  echo "## Latest Dispatch Packet"
  echo
  echo '```text'
  echo "${latest_packet:-not generated}"
  echo '```'
  echo
  echo "## Result Files"
  echo
  echo '```text'
  find "$SCTL_RESULTS" -maxdepth 1 -type f | sort
  echo '```'
  echo
  echo "## Context State"
  echo
  echo '```json'
  if [ -f "$SCTL_WORKSPACE/.strata/context/D_trace/context_state.json" ]; then
    cat "$SCTL_WORKSPACE/.strata/context/D_trace/context_state.json"
  fi
  echo '```'
  echo
  echo "## SCTL Context Git Log"
  echo
  echo '```text'
  git -C "$SCTL_WORKSPACE/.strata/context" log --oneline --all || true
  echo '```'
  echo
  echo "## SCTL Context Git Status"
  echo
  echo '```text'
  git -C "$SCTL_WORKSPACE/.strata/context" status --short || true
  echo '```'
  echo
  echo "## Telemetry Tail"
  echo
  echo '```jsonl'
  if [ -f "$SCTL_WORKSPACE/.strata/context/D_trace/telemetry/workflow_telemetry.jsonl" ]; then
    tail -n 60 "$SCTL_WORKSPACE/.strata/context/D_trace/telemetry/workflow_telemetry.jsonl"
  fi
  echo '```'
  echo
  echo "## Packet Preview"
  echo
  echo '```markdown'
  if [ -n "$latest_packet" ] && [ -f "$latest_packet" ]; then
    sed -n '1,180p' "$latest_packet"
  fi
  echo '```'
  echo
  echo "## DoD Conclusion"
  echo
  echo "脚本层验收完成。人工 session paste 记录请使用 templates/tester_zh/session_paste_record.blank.zh-CN.md 补齐。"
} > "$REPORT"

echo "DoD report generated: $REPORT"
