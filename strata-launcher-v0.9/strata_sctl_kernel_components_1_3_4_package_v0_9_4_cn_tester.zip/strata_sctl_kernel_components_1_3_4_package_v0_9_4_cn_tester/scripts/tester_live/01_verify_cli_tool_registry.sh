#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
ensure_prepared

run_sctl tools list > "$SCTL_RESULTS/01_tools_list.json"
json_assert_ok "$SCTL_RESULTS/01_tools_list.json"

for tool in \
  sctl.context.bootstrap.v1 \
  sctl.classb.put_file.v1 \
  sctl.message.send.v1 \
  sctl.dispatch.record.v1 \
  sctl.fixtures.run_scene.v1; do
  out="$SCTL_RESULTS/01_tool_${tool//./_}.json"
  run_sctl tools inspect --tool "$tool" > "$out"
  json_assert_ok "$out"
  node - "$out" <<'NODE'
const fs = require('fs');
const obj = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const tool = obj.result.tool;
if (tool.operator_role !== 'Tooling / Dispatch Operator') throw new Error('unexpected operator role');
if (tool.runtime_tmux !== false) throw new Error('runtime_tmux expected false');
if (tool.watches_implementation_git !== false) throw new Error('watches_implementation_git expected false');
NODE
done

echo "工具登记检查通过：Tooling / Dispatch Operator 边界成立。" | tee "$SCTL_RESULTS/01_tool_registry_summary.txt"
