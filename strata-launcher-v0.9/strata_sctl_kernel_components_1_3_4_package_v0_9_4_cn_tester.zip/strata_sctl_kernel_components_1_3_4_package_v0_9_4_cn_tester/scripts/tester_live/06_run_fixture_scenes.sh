#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"

rm -rf "$SCTL_FIXTURE_WORKSPACE"
mkdir -p "$SCTL_FIXTURE_WORKSPACE"
node "$PKG_ROOT/src/cli.js" fixtures list-scenes --workspace "$SCTL_FIXTURE_WORKSPACE" > "$SCTL_RESULTS/06_fixture_list.json"
json_assert_ok "$SCTL_RESULTS/06_fixture_list.json"

for scene in direct_to_trunk_small_change short_lived_branch_review blocker_recovery pending_notice_merge; do
  out="$SCTL_RESULTS/06_fixture_${scene}.json"
  node "$PKG_ROOT/src/cli.js" fixtures run-scene --workspace "$SCTL_FIXTURE_WORKSPACE" --name "$scene" > "$out"
  json_assert_ok "$out"
done

git -C "$SCTL_FIXTURE_WORKSPACE/.strata/context" log --oneline --all > "$SCTL_RESULTS/06_fixture_git_log.txt"
echo "Fixture 场景验证通过。Git log: $SCTL_RESULTS/06_fixture_git_log.txt" | tee "$SCTL_RESULTS/06_fixture_summary.txt"
