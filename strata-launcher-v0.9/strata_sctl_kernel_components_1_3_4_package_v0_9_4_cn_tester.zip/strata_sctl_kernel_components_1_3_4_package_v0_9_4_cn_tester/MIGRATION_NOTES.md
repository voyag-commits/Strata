# Migration Notes v0.9.3

## From v0.9.1/v0.9.2

- Class C now owns team communication and context notices.
- Class A owns doctrine, contracts, architecture, and bootstrap file-pin policy.
- Class B validation is strict and section-based.
- Evidence is embedded in operational reports and Class B reports.
- `EVIDENCE_READY` is retired from Worker Return Packets.
- Dispatch records are Git-logged as primary backend evidence.
- Implementation Git scanning is replaced by declared template/file references for backend and fixture tests.
- Active sessions receive lightweight Class C notices through the next targeted paste-ready dispatch packet.
