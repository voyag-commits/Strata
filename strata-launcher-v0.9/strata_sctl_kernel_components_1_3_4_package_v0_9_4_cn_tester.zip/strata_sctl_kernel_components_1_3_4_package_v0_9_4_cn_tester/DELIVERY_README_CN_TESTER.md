# Delivery README v0.9.4-cn-tester

## Package Purpose

本发行包面向中文测试员，用于在本地 WSL / tmux / session launcher 环境中执行 SCTL live workflow acceptance。

## Main Entry

```text
README.md
docs/zh-CN/00_测试员入口.md
```

## Main Command

```bash
npm run tester:live-all
```

## Local Handshake

```bash
bash scripts/tester_live/10_optional_tmux_session_handshake.sh
```

## Final Evidence

```text
.tester_runs/results/FINAL_DOD_REPORT.md
```
