# Session Paste Record

## Basic

```text
assignment_id:
nonce:
source role / id:
target role / id:
packet path:
paste time:
operator:
```

## Target Session

```text
session name:
launcher:
```

## Result

```text
target response type: Class C / Class B / Worker Return Packet
response path:
summary:
```

## Evidence

```text
Git commit:
telemetry line:
notes:
```
