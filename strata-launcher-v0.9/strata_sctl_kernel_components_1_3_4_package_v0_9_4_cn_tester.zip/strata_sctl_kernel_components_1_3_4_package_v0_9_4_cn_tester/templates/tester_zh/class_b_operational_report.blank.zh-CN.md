---
contract_id: strata.class_b.file.v1
class: B
id: B_<ASSIGNMENT>_OPERATIONAL_READY
title: <标题>
scope: actionable_report
assignment_id: <ASSIGNMENT>
agent_id: <AGENT_ID>
role: <ROLE>
status: ready
evidence: included
loaded_context_epoch: <EPOCH>
created_at: <ISO_TIME>
---

# <标题>

## Operational Summary

<运营摘要>

## Progress Delta

<进度增量>

## Trunk Integration

<trunk-based 开发关系>

## Verification

<验证动作与结果>

## Evidence

<证据路径、命令输出、派发包路径、Git commit>

## Risks / Blockers

<风险或阻塞>

## Next Action

<下一步动作>
