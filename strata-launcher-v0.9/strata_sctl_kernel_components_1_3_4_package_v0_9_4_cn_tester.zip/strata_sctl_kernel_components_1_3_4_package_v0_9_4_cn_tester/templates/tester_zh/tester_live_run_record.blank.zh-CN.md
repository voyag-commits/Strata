# Tester Live Run Record

## Run Metadata

```text
package version: v0.9.4-cn-tester
tester:
date:
workspace:
results dir:
```

## Commands

```bash
npm test
npm run secret-scan
npm run tester:live-all
```

## Key Evidence

```text
latest dispatch packet:
SCTL Git log:
telemetry tail:
DoD report:
```

## Outcome

```text
pass / retest / revise
```
