---
contract_id: strata.class_c.team_message.v1
class: C
message_id: TM_<ASSIGNMENT>_<NUMBER>
thread_id: THREAD_<ASSIGNMENT>_<TOPIC>
assignment_id: <ASSIGNMENT>
from_role: <SOURCE_ROLE>
from_id: <SOURCE_ID>
to_role: <TARGET_ROLE>
to_id: <TARGET_ID>
message_kind: qc_review_request
status: open
requires_response: true
related_class_b: .strata/context/B/<class_b_file>.md
created_at: <ISO_TIME>
---

# Team Message

## Message

<问题、评审请求、QC 反馈或协调说明>

## Requested Handling

<目标角色应完成的动作>
