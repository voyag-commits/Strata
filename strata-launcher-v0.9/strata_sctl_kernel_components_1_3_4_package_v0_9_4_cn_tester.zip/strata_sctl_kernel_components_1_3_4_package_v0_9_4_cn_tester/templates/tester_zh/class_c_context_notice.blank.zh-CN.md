---
contract_id: strata.class_c.context_notice.v1
class: C
notice_id: CTX_<ASSIGNMENT>_<TARGET>_<REVISION>
notice_kind: class_b_update
assignment_id: <ASSIGNMENT>
target_role: <TARGET_ROLE>
target_id: <TARGET_ID>
context_epoch: <EPOCH>
context_revision: <REVISION>
class_b_updates_since_full_refresh: <COUNT>
refresh_required: false
status: pending
created_at: <ISO_TIME>
---

# Context Notice

## Notice

Class B report changed for this assignment.

## Related Class B

- .strata/context/B/<class_b_file>.md

## Handling

This notice is queued for the next paste-ready dispatch packet to this session.
