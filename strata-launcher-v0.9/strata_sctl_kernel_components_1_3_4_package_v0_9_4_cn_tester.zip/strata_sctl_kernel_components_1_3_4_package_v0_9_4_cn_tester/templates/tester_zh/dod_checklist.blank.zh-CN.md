# DoD Checklist

| Item | Evidence | Result |
|---|---|---|
| npm test |  |  |
| secret scan |  |  |
| context Git isolated |  |  |
| Class B strict report |  |  |
| Class C team message |  |  |
| pending context notice |  |  |
| dispatch packet merge |  |  |
| paste-only delivery |  |  |
| telemetry JSONL |  |  |
| B drift threshold |  |  |
| A epoch update |  |  |
| fixture scenes |  |  |
| tmux/session paste |  |  |
