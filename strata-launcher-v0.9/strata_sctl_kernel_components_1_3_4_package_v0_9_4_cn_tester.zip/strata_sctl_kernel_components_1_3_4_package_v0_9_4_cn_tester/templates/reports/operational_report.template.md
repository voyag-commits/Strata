---
contract_id: strata.operational_report.template.v1
report_kind: operational_report
assignment_id: <assignment_id>
agent_id: <agent_id>
role: <role>
created_at: <ISO-8601>
---

# Operational Report

## Operational Summary

<concise summary>

## Progress Delta

<what changed since the previous accepted state>

## Trunk Integration

<direct-to-trunk or short-lived branch metadata using declared template/file references>

## Verification

<checks performed>

## Evidence

<evidence embedded here, or none_required>

## Risks / Blockers

<risks, blockers, or none>

## Next Action

<next SCTL action requested>
