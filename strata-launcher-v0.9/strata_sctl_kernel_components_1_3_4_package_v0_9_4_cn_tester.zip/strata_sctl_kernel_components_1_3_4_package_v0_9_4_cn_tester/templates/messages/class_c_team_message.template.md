---
contract_id: strata.class_c.team_message.v1
class: C
message_id: TM_<assignment>_<sequence>
thread_id: THREAD_<assignment>
assignment_id: <assignment_id>
from_role: <sender_role>
from_id: <sender_id>
to_role: <receiver_role>
to_id: <receiver_id>
message_kind: qc_review_request
status: open
requires_response: true
related_class_b: .strata/context/B/<report>.md
created_at: <ISO-8601>
---

# Team Message

## Message

<question, review request, QC feedback, clarification, or handoff note>

## Requested Handling

<expected reply or outcome report>
