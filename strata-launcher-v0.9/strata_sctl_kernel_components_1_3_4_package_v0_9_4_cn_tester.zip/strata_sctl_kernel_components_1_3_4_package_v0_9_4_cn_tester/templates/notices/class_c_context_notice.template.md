---
contract_id: strata.class_c.context_notice.v1
class: C
notice_id: CTX_<assignment>_<target>_<revision>
notice_kind: class_b_update
assignment_id: <assignment_id>
target_role: <role>
target_id: <session_id>
context_epoch: <epoch>
context_revision: <revision>
class_b_updates_since_full_refresh: <count>
refresh_required: false
status: pending
created_at: <ISO-8601>
---

# Context Notice

## Notice

A Class B report changed for this assignment.

## Related Class B

- .strata/context/B/<report>.md

## Handling

This notice is queued for the next paste-ready dispatch packet to this session.
