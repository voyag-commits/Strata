# 中文测试员入口

优先阅读：

```text
docs/zh-CN/00_测试员入口.md
```

常用命令：

```bash
npm run tester:live-all
npm run tester:dod
```

生成的 dispatch packet 位于：

```text
.strata/dispatch_outbox/<assignment>/<target_id>/<nonce>/dispatch_packet.md
```

测试员把该文件内容粘贴到目标会话输入框，按 Enter，目标角色即可按 packet 内容继续工作。
