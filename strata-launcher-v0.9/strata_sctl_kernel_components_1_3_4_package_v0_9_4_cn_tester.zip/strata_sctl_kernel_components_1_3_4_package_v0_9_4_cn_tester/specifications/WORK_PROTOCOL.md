# SCTL Work Protocol v0.9.3

## Normal Assignment Flow

```text
Tooling Operator registers active role sessions.
Tooling Operator records dispatch with declared template/file references.
Worker returns OPERATIONAL_REPORT_READY with valid operational report.
Tooling Operator commits durable state as Class B when appropriate.
SCTL queues Class C context notices for current-assignment sessions.
Sender creates Class C team message to next role.
SCTL renders paste-ready dispatch packet with pending notice, team message, and related Class B delta.
Reviewer continues from the bounded packet.
```

## Full Refresh Flow

```text
Class A update accepted
  -> context_epoch increments
  -> refresh_required set true
  -> next workers receive full context export

Class B updates exceed threshold
  -> refresh_required set true
  -> active sessions can be retired and restarted with full context export
```
