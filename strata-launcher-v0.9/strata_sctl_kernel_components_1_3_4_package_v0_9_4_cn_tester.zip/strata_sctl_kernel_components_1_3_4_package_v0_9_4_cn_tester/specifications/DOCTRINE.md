# SCTL Doctrine v0.9.3

SCTL is the context and progress tracking control plane for trunk-based development teams.

## Doctrine

1. SCTL context Git is isolated under `.strata/context/`.
2. Product implementation Git is managed outside SCTL.
3. Class A owns architecture, doctrine, contracts, and bootstrap file-pin policy.
4. Class B owns validated operational reports and progress records.
5. Class C owns team communication, context notices, and role-to-role working threads.
6. Class D_trace owns dispatch logs, telemetry, diagnostics, and raw trace records.
7. Every dispatch creates a Git-tracked dispatch log.
8. Every Class B update queues a lightweight Class C notice for current-assignment sessions.
9. Next targeted dispatch merges pending notices into the paste-ready packet.
10. Class A updates and Class B drift beyond threshold mark sessions for full context refresh.
