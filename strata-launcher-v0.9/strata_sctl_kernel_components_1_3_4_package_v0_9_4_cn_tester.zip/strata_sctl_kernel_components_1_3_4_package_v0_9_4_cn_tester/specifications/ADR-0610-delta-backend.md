# ADR-0610: SCTL Delta Backend v0.9.3

## Decision

SCTL backend development uses file-delta fixtures, declared template/file references, strict reports, and context Git history as the acceptance surface.

## Authority

```text
Class A: architecture, doctrine, contracts, bootstrap file-pin policy
Class B: strict operational reports
Class C: team messages and context notices
Class D_trace: dispatch logs, telemetry, diagnostics, raw traces
```

## Dispatch

Dispatch creates paste-ready outbox artifacts and a Git-tracked dispatch log. Local runtime delivery belongs to runtime-edge handshake.

## Worker Returns

`OPERATIONAL_REPORT_READY` ledgers a valid operational report. Class B updates happen through strict Class B report files and commits.

## Evidence

Evidence is embedded in operational report and Class B report sections.
