# Trunk-Based Work Discipline for SCTL v0.9.3

SCTL records trunk-based work as coordination and context state.

## Standard Scenes

```text
direct_to_trunk_small_change
short_lived_branch_review
blocker_recovery
pending_notice_merge
```

## Records

- Dispatch records capture assignment, target, nonce, and declared template/file references.
- Class B reports capture accepted operational state.
- Class C messages capture questions, review requests, feedback, and handoff notes.
- Class C notices capture context update awareness for current-assignment sessions.
- Class D_trace captures dispatch logs and telemetry.

## Team Activity Log

The SCTL context Git log is the compact team activity timeline.
