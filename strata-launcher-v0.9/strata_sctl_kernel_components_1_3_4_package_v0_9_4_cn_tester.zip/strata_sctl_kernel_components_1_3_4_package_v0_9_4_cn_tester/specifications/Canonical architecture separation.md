# Canonical Architecture Separation v0.9.3

## SCTL Backend

SCTL owns `.strata/context/` and records coordination state in an isolated Git repository.

## Implementation Repository

Product codebase Git remains separate. Fixture/backend tests use declared template paths instead of repository watching.

## Runtime Edge

Runtime edge owns local session delivery, including chatbox paste, WSL, tmux, and Codex launcher integration.

## Contract Boundary

SCTL prepares paste-ready packets and records dispatch logs. Runtime edge performs local delivery when handshake exists.
