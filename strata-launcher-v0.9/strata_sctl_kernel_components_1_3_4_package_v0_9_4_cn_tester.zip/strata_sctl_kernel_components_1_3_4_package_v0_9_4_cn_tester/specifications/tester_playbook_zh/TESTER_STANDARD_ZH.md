# SCTL 中文测试员标准

## 角色定位

测试员以 Tooling / Dispatch Operator 视角操作 SCTL，并在本地会话中模拟团队角色的接收与返回。

## 测试记录标准

每个测试用例记录：

```text
测试编号
assignment_id
source role / id
target role / id
CLI 命令
JSON result envelope
生成文件路径
SCTL context Git log
telemetry 片段
session paste 记录
最终结论
```

## 证据等级

| 等级 | 证据 |
|---|---|
| A | SCTL context Git commit + 文件路径 |
| B | CLI result envelope |
| C | telemetry JSONL |
| D | 人工 paste 记录 |

## 验收口径

一次功能验收通过时，应能复述：

```text
谁发起了工作
发给了哪个角色会话
关联的 Class B 报告是哪一个
pending notice 是否合并进入 dispatch packet
目标会话如何处理 packet
结果如何进入 Class C 或 Class B
SCTL Git log 如何记录该活动
```
