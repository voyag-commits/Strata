# 验收矩阵（中文测试员版）

| 编号 | 功能 | 证据 | 结论 |
|---|---|---|---|
| F01 | SCTL context Git 独立 | `.strata/context/.git` 与 Git log | 通过时填写 |
| F02 | Tool registry | `tools list` 输出 | 通过时填写 |
| F03 | Class C team message | `.strata/context/C/threads` | 通过时填写 |
| F04 | Class C pending notice | `.strata/context/C/notices` | 通过时填写 |
| F05 | Class B update queue notice | classb result `queued_notices` | 通过时填写 |
| F06 | Dispatch merge notice | dispatch packet 顶部 notice | 通过时填写 |
| F07 | Paste-only packet | dispatch manifest | 通过时填写 |
| F08 | Telemetry JSONL | `workflow_telemetry.jsonl` | 通过时填写 |
| F09 | Context state | `context_state.json` | 通过时填写 |
| F10 | B drift threshold | `refresh_required: true` | 通过时填写 |
| F11 | A update epoch | epoch 增加 | 通过时填写 |
| F12 | Fixture trunk scenes | fixture Git log | 通过时填写 |
| F13 | Invalid Class B denial | `commit_denied: true` | 通过时填写 |
| F14 | Live session paste | paste record | 通过时填写 |
