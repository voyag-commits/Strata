# 测试报告模板

## 包版本

```text
v0.9.4-cn-tester
```

## 测试环境

```text
测试员：
日期：
OS / WSL：
Node.js：
Git：
tmux：
```

## 命令记录

```bash
npm test
npm run secret-scan
npm run tester:live-all
```

## 证据路径

```text
SCTL workspace：
latest dispatch packet：
FINAL_DOD_REPORT：
```

## 人工会话记录

```text
source：
target：
packet path：
paste time：
目标返回：
```

## 结论

```text
通过 / 需复测 / 需修订
```
