# Live Session Playbook（WSL / tmux / session launcher）

## 目标

把 SCTL 生成的 dispatch packet 投递到目标角色会话，并验证目标会话基于 packet 开始工作。

## 标准流程

```text
SCTL 生成 packet
测试员打开 packet
测试员粘贴到目标会话底部
测试员按 Enter
目标角色执行 packet 中 Required Action
目标角色返回 Class C 或 Class B
测试员通过 SCTL 验证并收集证据
```

## tmux 示例

```bash
bash scripts/tester_live/10_optional_tmux_session_handshake.sh
PACKET="$(cat .tester_runs/results/latest_dispatch_packet_path.txt)"
tmux load-buffer "$PACKET"
tmux paste-buffer -t sctl_reviewer_001
tmux send-keys -t sctl_reviewer_001 C-m
```

## 粘贴记录

使用模板：

```text
templates/tester_zh/session_paste_record.blank.zh-CN.md
```
