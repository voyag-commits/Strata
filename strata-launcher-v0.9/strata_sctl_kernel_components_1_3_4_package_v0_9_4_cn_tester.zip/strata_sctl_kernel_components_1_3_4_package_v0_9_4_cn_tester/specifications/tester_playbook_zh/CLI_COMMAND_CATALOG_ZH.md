# CLI 命令目录（中文测试员版）

## 一键 live 测试

```bash
npm run tester:live-all
```

## 分段测试

```bash
npm run tester:prepare
npm run tester:tools
npm run tester:notice
npm run tester:invalid-classb
npm run tester:drift
npm run tester:classa
npm run tester:fixtures
npm run tester:dod
```

## 手工 CLI 流程

```bash
node src/cli.js context bootstrap --workspace .tester_runs/live_workspace
node src/cli.js sessions register --workspace .tester_runs/live_workspace --assignment-id A100 --role "Change Author" --id change_author_001
node src/cli.js sessions register --workspace .tester_runs/live_workspace --assignment-id A100 --role "Reviewer / QC Engineer" --id reviewer_001
node src/cli.js classb put --workspace .tester_runs/live_workspace --id B_A100_OPERATIONAL_READY --title "A100 operational ready" --assignment-id A100 --agent-id change_author_001 --role "Change Author"
node src/cli.js message send --workspace .tester_runs/live_workspace --assignment-id A100 --thread-id THREAD_A100_REVIEW --from-role "Change Author" --from-id change_author_001 --to-role "Reviewer / QC Engineer" --to-id reviewer_001 --message-kind qc_review_request --related-class-b .strata/context/B/b_a100_operational_ready.md --body "Please review."
node src/cli.js dispatch record --workspace .tester_runs/live_workspace --assignment-id A100 --nonce A100_N1 --from-role "Change Author" --from-id change_author_001 --target-role "Reviewer / QC Engineer" --target-id reviewer_001 --message-file .strata/context/C/threads/thread_a100_review/tm_a100_review_request.md --related-class-b .strata/context/B/b_a100_operational_ready.md
```
