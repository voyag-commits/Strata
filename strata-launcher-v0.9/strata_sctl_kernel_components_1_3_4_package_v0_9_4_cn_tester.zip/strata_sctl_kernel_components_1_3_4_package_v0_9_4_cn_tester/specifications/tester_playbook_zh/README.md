# 中文专用测试员 Playbook

本目录是中文测试员的标准操作入口。

推荐顺序：

```text
1. TESTER_STANDARD_ZH.md
2. CLI_COMMAND_CATALOG_ZH.md
3. LIVE_SESSION_PLAYBOOK_ZH.md
4. ACCEPTANCE_MATRIX_ZH.md
5. TEST_REPORT_TEMPLATE_ZH.md
```

核心测试理念：

```text
CLI 操作 SCTL
Git log 记录团队活动
Class B 承载运营报告
Class C 承载团队沟通
D_trace 承载派发日志与遥测
local session 通过 paste-only packet 接收工作
```
