# SCTL Testing Standard v0.9.3

Acceptance requires:

- SCTL context Git remains isolated.
- Dispatch records create outbox artifacts and Git-tracked dispatch logs.
- Class B reports pass strict frontmatter and section validation.
- Invalid Class B files create commit-denied results and error dispatches.
- Every accepted Class B update queues Class C context notices for current-assignment sessions.
- Next targeted dispatch merges pending notices into paste-ready packets.
- OPERATIONAL_REPORT_READY validates the operational report body and remains separate from Class B commits.
- Tool registry reports runtime/session flags false for all SCTL backend tools.
- Fixture scenes produce a readable SCTL context Git activity log.
