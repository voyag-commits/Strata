# Tester Playbook v0.9.3

Use this directory for backend acceptance testing with fixtures and blank templates. The tests exercise SCTL as the Tooling / Dispatch Operator role.
