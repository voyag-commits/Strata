# SCTL Test Report

## Test Scope

<fixture scene or CLI workflow>

## Commands Run

```bash
<commands>
```

## Result

<pass/fail and summary>

## Git Activity Evidence

```text
<git log --oneline output>
```

## Notes

<short operational notes>
