# Acceptance Matrix v0.9.3

| Area | Required Result |
|---|---|
| Context Git | Isolated under `.strata/context/` |
| Class A | Update increments epoch and marks refresh required |
| Class B | Strict report validation and accepted Git commit |
| Class B failure | Commit denied and error dispatch recorded |
| Class C | Team message and context notice contracts validate |
| Notice queue | Every Class B update queues current-assignment notices |
| Notice merge | Next targeted dispatch merges pending notice |
| Dispatch | Outbox + Git dispatch log + telemetry |
| Worker returns | OPERATIONAL_REPORT_READY validates report body |
| Evidence | Embedded in report body |
| Fixtures | Trunk scenes produce team activity Git log |
| Tools | Operational tooling only; runtime/session flags false |
