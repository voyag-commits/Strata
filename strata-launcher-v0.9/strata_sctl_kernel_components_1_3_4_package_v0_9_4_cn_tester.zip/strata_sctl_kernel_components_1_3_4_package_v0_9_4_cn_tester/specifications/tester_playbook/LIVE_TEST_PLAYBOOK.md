# Live Test Playbook v0.9.3

Current package scope is backend and fixture testing.

Local/session handshake acceptance can extend the same dispatch packet:

```text
SCTL renders paste-ready packet
operator or runtime-edge pastes packet into target session
worker replies with Worker Return Packet or Class C/Class B artifact
SCTL validates and Git-logs the result
```

Backend acceptance remains valid before local handshake because dispatch-to-Git is primary evidence.
