# SCTL Command Catalog for Testing v0.9.3

```bash
node src/cli.js context bootstrap --workspace <workspace>
node src/cli.js sessions register --workspace <workspace> --assignment-id A001 --role "Reviewer / QC Engineer" --id reviewer_001
node src/cli.js dispatch record --workspace <workspace> --assignment-id A001 --nonce N1 --target-role "Change Author" --target-id change_author_001 --summary "Prepare template change" --declared-file TEMPLATE:src/example.md
node src/cli.js classb put --workspace <workspace> --id B_A001_READY --title "Ready" --assignment-id A001 --agent-id change_author_001 --role "Change Author"
node src/cli.js message send --workspace <workspace> --assignment-id A001 --from-role "Change Author" --from-id change_author_001 --to-role "Reviewer / QC Engineer" --to-id reviewer_001 --message-kind qc_review_request --body "Please review." --related-class-b .strata/context/B/b_a001_ready.md
node src/cli.js dispatch record --workspace <workspace> --assignment-id A001 --nonce N2 --target-role "Reviewer / QC Engineer" --target-id reviewer_001 --message-file .strata/context/C/threads/thread_a001/tm.md --related-class-b .strata/context/B/b_a001_ready.md
node src/cli.js fixtures run-scene --workspace <workspace> --name pending_notice_merge
node src/cli.js tools list --workspace <workspace>
node src/cli.js secret-scan --workspace <package_root>
```
