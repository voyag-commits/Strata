# Package SHA Note

Package-level ZIP SHA256 is provided beside the release archive as `.zip.sha256`.

Internal file checksums are provided in `PACKAGE_CHECKSUMS.sha256`.
