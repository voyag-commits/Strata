# SCTL User Inputs — Minimal Revision Preserve

This file preserves the user's design inputs with light spelling and grammar cleanup while keeping the original concise design taste.

## 1. Package review and SCTL backend direction

There is a clear SCTL backend development choice because SCTL is separated from the launcher of Codex session spawn. The primary workflow in SCTL is the file delta.

Create a replacement script that allows the tester to manually drop a file into Git and mimic the worker committing a Class B context: operational-ready report.

SCTL backend also checks whether the report is correctly formatted. A few indexed blank reports can be used to mimic the actual workflow cycle.

The entire SCTL optimization and refactor can be done in the cloud environment with handshake to real live agent sessions because the only handshake is dispatch and report file drop to Git in SCTL. That part can be replaced by script.

## 2. Backend development and fixture testing

Assume the backend development and tests use fixtures.

If Class B validation fails, SCTL automatically denies the Git commit and drops a dispatch of error log back to the sender's session.

Eliminate `EVIDENCE_READY`. Evidence should always be included in the Class B report definition.

Key areas to work on:

1. The cloud refactor should focus on cutting down over-engineering.
2. Tool registry and tests: in the test environment, run the tools under the assumption that the role is Operational Tooling.
3. Additional feature: SCTL Git is for progress tracking and context distillation. Any dispatch should be logged into Git automatically. Current package has no dispatch session targets, so leave local delivery until local handshake. Treat dispatch to Git as the primary accepted evidence.
4. Standard trunk-based development has several workflows and scenes. Simulate those scenes with template files, with no live file until handshake with local. The focus is a Git log that records team activities.
5. Recommendations are largely accepted when they preserve SCTL's fundamental purposes. SCTL should be simple, manageable, CLI reachable, hold context Git cleanly, and suit context and progress tracking for most trunk-based development scenes. Codebase Git is separate and SCTL avoids watching it.

## 3. Architecture overview request

Provide a comprehensive architectural overview flow map for SCTL in Markdown format.

## 4. Workflow testing question

Confirm whether SCTL's workflow was tested.

## 5. Telemetry log idea

Consider adding a telemetry log so the workflow can be monitored line by line, with each line carrying one activity.

## 6. Team internal dispatch / communication file idea

Consider adding a team internal dispatch file.

There are two types of files in SCTL Git:

1. The current operational report files.
2. Another file type with a header that sessions fill: from `(role; id)` to `(role; id)`. The rest of the template supports questions, inquiry, and QC feedback.

A secondary template is needed because not all internal team communication in trunk-based development is an operational report.

## 7. Class C correction

Class C was previously framed as doctrine and file pin map assigned at bootstrap, but in the recent official definition that belongs to Class A. Team messages can belong to Class C. This is a correction if agreed.

## 8. Context contract update sync

How should the context of SCTL Git's contract update be synced?

Dispatch is the primary path. Simply copy it to the correct chat box.

Example:

- Code reviewer's prompt input is from Change Author.
- Change Author uses CLI to send to Code Reviewer role: Class C communication comment plus a file path of the operational report in Class B.
- In the Code Reviewer's chat box, it becomes Class C communication plus copy of Class B delta.
- No pin map is included, because pinned files load automatically.
- Press Enter, and reviewer work starts freshly.

## 9. Context refresh simplification

Updating Class A context continuously is too complicated.

Policy idea:

- If Class A context update count equals 1, retire sessions and restart sessions with full context export tool.
- If Class B context update count is greater than 10, retire sessions and restart sessions with full context export tool.
- Then dispatch the full context file that loads Class A and Class B into every new worker's chat.

Question:

How should we manage context updates for next workers that the sender is not directly pointing to?

Possibility:

Use a file-path pin load notice at the top of the rest of the team's chatbox so they know context was updated and can check if they want.

## 10. Lightweight notice merge policy

The lightweight pin notice should be dispatched at the time of a Class B update, but held before pressing Enter.

It should merge with the next sender's message when the sender points toward that session and drops a team message.

Confirmed policy:

1. Every Class B update creates a lightweight notice. This is easier to manage and check.
2. Notice scope is current assignment.
3. Delivery is paste-only. SCTL has no need to inspect what is already in the chatbox; each paste goes under what was already pasted.

## 11. Documentation style and deliverables

In documents, avoid phrasing that sounds like commands to a machine. Treat the audience as human directors.

Proceed with the full SCTL codebase revision and operational tests using fixtures and blank templates.

Deliver one additional file separately from the package: a file of all user original inputs, minimally revised to preserve the original design taste and conciseness, so these inputs can be reused in the future.

## 12. Dedicated Chinese tester-facing package

Create a dedicated Chinese version of the SCTL package, specifically for testers.

The tester will handshake with local WSL, tmux, and the session launcher, then proceed with feature tests for the features added earlier.

For a standard human tester, provide procedures to verify features during workflows.

The package should reference common playbook standards for a dedicated tester. Recommended content:

- Clear CLI manuals to operate SCTL and scripts, beyond unit tests, because testing happens live.
- Clear session-to-session workflow verification.
- Clear Definition of Done.

Feature areas to cover:

```text
Class C team message contract
Class C pending context notice contract
active session registry
every Class B update queues current-assignment notices
next targeted dispatch merges pending notices into paste-ready packet
paste-only delivery mode
workflow telemetry JSONL
context epoch / revision state
Class B drift threshold > 10 refresh_required behavior
Class A update epoch increment behavior
fixture scenes for trunk-based workflows
CLI smoke test as Tooling / Dispatch Operator
```
