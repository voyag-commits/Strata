# SCTL CLI 手册（测试员版）

所有命令均可加：

```bash
--workspace <workspace>
```

默认测试脚本使用：

```text
.tester_runs/live_workspace
```

## 初始化上下文

```bash
node src/cli.js context bootstrap --workspace .tester_runs/live_workspace
node src/cli.js context repo-status --workspace .tester_runs/live_workspace
```

验证点：

```text
.strata/context/.git 存在
context_state.json 存在
Git log 包含 strata context bootstrap
```

## 注册活动会话

```bash
node src/cli.js sessions register \
  --workspace .tester_runs/live_workspace \
  --assignment-id A100 \
  --role "Change Author" \
  --id change_author_001

node src/cli.js sessions register \
  --workspace .tester_runs/live_workspace \
  --assignment-id A100 \
  --role "Reviewer / QC Engineer" \
  --id reviewer_001

node src/cli.js sessions list --workspace .tester_runs/live_workspace
```

验证点：

```text
Class C session registry 写入 .strata/context/C/sessions/active_sessions.json
Git log 包含 session register A100 reviewer_001
```

## 写入 Class B 报告

```bash
node src/cli.js classb put \
  --workspace .tester_runs/live_workspace \
  --id B_A100_OPERATIONAL_READY \
  --title "A100 operational ready" \
  --assignment-id A100 \
  --agent-id change_author_001 \
  --role "Change Author" \
  --scope actionable_report \
  --summary "Change Author completed the bounded work." \
  --progress-delta "Progress delta is recorded in Class B." \
  --trunk-integration "Trunk-based fixture path is used." \
  --verification "CLI validation passed." \
  --risks "No active blocker." \
  --next-action "Reviewer receives Class C review request."
```

验证点：

```text
Class B 文件写入 .strata/context/B/
Class B 验证通过
当前 assignment 的活动 session 获得 pending context notice
context_revision 增加
telemetry 记录 classb.commit.completed
```

## 发送 Class C 团队消息

```bash
node src/cli.js message send \
  --workspace .tester_runs/live_workspace \
  --assignment-id A100 \
  --thread-id THREAD_A100_REVIEW \
  --message-id TM_A100_REVIEW_REQUEST \
  --from-role "Change Author" \
  --from-id change_author_001 \
  --to-role "Reviewer / QC Engineer" \
  --to-id reviewer_001 \
  --message-kind qc_review_request \
  --related-class-b .strata/context/B/b_a100_operational_ready.md \
  --body "Please review the Class B report and return QC feedback or review outcome."
```

验证点：

```text
Class C 消息写入 .strata/context/C/threads/
frontmatter 包含 from_role / from_id / to_role / to_id
Git log 包含 team message
```

## 生成 paste-only dispatch packet

```bash
node src/cli.js dispatch record \
  --workspace .tester_runs/live_workspace \
  --assignment-id A100 \
  --nonce A100_N1 \
  --from-role "Change Author" \
  --from-id change_author_001 \
  --target-role "Reviewer / QC Engineer" \
  --target-id reviewer_001 \
  --summary "Review request with pending notice." \
  --message-file .strata/context/C/threads/thread_a100_review/tm_a100_review_request.md \
  --related-class-b .strata/context/B/b_a100_operational_ready.md \
  --dispatch-kind TEAM_MESSAGE
```

验证点：

```text
.strata/dispatch_outbox/A100/reviewer_001/A100_N1/dispatch_packet.md 存在
packet 顶部包含 Pending Context Notice
packet 包含 Class C Team Message
packet 包含 Related Class B Delta
notice status 更新为 merged_to_dispatch
Git log 包含 dispatch record A100 A100_N1
```

## 工具登记表

```bash
node src/cli.js tools list --workspace .tester_runs/live_workspace
node src/cli.js tools inspect --workspace .tester_runs/live_workspace --tool sctl.message.send.v1
```

验证点：

```text
operator_role = Tooling / Dispatch Operator
runtime_tmux = false
watches_implementation_git = false
```

## Fixture 场景

```bash
node src/cli.js fixtures list-scenes --workspace .tester_runs/live_workspace
node src/cli.js fixtures run-scene --workspace .tester_runs/live_workspace --name pending_notice_merge
```

验证点：

```text
fixture 产生可读 Git activity log
Class B / Class C / dispatch / telemetry 证据路径齐全
```
