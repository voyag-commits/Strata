# 本地 WSL / tmux / session launcher 握手手册

## 适用范围

本手册用于把 SCTL 生成的 paste-ready dispatch packet 投递到本地会话。SCTL 当前负责 packet 生成与 Git 记录；本地会话启动器负责目标会话窗口、粘贴与 Enter。

## 推荐会话名

```text
sctl_change_author_001
sctl_reviewer_001
sctl_tech_lead_001
sctl_tooling_operator
```

## 准备 tmux 会话

```bash
bash scripts/tester_live/10_optional_tmux_session_handshake.sh
```

该脚本会输出推荐的 tmux 命令。测试员也可手动创建：

```bash
tmux new-session -d -s sctl_change_author_001
tmux new-session -d -s sctl_reviewer_001
tmux new-session -d -s sctl_tooling_operator
```

## 生成派发包

```bash
npm run tester:notice
```

查看 packet：

```bash
cat .tester_runs/results/latest_dispatch_packet_path.txt
cat "$(cat .tester_runs/results/latest_dispatch_packet_path.txt)"
```

## 粘贴到目标会话

示例：把 reviewer packet 放入 reviewer 会话。

```bash
PACKET="$(cat .tester_runs/results/latest_dispatch_packet_path.txt)"
tmux load-buffer "$PACKET"
tmux paste-buffer -t sctl_reviewer_001
tmux send-keys -t sctl_reviewer_001 C-m
```

测试员也可使用 GUI 复制该文件全文，粘贴到目标 chatbox 底部，然后按 Enter。

## 目标会话预期动作

Reviewer 收到 packet 后，按 packet 中 Required Action 执行。

典型返回：

```text
Class C qc_feedback
Class C clarification_request
Class B review_outcome
```

## 记录标准

每次人工粘贴记录以下内容：

```text
source role / id
target role / id
assignment id
nonce
packet path
paste time
operator name
目标会话产生的返回文件路径
```

模板：

```text
templates/tester_zh/session_paste_record.blank.zh-CN.md
```
