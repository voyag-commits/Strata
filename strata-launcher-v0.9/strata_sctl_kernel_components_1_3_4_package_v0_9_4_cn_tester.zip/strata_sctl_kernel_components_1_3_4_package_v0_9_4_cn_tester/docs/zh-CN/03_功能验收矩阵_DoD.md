# 功能验收矩阵与 DoD

## 总体 DoD

一次合格测试交付应包含：

```text
unit tests 通过
secret scan 通过
live feature scripts 通过
SCTL context Git log 可读
telemetry JSONL 有工作流事件
Class B / Class C / context notice / dispatch packet 证据齐全
至少一次 session-to-session paste 验证记录
最终测试报告完成
```

## 功能矩阵

| 功能 | 测试方法 | 通过证据 |
|---|---|---|
| Class C team message contract | `npm run tester:notice` | `.strata/context/C/threads/**.md`，`message validate` ok |
| Class C pending context notice contract | Class B 更新后检查 notice 文件 | `.strata/context/C/notices/pending/<target>/*.md` |
| active session registry | `npm run tester:prepare` | `.strata/context/C/sessions/active_sessions.json` |
| 每次 Class B 更新排队当前 assignment notice | `classb put` 后检查 queued_notices | result JSON 中 `queued_notices` 非空 |
| 下一次目标 dispatch 合并 pending notice | `dispatch record` 指向 reviewer | packet 中 `Pending Context Notice`，result `notice_count >= 1` |
| paste-only delivery mode | 查看 dispatch packet / manifest | `runtime_delivery: paste_only_packet_ready` |
| workflow telemetry JSONL | 查看 telemetry | `workflow_telemetry.jsonl` 包含 session/message/classb/dispatch 事件 |
| context epoch / revision | `context repo-status` | `context_state.json` 中 epoch / revision 可读 |
| Class B drift threshold > 10 | `npm run tester:drift` | `refresh_required: true` |
| Class A update epoch increment | `npm run tester:classa` | `context_epoch` 增加，`refresh_required: true` |
| fixture trunk workflow | `npm run tester:fixtures` | fixture Git activity log 可读 |
| CLI smoke as Tooling Operator | `npm run tester:tools` | tool registry flags 符合边界 |
| invalid Class B commit denial | `npm run tester:invalid-classb` | result ok=false，commit_denied=true，ERROR_LOG dispatch 产生 |

## 人工 session-to-session DoD

```text
Change Author 产出 Class B operational report
Change Author 发送 Class C qc_review_request 指向 Reviewer
SCTL 生成 reviewer dispatch packet
packet 顶部包含 pending context notice
packet 包含 Class C message
packet 包含 Class B delta
测试员将 packet 粘贴到 reviewer 会话并按 Enter
Reviewer 基于 packet 产出 Class C feedback 或 Class B review_outcome
SCTL 验证返回文件并记录 Git log
```
