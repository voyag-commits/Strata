# Changelog v0.9.4-cn-tester

## Added

- 中文测试员专用入口 README 与 docs/zh-CN 文档集。
- 中文 dedicated tester playbook：测试员标准、CLI 命令目录、live session playbook、验收矩阵、测试报告模板。
- `scripts/tester_live/` live 功能验证脚本。
- `npm run tester:*` 脚本入口。
- WSL / tmux / session launcher 粘贴式握手手册。
- 中文 blank templates：Class B 报告、Class C 团队消息、context notice、paste 记录、DoD checklist。
- dispatch record 相对 `--message-file` 路径解析测试。

## Fixed

- `dispatch record --message-file .strata/...` 现在会按 workspace 解析相对路径，并把 Class C Team Message 正确合并进 paste-ready packet。

## Preserved

- Class C team message contract。
- Class C pending context notice contract。
- active session registry。
- 每次 Class B update 排队当前 assignment notice。
- 下一次目标 dispatch 合并 pending notice。
- paste-only delivery mode。
- workflow telemetry JSONL。
- context epoch / revision state。
- Class B drift threshold > 10 refresh_required。
- Class A update epoch increment。
- trunk-based fixture scenes。
- Tooling / Dispatch Operator CLI smoke path。
