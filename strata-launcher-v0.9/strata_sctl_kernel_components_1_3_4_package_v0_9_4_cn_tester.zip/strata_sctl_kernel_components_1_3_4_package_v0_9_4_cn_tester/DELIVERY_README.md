# Delivery README v0.9.3

This package delivers the SCTL backend kernel for Components 1/3/4.

Primary capabilities:

```text
isolated SCTL context Git
strict Class B report validation
Class C team messages and context notices
paste-ready dispatch packets
dispatch Git logs
workflow telemetry JSONL
fixture scenes for trunk-based workflows
operational tooling CLI tests
```

Recommended acceptance commands:

```bash
npm test
npm run secret-scan
sha256sum -c PACKAGE_CHECKSUMS.sha256
```
