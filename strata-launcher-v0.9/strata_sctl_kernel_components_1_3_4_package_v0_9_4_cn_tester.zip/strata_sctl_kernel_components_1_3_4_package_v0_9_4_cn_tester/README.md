# Strata SCTL 中文测试员专用包 v0.9.4-cn-tester

本包面向标准人类测试员，用于在 WSL / tmux / 本地会话启动器环境中验证 SCTL 工作流。

SCTL 的核心定位：

```text
SCTL = Git 支撑的上下文与进度跟踪控制面
```

当前包保留 v0.9.3 的核心功能，并增加中文测试员层：

```text
Class A：架构、 doctrine、合约、bootstrap 文件 pin 政策
Class B：严格验证的运营报告、进度记录、评审结论、缺陷记录
Class C：团队消息、上下文轻量通知、角色到角色沟通
Class D_trace：派发日志、遥测、诊断、原始轨迹
```

## 测试员快速入口

```bash
npm test
npm run secret-scan
npm run tester:live-all
```

live-all 会创建测试工作区，执行：

```text
CLI 工具登记检查
Class C 团队消息验证
Class B 更新触发当前 assignment 的 pending notice
下一次指向该 session 的 dispatch 合并 pending notice
paste-only 派发包生成
无效 Class B 提交拒绝与 error dispatch
workflow telemetry JSONL
context epoch / revision 状态
Class B 超过阈值后的 refresh_required
Class A 更新后的 epoch 增量
trunk-based fixture 场景
最终 DoD 证据收集
```

## 中文文档

```text
docs/zh-CN/00_测试员入口.md
docs/zh-CN/01_CLI手册.md
docs/zh-CN/02_本地WSL_TMUX握手手册.md
docs/zh-CN/03_功能验收矩阵_DoD.md
docs/zh-CN/04_会话到会话测试流程.md
docs/zh-CN/05_测试报告模板.md
specifications/tester_playbook_zh/README.md
```

## live 测试脚本

```text
scripts/tester_live/00_prepare_workspace.sh
scripts/tester_live/01_verify_cli_tool_registry.sh
scripts/tester_live/02_verify_classc_notice_merge.sh
scripts/tester_live/03_verify_classb_invalid_denial.sh
scripts/tester_live/04_verify_classb_drift_threshold.sh
scripts/tester_live/05_verify_classa_epoch_update.sh
scripts/tester_live/06_run_fixture_scenes.sh
scripts/tester_live/10_optional_tmux_session_handshake.sh
scripts/tester_live/99_collect_dod_evidence.sh
scripts/tester_live/run_all_live_feature_tests.sh
```

## 默认工作区

```text
.tester_runs/live_workspace
.tester_runs/results
```

测试员可通过环境变量替换：

```bash
export SCTL_WORKSPACE=/path/to/workspace
export SCTL_RESULTS=/path/to/results
```

## 交付边界

本包负责生成、验证、记录和归档 SCTL 工作流证据。local WSL / tmux / session launcher 负责把 paste-ready dispatch packet 送入目标会话。
