# SCTL Architecture v0.9.3

## Purpose

SCTL records coordination, validates reports, maintains context classes, and creates a clean Git timeline of team progress.

## Boundary

```text
SCTL context Git: .strata/context/
Implementation Git: managed by product development outside SCTL
Runtime edge: local paste/session handoff, future handshake package
```

SCTL backend accepts fixture/template paths during cloud tests. Runtime session delivery is represented by paste-ready dispatch packets.

## Context Classes

| Class | Content | Authority |
|---|---|---|
| A | Architecture, doctrine, contracts, bootstrap file-pin policy | Git-tracked Markdown |
| B | Operational reports, progress records, review outcomes, defect records | Strict validated Git-tracked Markdown |
| C | Team messages, context notices, role-to-role communication | Validated Git-tracked Markdown |
| D_trace | Dispatch logs, telemetry, diagnostics, raw traces | Git-tracked trace artifacts |

## Primary Flow

```text
Context bootstrap
  -> active session registry
  -> dispatch record
  -> Worker Return Packet classify
  -> Class B report commit
  -> Class C pending notice queued for current assignment sessions
  -> Class C message sent to target role/session
  -> dispatch packet rendered with pending notice + message + Class B delta
  -> dispatch log committed to SCTL context Git
```

## Context Refresh Policy

```text
Every Class B update:
  queue lightweight Class C context notice for current assignment sessions

Class B updates > 10 since full refresh:
  mark refresh_required in context state

Every Class A update:
  increment context_epoch and mark refresh_required

Existing sessions:
  receive pending notices through the next targeted paste-ready dispatch packet

New or retired sessions:
  receive full context export containing Class A and Class B
```

## Dispatch Packet Model

A dispatch packet contains:

```text
pending Class C context notice, when queued
Class C team message, when present
related Class B delta content, when referenced
declared template/file references
required action
paste-only delivery instruction
```

Each dispatch writes:

```text
.strata/dispatch_outbox/<assignment>/<target>/<nonce>/dispatch_packet.md
.strata/dispatch_outbox/<assignment>/<target>/<nonce>/dispatch_packet.json
.strata/context/D_trace/dispatch_log/*.json
.strata/context/D_trace/telemetry/workflow_telemetry.jsonl
```

The dispatch log and telemetry are committed to context Git.
