# Operational Test Report v0.9.3

## Scope

This test run covers the SCTL backend workflow with fixtures and CLI smoke checks. Runtime-edge local session handshake remains a separate integration layer.

## Tested Capabilities

```text
context bootstrap
isolated context Git inside outer Git repo
session registration
strict Class B report write, validate, commit
invalid Class B commit denial with error dispatch
current-assignment pending notice queue
Class C team message write and validate
pending notice merge into paste-ready dispatch packet
dispatch outbox artifact creation
dispatch Git log commit
workflow telemetry JSONL
OPERATIONAL_REPORT_READY report validation
EVIDENCE_READY retirement
Class A epoch update behavior
Class B drift threshold > 10 behavior
fixture scene Git activity log
tool registry boundary
CLI workflow from Tooling / Dispatch Operator perspective
secret scan
checksum verification
```

## Automated Test Result

```text
npm test: 15/15 passed
```

## Secret Scan

```text
npm run secret-scan: passed
```

## Fixture Git Activity Pattern

Expected activity log includes commits like:

```text
d410f2f dispatch record A004 A004_N1
55ce23b team message A004 coordination_note change_author_001 -> reviewer_001
b120134 class B report put B_A004_OPERATIONAL_READY
40c670c session register A004 reviewer_001
31e6f3c session register A004 change_author_001
b98ebb6 telemetry context bootstrap
d25da58 strata context bootstrap
```

## Acceptance Statement

The backend workflow supports cloud fixture testing for SCTL context and progress tracking. Paste-ready dispatch packets are prepared and Git-logged as accepted backend evidence.
