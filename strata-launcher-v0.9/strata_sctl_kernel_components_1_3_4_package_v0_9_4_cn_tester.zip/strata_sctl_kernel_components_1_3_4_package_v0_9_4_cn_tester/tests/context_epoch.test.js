import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { putContextEntry, repoStatus } from "../src/lib/context.js";

function tmp(name) { return fs.mkdtempSync(path.join(os.tmpdir(), name)); }

test("Class A update increments context epoch and marks refresh required", () => {
  const root = tmp("sctl-classa-epoch-");
  const before = repoStatus(root).result.state;
  const result = putContextEntry(root, { klass: "A", id: "context_taxonomy", title: "Context Taxonomy", body: "Class A owns doctrine and pin policy." });
  assert.equal(result.ok, true);
  const after = repoStatus(root).result.state;
  assert.equal(after.context_epoch, before.context_epoch + 1);
  assert.equal(after.refresh_required, true);
  assert.equal(after.refresh_reason, "Class A contract or doctrine update");
});

test("generic context put routes Class B users to classb commands", () => {
  const root = tmp("sctl-context-b-reject-");
  assert.throws(() => putContextEntry(root, { klass: "B", id: "B1", title: "B1", body: "Body" }), /use classb commands/);
});
