import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { bootstrap } from "../src/lib/context.js";
import { registerSession, sendTeamMessage } from "../src/lib/messages.js";
import { putClassBFile } from "../src/lib/classb.js";
import { recordDispatch } from "../src/lib/dispatch_outbox.js";

function tmp() { return fs.mkdtempSync(path.join(os.tmpdir(), "sctl-rel-msg-")); }

test("dispatch record resolves relative message-file paths inside workspace", () => {
  const root = tmp();
  bootstrap(root);
  registerSession(root, { assignmentId: "A777", role: "Reviewer / QC Engineer", id: "reviewer_777" });
  putClassBFile(root, { id: "B_A777_READY", title: "ready", assignmentId: "A777", agentId: "change_author_777", role: "Change Author" });
  const msg = sendTeamMessage(root, {
    assignmentId: "A777",
    threadId: "THREAD_A777_REVIEW",
    messageId: "TM_A777_REVIEW_REQUEST",
    fromRole: "Change Author",
    fromId: "change_author_777",
    toRole: "Reviewer / QC Engineer",
    toId: "reviewer_777",
    messageKind: "qc_review_request",
    relatedClassB: [".strata/context/B/b_a777_ready.md"],
    body: "Please review with a relative message-file path."
  });
  assert.equal(msg.ok, true);
  const dispatch = recordDispatch(root, {
    assignmentId: "A777",
    nonce: "A777_N1",
    targetRole: "Reviewer / QC Engineer",
    targetId: "reviewer_777",
    messageFile: ".strata/context/C/threads/thread_a777_review/tm_a777_review_request.md",
    relatedClassB: [".strata/context/B/b_a777_ready.md"]
  });
  assert.equal(dispatch.ok, true);
  assert.equal(dispatch.result.packet.class_c_message_path, ".strata/context/C/threads/thread_a777_review/tm_a777_review_request.md");
  const md = fs.readFileSync(dispatch.result.outbox.packetMdPath, "utf8");
  assert.match(md, /Class C Team Message/);
  assert.match(md, /Please review with a relative message-file path/);
});
