# Changelog v0.9.3

## Added

- Class C team message contract and CLI.
- Active session registry.
- Pending Class C context notices on every accepted Class B update.
- Notice merge into next targeted paste-ready dispatch packet.
- Telemetry JSONL under Class D_trace.
- Context epoch/revision state and Class B drift threshold.
- Fixture scenes for trunk-based workflow simulation.
- CLI smoke test from Tooling / Dispatch Operator perspective.

## Changed

- Class B validation is strict and section-based.
- Invalid Class B commits create error dispatch evidence and keep invalid report outside accepted commits.
- Dispatch record uses declared template/file references instead of implementation Git watching.
- Tool registry marks every tool as operational tooling with runtime/session flags false.

## Retired

- `EVIDENCE_READY` Worker Return Packet kind.
- `evidence_path` as Worker Return Packet authority.
- Generic `context put --class B` path.
