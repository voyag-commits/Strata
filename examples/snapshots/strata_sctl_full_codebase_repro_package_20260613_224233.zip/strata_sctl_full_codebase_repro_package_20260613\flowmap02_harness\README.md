# Flowmap 02 Shell Harness

This directory contains shell scripts compiled from `FLOWMAP_02_TRUNK_BASED_DISPOSABLE_WORKER_CYCLE.md`.

Primary entrypoint:

```bash
bash flowmap02_run.sh
```

The harness writes:

```text
flowmap02_operational.log
flowmap02_step_diagnosis.tsv
flowmap02_evidence_paths.txt
flowmap02_result.md
```

Default behavior:

- Uses the patched package as `PACKAGE_ROOT`.
- Uses `/home/hou16/sctl-live-test-A_LIVE_001` as `SCTL_WORKSPACE`.
- Creates a disposable fixture Codebase Git repo if `CODEBASE_REPO` is not set.
- Uses launcher/runtime path through `scripts/wsl_tmux/sctl-session-new`.
- Renames launcher-created tmux sessions to the requested Flowmap 02 names only when `FLOWMAP02_ALLOW_SESSION_RENAME=1`.
- Simulates worker return packets and reports when `FLOWMAP02_SIMULATE_RETURNS=1`.
- Runs the approved path by default with `FLOWMAP02_REVIEW_RESULT=approved`.

Useful overrides:

```bash
export PACKAGE_ROOT="/path/to/package"
export SCTL_WORKSPACE="/path/to/live/sctl/workspace"
export SCTL_RUNTIME_EDGE_ROOT="/path/to/runtime-edge"
export CODEBASE_REPO="/path/to/codebase/repo"
export TRUNK_BRANCH="main"
export FLOWMAP02_REVIEW_RESULT="approved"   # approved | denied | blocked
export FLOWMAP02_NO_LAUNCH=1                # metadata-only session registration
export FLOWMAP02_INJECT=0                   # skip live tmux injection
export FLOWMAP02_MERGE=0                    # skip merge even if approved
```

The script is intentionally diagnostic. It records `OBSERVED`, `WRONG_METHOD`, `MISSING_EVIDENCE`, `BROKEN`, `BLOCKED`, or `NOT_RUN` per step and continues far enough to identify the broken method boundary unless a stop condition makes continuing unsafe.
