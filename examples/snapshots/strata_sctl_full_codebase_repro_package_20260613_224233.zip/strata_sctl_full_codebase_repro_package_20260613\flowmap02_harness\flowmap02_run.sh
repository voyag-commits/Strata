#!/usr/bin/env bash
set -u

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"

PACKAGE_ROOT="${PACKAGE_ROOT:-/mnt/c/Users/hou16/Downloads/Codex_CLI_agent fleet/_package_patch_v0_9_4_simplified_runtime/strata_sctl_kernel_components_1_3_4_package_v0_9_4_simplified_runtime}"
SCTL_WORKSPACE="${SCTL_WORKSPACE:-/home/hou16/sctl-live-test-A_LIVE_001}"
SCTL_RUNTIME_EDGE_ROOT="${SCTL_RUNTIME_EDGE_ROOT:-/mnt/c/Users/hou16/Downloads/Codex_CLI_agent fleet/strata_runtime_edge_launcher_delegate_component2_3_v0_9/strata_runtime_edge_launcher_delegate_component2_3_v0_9}"

ASSIGNMENT_ID="${ASSIGNMENT_ID:-A_FLOWMAP_02_001}"
TRUNK_COORDINATOR_ID="${TRUNK_COORDINATOR_ID:-trunk_coordinator_001}"
CHANGE_AUTHOR_ID="${CHANGE_AUTHOR_ID:-change_author_001}"
REVIEWER_ID="${REVIEWER_ID:-reviewer_001}"

TRUNK_COORDINATOR_SESSION="${TRUNK_COORDINATOR_SESSION:-SCTL-TC-A-FLOWMAP-02-001}"
CHANGE_AUTHOR_SESSION="${CHANGE_AUTHOR_SESSION:-SCTL-CA-A-FLOWMAP-02-001}"
REVIEWER_SESSION="${REVIEWER_SESSION:-SCTL-CR-A-FLOWMAP-02-001}"

TRUNK_BRANCH="${TRUNK_BRANCH:-main}"
CHANGE_BRANCH="${CHANGE_BRANCH:-change/A_FLOWMAP_02_001/small-change}"
FLOWMAP02_REVIEW_RESULT="${FLOWMAP02_REVIEW_RESULT:-approved}" # approved | denied | blocked
FLOWMAP02_NO_LAUNCH="${FLOWMAP02_NO_LAUNCH:-0}"
FLOWMAP02_INJECT="${FLOWMAP02_INJECT:-1}"
FLOWMAP02_ALLOW_SESSION_RENAME="${FLOWMAP02_ALLOW_SESSION_RENAME:-1}"
FLOWMAP02_SIMULATE_RETURNS="${FLOWMAP02_SIMULATE_RETURNS:-1}"
FLOWMAP02_MERGE="${FLOWMAP02_MERGE:-1}"
FLOWMAP02_RUN_CI="${FLOWMAP02_RUN_CI:-1}"
FLOWMAP02_APPLY_CODE_CHANGE="${FLOWMAP02_APPLY_CODE_CHANGE:-}"
FLOWMAP02_RETURN_WAIT_SECONDS="${FLOWMAP02_RETURN_WAIT_SECONDS:-60}"

RUN_ID="${RUN_ID:-$(date -u +%Y%m%dT%H%M%SZ)}"
RUN_ROOT="${FLOWMAP02_RUN_ROOT:-$SCRIPT_DIR/run_$RUN_ID}"
LOG="$RUN_ROOT/flowmap02_operational.log"
DIAG="$RUN_ROOT/flowmap02_step_diagnosis.tsv"
EVIDENCE="$RUN_ROOT/flowmap02_evidence_paths.txt"
REPORT="$RUN_ROOT/flowmap02_result.md"
STATE="$RUN_ROOT/flowmap02_state.env"
CI_LOG="$RUN_ROOT/${ASSIGNMENT_ID}_ci.log"

mkdir -p "$RUN_ROOT"
: > "$LOG"
: > "$DIAG"
: > "$EVIDENCE"
: > "$STATE"
printf 'step\tstatus\tboundary\tresult\tdiagnosis\tnext_inspection\tevidence\n' > "$DIAG"

exec > >(tee -a "$LOG") 2>&1

SCTL=(node src/cli.js --workspace "$SCTL_WORKSPACE")

ts() { date -u +%Y-%m-%dT%H:%M:%SZ; }

quote_cmd() {
  printf '+'
  printf ' %q' "$@"
  printf '\n'
}

record_step() {
  local step="$1" status="$2" boundary="$3" result="$4" diagnosis="$5" next="$6" evidence="${7:-}"
  printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\n' "$step" "$status" "$boundary" "$result" "$diagnosis" "$next" "$evidence" >> "$DIAG"
  printf 'DIAG[%s]=%s | %s | %s\n' "$step" "$status" "$result" "$diagnosis"
  [ -z "$evidence" ] || printf '%s\n' "$evidence" >> "$EVIDENCE"
}

run_cmd() {
  local label="$1"
  shift
  echo
  echo "===== $label ====="
  quote_cmd "$@"
  "$@"
  local status=$?
  echo "STATUS[$label]=$status"
  return "$status"
}

json_field() {
  node -e 'const fs=require("fs"); const obj=JSON.parse(fs.readFileSync(process.argv[1],"utf8")); const parts=process.argv[2].split("."); let cur=obj; for (const p of parts) cur=cur?.[p]; if (cur === undefined || cur === null) process.exit(1); process.stdout.write(String(cur));' "$1" "$2"
}

json_ok() {
  python3 - "$1" <<'PY'
import json, sys
with open(sys.argv[1], encoding="utf-8") as f:
    obj = json.load(f)
sys.exit(0 if obj.get("ok") is True else 1)
PY
}

lower_id() {
  printf '%s' "$1" | tr '[:upper:]' '[:lower:]'
}

safe_role_segment() {
  printf '%s' "$1" | tr '[:lower:]' '[:upper:]' | sed -E 's/[^A-Z0-9]+/-/g; s/^-+|-+$//g'
}

launcher_candidate_session() {
  local role="$1" requested="$2"
  printf 'STRATA-%s-%s-1' "$(safe_role_segment "$role")" "$requested"
}

tmux_has() {
  tmux has-session -t "$1" >/dev/null 2>&1
}

wait_for_return_packet() {
  local role_id="$1" label="$2"
  local packet="$SCTL_WORKSPACE/.strata/returns/$ASSIGNMENT_ID/$role_id/packet.json"
  local report="$SCTL_WORKSPACE/.strata/returns/$ASSIGNMENT_ID/$role_id/operational_report.md"
  local waited=0
  while [ "$waited" -lt "$FLOWMAP02_RETURN_WAIT_SECONDS" ]; do
    if [ -s "$packet" ] && [ -s "$report" ]; then
      record_step "$label.wait" "OBSERVED" "live worker return file drop" "$packet" "Worker return packet and operational report appeared without harness simulation." "Classify return." "$packet"
      return 0
    fi
    sleep 5
    waited=$((waited + 5))
  done
  record_step "$label.wait" "BLOCKED" "live worker return file drop" "missing after ${FLOWMAP02_RETURN_WAIT_SECONDS}s: $packet" "Live session did not create the Worker Return Packet/report in the expected SCTL drop zone. Continuing would require simulated evidence, which this run forbids." "Inspect the live session capture and .strata/returns path." "$SCTL_WORKSPACE/.strata/returns/$ASSIGNMENT_ID/$role_id"
  return 1
}

align_or_diagnose_session() {
  local step="$1" role="$2" requested="$3"
  if [ "$FLOWMAP02_NO_LAUNCH" = "1" ]; then
    record_step "$step.session_target" "NOT_RUN" "launcher/tmux session target" "metadata-only mode" "No live tmux target required because FLOWMAP02_NO_LAUNCH=1." "Inspect active_sessions.json." "$SCTL_WORKSPACE/.strata/context/C/sessions/active_sessions.json"
    return 0
  fi
  if tmux_has "$requested"; then
    record_step "$step.session_target" "OBSERVED" "launcher-created tmux session" "$requested exists" "Requested session name is directly targetable by adapter." "Continue to dispatch injection." ""
    return 0
  fi
  local candidate
  candidate="$(launcher_candidate_session "$role" "$requested")"
  if tmux_has "$candidate"; then
    if [ "$FLOWMAP02_ALLOW_SESSION_RENAME" = "1" ]; then
      run_cmd "$step align session name" tmux rename-session -t "$candidate" "$requested"
      if tmux_has "$requested"; then
        record_step "$step.session_target" "OBSERVED" "launcher session name alignment" "$candidate renamed to $requested" "Launcher created a role-prefixed name; harness aligned it to SCTL registered session_name and logged the rename." "Continue to dispatch injection." ""
        return 0
      fi
    fi
    record_step "$step.session_target" "WRONG_METHOD" "launcher session name alignment" "candidate exists: $candidate; requested missing: $requested" "Launcher produced a different tmux name than SCTL registered. Adapter injection would fail unless the exact live name is registered or renamed." "Run: tmux list-sessions | grep -i flowmap" ""
    return 1
  fi
  record_step "$step.session_target" "BROKEN" "launcher/tmux session target" "requested missing: $requested" "No target tmux session found for adapter injection." "Inspect runtime launcher output and tmux list-sessions." ""
  return 1
}

ensure_package() {
  cd "$PACKAGE_ROOT" || {
    record_step "preflight.package_root" "BLOCKED" "package root" "$PACKAGE_ROOT missing" "Cannot run SCTL CLI or adapter scripts." "Set PACKAGE_ROOT to the patched package extraction." ""
    exit 1
  }
}

ensure_codebase_repo() {
  if [ -z "${CODEBASE_REPO:-}" ]; then
    CODEBASE_IS_FIXTURE=1
    CODEBASE_REPO="$RUN_ROOT/codebase_fixture"
    mkdir -p "$CODEBASE_REPO"
    if [ ! -d "$CODEBASE_REPO/.git" ]; then
      run_cmd "fixture codebase git init" git -C "$CODEBASE_REPO" init -b "$TRUNK_BRANCH"
      run_cmd "fixture codebase git config email" git -C "$CODEBASE_REPO" config user.email "flowmap02@example.invalid"
      run_cmd "fixture codebase git config name" git -C "$CODEBASE_REPO" config user.name "Flowmap 02 Fixture"
      cat > "$CODEBASE_REPO/package.json" <<'JSON'
{
  "name": "flowmap02-fixture-codebase",
  "version": "0.0.0",
  "private": true,
  "scripts": {
    "test": "node -e \"const fs=require('fs'); if(!fs.existsSync('flowmap02_change.txt')) process.exit(0); console.log('flowmap02 fixture checks passed')\""
  }
}
JSON
      printf '# Flowmap 02 Fixture Codebase\n' > "$CODEBASE_REPO/README.md"
      run_cmd "fixture codebase initial commit" bash -lc 'cd "$0" && git add . && git commit -m "fixture trunk baseline"' "$CODEBASE_REPO"
    fi
    record_step "3.fixture_repo" "OBSERVED" "Codebase Git fixture" "$CODEBASE_REPO" "No real CODEBASE_REPO was supplied, so a local fixture repo was created and recorded." "Inspect fixture repo Git log." "$CODEBASE_REPO"
  else
    CODEBASE_IS_FIXTURE=0
    if [ ! -d "$CODEBASE_REPO/.git" ]; then
      record_step "3.codebase_repo" "BLOCKED" "Codebase Git" "$CODEBASE_REPO is not a Git repo" "Flowmap 02 requires a separate Codebase Git repo." "Set CODEBASE_REPO or unset it to use a fixture." "$CODEBASE_REPO"
      exit 1
    fi
    record_step "3.codebase_repo" "OBSERVED" "Codebase Git" "$CODEBASE_REPO" "Using caller-supplied Codebase Git repo." "Inspect git status before branch creation." "$CODEBASE_REPO"
  fi
  if [ -z "$FLOWMAP02_APPLY_CODE_CHANGE" ]; then
    [ "$CODEBASE_IS_FIXTURE" = "1" ] && FLOWMAP02_APPLY_CODE_CHANGE=1 || FLOWMAP02_APPLY_CODE_CHANGE=0
  fi
}

check_stop_separation() {
  local context="$SCTL_WORKSPACE/.strata/context"
  local resolved_context resolved_codebase
  resolved_context="$(cd "$context" 2>/dev/null && pwd -P || true)"
  resolved_codebase="$(cd "$CODEBASE_REPO" 2>/dev/null && pwd -P || true)"
  if [ -n "$resolved_context" ] && [ -n "$resolved_codebase" ] && [[ "$resolved_codebase" == "$resolved_context"* ]]; then
    record_step "stop.1" "BLOCKED" "SCTL Git / Codebase Git separation" "$resolved_codebase is inside $resolved_context" "Stop condition hit: Codebase Git must not live under .strata/context." "Move CODEBASE_REPO outside SCTL context Git." "$resolved_codebase"
    exit 1
  fi
}

write_author_return() {
  local commit
  commit="$(git -C "$CODEBASE_REPO" rev-parse HEAD 2>/dev/null || printf 'unknown')"
  local dir="$SCTL_WORKSPACE/.strata/returns/$ASSIGNMENT_ID/$CHANGE_AUTHOR_ID"
  mkdir -p "$dir"
  cat > "$dir/operational_report.md" <<EOF_REPORT
---
contract_id: strata.class_b.file.v1
class: B
id: B_${ASSIGNMENT_ID}_AUTHOR_READY
title: ${ASSIGNMENT_ID} Change Author operational report
scope: actionable_report
assignment_id: ${ASSIGNMENT_ID}
agent_id: ${CHANGE_AUTHOR_ID}
role: Change Author
status: ready
evidence: included
loaded_context_epoch: 0
created_at: $(date -u +%Y-%m-%dT%H:%M:%S.000Z)
---

# Operational Report

## Operational Summary

Change Author completed the assigned branch work for ${ASSIGNMENT_ID}.

## Progress Delta

Short-lived branch ${CHANGE_BRANCH} contains the proposed codebase change.

## Trunk Integration

Implementation repository: ${CODEBASE_REPO}. Trunk branch: ${TRUNK_BRANCH}. Short-lived branch: ${CHANGE_BRANCH}. Merge not performed by Change Author.

## Verification

Available local checks were run or explicitly recorded as not available in the evidence. Current implementation commit: ${commit}.

## Evidence

Codebase repo: ${CODEBASE_REPO}. Branch: ${CHANGE_BRANCH}. Commit: ${commit}. Session capture: .strata/evidence/session_captures/${CHANGE_AUTHOR_SESSION}.txt.

## Risks / Blockers

None recorded for fixture test.

## Next Action

Create a fresh Code Reviewer session and review the branch/report.
EOF_REPORT
  cat > "$dir/packet.json" <<EOF_PACKET
{
  "contract_id": "worker_return_packet.v1",
  "return_id": "ret_${ASSIGNMENT_ID}_${CHANGE_AUTHOR_ID}_001",
  "assignment_id": "${ASSIGNMENT_ID}",
  "agent_id": "${CHANGE_AUTHOR_ID}",
  "role": "Change Author",
  "return_kind": "OPERATIONAL_REPORT_READY",
  "status": "report_ready_not_class_b_intake",
  "summary": "Change Author returned branch work and operational report.",
  "nonce": "N_AUTHOR_1",
  "report_scope": "actionable_report",
  "implementation_repository": "${CODEBASE_REPO}",
  "implementation_commit": "${commit}",
  "trunk_branch": "${TRUNK_BRANCH}",
  "short_lived_branch": "${CHANGE_BRANCH}",
  "integration_mode": "short_lived_change_branch",
  "supersedes_entry_id": null,
  "message_path": "${AUTHOR_MSG_FILE:-}",
  "question_path": null,
  "report_path": ".strata/returns/${ASSIGNMENT_ID}/${CHANGE_AUTHOR_ID}/operational_report.md",
  "diagnostic_path": null,
  "created_at": "$(date -u +%Y-%m-%dT%H:%M:%S.000Z)"
}
EOF_PACKET
}

write_reviewer_return() {
  local result="$1"
  local dir="$SCTL_WORKSPACE/.strata/returns/$ASSIGNMENT_ID/$REVIEWER_ID"
  local recommendation="merge"
  local risks="None recorded after review."
  local next_action="Run CI/checks and merge by Trunk Coordinator."
  if [ "$result" = "denied" ]; then
    recommendation="revise"
    risks="Reviewer denied first attempt; revision instructions required."
    next_action="Send one denial delta to the same Change Author session."
  elif [ "$result" = "blocked" ]; then
    recommendation="block"
    risks="Reviewer blocked the change pending coordinator decision."
    next_action="Escalate or revise after blocker is resolved."
  fi
  mkdir -p "$dir"
  cat > "$dir/operational_report.md" <<EOF_REPORT
---
contract_id: strata.class_b.file.v1
class: B
id: B_${ASSIGNMENT_ID}_REVIEW_OUTCOME
title: ${ASSIGNMENT_ID} review outcome
scope: review_outcome
assignment_id: ${ASSIGNMENT_ID}
agent_id: ${REVIEWER_ID}
role: Code Reviewer / QC Engineer
status: ready
evidence: included
loaded_context_epoch: 0
created_at: $(date -u +%Y-%m-%dT%H:%M:%S.000Z)
---

# Operational Report

## Operational Summary

Review result: ${result}.

## Progress Delta

Reviewer inspected branch ${CHANGE_BRANCH} and returned outcome ${result}.

## Trunk Integration

Codebase repo: ${CODEBASE_REPO}. Trunk: ${TRUNK_BRANCH}. Branch: ${CHANGE_BRANCH}. Merge recommendation: ${recommendation}.

## Verification

Review packet, author report, branch metadata, and available CI/test evidence were inspected or simulated by this harness.

## Evidence

Author Class B report: ${AUTHOR_CLASSB_REL:-}. Reviewer capture: .strata/evidence/session_captures/${REVIEWER_SESSION}.txt. CI log: ${CI_LOG}.

## Risks / Blockers

${risks}

## Next Action

${next_action}
EOF_REPORT
  cat > "$dir/packet.json" <<EOF_PACKET
{
  "contract_id": "worker_return_packet.v1",
  "return_id": "ret_${ASSIGNMENT_ID}_${REVIEWER_ID}_001",
  "assignment_id": "${ASSIGNMENT_ID}",
  "agent_id": "${REVIEWER_ID}",
  "role": "Code Reviewer / QC Engineer",
  "return_kind": "OPERATIONAL_REPORT_READY",
  "status": "report_ready_not_class_b_intake",
  "summary": "Reviewer returned ${result} review outcome.",
  "nonce": "N_REVIEW_1",
  "report_scope": "review_outcome",
  "implementation_repository": "${CODEBASE_REPO}",
  "implementation_commit": "$(git -C "$CODEBASE_REPO" rev-parse HEAD 2>/dev/null || printf 'unknown')",
  "trunk_branch": "${TRUNK_BRANCH}",
  "short_lived_branch": "${CHANGE_BRANCH}",
  "integration_mode": "short_lived_change_branch",
  "supersedes_entry_id": null,
  "message_path": "${REVIEW_MSG_FILE:-}",
  "question_path": null,
  "report_path": ".strata/returns/${ASSIGNMENT_ID}/${REVIEWER_ID}/operational_report.md",
  "diagnostic_path": null,
  "created_at": "$(date -u +%Y-%m-%dT%H:%M:%S.000Z)"
}
EOF_PACKET
}

validate_packet_structure() {
  local step="$1" packet="$2"
  if [ ! -s "$packet" ]; then
    record_step "$step" "MISSING_EVIDENCE" "dispatch packet snapshot" "$packet missing" "Dispatch did not preserve canonical packet under D_trace/dispatch_packets." "Inspect sctl-dispatch-render output and dispatch record errors." "$packet"
    return 1
  fi
  if grep -q '# Below is system level full context picture.' "$packet" && grep -q '# Class C Team Message' "$packet"; then
    record_step "$step" "OBSERVED" "dispatch packet snapshot" "$packet" "Packet contains Class C message and fixed context headline." "Continue to injection." "$packet"
    return 0
  fi
  record_step "$step" "BROKEN" "dispatch packet content" "$packet" "Packet exists but does not contain required Class C/headline structure." "Open packet and inspect renderDispatchPacket/exportMarkdown boundary." "$packet"
  return 1
}

begin_report() {
  cat > "$REPORT" <<EOF_REPORT
# Flowmap 02 Test Result - Trunk-Based Disposable Worker Cycle

Assignment ID: ${ASSIGNMENT_ID}
Date: $(ts)
SCTL package: ${PACKAGE_ROOT}
SCTL workspace: ${SCTL_WORKSPACE}
Codebase repo: ${CODEBASE_REPO:-unset}
Trunk branch: ${TRUNK_BRANCH}
Change branch: ${CHANGE_BRANCH}

## Operational Log

Raw log: ${LOG}

## Step Diagnosis

See: ${DIAG}

EOF_REPORT
}

finish_report() {
  {
    echo "## Evidence Paths"
    echo
    sed 's/^/- /' "$EVIDENCE" | sort -u
    echo
    echo "## Final Git Audit"
    echo
    echo '```text'
    git -C "$SCTL_WORKSPACE/.strata/context" status --short 2>&1 || true
    git -C "$SCTL_WORKSPACE/.strata/context" log --oneline -30 2>&1 || true
    echo '```'
    echo
    echo "## Diagnosis Table"
    echo
    echo '```text'
    cat "$DIAG"
    echo '```'
  } >> "$REPORT"
}

main() {
  echo "FLOWMAP_02_START=$(ts)"
  echo "RUN_ROOT=$RUN_ROOT"
  echo "PACKAGE_ROOT=$PACKAGE_ROOT"
  echo "SCTL_WORKSPACE=$SCTL_WORKSPACE"
  echo "SCTL_RUNTIME_EDGE_ROOT=$SCTL_RUNTIME_EDGE_ROOT"
  echo "FLOWMAP02_REVIEW_RESULT=$FLOWMAP02_REVIEW_RESULT"

  ensure_package
  begin_report

  run_cmd "preflight npm test" npm test
  [ "$?" -eq 0 ] && record_step "preflight.tests" "OBSERVED" "npm test" "package tests passed" "SCTL package baseline is executable." "Continue." "$PACKAGE_ROOT" || record_step "preflight.tests" "BROKEN" "npm test" "package tests failed" "Do not trust flowmap results until package baseline is fixed." "Inspect npm test output." "$LOG"

  run_cmd "preflight adapter syntax" bash -lc 'for script in scripts/wsl_tmux/sctl-*; do bash -n "$script" || exit 1; done'
  [ "$?" -eq 0 ] && record_step "preflight.adapters" "OBSERVED" "bash -n scripts/wsl_tmux/sctl-*" "adapter syntax passed" "Adapter scripts parse." "Continue." "$PACKAGE_ROOT/scripts/wsl_tmux" || record_step "preflight.adapters" "BROKEN" "adapter syntax" "adapter syntax failed" "Adapter scripts cannot be trusted." "Inspect failing script." "$LOG"

  ensure_codebase_repo
  check_stop_separation

  run_cmd "0 context bootstrap" "${SCTL[@]}" context bootstrap
  [ "$?" -eq 0 ] && record_step "0" "OBSERVED" "context bootstrap -> bootstrap()" "context bootstrap ok" "SCTL context Git exists and bootstrap committed or updated state." "Inspect .strata/context git log." "$SCTL_WORKSPACE/.strata/context" || record_step "0" "BROKEN" "context bootstrap" "bootstrap failed" "SCTL context Git cannot be established." "Inspect CLI output." "$LOG"

  LAUNCH_FLAG=()
  [ "$FLOWMAP02_NO_LAUNCH" = "1" ] && LAUNCH_FLAG=(--no-launch)

  run_cmd "1 session new trunk coordinator" env SCTL_RUNTIME_EDGE_ROOT="$SCTL_RUNTIME_EDGE_ROOT" scripts/wsl_tmux/sctl-session-new \
    --workspace "$SCTL_WORKSPACE" --assignment-id "$ASSIGNMENT_ID" --role "Trunk Coordinator" --id "$TRUNK_COORDINATOR_ID" \
    --session-name "$TRUNK_COORDINATOR_SESSION" --session-mode long_running "${LAUNCH_FLAG[@]}"
  [ "$?" -eq 0 ] && record_step "1" "OBSERVED" "sctl-session-new -> sessions register -> registerSession()" "$TRUNK_COORDINATOR_ID registered" "Persistent Trunk Coordinator was recorded in SCTL Git." "Inspect active_sessions.json." "$SCTL_WORKSPACE/.strata/context/C/sessions/active_sessions.json" || record_step "1" "BROKEN" "sctl-session-new" "Trunk Coordinator registration failed" "Session registry was not updated." "Inspect adapter output." "$LOG"
  align_or_diagnose_session "1" "Trunk Coordinator" "$TRUNK_COORDINATOR_SESSION" || true

  run_cmd "2 context freshness coordinator" "${SCTL[@]}" context freshness --loaded-context-epoch 0 --loaded-class-a-revision 1
  [ "$?" -eq 0 ] && record_step "2" "OBSERVED" "context freshness -> contextFreshness()" "freshness result emitted" "Coordinator context freshness math is available for decision." "Inspect action/math in log." "$LOG" || record_step "2" "BROKEN" "context freshness" "freshness failed" "Coordinator cannot evaluate context freshness." "Inspect context state JSON." "$SCTL_WORKSPACE/.strata/context/D_trace/context_state.json"

  run_cmd "3 codebase branch status" git -C "$CODEBASE_REPO" status --short
  run_cmd "3 codebase switch trunk" git -C "$CODEBASE_REPO" switch "$TRUNK_BRANCH"
  run_cmd "3 codebase pull ff only" git -C "$CODEBASE_REPO" pull --ff-only
  if git -C "$CODEBASE_REPO" show-ref --verify --quiet "refs/heads/$CHANGE_BRANCH"; then
    run_cmd "3 codebase switch existing branch" git -C "$CODEBASE_REPO" switch "$CHANGE_BRANCH"
  else
    run_cmd "3 codebase create branch" git -C "$CODEBASE_REPO" switch -c "$CHANGE_BRANCH" "$TRUNK_BRANCH"
  fi
  if [ "$?" -eq 0 ]; then
    if [ "$FLOWMAP02_APPLY_CODE_CHANGE" = "1" ]; then
      printf 'Flowmap 02 fixture change at %s\n' "$(ts)" > "$CODEBASE_REPO/flowmap02_change.txt"
      run_cmd "3 codebase commit fixture change" bash -lc 'cd "$0" && git add flowmap02_change.txt && git commit -m "flowmap02 small change" || true' "$CODEBASE_REPO"
    else
      record_step "3.code_change" "NOT_RUN" "Codebase Git branch work" "FLOWMAP02_APPLY_CODE_CHANGE=0" "Harness did not modify caller-supplied Codebase Git; live Change Author or tester must create the branch change." "Inspect Codebase Git branch work before return simulation." "$CODEBASE_REPO"
    fi
    record_step "3" "OBSERVED" "Codebase Git branch" "$CHANGE_BRANCH" "Short-lived Codebase Git branch exists outside SCTL Git." "Inspect codebase git log/status." "$CODEBASE_REPO"
  else
    record_step "3" "BROKEN" "Codebase Git branch" "$CHANGE_BRANCH branch creation failed" "Cannot continue trunk-based cycle without a short-lived branch." "Inspect CODEBASE_REPO and TRUNK_BRANCH." "$CODEBASE_REPO"
  fi

  run_cmd "4 session new change author" env SCTL_RUNTIME_EDGE_ROOT="$SCTL_RUNTIME_EDGE_ROOT" scripts/wsl_tmux/sctl-session-new \
    --workspace "$SCTL_WORKSPACE" --assignment-id "$ASSIGNMENT_ID" --role "Change Author" --id "$CHANGE_AUTHOR_ID" \
    --session-name "$CHANGE_AUTHOR_SESSION" --session-mode disposable "${LAUNCH_FLAG[@]}"
  [ "$?" -eq 0 ] && record_step "4" "OBSERVED" "sctl-session-new -> registerSession()" "$CHANGE_AUTHOR_ID active disposable" "Fresh Change Author session was recorded in SCTL Git." "Inspect active_sessions.json." "$SCTL_WORKSPACE/.strata/context/C/sessions/active_sessions.json" || record_step "4" "BROKEN" "sctl-session-new" "Change Author registration failed" "No author session to dispatch." "Inspect adapter output." "$LOG"
  align_or_diagnose_session "4" "Change Author" "$CHANGE_AUTHOR_SESSION" || true

  AUTHOR_MSG_JSON="$RUN_ROOT/author_message.json"
  run_cmd "5 author message send" bash -lc 'set -o pipefail; node src/cli.js --workspace "$0" message send --assignment-id "$1" --thread-id "THREAD_${1}_AUTHOR" --from-role "Trunk Coordinator" --from-id "$2" --to-role "Change Author" --to-id "$3" --message-kind coordination_note --requested-handling "Work only on the assigned short-lived codebase branch. Return a Worker Return Packet and operational report." --body "Prepare the assigned codebase change on branch '"$CHANGE_BRANCH"'. Do not merge. Run available checks. Return branch name, commit, verification, risks, and next action." | tee "$4"' "$SCTL_WORKSPACE" "$ASSIGNMENT_ID" "$TRUNK_COORDINATOR_ID" "$CHANGE_AUTHOR_ID" "$AUTHOR_MSG_JSON"
  AUTHOR_MSG_FILE="$(json_field "$AUTHOR_MSG_JSON" result.file 2>/dev/null || true)"
  printf 'AUTHOR_MSG_FILE=%q\n' "$AUTHOR_MSG_FILE" >> "$STATE"
  if [ -n "$AUTHOR_MSG_FILE" ] && run_cmd "5 author message validate" "${SCTL[@]}" message validate --file "$AUTHOR_MSG_FILE"; then
    record_step "5" "OBSERVED" "message send -> sendTeamMessage()" "$AUTHOR_MSG_FILE" "Class C assignment message exists and validates." "Continue to dispatch render." "$AUTHOR_MSG_FILE"
  else
    record_step "5" "BROKEN" "message send/validate" "author message missing or invalid" "Class C assignment message boundary failed." "Inspect message send JSON." "$AUTHOR_MSG_JSON"
  fi

  run_cmd "6 author dispatch render" scripts/wsl_tmux/sctl-dispatch-render \
    --workspace "$SCTL_WORKSPACE" --assignment-id "$ASSIGNMENT_ID" --nonce N_AUTHOR_1 \
    --from-role "Trunk Coordinator" --from-id "$TRUNK_COORDINATOR_ID" \
    --target-role "Change Author" --target-id "$CHANGE_AUTHOR_ID" \
    --summary "Flowmap 02 Change Author branch assignment" --message-file "$AUTHOR_MSG_FILE" \
    --declared-file "CODEBASE_REPO:$CODEBASE_REPO" --declared-file "TRUNK_BRANCH:$TRUNK_BRANCH" --declared-file "CHANGE_BRANCH:$CHANGE_BRANCH"
  AUTHOR_PACKET="$SCTL_WORKSPACE/.strata/context/D_trace/dispatch_packets/$ASSIGNMENT_ID/$CHANGE_AUTHOR_ID/N_AUTHOR_1/dispatch_packet.md"
  AUTHOR_PACKET_REL=".strata/context/D_trace/dispatch_packets/$ASSIGNMENT_ID/$CHANGE_AUTHOR_ID/N_AUTHOR_1/dispatch_packet.md"
  validate_packet_structure "6" "$AUTHOR_PACKET" || true

  if [ "$FLOWMAP02_INJECT" = "1" ] && [ "$FLOWMAP02_NO_LAUNCH" != "1" ]; then
    run_cmd "7 author dispatch dry run" scripts/wsl_tmux/sctl-dispatch-inject --session "$CHANGE_AUTHOR_SESSION" --packet "$AUTHOR_PACKET_REL" --dry-run
    run_cmd "7 author dispatch inject" bash -lc 'cd "$0" && "$1/scripts/wsl_tmux/sctl-dispatch-inject" --session "$2" --packet "$3"' "$SCTL_WORKSPACE" "$PACKAGE_ROOT" "$CHANGE_AUTHOR_SESSION" "$AUTHOR_PACKET_REL"
    [ "$?" -eq 0 ] && record_step "7" "OBSERVED" "sctl-dispatch-inject -> tmux load-buffer/paste-buffer/send-keys" "$CHANGE_AUTHOR_SESSION injected" "Change Author packet was injected through adapter using Git-backed packet path." "Observe/capture target session." "$AUTHOR_PACKET" || record_step "7" "BROKEN" "sctl-dispatch-inject" "author injection failed" "Adapter/session target boundary failed." "Inspect tmux sessions and adapter output." "$LOG"
  else
    record_step "7" "NOT_RUN" "sctl-dispatch-inject" "injection skipped" "FLOWMAP02_INJECT=0 or metadata-only mode; no live packet delivery attempted." "Run with FLOWMAP02_INJECT=1 and launcher enabled." "$AUTHOR_PACKET"
  fi

  if [ "$FLOWMAP02_NO_LAUNCH" != "1" ]; then
    run_cmd "8 author session capture" bash -lc 'cd "$0" && "$1/scripts/wsl_tmux/sctl-session-capture" --session "$2" --out ".strata/evidence/session_captures/${2}.txt"' "$SCTL_WORKSPACE" "$PACKAGE_ROOT" "$CHANGE_AUTHOR_SESSION"
    [ "$?" -eq 0 ] && record_step "8" "OBSERVED" "sctl-session-capture -> runtime capture/tmux capture" "$CHANGE_AUTHOR_SESSION capture written" "Author session capture evidence exists." "Inspect capture file." "$SCTL_WORKSPACE/.strata/evidence/session_captures/${CHANGE_AUTHOR_SESSION}.txt" || record_step "8" "MISSING_EVIDENCE" "session capture" "author capture failed" "Capture is optional evidence but live observation is weaker without it." "Inspect tmux capture error." "$LOG"
  else
    record_step "8" "NOT_RUN" "session capture" "metadata-only mode" "No live session capture expected." "Run with launcher enabled for capture evidence." ""
  fi

  if [ "$FLOWMAP02_SIMULATE_RETURNS" = "1" ]; then
    write_author_return
    record_step "9" "OBSERVED" "external worker return file drop" "$SCTL_WORKSPACE/.strata/returns/$ASSIGNMENT_ID/$CHANGE_AUTHOR_ID/packet.json" "Controlled local author Worker Return Packet and report were created." "Classify return." "$SCTL_WORKSPACE/.strata/returns/$ASSIGNMENT_ID/$CHANGE_AUTHOR_ID/packet.json"
  else
    if ! wait_for_return_packet "$CHANGE_AUTHOR_ID" "9"; then
      run_cmd "9 author returns directory" find "$SCTL_WORKSPACE/.strata/returns/$ASSIGNMENT_ID/$CHANGE_AUTHOR_ID" -maxdepth 2 -type f
      run_cmd "9 author capture tail" bash -lc 'test -f "$0" && tail -120 "$0" || true' "$SCTL_WORKSPACE/.strata/evidence/session_captures/${CHANGE_AUTHOR_SESSION}.txt"
      record_step "10" "NOT_RUN" "returns classify -> classifyWorkerReturnPacket()" "author return missing" "Classification was not run because the live worker did not write the expected packet/report." "Inspect author session and dispatch instructions." "$SCTL_WORKSPACE/.strata/returns/$ASSIGNMENT_ID/$CHANGE_AUTHOR_ID"
      record_step "11" "NOT_RUN" "classb commit -> commitClassBFile()" "author Class B promotion skipped" "No valid live author return existed to promote." "Resolve return-generation boundary first." ""
      record_step "12-22" "NOT_RUN" "downstream review/merge path" "blocked by missing author return" "Reviewer dispatch, CI, merge, and final Class B outcome require author return evidence." "Fix worker return path, then rerun from Step 9 or full cycle." ""
      finish_report
      echo "FLOWMAP_02_END=$(ts)"
      echo "RUN_ROOT=$RUN_ROOT"
      echo "LOG=$LOG"
      echo "DIAG=$DIAG"
      echo "REPORT=$REPORT"
      return 2
    fi
  fi

  AUTHOR_CLASSIFY_JSON="$RUN_ROOT/author_classify.json"
  run_cmd "10 classify author return" bash -lc 'set -o pipefail; node src/cli.js --workspace "$0" returns classify --packet ".strata/returns/'"$ASSIGNMENT_ID"'/'"$CHANGE_AUTHOR_ID"'/packet.json" | tee "$1"' "$SCTL_WORKSPACE" "$AUTHOR_CLASSIFY_JSON"
  if [ "$?" -eq 0 ] && json_ok "$AUTHOR_CLASSIFY_JSON"; then
    record_step "10" "OBSERVED" "returns classify -> classifyWorkerReturnPacket()" "author return classified" "Author return was ledgered, not automatically promoted to Class B." "Inspect return_ledgers and routing_decision." "$SCTL_WORKSPACE/.strata/context/D_trace/return_ledgers"
  else
    record_step "10" "BROKEN" "returns classify -> classifyWorkerReturnPacket()" "author return classification failed or JSON ok:false" "Return packet/report validation boundary failed." "Inspect author_classify.json and return diagnostics." "$AUTHOR_CLASSIFY_JSON"
  fi

  AUTHOR_CLASSB_REL=".strata/context/B/b_$(lower_id "$ASSIGNMENT_ID")_author_ready.md"
  AUTHOR_CLASSB="$SCTL_WORKSPACE/$AUTHOR_CLASSB_REL"
  cp "$SCTL_WORKSPACE/.strata/returns/$ASSIGNMENT_ID/$CHANGE_AUTHOR_ID/operational_report.md" "$AUTHOR_CLASSB"
  START_REV_AUTHOR="$(node -e 'const fs=require("fs"); const j=JSON.parse(fs.readFileSync(process.argv[1],"utf8")); process.stdout.write(String(j.current_class_b_revision ?? j.class_b_revision ?? 0));' "$SCTL_WORKSPACE/.strata/context/D_trace/context_state.json")"
  AUTHOR_CLASSB_JSON="$RUN_ROOT/author_classb_commit.json"
  run_cmd "11 classb commit author report" bash -lc 'set -o pipefail; node src/cli.js --workspace "$0" classb commit --file "$1" --message "class B accept '"$ASSIGNMENT_ID"' author report" | tee "$2"' "$SCTL_WORKSPACE" "$AUTHOR_CLASSB_REL" "$AUTHOR_CLASSB_JSON"
  END_REV_AUTHOR="$(node -e 'const fs=require("fs"); const j=JSON.parse(fs.readFileSync(process.argv[1],"utf8")); process.stdout.write(String(j.current_class_b_revision ?? j.class_b_revision ?? 0));' "$SCTL_WORKSPACE/.strata/context/D_trace/context_state.json")"
  if json_ok "$AUTHOR_CLASSB_JSON" && [ "$END_REV_AUTHOR" -eq $((START_REV_AUTHOR + 1)) ] 2>/dev/null; then
    record_step "11" "OBSERVED" "classb commit -> commitClassBFile()" "Class B revision $START_REV_AUTHOR -> $END_REV_AUTHOR" "Author report accepted into Class B and revision incremented exactly once." "Continue to reviewer." "$AUTHOR_CLASSB"
  else
    cp "$AUTHOR_CLASSB" "$RUN_ROOT/invalid_uncommitted_$(basename "$AUTHOR_CLASSB")" 2>/dev/null || true
    rm -f "$AUTHOR_CLASSB"
    record_step "11" "BROKEN" "classb commit -> commitClassBFile()" "Class B revision $START_REV_AUTHOR -> $END_REV_AUTHOR" "Author report was not accepted into Class B; invalid copy was preserved in run evidence and removed from context Git." "Inspect author_classb_commit.json and invalid_uncommitted copy." "$AUTHOR_CLASSB_JSON"
    record_step "12-22" "NOT_RUN" "downstream review/merge path" "blocked by broken author Class B promotion" "Reviewer dispatch, CI, merge, and final outcome require accepted author evidence." "Fix author report format or use classb put from validated fields, then rerun." ""
    finish_report
    echo "FLOWMAP_02_END=$(ts)"
    echo "RUN_ROOT=$RUN_ROOT"
    echo "LOG=$LOG"
    echo "DIAG=$DIAG"
    echo "REPORT=$REPORT"
    return 4
  fi

  run_cmd "12 session new reviewer" env SCTL_RUNTIME_EDGE_ROOT="$SCTL_RUNTIME_EDGE_ROOT" scripts/wsl_tmux/sctl-session-new \
    --workspace "$SCTL_WORKSPACE" --assignment-id "$ASSIGNMENT_ID" --role "Code Reviewer / QC Engineer" --id "$REVIEWER_ID" \
    --session-name "$REVIEWER_SESSION" --session-mode disposable "${LAUNCH_FLAG[@]}"
  [ "$?" -eq 0 ] && record_step "12" "OBSERVED" "sctl-session-new -> registerSession()" "$REVIEWER_ID active disposable" "Fresh reviewer session was recorded in SCTL Git." "Inspect active_sessions.json." "$SCTL_WORKSPACE/.strata/context/C/sessions/active_sessions.json" || record_step "12" "BROKEN" "sctl-session-new" "Reviewer registration failed" "No reviewer session to dispatch." "Inspect adapter output." "$LOG"
  align_or_diagnose_session "12" "Code Reviewer / QC Engineer" "$REVIEWER_SESSION" || true

  REVIEW_MSG_JSON="$RUN_ROOT/review_message.json"
  run_cmd "13 review message send" bash -lc 'set -o pipefail; node src/cli.js --workspace "$0" message send --assignment-id "$1" --thread-id "THREAD_${1}_REVIEW" --from-role "Trunk Coordinator" --from-id "$2" --to-role "Code Reviewer / QC Engineer" --to-id "$3" --message-kind qc_review_request --related-class-b "$4" --requested-handling "Review the codebase branch, the Change Author report, and available CI/test evidence. Return approved, denied, or blocked." --body "Review branch '"$CHANGE_BRANCH"' against trunk '"$TRUNK_BRANCH"'. Confirm whether CI/checks pass. If denied, write a denial report with exact revision instructions." | tee "$5"' "$SCTL_WORKSPACE" "$ASSIGNMENT_ID" "$TRUNK_COORDINATOR_ID" "$REVIEWER_ID" "$AUTHOR_CLASSB_REL" "$REVIEW_MSG_JSON"
  REVIEW_MSG_FILE="$(json_field "$REVIEW_MSG_JSON" result.file 2>/dev/null || true)"
  printf 'REVIEW_MSG_FILE=%q\n' "$REVIEW_MSG_FILE" >> "$STATE"
  if [ -n "$REVIEW_MSG_FILE" ] && run_cmd "13 review message validate" "${SCTL[@]}" message validate --file "$REVIEW_MSG_FILE"; then
    record_step "13" "OBSERVED" "message send -> sendTeamMessage()" "$REVIEW_MSG_FILE" "Class C review request exists and validates." "Continue to reviewer dispatch." "$REVIEW_MSG_FILE"
  else
    record_step "13" "BROKEN" "message send/validate" "review message missing or invalid" "Class C review request boundary failed." "Inspect message send JSON." "$REVIEW_MSG_JSON"
  fi

  run_cmd "14 review dispatch render" scripts/wsl_tmux/sctl-dispatch-render \
    --workspace "$SCTL_WORKSPACE" --assignment-id "$ASSIGNMENT_ID" --nonce N_REVIEW_1 \
    --from-role "Trunk Coordinator" --from-id "$TRUNK_COORDINATOR_ID" \
    --target-role "Code Reviewer / QC Engineer" --target-id "$REVIEWER_ID" \
    --summary "Flowmap 02 code review request" --message-file "$REVIEW_MSG_FILE" \
    --declared-file "CODEBASE_REPO:$CODEBASE_REPO" --declared-file "TRUNK_BRANCH:$TRUNK_BRANCH" --declared-file "CHANGE_BRANCH:$CHANGE_BRANCH"
  REVIEW_PACKET="$SCTL_WORKSPACE/.strata/context/D_trace/dispatch_packets/$ASSIGNMENT_ID/$REVIEWER_ID/N_REVIEW_1/dispatch_packet.md"
  REVIEW_PACKET_REL=".strata/context/D_trace/dispatch_packets/$ASSIGNMENT_ID/$REVIEWER_ID/N_REVIEW_1/dispatch_packet.md"
  validate_packet_structure "14" "$REVIEW_PACKET" || true

  if [ "$FLOWMAP02_INJECT" = "1" ] && [ "$FLOWMAP02_NO_LAUNCH" != "1" ]; then
    run_cmd "15 reviewer dispatch dry run" scripts/wsl_tmux/sctl-dispatch-inject --session "$REVIEWER_SESSION" --packet "$REVIEW_PACKET_REL" --dry-run
    run_cmd "15 reviewer dispatch inject" bash -lc 'cd "$0" && "$1/scripts/wsl_tmux/sctl-dispatch-inject" --session "$2" --packet "$3"' "$SCTL_WORKSPACE" "$PACKAGE_ROOT" "$REVIEWER_SESSION" "$REVIEW_PACKET_REL"
    [ "$?" -eq 0 ] && record_step "15" "OBSERVED" "sctl-dispatch-inject -> tmux load-buffer/paste-buffer/send-keys" "$REVIEWER_SESSION injected" "Reviewer packet was injected through adapter." "Observe/capture target session." "$REVIEW_PACKET" || record_step "15" "BROKEN" "sctl-dispatch-inject" "reviewer injection failed" "Adapter/session target boundary failed." "Inspect tmux sessions and adapter output." "$LOG"
  else
    record_step "15" "NOT_RUN" "sctl-dispatch-inject" "injection skipped" "FLOWMAP02_INJECT=0 or metadata-only mode; no live packet delivery attempted." "Run with FLOWMAP02_INJECT=1 and launcher enabled." "$REVIEW_PACKET"
  fi

  if [ "$FLOWMAP02_NO_LAUNCH" != "1" ]; then
    run_cmd "16 reviewer session capture" bash -lc 'cd "$0" && "$1/scripts/wsl_tmux/sctl-session-capture" --session "$2" --out ".strata/evidence/session_captures/${2}.txt"' "$SCTL_WORKSPACE" "$PACKAGE_ROOT" "$REVIEWER_SESSION"
    [ "$?" -eq 0 ] && record_step "16" "OBSERVED" "sctl-session-capture" "$REVIEWER_SESSION capture written" "Reviewer session capture evidence exists." "Inspect capture file." "$SCTL_WORKSPACE/.strata/evidence/session_captures/${REVIEWER_SESSION}.txt" || record_step "16" "MISSING_EVIDENCE" "session capture" "reviewer capture failed" "Capture is optional evidence but live observation is weaker without it." "Inspect tmux capture error." "$LOG"
  else
    record_step "16" "NOT_RUN" "session capture" "metadata-only mode" "No live reviewer capture expected." "Run with launcher enabled for capture evidence." ""
  fi

  if [ "$FLOWMAP02_SIMULATE_RETURNS" = "1" ]; then
    write_reviewer_return "$FLOWMAP02_REVIEW_RESULT"
    record_step "17.return_files" "OBSERVED" "external reviewer return file drop" "$SCTL_WORKSPACE/.strata/returns/$ASSIGNMENT_ID/$REVIEWER_ID/packet.json" "Controlled local reviewer Worker Return Packet and report were created." "Classify reviewer return." "$SCTL_WORKSPACE/.strata/returns/$ASSIGNMENT_ID/$REVIEWER_ID/packet.json"
  else
    if ! wait_for_return_packet "$REVIEWER_ID" "17"; then
      run_cmd "17 reviewer returns directory" find "$SCTL_WORKSPACE/.strata/returns/$ASSIGNMENT_ID/$REVIEWER_ID" -maxdepth 2 -type f
      run_cmd "17 reviewer capture tail" bash -lc 'test -f "$0" && tail -120 "$0" || true' "$SCTL_WORKSPACE/.strata/evidence/session_captures/${REVIEWER_SESSION}.txt"
      record_step "17" "NOT_RUN" "returns classify -> classifyWorkerReturnPacket()" "reviewer return missing" "Classification was not run because the live reviewer did not write the expected packet/report." "Inspect reviewer session and dispatch instructions." "$SCTL_WORKSPACE/.strata/returns/$ASSIGNMENT_ID/$REVIEWER_ID"
      record_step "18A" "NOT_RUN" "CI/merge path" "blocked by missing reviewer approval" "Merge is prohibited without reviewer outcome evidence." "Fix reviewer return path." ""
      record_step "19" "NOT_RUN" "classb put -> putClassBFile()" "final outcome skipped" "No valid reviewer outcome existed to record." "Resolve reviewer return generation first." ""
      record_step "20" "NOT_RUN" "session retirement" "blocked before completion" "Disposable sessions remain available for inspection." "Capture and inspect live sessions." "$SCTL_WORKSPACE/.strata/evidence/session_captures"
      record_step "21" "NOT_RUN" "coordinator refresh" "blocked before outcome" "Coordinator refresh depends on complete or explicitly blocked outcome." "Resolve reviewer return path." ""
      record_step "22" "NOT_RUN" "final audit" "trace incomplete" "Run final audit after return boundary is resolved." "Inspect SCTL Git status manually." "$SCTL_WORKSPACE/.strata/context"
      finish_report
      echo "FLOWMAP_02_END=$(ts)"
      echo "RUN_ROOT=$RUN_ROOT"
      echo "LOG=$LOG"
      echo "DIAG=$DIAG"
      echo "REPORT=$REPORT"
      return 3
    fi
  fi
  REVIEWER_CLASSIFY_JSON="$RUN_ROOT/reviewer_classify.json"
  run_cmd "17 classify reviewer return" bash -lc 'set -o pipefail; node src/cli.js --workspace "$0" returns classify --packet ".strata/returns/'"$ASSIGNMENT_ID"'/'"$REVIEWER_ID"'/packet.json" | tee "$1"' "$SCTL_WORKSPACE" "$REVIEWER_CLASSIFY_JSON"
  [ "$?" -eq 0 ] && json_ok "$REVIEWER_CLASSIFY_JSON" && record_step "17" "OBSERVED" "returns classify -> classifyWorkerReturnPacket()" "reviewer return classified" "Reviewer return was ledgered under return_ledgers." "Inspect routing_decision and ledger index." "$SCTL_WORKSPACE/.strata/context/D_trace/return_ledgers" || record_step "17" "BROKEN" "returns classify -> classifyWorkerReturnPacket()" "reviewer return classification failed or JSON ok:false" "Reviewer packet/report validation boundary failed." "Inspect reviewer_classify.json and return diagnostics." "$REVIEWER_CLASSIFY_JSON"

  if [ "$FLOWMAP02_REVIEW_RESULT" = "approved" ]; then
    if [ "$FLOWMAP02_RUN_CI" = "1" ]; then
      run_cmd "18A ci local checks" bash -lc 'set -o pipefail; cd "$0" && if [ -f package.json ]; then npm test; else git status --short; fi | tee "$1"' "$CODEBASE_REPO" "$CI_LOG"
      [ "$?" -eq 0 ] && record_step "18A.ci" "OBSERVED" "Codebase CI/checks" "$CI_LOG" "Local checks command was executed before merge." "Inspect CI log." "$CI_LOG" || {
        record_step "18A.ci" "BROKEN" "Codebase CI/checks" "CI/check command failed" "Stop condition prohibits merge without green CI/check evidence." "Inspect CI log." "$CI_LOG"
        FLOWMAP02_MERGE=0
      }
    else
      record_step "18A.ci" "BLOCKED" "Codebase CI/checks" "CI skipped by FLOWMAP02_RUN_CI=0" "Stop condition would prohibit merge without CI evidence." "Run CI/checks before merge." "$CI_LOG"
      FLOWMAP02_MERGE=0
    fi
    if [ "$FLOWMAP02_MERGE" = "1" ]; then
      run_cmd "18A merge ff only" bash -lc 'cd "$0" && git switch "$1" && git merge --ff-only "$2" && git status --short' "$CODEBASE_REPO" "$TRUNK_BRANCH" "$CHANGE_BRANCH"
      [ "$?" -eq 0 ] && record_step "18A.merge" "OBSERVED" "Codebase Git merge --ff-only" "$CHANGE_BRANCH -> $TRUNK_BRANCH" "Coordinator merge path completed after review approval and CI/checks." "Record merge outcome in Class B." "$CODEBASE_REPO" || record_step "18A.merge" "BROKEN" "Codebase Git merge" "merge failed" "Approved path could not merge branch." "Inspect codebase git graph/status." "$CODEBASE_REPO"
    else
      record_step "18A.merge" "NOT_RUN" "Codebase Git merge" "merge disabled" "Merge was intentionally not performed." "Record unmerged approved outcome or rerun with FLOWMAP02_MERGE=1." "$CODEBASE_REPO"
    fi
  elif [ "$FLOWMAP02_REVIEW_RESULT" = "denied" ]; then
    record_step "18B" "OBSERVED" "denied path policy" "first denial" "Same Change Author session should receive one revision delta and remain active." "Inspect revision request dispatch." ""
    DENY_MSG_JSON="$RUN_ROOT/deny_message.json"
    run_cmd "18B denial revision message" bash -lc 'set -o pipefail; node src/cli.js --workspace "$0" message send --assignment-id "$1" --thread-id "THREAD_${1}_REVISION_1" --from-role "Trunk Coordinator" --from-id "$2" --to-role "Change Author" --to-id "$3" --message-kind revision_request --requested-handling "Revise the same branch once using the denial report. Return a revised Worker Return Packet and operational report." --body "Reviewer denied the first attempt. Revise branch '"$CHANGE_BRANCH"' according to the denial report. Do not merge. Return revised evidence." | tee "$4"' "$SCTL_WORKSPACE" "$ASSIGNMENT_ID" "$TRUNK_COORDINATOR_ID" "$CHANGE_AUTHOR_ID" "$DENY_MSG_JSON"
    DENY_MSG_FILE="$(json_field "$DENY_MSG_JSON" result.file 2>/dev/null || true)"
    run_cmd "18B denial dispatch render" scripts/wsl_tmux/sctl-dispatch-render --workspace "$SCTL_WORKSPACE" --assignment-id "$ASSIGNMENT_ID" --nonce N_AUTHOR_REVISION_1 --from-role "Trunk Coordinator" --from-id "$TRUNK_COORDINATOR_ID" --target-role "Change Author" --target-id "$CHANGE_AUTHOR_ID" --summary "First denial revision request" --message-file "$DENY_MSG_FILE"
    REVISION_PACKET_REL=".strata/context/D_trace/dispatch_packets/$ASSIGNMENT_ID/$CHANGE_AUTHOR_ID/N_AUTHOR_REVISION_1/dispatch_packet.md"
    if [ "$FLOWMAP02_INJECT" = "1" ] && [ "$FLOWMAP02_NO_LAUNCH" != "1" ]; then
      run_cmd "18B denial dispatch inject" bash -lc 'cd "$0" && "$1/scripts/wsl_tmux/sctl-dispatch-inject" --session "$2" --packet "$3"' "$SCTL_WORKSPACE" "$PACKAGE_ROOT" "$CHANGE_AUTHOR_SESSION" "$REVISION_PACKET_REL"
    fi
    record_step "18C" "NOT_RUN" "second denial policy" "denial count is not greater than one" "Replacement author path not applicable for first denial." "Only run 18C after repeated denial." ""
  else
    record_step "18A" "NOT_RUN" "approved merge path" "$FLOWMAP02_REVIEW_RESULT outcome" "Merge path not allowed for non-approved reviewer outcome." "Record block/denial in Class B." ""
    record_step "18B" "NOT_RUN" "first denial revision path" "$FLOWMAP02_REVIEW_RESULT outcome" "Denied path not applicable unless review result is denied." "Inspect reviewer report." ""
    record_step "18C" "NOT_RUN" "repeated denial path" "$FLOWMAP02_REVIEW_RESULT outcome" "Repeated-denial path not applicable." "Inspect reviewer report." ""
  fi

  START_REV_FINAL="$(node -e 'const fs=require("fs"); const j=JSON.parse(fs.readFileSync(process.argv[1],"utf8")); process.stdout.write(String(j.current_class_b_revision ?? j.class_b_revision ?? 0));' "$SCTL_WORKSPACE/.strata/context/D_trace/context_state.json")"
  run_cmd "19 final outcome classb put" "${SCTL[@]}" classb put \
    --id "B_${ASSIGNMENT_ID}_MERGE_OUTCOME" --title "${ASSIGNMENT_ID} ${FLOWMAP02_REVIEW_RESULT} outcome" \
    --assignment-id "$ASSIGNMENT_ID" --agent-id "$TRUNK_COORDINATOR_ID" --role "Trunk Coordinator" --scope review_outcome \
    --summary "Reviewer outcome: ${FLOWMAP02_REVIEW_RESULT}." \
    --progress-delta "Flowmap 02 routed coordinator intent through author and reviewer sessions." \
    --trunk-integration "Codebase repo: ${CODEBASE_REPO}; trunk: ${TRUNK_BRANCH}; branch: ${CHANGE_BRANCH}; merge setting: ${FLOWMAP02_MERGE}." \
    --verification "Reviewer return classified. CI log path: ${CI_LOG}." \
    --evidence-detail "Author packet: ${AUTHOR_PACKET_REL}; review packet: ${REVIEW_PACKET_REL}; return ledgers: .strata/context/D_trace/return_ledgers/." \
    --risks "See reviewer outcome report for remaining risks." \
    --next-action "Refresh Trunk Coordinator context and select next small change."
  END_REV_FINAL="$(node -e 'const fs=require("fs"); const j=JSON.parse(fs.readFileSync(process.argv[1],"utf8")); process.stdout.write(String(j.current_class_b_revision ?? j.class_b_revision ?? 0));' "$SCTL_WORKSPACE/.strata/context/D_trace/context_state.json")"
  [ "$END_REV_FINAL" -eq $((START_REV_FINAL + 1)) ] 2>/dev/null && record_step "19" "OBSERVED" "classb put -> putClassBFile()" "Class B revision $START_REV_FINAL -> $END_REV_FINAL" "Final outcome entered Class B." "Audit SCTL Git." "$SCTL_WORKSPACE/.strata/context/B" || record_step "19" "BROKEN" "classb put" "Class B revision $START_REV_FINAL -> $END_REV_FINAL" "Expected final outcome to increment Class B revision by one." "Inspect classb output." "$LOG"

  if [ "$FLOWMAP02_REVIEW_RESULT" = "approved" ] || [ "$FLOWMAP02_REVIEW_RESULT" = "blocked" ]; then
    run_cmd "20 retire change author" env SCTL_RUNTIME_EDGE_ROOT="$SCTL_RUNTIME_EDGE_ROOT" scripts/wsl_tmux/sctl-session-retire --workspace "$SCTL_WORKSPACE" --assignment-id "$ASSIGNMENT_ID" --id "$CHANGE_AUTHOR_ID" --session "$CHANGE_AUTHOR_SESSION" --reason "Flowmap 02 Change Author cycle completed"
    run_cmd "20 retire reviewer" env SCTL_RUNTIME_EDGE_ROOT="$SCTL_RUNTIME_EDGE_ROOT" scripts/wsl_tmux/sctl-session-retire --workspace "$SCTL_WORKSPACE" --assignment-id "$ASSIGNMENT_ID" --id "$REVIEWER_ID" --session "$REVIEWER_SESSION" --reason "Flowmap 02 review cycle completed"
    record_step "20" "OBSERVED" "sctl-session-retire -> retireSession()" "disposable sessions retired or retire commands attempted" "Author and reviewer lifecycle closure was recorded through SCTL." "Inspect active_sessions.json/lifecycle." "$SCTL_WORKSPACE/.strata/context/C/sessions"
  else
    run_cmd "20 retire reviewer only after first denial" env SCTL_RUNTIME_EDGE_ROOT="$SCTL_RUNTIME_EDGE_ROOT" scripts/wsl_tmux/sctl-session-retire --workspace "$SCTL_WORKSPACE" --assignment-id "$ASSIGNMENT_ID" --id "$REVIEWER_ID" --session "$REVIEWER_SESSION" --reason "Flowmap 02 first denial review cycle completed"
    record_step "20" "OBSERVED" "denial lifecycle policy" "reviewer retired; author kept active for one revision delta" "First denial policy keeps same Change Author session active." "Inspect active_sessions.json." "$SCTL_WORKSPACE/.strata/context/C/sessions/active_sessions.json"
  fi

  run_cmd "21 coordinator freshness" "${SCTL[@]}" context freshness --loaded-context-epoch 0 --loaded-class-a-revision 1
  run_cmd "21 coordinator export refresh" "${SCTL[@]}" context export-markdown --include-classes A,B --out ".strata/exports/${ASSIGNMENT_ID}_coordinator_refresh"
  record_step "21" "OBSERVED" "context freshness/exportMarkdown" "coordinator freshness/export commands completed" "Coordinator can refresh from current SCTL Git state instead of private chat memory." "Inspect export manifest/context." "$SCTL_WORKSPACE/.strata/exports/${ASSIGNMENT_ID}_coordinator_refresh"

  run_cmd "22 final sctl git status" git -C "$SCTL_WORKSPACE/.strata/context" status --short
  run_cmd "22 final sctl git log" git -C "$SCTL_WORKSPACE/.strata/context" log --oneline -30
  run_cmd "22 final dispatch files" find "$SCTL_WORKSPACE/.strata/context/D_trace/dispatch_packets" -maxdepth 5 -type f
  run_cmd "22 final return ledgers" find "$SCTL_WORKSPACE/.strata/context/D_trace/return_ledgers" -type f
  run_cmd "22 final classb files" find "$SCTL_WORKSPACE/.strata/context/B" -type f
  if [ -z "$(git -C "$SCTL_WORKSPACE/.strata/context" status --short)" ]; then
    record_step "22" "OBSERVED" "SCTL Git final audit" "status clean" "SCTL context Git is clean and log contains cycle commits." "Review diagnosis table for any non-observed steps." "$SCTL_WORKSPACE/.strata/context"
  else
    record_step "22" "MISSING_EVIDENCE" "SCTL Git final audit" "status not clean" "Final SCTL context Git has uncommitted files." "Inspect git status output." "$SCTL_WORKSPACE/.strata/context"
  fi

  finish_report
  echo "FLOWMAP_02_END=$(ts)"
  echo "RUN_ROOT=$RUN_ROOT"
  echo "LOG=$LOG"
  echo "DIAG=$DIAG"
  echo "REPORT=$REPORT"
}

main "$@"
