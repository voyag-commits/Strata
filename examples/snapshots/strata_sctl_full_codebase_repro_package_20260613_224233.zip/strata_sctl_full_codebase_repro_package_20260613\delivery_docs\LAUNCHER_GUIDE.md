# Strata Fleet Launcher Guide

## Overview

This document describes the launcher ecosystem installed during the v0.9 diagnostic and fleet-mobilization work. Three launcher scripts sit in `~/bin/`, each serving a distinct layer in the Strata Component 2 + Component 3 pipeline. All are reachable from any WSL shell.

## Launcher Inventory

| Launcher | Path | Purpose | Used By |
|---|---|---|---|
| `strata-codex-local` | `~/bin/strata-codex-local` | Low-level: starts a Codex CLI + DeepSeek bridge. Owns the bridge process, env, and PID files. | v0.9 `provider.ts` (`mode: exec`) |
| `strata-codex-linux-desktop` | `~/bin/strata-codex-linux-desktop` | Mid-level: one-session wrapper. Creates/names a tmux session with status bar, then attaches. Used by the Windows `.lnk` shortcut. | Desktop shortcut, `common.ts` (v0.9 first attempt) |
| **`strata-fleet-launch`** | **`~/bin/strata-fleet-launch`** | **High-level: launches N visible Codex CLI sessions as a fleet. Calls the v0.9 CLI underneath.** | **New — v0.9 diagnostic work product** |

## `strata-fleet-launch` — Usage

```bash
# Simplest: 3 sessions, letters A/B/C
strata-fleet-launch --count 3

# Named sessions
strata-fleet-launch FLEET-A FLEET-B FLEET-C

# Custom role, numbered suffixes
strata-fleet-launch --role coder --count 2 --prefix DEV --layout number

# Headless only (no Windows Terminal tabs)
strata-fleet-launch --count 3 --no-tab

# Full help
strata-fleet-launch --help
```

**Output per session:**
- A headless tmux session (capturable, dispatch-injectable)
- A visible Windows Terminal tab (via `wt.exe`)
- Status bar with session name (green/blue/red, matching desktop-shortcut aesthetic)
- Evidence trail in `.strata-runtime/evidence/`

## Architecture Relationship

### What the v0.9 package provides

The `strata_runtime_edge_launcher_delegate_component2_3_v0_9` package is the **deterministic payload**. It exposes:

```
node dist/src/cli.js
  ├── provider init-template          # write launcher_delegate.local.json
  ├── provider doctor                # verify launcher health
  ├── session launch --role X --assignment-id Y   # create tmux session + record
  ├── session list / capture / terminate
  ├── dispatch render / inject       # Component 3: notice delivery
```

It follows the BYOR pattern: secrets live in your local launcher, not in the package.

### What we added (diagnostic + fleet work)

Two files were modified inside the v0.9 package:

| File | Change | Why |
|---|---|---|
| `src/common.ts` | Added `isWsl()`, `spawnTerminalTab()` | Detects WSL, resolves `wt.exe`, launches visible Windows Terminal tab attached to tmux session |
| `src/runtime.ts` | Added `applyTmuxCosmetics()`, calls `spawnTerminalTab()` after session creation | Every `session launch` now auto-opens a visible desktop tab with the standard status bar |

One new script was installed **outside** the package (stable, independently callable):

| Script | Path | What |
|---|---|---|
| `strata-fleet-launch` | `~/bin/` | Wraps the v0.9 CLI in a loop. Auto-generates assignment IDs, launches N sessions, prints a status grid. |

### Separation of concerns

```
┌──────────────────────────────────────────────┐
│              strata-fleet-launch              │  ← New: fleet orchestration
│  (loop: generate IDs, call v0.9 CLI)         │
└──────────────────┬───────────────────────────┘
                   │ calls
┌──────────────────▼───────────────────────────┐
│  strata_runtime_edge_launcher_delegate v0.9  │  ← Payload: never stores secrets
│  src/cli.ts → runtime.ts + common.ts         │
│    session launch ──→ tmux -d session        │
│                  ──→ wt.exe tab attach        │  ← Added: visible terminal
│                  ──→ evidence record          │
│                  ──→ tmux status cosmetics    │  ← Added: status bar
│    dispatch inject ──→ tmux set-buffer/paste │
└──────────────────┬───────────────────────────┘
                   │ delegates
┌──────────────────▼───────────────────────────┐
│           ~/bin/strata-codex-local            │  ← BYOR: owns secrets, bridge
│  (Codex CLI + DeepSeek bridge process)       │
└──────────────────────────────────────────────┘
```

## Quick Start

```bash
# 1. Verify health
cd "~/Downloads/Codex_CLI_agent fleet/strata_runtime_edge_launcher_delegate_component2_3_v0_9"
node dist/src/cli.js provider doctor

# 2. Launch a fleet (3 visible tabs)
strata-fleet-launch --count 3

# 3. Dispatch a message to all fleet sessions
for S in STRATA-IC-FLEET-A STRATA-IC-FLEET-B STRATA-IC-FLEET-C; do
  echo "hello codex, you are now living in wsl" | tmux set-buffer -b strata &&
  tmux paste-buffer -b strata -t "$S" &&
  tmux send-keys -t "$S" Enter
done

# 4. Send a structured notice via v0.9 dispatch
node dist/src/cli.js dispatch inject \
  --notice .strata-runtime/notices/runtime_edge_notice_A001_acceptance.json \
  --session STRATA-IC-FLEET-A

# 5. Check evidence
node dist/src/cli.js session list
```

## WSL Paths Map

| Concept | Path |
|---|---|
| Fleet launcher script | `/home/hou16/bin/strata-fleet-launch` |
| Desktop shortcut launcher | `/home/hou16/bin/strata-codex-linux-desktop` |
| BYOR bridge launcher | `/home/hou16/bin/strata-codex-local` |
| v0.9 package root | `~/Downloads/Codex_CLI_agent fleet/strata_runtime_edge_launcher_delegate_component2_3_v0_9` |
| v0.9 config | `.../v0_9/.strata-runtime/config/launcher_delegate.local.json` |
| v0.9 evidence | `.../v0_9/.strata-runtime/evidence/` |
| Windows Terminal exe | `/mnt/c/Users/hou16/AppData/Local/Microsoft/WindowsApps/wt.exe` |
| Desktop shortcut | `C:\Users\hou16\Desktop\Codex Linux (DeepSeek).lnk` |
