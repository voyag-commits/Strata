﻿# Delivery Package Notes

Created: 2026-06-13T15:13:01.4202808+08:00

Contents:
- Patched SCTL package source, docs, specs, templates, tests, and WSL/tmux adapter scripts.
- Flowmap 02 harness scripts under flowmap02_harness/.
- Source procedure docs and selected live-run evidence under delivery_docs/.

Excluded intentionally:
- node_modules
- .git directories
- .strata-runtime live evidence
- runtime-generated .strata/evidence JSON files
- Flowmap fixture run repositories and bulky run directories, except selected A_FLOWMAP_02_003 evidence files.

Known caveat:
- The A_FLOWMAP_02_003 live trace used launcher/tmux/live returns, but the codebase repository was a fixture because no real CODEBASE_REPO was supplied.
