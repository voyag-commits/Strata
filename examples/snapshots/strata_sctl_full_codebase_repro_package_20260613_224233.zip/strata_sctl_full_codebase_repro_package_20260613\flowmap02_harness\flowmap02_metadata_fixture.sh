#!/usr/bin/env bash
set -u
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"

export FLOWMAP02_NO_LAUNCH="${FLOWMAP02_NO_LAUNCH:-1}"
export FLOWMAP02_INJECT="${FLOWMAP02_INJECT:-0}"
export FLOWMAP02_SIMULATE_RETURNS="${FLOWMAP02_SIMULATE_RETURNS:-1}"
export FLOWMAP02_REVIEW_RESULT="${FLOWMAP02_REVIEW_RESULT:-approved}"

exec bash "$SCRIPT_DIR/flowmap02_run.sh" "$@"
