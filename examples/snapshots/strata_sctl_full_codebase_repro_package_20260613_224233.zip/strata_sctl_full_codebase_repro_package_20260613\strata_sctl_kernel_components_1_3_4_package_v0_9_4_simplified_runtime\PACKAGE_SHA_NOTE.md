# Package SHA Note v0.9.4

Recompute package checksum after zipping:

```bash
sha256sum strata_sctl_kernel_components_1_3_4_package_v0_9_4_simplified_runtime.zip
```

Internal file checksums are listed in `PACKAGE_CHECKSUMS.sha256`.
