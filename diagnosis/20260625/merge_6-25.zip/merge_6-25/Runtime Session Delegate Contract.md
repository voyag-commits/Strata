# Runtime Session Delegate Contract

Status: ADR_06_18 stabilized; live WSL/tmux runtime verified 2026-06-25.

SCTL interacts with the delegate through eight contract verbs: `session-register`, `session-create`, `dispatch-deliver`, `return-drop`, `return-dir`, `session-capture`, `session-terminate`, `session-list`.

**Installation:** package `strata-runtime-edge-delegate-control-surface` v1.0.0-adr0618 at `~/workspace/runtime-delegates/strata-runtime-edge-delegate-control-surface`, symlinked via `~/bin/strata-runtime-edge-delegate-current`. Binary: `node dist/src/cli.js`. Legacy `strata-runtime-edge-launcher-delegate-component2-3` is demoted fallback only.

**Routing:** SCTL selects the delegate via `SCTL_RUNTIME_DELEGATE_ROOT` and `SCTL_RUNTIME_DELEGATE_BIN`.

**Operations:** Session verbs bind tmux targets and register contract records. Dispatch delivers packets unchanged with SHA256 evidence. Return verbs target `.strata/returns/<assignment_id>/<session_id>/`. Capture reads pane output; terminate retires sessions per `kill-session` policy.

**Failures** are machine-readable: `ok`, `error_code`, `message`, `evidence_path`, `recoverable`. SCTL owns validation, context commits, and cycle progression.
