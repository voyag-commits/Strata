# SCTL Delegate Contract Alignment Report

Status: patched package produced from the uploaded `Strata_ADR0618_E2E_mock_runtime_implemented(1).zip`.

## Applied decisions

- Decision 1: `SCTL_RUNTIME_DELEGATE_ROOT` / `SCTL_RUNTIME_DELEGATE_BIN` are canonical. `SCTL_RUNTIME_EDGE_ROOT` / `SCTL_RUNTIME_EDGE_CLI` remain one-cycle deprecated aliases with warnings.
- Decision 2: active live-harness runtime function names were renamed to delegate-verb semantics.
- Decision 3: SCTL live path uses `session-register` only; `session-create` is not added to SCTL Flowmap 02.
- Decision 4: SCTL owns `.strata/returns/<assignment_id>/<session_id>/` return directory paths.
- Decision 5: embedded SCTL mock runtime implementation and mock E2E assets were removed.
- Decision 6: delegate command JSON is preserved directly as evidence; SCTL does not flatten or reinterpret delegate errors beyond step failure routing.

## Main code changes

- `flowmaps/flowmap02/live_cycle_harness.sh`
  - Calls external delegate contract verbs directly: `session-list`, `session-register`, `dispatch-deliver`, `session-capture`, `session-terminate`.
  - Uses delegate env names as canonical.
  - Creates/owns return directories under `.strata/returns/...`.
  - Keeps SCTL responsibilities: Director Entry, context export, dispatch render, return classify, Class B commit, cycle progression.

- `scripts/wsl_tmux/`
  - Removed old runtime wrapper scripts: `sctl-session-new`, `sctl-dispatch-inject`, `sctl-session-capture`, `sctl-session-retire`, `sctl-fleet-smoke`.
  - Kept only SCTL-owned utilities: `sctl-dispatch-render`, `sctl-git-panel`, and shared setup.

- Removed embedded mock runtime assets:
  - `scripts/mock_runtime_delegate/`
  - `scripts/adr_06_18_e2e_mock_runtime.sh`
  - `examples/adr_06_18_e2e_mock_runtime/`
  - stale mock/live log and snapshot examples.

- `src/lib/dispatch_outbox.js` and `src/lib/flowmap.js`
  - Updated suggested runtime commands to delegate contract verbs.

- `tests/runtime_delegate_contract.test.js`
  - Replaced mock-runtime execution test with semantic contract checks.

## Verification

- `npm test`: pass, 27/27.
- Bash syntax checks: pass for active shell scripts.
- `npm run secret-scan`: pass, no findings.
- `sha256sum -c PACKAGE_CHECKSUMS.sha256`: pass.

## Known caveat

I could not run a real WSL/tmux/Codex live pane from this sandbox. The patch aligns SCTL to the delegate contract and verifies package behavior statically/unit-wise, but live operation still needs one WSL smoke run against the installed delegate binary and an actual registered tmux target.
