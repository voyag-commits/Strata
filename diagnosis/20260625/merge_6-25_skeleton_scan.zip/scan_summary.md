# merge_6-25 — Comprehensive Skeleton Extraction Report

**Generated:** 2026-06-25 19:10:29  
**Tool:** skeleton-extractor v0.1.0  
**Target:** C:\Users\hou16\Downloads\merge_6-25_extracted  

## Scan Statistics

| Metric | Value |
|---|---|
| Files processed | 143 |
| Skeletons extracted | 55 |
| Total symbols | 614 |
| Unsupported files (logged) | 88 |

## Contents Scanned

### 1. Loose files in merge_6-25/
- Runtime Session Delegate Contract.md
- delegate_control_surface_USER_MANUAL.md  
- delegate_control_surface_artifact_sha256.txt
- sctl_delegate_contract_alignment_report.md
- strata_runtime_edge_delegate_control_surface_adr0618_wsl_ready.zip (extracted)
- strata_sctl_delegate_contract_aligned_adr0618_v0_9_5.zip (extracted)

### 2. strata-runtime-edge-delegate-control-surface (zip extracted)
- TypeScript sources (src/*.ts) — 9 files
- Compiled JS (dist/src/*.js) — 9 files  
- Tests (tests/*.test.ts, dist/tests/*.test.js)
- Docs, ADRs, templates
- Tester playbook

### 3. Strata SCTL Kernel (zip extracted)
- JavaScript sources (src/*.js, src/lib/*.js) — 16 JS files
- Shell scripts (scripts/*.sh, flowmaps/flowmap02/*.sh)
- Tests (tests/*.test.js) — 9 files
- Schemas, docs, templates, flowmaps

## Supported Language Breakdown

| Language | Skeletons | Symbols |
|---|---|---|
| JavaScript (.js, .mjs) | 32 | ~390 |
| TypeScript (.ts) | 18 | ~190 |
| Shell (.sh) | 5 | ~34 |
| **Total** | **55** | **614** |

## Output Files

- `skeleton.md` — Human-readable codebase skeleton with symbols
- `metadata.json` — Machine-readable metadata + call graph
- `errors.json` — Extraction errors log (88 unsupported .md/.txt/.json files)
- `scan_log.txt` — This scan session log
- `scan_summary.md` — This summary document
