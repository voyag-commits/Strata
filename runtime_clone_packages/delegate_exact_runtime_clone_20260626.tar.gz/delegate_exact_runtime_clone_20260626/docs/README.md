# Exact WSL Runtime Clone Package

This package reconstructs the Delegate -> strata-codex-local -> Codex deepseek_bridge -> Fastify bridge -> DeepSeek runtime path in another WSL environment.

## Restore

1. Extract the archive under `/home/hou16`.
2. Copy `secrets/bridge.env.template` to `secrets/bridge.env.local`.
3. Fill `DEEPSEEK_API_KEY` and `BRIDGE_AUTH_KEY` in `secrets/bridge.env.local`.
4. Run `./restore.sh --target-home /home/hou16`.
5. Run `./bin/verify_live.sh --target-home /home/hou16`.

Restore intentionally blocks if the target runtime paths already exist. This prevents silently overwriting an existing WSL runtime.

## Runtime Values

- Delegate root: `/home/hou16/workspace/runtime-delegates/strata-runtime-edge-delegate-control-surface`
- Bridge root: `/home/hou16/strata/bridge/bridge`
- Launcher: `/home/hou16/bin/strata-codex-local`
- Codex profile: `/home/hou16/.codex/deepseek_bridge.config.toml`
- Bridge URL: `http://127.0.0.1:38441/v1`
- DeepSeek model: `deepseek-v4-pro`
- Thinking: enabled, effort `max`, budget `12000`
