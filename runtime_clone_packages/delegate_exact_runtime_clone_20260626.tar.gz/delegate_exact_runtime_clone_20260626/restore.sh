#!/usr/bin/env bash
set -euo pipefail

PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
TARGET_HOME=""
export PATH="/home/hou16/.nvm/versions/node/v22.17.1/bin:$PATH"

usage() {
  echo "usage: restore.sh --target-home /home/hou16" >&2
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --target-home) TARGET_HOME="$2"; shift 2 ;;
    --help) usage; exit 0 ;;
    *) echo "UNKNOWN_ARGUMENT: $1" >&2; usage; exit 2 ;;
  esac
done

[ "$TARGET_HOME" = "/home/hou16" ] || {
  echo "BLOCKED_TARGET_HOME_MUST_BE_EXACT: expected /home/hou16 got ${TARGET_HOME:-<missing>}" >&2
  exit 30
}

SECRET_FILE="$PACKAGE_DIR/secrets/bridge.env.local"
[ -f "$SECRET_FILE" ] || {
  echo "BLOCKED_SECRET_REQUIRED: create $SECRET_FILE from secrets/bridge.env.template" >&2
  exit 31
}
if grep -q '<REQUIRED>' "$SECRET_FILE"; then
  echo "BLOCKED_SECRET_REQUIRED: $SECRET_FILE still contains <REQUIRED>" >&2
  exit 32
fi
grep -q '^DEEPSEEK_API_KEY=' "$SECRET_FILE" || { echo "BLOCKED_SECRET_REQUIRED: missing DEEPSEEK_API_KEY" >&2; exit 33; }
grep -q '^BRIDGE_AUTH_KEY=' "$SECRET_FILE" || { echo "BLOCKED_SECRET_REQUIRED: missing BRIDGE_AUTH_KEY" >&2; exit 34; }

for command in node npm tmux curl codex sha256sum tar; do
  command -v "$command" >/dev/null 2>&1 || { echo "BLOCKED_MISSING_COMMAND: $command" >&2; exit 35; }
done

if [ -e "$TARGET_HOME/workspace/runtime-delegates/strata-runtime-edge-delegate-control-surface" ] ||
   [ -e "$TARGET_HOME/strata/bridge/bridge" ] ||
   [ -e "$TARGET_HOME/bin/strata-codex-local" ] ||
   [ -e "$TARGET_HOME/.codex/deepseek_bridge.config.toml" ]; then
  echo "BLOCKED_RESTORE_TARGET_EXISTS: restore requires a clean target for exact clone" >&2
  exit 36
fi

mkdir -p "$TARGET_HOME/workspace/runtime-delegates" "$TARGET_HOME/strata/bridge" "$TARGET_HOME/bin" "$TARGET_HOME/.codex" "$TARGET_HOME/.codex-deepseek"

cp -a "$PACKAGE_DIR/payload/delegate" "$TARGET_HOME/workspace/runtime-delegates/strata-runtime-edge-delegate-control-surface"
cp -a "$PACKAGE_DIR/payload/bridge" "$TARGET_HOME/strata/bridge/bridge"
cp -a "$PACKAGE_DIR/payload/bin/strata-codex-local" "$TARGET_HOME/bin/strata-codex-local"
chmod 0755 "$TARGET_HOME/bin/strata-codex-local"
cp -a "$PACKAGE_DIR/payload/codex/deepseek_bridge.config.toml" "$TARGET_HOME/.codex/deepseek_bridge.config.toml"

mkdir -p "$TARGET_HOME/workspace/runtime-delegates/strata-runtime-edge-delegate-control-surface/.strata-runtime/config"
cp -a "$PACKAGE_DIR/runtime_config/launcher_delegate.local.json" "$TARGET_HOME/workspace/runtime-delegates/strata-runtime-edge-delegate-control-surface/.strata-runtime/config/launcher_delegate.local.json"

cp -a "$SECRET_FILE" "$TARGET_HOME/strata/bridge/bridge/.env"
chmod 0600 "$TARGET_HOME/strata/bridge/bridge/.env"

ln -sfn "$TARGET_HOME/workspace/runtime-delegates/strata-runtime-edge-delegate-control-surface" "$TARGET_HOME/bin/strata-runtime-edge-delegate-current"

(cd "$TARGET_HOME/workspace/runtime-delegates/strata-runtime-edge-delegate-control-surface" && npm ci)
(cd "$TARGET_HOME/strata/bridge/bridge" && npm ci)

"$PACKAGE_DIR/bin/verify_static.sh" --target-home "$TARGET_HOME"
echo "RESTORE_OK: exact runtime clone restored under $TARGET_HOME"
