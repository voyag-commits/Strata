# Strata v0.7 SCTL Tester Playbook Package

Status: tester package draft for approval
Target package under test: `strata_v0_7_sctl_delivery.zip`
Primary architecture inputs: ADR0601, ADR-0602, ADR-0603, plus the preserved operating inputs in this package.

## Purpose

This package defines a durable test practice for Strata v0.7 SCTL. It is not a one-time checklist.

The core validation question is:

```text
Does the live Strata runtime show the designed operating pattern through real CLI calls, Git-backed context operations, role-scoped sessions, file-based worker returns, routing decisions, and durable evidence?
```

Built-in test files remain useful, but they are only one layer. Acceptance requires live in-loop validation.

## Required reading order

1. `IMMUTABLE_PARSED_OPERATING_INPUTS.md`
2. `TESTING_STANDARD.md`
3. `RUNTIME_TOPOLOGY_UNDER_TEST.md`
4. `ROLE_SESSION_BOOTSTRAP.md`
5. `LIVE_TEST_PLAYBOOK.md`
6. `ACCEPTANCE_MATRIX.md`
7. `COMMAND_CATALOG_FOR_TESTING.md`
8. `TEST_REPORT_TEMPLATE.md`
9. `DIRECTOR_COMMUNICATION_PLACEHOLDER_SPEC.md`

Source ADRs are copied under `source_adr/` for local reference.

## Test layers

```text
L0 static/package checks
L1 unit/regression tests
L2 CLI contract tests
L3 SCTL authority integration tests
L4 live in-loop validation
```

L4 is the highest-importance acceptance layer for this project. L0-L3 establish basic confidence. L4 shows the runtime pattern the architecture is intended to produce.

## Minimum L4 live pattern

For the primary `REPORT_READY` smoke run, the Backend Loop Ledger must record one consistent nonce chain:

```text
WORK_PASSED
-> RETURN_FILE_DETECTED
-> RETURN_PACKET_CLASSIFIED
-> REPORT_LEDGERED
-> ROUTED_TO_REVIEWER
```

If the run is partial, label the exact partial state. Avoid vague success language.

## Industrial practice references

This playbook borrows the testing shape from the practical test pyramid: more low-level regression tests, fewer high-value integration and end-to-end tests. It borrows the live operating shape from SRE incident-management discipline: explicit roles, command/coordination, durable evidence, and observable behavior.

Reference links:

- Martin Fowler, Practical Test Pyramid: https://martinfowler.com/articles/practical-test-pyramid.html
- Google SRE Incident Management Guide: https://sre.google/resources/practices-and-processes/incident-management-guide/
- Google SRE Workbook, Incident Response: https://sre.google/workbook/incident-response/
- Google SRE Book, Managing Incidents: https://sre.google/sre-book/managing-incidents/
- Google SRE Book, Monitoring Distributed Systems: https://sre.google/sre-book/monitoring-distributed-systems/

## Package output expectation

A completed test run should produce a report with:

```text
commands run
pass/fail or blocked state
evidence paths
backend_loop_ledger.jsonl
backend_loop_ledger.md
acceptance matrix coverage
remaining gaps
suspected legacy bypasses
recommendation
```
