# Director Communication Placeholder Spec

Status: planned tool placeholder for future patch
Initial authorized caller roles: IC, BOC

## 1. Purpose

`director communication` is a planned special channel for escalation and Q/A with the Director.

It should be deterministic SCTL infrastructure. It records a request and returns a stable result envelope. It does not make a judgment, rewrite context, or imply that the Director has responded.

## 2. Recommended public tool id

Placeholder phase:

```text
director.communication.placeholder.v1
```

Implemented transport phase:

```text
director.communication.v1
```

## 3. Intended callers

Initial allowed callers:

```text
IC
BOC
```

Initial route for other roles:

```text
route request through IC
```

## 4. Required input fields

```json
{
  "request_id": "DIRCOMM-A017-001",
  "caller_id": "ic_017",
  "caller_role": "ic",
  "assignment_id": "A017",
  "subject": "Scope clarification",
  "body_path": ".strata/director_communication/DIRCOMM-A017-001/request.md",
  "urgency": "normal|high",
  "related_artifacts": []
}
```

## 5. Required artifacts

```text
.strata/director_communication/<request_id>/request.md
.strata/director_communication/<request_id>/manifest.json
.strata/director_communication/<request_id>/related_artifacts.json
.strata/backend/tool_runs/<tool_run_id>/result.json
```

## 6. Minimal result envelope

```json
{
  "ok": true,
  "tool_id": "director.communication.placeholder.v1",
  "tool_run_id": "<tool_run_id>",
  "result_path": ".strata/director_communication/<request_id>/manifest.json",
  "evidence_paths": [
    ".strata/director_communication/<request_id>/request.md"
  ],
  "errors": [],
  "warnings": [
    "No external delivery transport is configured. Request is queued as a local artifact."
  ],
  "status": "queued_for_director_review"
}
```

## 7. Validation checks for tester after patch

| Check | Expected behavior |
| --- | --- |
| `tools inspect director.communication.v1` | returns contract |
| IC request | creates request artifact and result envelope |
| BOC request | creates request artifact and result envelope |
| Coder request | returns role route result through IC or blocked-with-reason |
| A/B/C mutation check | no authoritative context change |
| evidence check | request, manifest, and tool-run result exist |

## 8. Current-state handling

If this tool is not yet patched into the codebase, the tester records:

```text
status: gap_recorded
path: .strata/evidence/live_runs/<run_id>/gaps/director_communication_placeholder_absent.md
impact: planned capability absent, not a failure of ADR-0603 unless required by test scope
```
