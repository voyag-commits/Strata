# Command Catalog for Testing

Status: tester command reference

Use commands through the SCTL CLI. Raw Git may be used for read-only inspection, but authority actions use `strata context ...`.

## 1. Package commands

```bash
npm ci
npm run build
npm test
npm run secret-scan
```

## 2. General CLI

```bash
npm --silent run strata -- help
```

## 3. Context repo and authority commands

```bash
npm --silent run strata -- context repo-status
npm --silent run strata -- context bootstrap
npm --silent run strata -- context propose --proposal <id> --caller-id <id> --caller-role <role> --class A|B|C --id <semantic_id> --title <title> --body <body>
npm --silent run strata -- context validate --proposal <id>
npm --silent run strata -- context diff --proposal <id>
npm --silent run strata -- context review-request --proposal <id> --caller-id <id> --caller-role <role>
npm --silent run strata -- context approve --proposal <id> --reviewer-id <id> --reviewer-role reviewer
npm --silent run strata -- context reject --proposal <id> --reviewer-id <id> --reviewer-role reviewer --reason-file <path>
npm --silent run strata -- context request-revision --proposal <id> --reviewer-id <id> --reviewer-role reviewer --reason-file <path>
npm --silent run strata -- context merge --proposal <id> --caller-id <id> --caller-role human_director
npm --silent run strata -- context revert --commit <commit> --caller-id <id> --caller-role human_director
npm --silent run strata -- context list
npm --silent run strata -- context summary
```

## 4. Context export commands

```bash
npm --silent run strata -- context export-markdown --scope all --out .strata/exports/context/<export_id>
npm --silent run strata -- context export-pdf --scope all --out .strata/exports/context/<export_id>
```

Expected export artifacts:

```text
context.md
context.pdf
manifest.json
source_index.json
checksums.sha256
```

## 5. Tool registry commands

```bash
npm --silent run strata -- tools list
npm --silent run strata -- tools inspect --tool context.export_markdown.v1
npm --silent run strata -- tools inspect --tool context.export_pdf.v1
npm --silent run strata -- tools inspect --tool classd.locate_codex_sessions.v1
npm --silent run strata -- tools inspect --tool classd.register_session.v1
npm --silent run strata -- tools inspect --tool classd.export_markdown.v1
npm --silent run strata -- tools inspect --tool classd.export_pdf.v1
npm --silent run strata -- tools inspect --tool classd.verify_checksums.v1
npm --silent run strata -- tools inspect --tool classd.inspect.v1
npm --silent run strata -- tools inspect --tool session.launch_codex_tmux.v1
npm --silent run strata -- tools inspect --tool returns.scan.v1
npm --silent run strata -- tools inspect --tool returns.watch.v1
npm --silent run strata -- tools run --tool <tool_id> --input <json_file>
```

## 6. Class D local transcript commands

```bash
npm --silent run strata -- classd locate
npm --silent run strata -- classd locate --sessions-root ~/.codex/sessions
npm --silent run strata -- classd register-session --source <codex_session_file> --session-id <session_id>
npm --silent run strata -- classd export-markdown --session-id <session_id>
npm --silent run strata -- classd export-pdf --session-id <session_id>
npm --silent run strata -- classd verify-checksums --session-id <session_id>
npm --silent run strata -- classd inspect --session-id <session_id>
```

## 7. Runtime/tmux commands

```bash
npm --silent run strata -- sessions create --session STRATA-CODER-A017 --assignment-id A017 --agent-id coder_017 --role coder --cwd "$PWD" --command "codex" --replace
npm --silent run strata -- sessions list
npm --silent run strata -- sessions status --session STRATA-CODER-A017
npm --silent run strata -- dispatch send --session STRATA-CODER-A017 --packet <packet_path> --from-role IC
```

## 8. Packet and return loop commands

```bash
npm --silent run strata -- packet context-load --assignment-id A017 --agent-id coder_017 --role coder --session STRATA-CODER-A017
npm --silent run strata -- packet work-dispatch --assignment-id A017 --agent-id coder_017 --role coder --kind task --action "<action>" --body "<body>" --from-role IC
npm --silent run strata -- packet return-template --assignment-id A017 --agent-id coder_017 --role coder --kind REPORT_READY --nonce <nonce> --report-path <path>
npm --silent run strata -- returns classify --packet <packet_path>
npm --silent run strata -- returns scan --assignment-id A017 --agent-id coder_017
npm --silent run strata -- returns watch --assignment-id A017 --agent-id coder_017
npm --silent run strata -- report list
npm --silent run strata -- evidence inspect --tail 50
```

## 9. DeepSeek bridge commands

```bash
npm --silent run strata -- bridge gate --format json
npm --silent run strata -- bridge gate --format bash
npm run start:bridge
```

Record bridge status without exposing secrets.

## 10. Retired/blocked shortcut commands

These commands should return retired/blocked results for SCTL authority:

```bash
npm --silent run strata -- context add
npm --silent run strata -- classb import
npm --silent run strata -- gate evaluate
npm --silent run strata -- gate list
npm --silent run strata -- gate digest
npm --silent run strata -- report review
```

Record outputs under:

```text
.strata/evidence/live_runs/<run_id>/commands/retired_shortcuts/
```
