# Immutable Parsed Operating Inputs

Status: tester-playbook immutable baseline
Scope: preserves the practical meaning of the Director's three testing inputs

These inputs define how the tester package interprets the live behavior to validate. They are operational doctrine for this test package.

## Input A: Unit tests are not live acceptance

Parsed meaning:

```text
Built-in test files are unit/regression tests. They are required baseline checks, but they are not enough to accept Strata v0.7. The main acceptance evidence must come from real backend activity and live loops.
```

The durable test taxonomy is:

```text
L0 static/package checks
L1 unit/regression tests
L2 CLI contract tests
L3 SCTL authority integration tests
L4 live in-loop validation
```

L4 must show the designed operating pattern, not only command success.

## Input B: Runtime and role-session operating model

Parsed meaning:

```text
The live system under test is WSL/tmux -> Codex CLI with DeepSeek bridge where configured -> Git-backed context/progress store -> SCTL tool registry -> file-based reports and return packets.
```

Manual assistance for session opening is acceptable. The test remains live if the session creation path, role assignment, file-based return, SCTL commands, and evidence capture are recorded.

Each Codex CLI session receives a first role-assignment message during session creation. Role sessions include:

```text
IC
Coder
Reviewer
BOC
```

The role-assignment messages should read like practical SRE role instructions. They should not discuss whether the session operator is artificial or human. They should state what to do, where to write files, how to report, how to route questions, and which evidence to preserve.

Each role should save work and reports through the assigned durable paths:

```text
implementation work: assigned codebase/worktree/scratch path
progress/context reports: local Git/SCTL proposal path or assigned report path
worker return: Worker Return Packet under returns/<assignment_id>/<agent_id>/
```

Chat/session text is an operational control surface. Durable delivery is file-based.

## Input C: IC role emphasis

Parsed meaning:

```text
The IC holds project overview and milestone state from the Director, gives feedback, routes reviews, raises escalations to the Director, accepts Class B reports in Git only through approved authority paths, avoids direct implementation editing unless specifically assigned, prepares coder handoffs, receives reviewer reports, and plans next moves.
```

The IC is a coordination and control role. The Coder performs implementation work. The Reviewer evaluates deliverables. The BOC operates backend/runtime mechanics and records evidence.

## Input D: Backend tool registry and Director communication placeholder

Parsed meaning:

```text
Tester must exercise backend tools through the SCTL registry where possible. A future tool named director communication is planned as a special channeled communication path for escalation and Q/A with the Director. IC and BOC are the intended initial authorized users.
```

Until implemented, the tester records `director communication` as a planned placeholder. After implementation, it should be registered as a deterministic SCTL tool with fixed evidence artifacts and role-limited caller policy.

Recommended future public tool id:

```text
director.communication.placeholder.v1
```

or, after transport is real:

```text
director.communication.v1
```
