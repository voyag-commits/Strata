# Change Control

Status: draft awaiting Director approval

This tester package treats the parsed operating inputs as immutable in meaning. Future edits may improve wording, templates, or automation, but should preserve:

```text
L0-L4 layered testing
L4 live in-loop validation as highest importance
WSL/tmux -> Codex CLI -> DeepSeek bridge where configured -> SCTL/Git/tool registry runtime model
role bootstrap for IC/Coder/Reviewer/BOC
file-based reports and Worker Return Packets
IC overview/coordination role
BOC runtime/evidence role
Reviewer review/report role
Coder implementation/report role
Director communication placeholder for IC/BOC escalation and Q/A
```

Suggested approval states:

```text
approved_for_tester_use
approved_with_edits
revise_before_use
```
