# Strata v0.7 SCTL Testing Standard

Status: durable standard
Scope: package, CLI, SCTL authority, runtime, role loop, and evidence validation

## 1. Testing objective

The tester validates both code correctness and operating behavior.

The acceptance claim is valid only when the tested package shows:

```text
real CLI calls
configured Git-backed A/B/C context repo
stable tool registry
role-scoped authority boundaries
file-based worker return discipline
Class D separation
A/B/C export behavior
backend loop ledger evidence
failure artifacts for failed state-changing commands
```

## 2. Test layer taxonomy

| Layer | Name | Purpose | Evidence type | Acceptance weight |
| --- | --- | --- | --- | --- |
| L0 | Static/package checks | Verify install/build/test/secret-scan baseline. | command logs | required baseline |
| L1 | Unit/regression tests | Verify coded rules and module regressions. | `npm test` logs and test files | required baseline |
| L2 | CLI contract tests | Verify real `strata ...` command contracts, JSON envelopes, registry, and failure artifacts. | command logs, tool-run `result.json` | high |
| L3 | SCTL authority integration tests | Verify Git-backed proposal/review/merge/export/Class D behavior across components. | context repo state, diffs, result envelopes, export artifacts | very high |
| L4 | Live in-loop validation | Verify WSL/tmux/Codex role fleet, return files, routing, and loop ledger. | backend loop ledger, return packet, report ledger, evidence tree | highest |

## 3. L0 static/package checks

Run from the package root:

```bash
node -v
npm -v
git --version
npm ci
npm run build
npm test
npm run secret-scan
```

Record each command under:

```text
.strata/evidence/live_runs/<run_id>/commands/L0/
```

## 4. L1 unit/regression tests

Use built-in tests as coded-regression evidence. Treat `tests/sctl_context.test.ts` as a map of important rules, not as acceptance by itself.

Record:

```text
which test files ran
pass/fail output
known skipped areas
whether the tests exercise real filesystem and Git operations or isolated temporary fixtures
```

## 5. L2 CLI contract tests

Exercise the public command surface:

```text
strata context repo-status
strata tools list
strata tools inspect
strata tools run
strata classd ...
strata returns scan
strata evidence inspect
```

Expected properties:

```text
commands parse predictably
outputs are machine-readable where contract requires JSON
registered tool ids are stable
failed state-changing commands write tool-run artifacts
obsolete shortcut commands return explicit retired/blocked result
```

## 6. L3 SCTL authority integration tests

Exercise real SCTL authority paths:

```text
context propose
context validate
context diff
context review-request
context approve
context reject
context request-revision
context merge
context revert
context export-markdown
context export-pdf
```

Acceptance behaviors:

```text
worker proposal is allowed in proposal branch
worker self-approval is blocked
worker merge is blocked
reviewer/IC final merge is blocked
Human Director final merge succeeds
invalid schema/path proposals fail validation
approval does not merge
exports do not mutate authoritative A/B/C stores
Class D artifacts stay outside A/B/C authority
```

## 7. L4 live in-loop validation

L4 shows the actual operating pattern. It uses the real runtime path where available:

```text
WSL/tmux
Codex CLI sessions
DeepSeek bridge where configured
SCTL CLI
local Git context repo
tool registry
file-based Worker Return Packets
return scan/watch/classifier
Backend Loop Ledger
```

Primary `REPORT_READY` smoke chain:

```text
WORK_PASSED
-> RETURN_FILE_DETECTED
-> RETURN_PACKET_CLASSIFIED
-> REPORT_LEDGERED
-> ROUTED_TO_REVIEWER
```

The same assignment id, worker id, and nonce must carry the chain.

## 8. Evidence standard

Each run creates:

```text
.strata/evidence/live_runs/<run_id>/
  manifest.json
  backend_loop_ledger.jsonl
  backend_loop_ledger.md
  commands/
  runtime/
  role_bootstrap/
  tool_runs/
  context_repo/
  returns/
  reports/
  exports/
  classd/
  gaps/
```

The JSONL ledger is the first review surface. Raw logs support the ledger.

## 9. Result language

Use operational status words:

```text
observed
recorded
validated
routed
accepted
rejected
blocked
needs_revision
gap_recorded
```

Avoid vague outcome words in reports. A line such as `command worked` should be replaced by a controlled event, artifact path, and result status.

## 10. Industrial practice basis

This standard follows the practical test pyramid pattern: many lower-level tests, fewer high-value integration and end-to-end tests. For live operation, it uses SRE-style role clarity, coordination, control, and observable evidence. Monitoring practice distinguishes externally visible behavior from internal instrumentation; this package requires both live behavior and internal evidence artifacts.
