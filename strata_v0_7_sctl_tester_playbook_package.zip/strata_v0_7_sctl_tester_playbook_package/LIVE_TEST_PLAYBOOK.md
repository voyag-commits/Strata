# Live Test Playbook

Status: tester execution playbook
Priority: L4 live in-loop validation is highest importance

## 1. Run setup

Choose a single run id, assignment id, and nonce.

Example:

```bash
export RUN_ID="LIVE-2026-06-09-001"
export ASSIGNMENT_ID="A017"
export CODER_ID="coder_017"
export REVIEWER_ID="reviewer_017"
export IC_ID="ic_017"
export BOC_ID="boc_017"
export NONCE=""  # populated from the dispatch packet before the Worker Return Packet is written
export EVIDENCE_ROOT=".strata/evidence/live_runs/$RUN_ID"
mkdir -p "$EVIDENCE_ROOT"/{commands,runtime,role_bootstrap,tool_runs,context_repo,returns,reports,exports,classd,gaps}
```

Create the run manifest from:

```text
templates/live_run_manifest.template.json
```

## 2. L0: static/package checks

Run:

```bash
node -v | tee "$EVIDENCE_ROOT/commands/L0_node_version.log"
npm -v | tee "$EVIDENCE_ROOT/commands/L0_npm_version.log"
git --version | tee "$EVIDENCE_ROOT/commands/L0_git_version.log"
npm ci > "$EVIDENCE_ROOT/commands/L0_npm_ci.log" 2>&1
npm run build > "$EVIDENCE_ROOT/commands/L0_npm_run_build.log" 2>&1
npm test > "$EVIDENCE_ROOT/commands/L1_npm_test.log" 2>&1
npm run secret-scan > "$EVIDENCE_ROOT/commands/L0_secret_scan.log" 2>&1
```

Record L0/L1 outcomes in the test report.

## 3. L2: CLI contract smoke

Run:

```bash
npm --silent run strata -- help > "$EVIDENCE_ROOT/commands/L2_help.log" 2>&1
npm --silent run strata -- context repo-status > "$EVIDENCE_ROOT/commands/L2_context_repo_status.json" 2>&1
npm --silent run strata -- tools list > "$EVIDENCE_ROOT/commands/L2_tools_list.json" 2>&1
npm --silent run strata -- tools inspect --tool context.export_markdown.v1 > "$EVIDENCE_ROOT/commands/L2_tool_context_export_markdown.json" 2>&1
npm --silent run strata -- tools inspect --tool context.export_pdf.v1 > "$EVIDENCE_ROOT/commands/L2_tool_context_export_pdf.json" 2>&1
npm --silent run strata -- tools inspect --tool classd.export_pdf.v1 > "$EVIDENCE_ROOT/commands/L2_tool_classd_export_pdf.json" 2>&1
npm --silent run strata -- tools inspect --tool returns.scan.v1 > "$EVIDENCE_ROOT/commands/L2_tool_returns_scan.json" 2>&1
```

Expected:

```text
context repo path is resolved
tool registry is available
required tool ids inspect successfully
JSON result envelopes include ok/tool_id/tool_run_id/result_path/evidence_paths/errors where applicable
```

## 4. L3: SCTL authority integration

### 4.1 Bootstrap context repo

```bash
npm --silent run strata -- context repo-status > "$EVIDENCE_ROOT/context_repo/repo_status_before.json" 2>&1
```

### 4.2 Create Class A proposal

```bash
npm --silent run strata -- context propose \
  --proposal P-LIVE-A-001 \
  --caller-id "$CODER_ID" \
  --caller-role worker \
  --class A \
  --id A-LIVE-001 \
  --title "Live Test Class A" \
  --body "Base context for live tester run $RUN_ID." \
  --origin-worker-id "$CODER_ID" \
  --origin-dispatch-channel "file:$EVIDENCE_ROOT/role_bootstrap/coder_dispatch.md" \
  > "$EVIDENCE_ROOT/context_repo/propose_A.json" 2>&1

npm --silent run strata -- context validate --proposal P-LIVE-A-001 > "$EVIDENCE_ROOT/context_repo/validate_A.json" 2>&1
npm --silent run strata -- context diff --proposal P-LIVE-A-001 > "$EVIDENCE_ROOT/context_repo/diff_A.patch" 2>&1
```

### 4.3 Create Class C file pin proposal

```bash
printf 'pinned file source for %s\n' "$RUN_ID" > "$EVIDENCE_ROOT/context_repo/pinned_source.txt"
PIN_SHA=$(sha256sum "$EVIDENCE_ROOT/context_repo/pinned_source.txt" | awk '{print $1}')

npm --silent run strata -- context propose \
  --proposal P-LIVE-C-001 \
  --caller-id "$CODER_ID" \
  --caller-role worker \
  --class C \
  --id C-LIVE-001 \
  --pinned-path "$EVIDENCE_ROOT/context_repo/pinned_source.txt" \
  --checksum-sha256 "$PIN_SHA" \
  --origin-worker-id "$CODER_ID" \
  --origin-dispatch-channel "file:$EVIDENCE_ROOT/role_bootstrap/coder_dispatch.md" \
  > "$EVIDENCE_ROOT/context_repo/propose_C.json" 2>&1

npm --silent run strata -- context validate --proposal P-LIVE-C-001 > "$EVIDENCE_ROOT/context_repo/validate_C.json" 2>&1
npm --silent run strata -- context diff --proposal P-LIVE-C-001 > "$EVIDENCE_ROOT/context_repo/diff_C.patch" 2>&1
```

### 4.4 Create Class B proposal

```bash
npm --silent run strata -- context propose \
  --proposal P-LIVE-B-001 \
  --caller-id "$CODER_ID" \
  --caller-role worker \
  --class B \
  --id B-LIVE-001 \
  --title "Live Test Operational Finding" \
  --body "Accepted operational context should appear after Class A and Class C in exports." \
  --origin-worker-id "$CODER_ID" \
  --origin-dispatch-channel "file:$EVIDENCE_ROOT/role_bootstrap/coder_dispatch.md" \
  > "$EVIDENCE_ROOT/context_repo/propose_B.json" 2>&1

npm --silent run strata -- context validate --proposal P-LIVE-B-001 > "$EVIDENCE_ROOT/context_repo/validate_B.json" 2>&1
npm --silent run strata -- context diff --proposal P-LIVE-B-001 > "$EVIDENCE_ROOT/context_repo/diff_B.patch" 2>&1
```

### 4.5 Blocked authority cases

Run these as expected-blocked commands:

```bash
npm --silent run strata -- context approve --proposal P-LIVE-B-001 --reviewer-id "$CODER_ID" --reviewer-role worker > "$EVIDENCE_ROOT/context_repo/blocked_worker_self_approve.json" 2>&1 || true
npm --silent run strata -- context merge --proposal P-LIVE-B-001 --caller-id "$CODER_ID" --caller-role worker > "$EVIDENCE_ROOT/context_repo/blocked_worker_merge.json" 2>&1 || true
npm --silent run strata -- context merge --proposal P-LIVE-B-001 --caller-id "$REVIEWER_ID" --caller-role reviewer > "$EVIDENCE_ROOT/context_repo/blocked_reviewer_merge.json" 2>&1 || true
npm --silent run strata -- context merge --proposal P-LIVE-B-001 --caller-id "$IC_ID" --caller-role ic > "$EVIDENCE_ROOT/context_repo/blocked_ic_merge.json" 2>&1 || true
```

Expected:

```text
self-approval blocked
worker merge blocked
reviewer merge blocked
IC merge blocked
failure artifacts exist for failed state-changing paths where implemented
```

### 4.6 Reviewer approval and Human Director merge

```bash
for P in P-LIVE-A-001 P-LIVE-C-001 P-LIVE-B-001; do
  npm --silent run strata -- context approve --proposal "$P" --reviewer-id "$REVIEWER_ID" --reviewer-role reviewer > "$EVIDENCE_ROOT/context_repo/approve_${P}.json" 2>&1
  npm --silent run strata -- context merge --proposal "$P" --caller-id hd_001 --caller-role human_director > "$EVIDENCE_ROOT/context_repo/merge_${P}.json" 2>&1
done

npm --silent run strata -- context list > "$EVIDENCE_ROOT/context_repo/authoritative_list_after_merge.json" 2>&1
npm --silent run strata -- context repo-status > "$EVIDENCE_ROOT/context_repo/repo_status_after_merge.json" 2>&1
```

Expected:

```text
approval records review state without merging
Human Director merge writes authoritative A/B/C context
Class B timing index contains accepted Class B entry
```

### 4.7 Reject and request-revision fixed dispatch checks

Create two additional proposals with `origin-dispatch-channel`, then reject/request revision with reason files.

```bash
cat > "$EVIDENCE_ROOT/context_repo/reviewer_reason_needs_revision.md" <<EOF
Reviewer note: live test revision request.
EOF
cat > "$EVIDENCE_ROOT/context_repo/reviewer_reason_rejected.md" <<EOF
Reviewer note: live test rejection.
EOF

npm --silent run strata -- context propose --proposal P-LIVE-REVISION-001 --caller-id "$CODER_ID" --caller-role worker --class B --id B-LIVE-REVISION-001 --title "Needs Revision Candidate" --body "Candidate for fixed revision dispatch." --origin-dispatch-channel "file:$EVIDENCE_ROOT/returns/revision_dispatch_message.md" > "$EVIDENCE_ROOT/context_repo/propose_revision_candidate.json" 2>&1
npm --silent run strata -- context request-revision --proposal P-LIVE-REVISION-001 --reviewer-id "$REVIEWER_ID" --reviewer-role reviewer --reason-file "$EVIDENCE_ROOT/context_repo/reviewer_reason_needs_revision.md" > "$EVIDENCE_ROOT/context_repo/request_revision_result.json" 2>&1

npm --silent run strata -- context propose --proposal P-LIVE-REJECT-001 --caller-id "$CODER_ID" --caller-role worker --class B --id B-LIVE-REJECT-001 --title "Rejected Candidate" --body "Candidate for fixed rejection dispatch." --origin-dispatch-channel "file:$EVIDENCE_ROOT/returns/rejected_dispatch_message.md" > "$EVIDENCE_ROOT/context_repo/propose_reject_candidate.json" 2>&1
npm --silent run strata -- context reject --proposal P-LIVE-REJECT-001 --reviewer-id "$REVIEWER_ID" --reviewer-role reviewer --reason-file "$EVIDENCE_ROOT/context_repo/reviewer_reason_rejected.md" > "$EVIDENCE_ROOT/context_repo/reject_result.json" 2>&1
```

Expected:

```text
needs_revision writes fixed message to original dispatch channel when known
rejected writes fixed message to original dispatch channel when known
if dispatch channel is unknown, result warns and dispatch-needed artifact is written
```

## 5. L3: export and Class D separation

### 5.1 Export A/B/C Markdown and PDF

```bash
npm --silent run strata -- context export-markdown --scope all --out "$EVIDENCE_ROOT/exports/context_md" > "$EVIDENCE_ROOT/exports/export_markdown_result.json" 2>&1
npm --silent run strata -- context export-pdf --scope all --out "$EVIDENCE_ROOT/exports/context_pdf" > "$EVIDENCE_ROOT/exports/export_pdf_result.json" 2>&1
```

Inspect:

```text
$EVIDENCE_ROOT/exports/context_md/context.md
$EVIDENCE_ROOT/exports/context_md/manifest.json
$EVIDENCE_ROOT/exports/context_md/source_index.json
$EVIDENCE_ROOT/exports/context_md/checksums.sha256
$EVIDENCE_ROOT/exports/context_pdf/context.pdf
```

Expected order in Markdown:

```text
1. Class A context
2. Class C context for file pins
3. Class B context with timing index
```

Record a context repo status before and after export. Exports are view artifacts and should not mutate authoritative A/B/C context.

### 5.2 Class D transcript tools

Use a real Codex session file if available. Use a synthetic minimal file only for fallback tool-contract validation.

```bash
printf '{"role":"user","content":"class d live fallback source"}\n' > "$EVIDENCE_ROOT/classd/codex-session-fallback.jsonl"

npm --silent run strata -- classd register-session --source "$EVIDENCE_ROOT/classd/codex-session-fallback.jsonl" --session-id "classd-$RUN_ID" > "$EVIDENCE_ROOT/classd/register_session.json" 2>&1
npm --silent run strata -- classd export-markdown --session-id "classd-$RUN_ID" > "$EVIDENCE_ROOT/classd/export_markdown.json" 2>&1
npm --silent run strata -- classd export-pdf --session-id "classd-$RUN_ID" > "$EVIDENCE_ROOT/classd/export_pdf.json" 2>&1
npm --silent run strata -- classd verify-checksums --session-id "classd-$RUN_ID" > "$EVIDENCE_ROOT/classd/verify_checksums.json" 2>&1
npm --silent run strata -- classd inspect --session-id "classd-$RUN_ID" > "$EVIDENCE_ROOT/classd/inspect.json" 2>&1
```

Expected:

```text
raw transcript source copied/preserved
Markdown/PDF are view artifacts
Class D material does not appear in authoritative Class B
```

## 6. L4: live role-session fleet and worker return loop

### 6.1 Bootstrap sessions

Create or observe sessions:

```bash
npm --silent run strata -- sessions create --session STRATA-IC-$ASSIGNMENT_ID --assignment-id "$ASSIGNMENT_ID" --agent-id "$IC_ID" --role ic --cwd "$PWD" --command "codex" --replace || true
npm --silent run strata -- sessions create --session STRATA-CODER-$ASSIGNMENT_ID --assignment-id "$ASSIGNMENT_ID" --agent-id "$CODER_ID" --role coder --cwd "$PWD" --command "codex" --replace || true
npm --silent run strata -- sessions create --session STRATA-REVIEWER-$ASSIGNMENT_ID --assignment-id "$ASSIGNMENT_ID" --agent-id "$REVIEWER_ID" --role reviewer --cwd "$PWD" --command "codex" --replace || true
npm --silent run strata -- sessions create --session STRATA-BOC-$ASSIGNMENT_ID --assignment-id "$ASSIGNMENT_ID" --agent-id "$BOC_ID" --role boc --cwd "$PWD" --command "codex" --replace || true
npm --silent run strata -- sessions list > "$EVIDENCE_ROOT/runtime/sessions_list.txt" 2>&1
```

If manual session opening is used, record it in:

```text
$EVIDENCE_ROOT/runtime/manual_session_creation.md
```

Paste the role bootstrap messages from `templates/role_assignment/` into the appropriate sessions. Save copied messages under:

```text
$EVIDENCE_ROOT/role_bootstrap/
```

### 6.2 Create dispatch packet

```bash
npm --silent run strata -- packet work-dispatch \
  --assignment-id "$ASSIGNMENT_ID" \
  --agent-id "$CODER_ID" \
  --role coder \
  --kind task \
  --action "Create a brief live smoke report and Worker Return Packet for $RUN_ID." \
  --body "Use the report template. Main paragraph: what you did; what completed on your side; findings or blockers; options forward. Use the dispatch packet nonce in the return packet. The BOC will extract it from the packet result and restate it in-session." \
  --from-role IC \
  > "$EVIDENCE_ROOT/runtime/work_dispatch_packet_result.json" 2>&1
```

Extract the emitted packet path and nonce, then copy both into the Coder session. Use that nonce for the Worker Return Packet.

```bash
PACKET_PATH=$(node -e "const fs=require('fs'); const j=JSON.parse(fs.readFileSync(process.argv[1],'utf8')); console.log(j.packet_path || j.payload?.packet_path || '');" "$EVIDENCE_ROOT/runtime/work_dispatch_packet_result.json")
NONCE=$(node -e "const fs=require('fs'); const j=JSON.parse(fs.readFileSync(process.argv[1],'utf8')); console.log(j.nonce || j.payload?.nonce || '');" "$EVIDENCE_ROOT/runtime/work_dispatch_packet_result.json")
printf 'Dispatch packet: %s\nNonce: %s\n' "$PACKET_PATH" "$NONCE" | tee "$EVIDENCE_ROOT/runtime/dispatch_packet_and_nonce.txt"
```

If using tmux send:

```bash
npm --silent run strata -- dispatch send --session STRATA-CODER-$ASSIGNMENT_ID --packet "$PACKET_PATH" --from-role IC > "$EVIDENCE_ROOT/runtime/dispatch_send_result.json" 2>&1 || true
```

Record `WORK_PASSED` in the Backend Loop Ledger when dispatch reaches the session and is submitted/verified. If tmux send cannot prove visual receipt, record a precise blocked or partial state.

### 6.3 Worker report and return packet

The Coder writes a brief report file. Suggested path:

```text
$EVIDENCE_ROOT/reports/coder_live_smoke_report.md
```

Create a return packet template:

```bash
npm --silent run strata -- packet return-template \
  --assignment-id "$ASSIGNMENT_ID" \
  --agent-id "$CODER_ID" \
  --role coder \
  --kind REPORT_READY \
  --nonce "$NONCE" \
  --report-path "$EVIDENCE_ROOT/reports/coder_live_smoke_report.md" \
  --evidence-path "$EVIDENCE_ROOT/reports" \
  > "$EVIDENCE_ROOT/returns/return_template_result.json" 2>&1
```

If the live Coder writes the packet directly, compare it against:

```text
templates/packets/worker_return_packet.report_ready.template.json
```

### 6.4 Scan/classify return

```bash
npm --silent run strata -- returns scan --assignment-id "$ASSIGNMENT_ID" --agent-id "$CODER_ID" > "$EVIDENCE_ROOT/returns/returns_scan_result.json" 2>&1
npm --silent run strata -- report list > "$EVIDENCE_ROOT/reports/report_list_after_scan.json" 2>&1
npm --silent run strata -- evidence inspect --tail 50 > "$EVIDENCE_ROOT/backend_loop_ledger_tail.json" 2>&1
```

Required L4 primary chain:

```text
WORK_PASSED
RETURN_FILE_DETECTED
RETURN_PACKET_CLASSIFIED
REPORT_LEDGERED
ROUTED_TO_REVIEWER
```

If current CLI emits `RETURN_PACKET_CLASSIFIED` and ledgered report artifacts but does not automatically emit `REPORT_LEDGERED` or `ROUTED_TO_REVIEWER`, record the gap precisely in:

```text
$EVIDENCE_ROOT/gaps/L4_ledger_event_gap.md
```

Then continue with manual evidence mapping in the acceptance matrix. This distinguishes product behavior from playbook expectation.

## 7. Director communication placeholder check

If the tool is implemented, test:

```bash
npm --silent run strata -- tools inspect --tool director.communication.v1 > "$EVIDENCE_ROOT/commands/L2_tool_director_communication.json" 2>&1 || true
```

If absent, record:

```text
$EVIDENCE_ROOT/gaps/director_communication_placeholder_absent.md
```

If present, verify:

```text
IC and BOC can create communication request artifacts
Coder role is rejected or routed through IC
no A/B/C context mutation occurs
result envelope is deterministic
```

## 8. Package completion rule

A live test package is ready for review only when it contains:

```text
manifest.json
backend_loop_ledger.jsonl
backend_loop_ledger.md
commands/
runtime/
role_bootstrap/
returns/
reports/
exports/
classd/
context_repo/
gaps/ if any
completed TEST_REPORT_TEMPLATE.md
completed ACCEPTANCE_MATRIX.md
```

A partial run is acceptable only when the report states the exact blocked state and evidence path.
