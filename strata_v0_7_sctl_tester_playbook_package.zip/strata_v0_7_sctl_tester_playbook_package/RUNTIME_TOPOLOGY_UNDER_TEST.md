# Runtime Topology Under Test

Status: required tester inventory

## 1. Runtime overview

The live system under test is:

```text
Director
  -> BOC runtime operation
  -> WSL/Linux shell
  -> tmux sessions
  -> Codex CLI sessions
  -> DeepSeek bridge where configured
  -> SCTL CLI
  -> local Git-backed A/B/C context repo
  -> SCTL tool registry
  -> Class D transcript tools
  -> Worker Return Packet folders
  -> Backend Loop Ledger and evidence tree
```

The SCTL authority path must work without relying on model semantics. Codex CLI and DeepSeek bridge tests validate the live worker endpoint behavior.

## 2. Required topology inventory

Create:

```text
.strata/evidence/live_runs/<run_id>/runtime/topology_inventory.md
.strata/evidence/live_runs/<run_id>/runtime/topology_inventory.json
```

Record:

| Field | Example | Required |
| --- | --- | --- |
| run_id | `LIVE-2026-06-09-001` | yes |
| package_root | `/path/to/strata_v0_7_sctl` | yes |
| implementation_repo | `/path/to/codebase` | yes |
| context_repo_path | `.strata/context_repo` or configured path | yes |
| WSL/Linux environment | distro/kernel | yes |
| Node version | `v22.x` | yes |
| npm version | `10.x` | yes |
| Git version | `2.x` | yes |
| tmux version | `3.x` | required for runtime sessions |
| Codex CLI path | output of `command -v codex` | required for Codex live session |
| DeepSeek bridge status | configured/not_configured | if applicable |
| SCTL CLI command | `npm --silent run strata -- ...` | yes |
| tool registry path | from `strata tools list` | yes |
| evidence root | `.strata/evidence/live_runs/<run_id>` | yes |

## 3. Suggested inventory commands

```bash
pwd
uname -a
node -v
npm -v
git --version
tmux -V || true
command -v codex || true
npm --silent run strata -- context repo-status
npm --silent run strata -- tools list
npm --silent run strata -- bridge gate --format json || true
```

For bridge checks, record redacted configuration only. API keys and secret values stay outside evidence.

## 4. Runtime separation rules

Use these distinctions when recording evidence:

```text
implementation repo: code changes and build/test work
context repo: authoritative/proposed A/B/C context through SCTL
Class D: raw local transcript evidence and transcript view artifacts
return folders: Worker Return Packet intake
exports: view artifacts for review
```

## 5. Topology acceptance states

| State | Meaning |
| --- | --- |
| `TOPOLOGY_RECORDED` | required runtime inventory was recorded |
| `CODEX_RUNTIME_AVAILABLE` | Codex CLI path/session availability observed |
| `CODEX_RUNTIME_BLOCKED` | Codex path/session blocked with reason |
| `BRIDGE_CONFIGURED` | DeepSeek bridge configuration observed without secret exposure |
| `BRIDGE_NOT_CONFIGURED` | bridge absent and not required for SCTL authority |
| `CONTEXT_REPO_CONFIGURED` | `context repo-status` returns resolved repo path |
| `TOOL_REGISTRY_AVAILABLE` | `tools list` returns index and expected tool ids |
