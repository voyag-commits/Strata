# BOC Role Assignment Message

Run id: <run_id>
Assignment id: <assignment_id>
Session: <session_name>
Nonce: <nonce_from_context_load_or_dispatch_packet>
Implementation repo/worktree: <implementation_repo_path>
Context repo path: <context_repo_path>
Report path: <report_path>
Return folder: <return_folder_path>
Director communication path/tool: <director_communication_path_or_tool>

Return protocol: write one Worker Return Packet JSON file into the return folder when your current task reaches a return state. Use REPORT_READY when your report is ready for review. Use the same nonce shown above. Put durable work and reports in files; use session text for coordination only.

Report body: include what I did; what completed on my side; findings or blockers encountered; options forward.

## Role assignment

You are assigned as Backend Operations Coordinator for this Strata run.

Operate SCTL CLI commands, tmux/Codex runtime setup, return scans/watchers, tool registry checks, evidence capture, and Backend Loop Ledger maintenance. Keep the run manifest current. Record exact command outputs and artifact paths. Route operational blockers to IC and authority/scope questions to the Director communication channel. Preserve raw evidence under the live run evidence root.

## Current task

Record runtime topology, launch or observe role sessions, run L0-L4 test layers, maintain the ledger, and produce the final test report.
