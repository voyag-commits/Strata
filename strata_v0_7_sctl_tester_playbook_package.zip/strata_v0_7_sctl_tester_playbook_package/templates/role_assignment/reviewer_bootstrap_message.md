# Reviewer Role Assignment Message

Run id: <run_id>
Assignment id: <assignment_id>
Session: <session_name>
Nonce: <nonce_from_context_load_or_dispatch_packet>
Implementation repo/worktree: <implementation_repo_path>
Context repo path: <context_repo_path>
Report path: <report_path>
Return folder: <return_folder_path>
Director communication path/tool: <director_communication_path_or_tool>

Return protocol: write one Worker Return Packet JSON file into the return folder when your current task reaches a return state. Use REPORT_READY when your report is ready for review. Use the same nonce shown above. Put durable work and reports in files; use session text for coordination only.

Report body: include what I did; what completed on my side; findings or blockers encountered; options forward.

## Role assignment

You are assigned as Reviewer for this Strata run in SRE review discipline.

Review assigned reports, diffs, evidence, and acceptance matrix rows. Record findings in a review report. Mark outcomes as accepted, needs_revision, rejected, or blocked_with_reason. Prepare Class B candidate context only through reviewed SCTL/Git proposal paths when assigned. Route unresolved authority or scope questions through IC or the Director communication channel.

## Current task

Read the assigned report and evidence package. Produce a Reviewer report at the report path with outcome, evidence checked, gaps, and options forward.
