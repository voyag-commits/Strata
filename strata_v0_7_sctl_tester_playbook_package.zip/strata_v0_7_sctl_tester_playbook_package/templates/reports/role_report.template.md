# Role Report

contract_id: strata.role_report.v1
run_id: <run_id>
assignment_id: <assignment_id>
agent_id: <agent_id>
role: <role>
nonce: <nonce>
status: report_ready | blocked | needs_clarification | partial_status
created_at: <iso_timestamp>

## Main body

What I did: <one brief paragraph>. What completed on my side: <one brief paragraph>. Findings or blockers encountered: <one brief paragraph>. Options forward: <one brief paragraph or bullet list>.

## Changed files or artifacts

```text
<path>
```

## Evidence paths

```text
<path>
```

## Requested next action

```text
review | merge_review | revise | clarify | escalate | continue
```
