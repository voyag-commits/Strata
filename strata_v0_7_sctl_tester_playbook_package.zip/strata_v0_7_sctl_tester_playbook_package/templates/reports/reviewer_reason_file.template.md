# Reviewer Reason File

contract_id: strata.reviewer_reason.v1
proposal_id: <proposal_id>
reviewer_id: <reviewer_id>
review_outcome: needs_revision | rejected
created_at: <iso_timestamp>

## Reviewer note

<brief reason and required correction or stop condition>

## Affected files

```text
<path>
```
