# Director Communication Request

contract_id: strata.director_communication_request.v1
request_id: <request_id>
run_id: <run_id>
assignment_id: <assignment_id>
caller_id: <caller_id>
caller_role: ic | boc
urgency: normal | high
created_at: <iso_timestamp>

## Subject

<short subject>

## Request

<state the decision, clarification, escalation, or Q/A needed>

## Current state

<state current run/milestone/blocked condition>

## Options forward

1. <option>
2. <option>
3. <option>

## Related artifacts

```text
<path>
```
