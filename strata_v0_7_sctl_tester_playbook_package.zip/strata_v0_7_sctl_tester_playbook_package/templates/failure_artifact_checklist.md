# Failure Artifact Checklist

For each failed state-changing command, verify:

```text
.strata/backend/tool_runs/<tool_run_id>/result.json exists
result.json contains ok=false or explicit error state
stderr/stdout/diagnostics artifacts exist when applicable
command log is stored under live run evidence
failure is referenced in the test report
```

Record:

| Command | Expected failure? | tool_run_id | result_path | stderr/stdout path | Notes |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |
