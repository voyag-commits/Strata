# Backend Loop Ledger Mirror Example

2026-06-09T12:00:00Z loop=0001 event=DUTY_REGISTERED assignment=A017 actor=BOC worker=coder_017 role=coder session=STRATA-CODER-A017 status=on_duty evidence=.strata/evidence/live_runs/LIVE-001/runtime/
2026-06-09T12:05:00Z loop=0002 event=WORK_PASSED assignment=A017 from=IC to=coder_017 session=STRATA-CODER-A017 nonce=STRATA_NONCE_A017_LIVE_001 status=SUBMITTED_AND_VERIFIED evidence=.strata/evidence/live_runs/LIVE-001/runtime/dispatch_send_result.json
2026-06-09T12:10:00Z loop=0003 event=RETURN_FILE_DETECTED assignment=A017 worker=coder_017 artifact=.strata/returns/A017/coder_017/RETURN_001.report_ready.json status=detected evidence=.strata/evidence/live_runs/LIVE-001/returns/
2026-06-09T12:10:01Z loop=0004 event=RETURN_PACKET_CLASSIFIED assignment=A017 worker=coder_017 return_kind=REPORT_READY status=valid route=agent_report_ledger evidence=.strata/evidence/live_runs/LIVE-001/returns/
2026-06-09T12:10:02Z loop=0005 event=REPORT_LEDGERED assignment=A017 worker=coder_017 report=.strata/ledgers/agent_reports/REPORT_001.json status=pending_review evidence=.strata/evidence/live_runs/LIVE-001/reports/
2026-06-09T12:10:03Z loop=0006 event=ROUTED_TO_REVIEWER assignment=A017 worker=coder_017 to=reviewer status=pending_review evidence=.strata/evidence/live_runs/LIVE-001/reports/
