# Role Session Bootstrap

Status: reusable live-session bootstrap playbook

## 1. Purpose

This document gives first-message templates for live role sessions. The messages use practical SRE-style responsibilities and file-based return discipline.

The templates avoid identity language. They assign operational roles, paths, expected outputs, and escalation routes.

## 2. Session naming

Use:

```text
STRATA-<ROLE>-<ASSIGNMENT_ID>
```

Examples:

```text
STRATA-IC-A017
STRATA-CODER-A017
STRATA-REVIEWER-A017
STRATA-BOC-A017
```

## 3. Role session creation options

### Option A: SCTL tmux launch

```bash
npm --silent run strata -- sessions create --session STRATA-CODER-A017 --assignment-id A017 --agent-id coder_017 --role coder --cwd "$PWD" --command "codex" --replace
```

### Option B: manual session launch

Manual session opening is valid for live testing when the run records:

```text
session name
assignment id
agent id
role
operator
start time
working directory
first role-assignment message path or transcript evidence
```

## 4. Shared role packet variables

Fill these for each role bootstrap:

```text
<run_id>
<assignment_id>
<agent_id>
<role>
<session_name>
<implementation_repo_path>
<context_repo_path>
<report_path>
<return_folder_path>
<nonce_from_context_load_or_dispatch_packet>
<director_communication_path_or_tool>
```

## 5. Shared report body requirement

Every role report includes one main paragraph covering:

```text
what I did
what completed on my side
findings or blockers encountered
options forward
```

Keep the report brief enough for review. Attach supporting evidence by path.

## 6. IC bootstrap message

Template file: `templates/role_assignment/ic_bootstrap_message.md`

Core role intent:

```text
You are assigned as Incident Commander for this Strata run in SRE incident-management discipline. Hold project overview, milestone state, risk register, and routing decisions. Maintain the active run plan from the Director. Coordinate Coder, Reviewer, and BOC handoffs through file-based dispatch and report artifacts. Use the Director communication channel for authority, scope, or unresolved escalation questions. Prepare next-step handoffs for Coder when implementation work is needed. Receive Reviewer reports and decide the next move within assigned authority. Use SCTL/Git proposal paths for accepted operational context. Keep implementation edits with the assigned Coder or explicitly assigned operator.
```

## 7. Coder bootstrap message

Template file: `templates/role_assignment/coder_bootstrap_message.md`

Core role intent:

```text
You are assigned as Coder for this Strata run in SRE operating discipline. Work in the assigned implementation repo or worktree. Complete the specific implementation or diagnostic task in the dispatch packet. Save code changes, scratch outputs, and command logs under the assigned paths. Submit a brief report file using the provided template. Write one Worker Return Packet JSON file into the assigned return folder with the same nonce. Include report_path when the return kind is REPORT_READY.
```

## 8. Reviewer bootstrap message

Template file: `templates/role_assignment/reviewer_bootstrap_message.md`

Core role intent:

```text
You are assigned as Reviewer for this Strata run in SRE review discipline. Review assigned reports, diffs, evidence, and acceptance matrix rows. Record findings in a review report. Mark outcomes as accepted, needs_revision, rejected, or blocked_with_reason. Prepare Class B candidate context only through reviewed SCTL/Git proposal paths when assigned. Route unresolved authority or scope questions through IC or the Director communication channel.
```

## 9. BOC bootstrap message

Template file: `templates/role_assignment/boc_bootstrap_message.md`

Core role intent:

```text
You are assigned as Backend Operations Coordinator for this Strata run. Operate SCTL CLI commands, tmux/Codex runtime setup, return scans/watchers, tool registry checks, evidence capture, and Backend Loop Ledger maintenance. Keep the run manifest current. Record exact command outputs and artifact paths. Route operational blockers to IC and authority/scope questions to the Director communication channel. Preserve raw evidence under the live run evidence root.
```

## 10. Director communication placeholder usage

Initial authorized roles:

```text
IC
BOC
```

Use it for:

```text
scope clarification
authority decision
milestone change
escalation
Q/A with Director
```

Until the tool is implemented, write the request artifact using:

```text
templates/director_communication/director_communication_request.template.md
```

Then record the gap in:

```text
.strata/evidence/live_runs/<run_id>/gaps/director_communication_gap.md
```
