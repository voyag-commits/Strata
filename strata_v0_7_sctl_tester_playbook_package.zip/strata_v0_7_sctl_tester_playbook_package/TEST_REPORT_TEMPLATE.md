# Strata v0.7 SCTL Test Report

Run id: `<run_id>`
Package under test: `<path_or_zip_name>`
Tester/operator: `<name_or_role>`
Date: `<YYYY-MM-DD>`
Recommendation: `accept | accept_with_gaps | reject | rerun_required`

## 1. Executive result

```text
Overall status:
L0 status:
L1 status:
L2 status:
L3 status:
L4 status:
Highest-risk gap:
Recommendation:
```

## 2. Environment

```text
package_root:
implementation_repo:
context_repo_path:
node_version:
npm_version:
git_version:
tmux_version:
codex_cli_status:
deepseek_bridge_status:
run_id:
assignment_id:
nonce:
evidence_root:
```

## 3. Evidence tree

Paste `find` output or curated tree:

```text
.strata/evidence/live_runs/<run_id>/
```

## 4. Commands run

| Layer | Command | Exit status | Output path | Notes |
| --- | --- | --- | --- | --- |
| L0 | `npm ci` |  |  |  |
| L0 | `npm run build` |  |  |  |
| L1 | `npm test` |  |  |  |
| L2 | `strata tools list` |  |  |  |
| L3 | `strata context propose` |  |  |  |
| L4 | `strata returns scan` |  |  |  |

## 5. L0 static/package evidence

Result:

```text
npm ci:
npm run build:
npm run secret-scan:
```

Evidence paths:

```text

```

## 6. L1 unit/regression evidence

Result:

```text
npm test:
unit/regression scope covered:
unit/regression scope not covered:
```

Evidence paths:

```text

```

## 7. L2 CLI contract evidence

Result:

```text
context repo-status:
tools list:
tools inspect context.export_markdown.v1:
tools inspect context.export_pdf.v1:
tools inspect classd.export_pdf.v1:
returns.scan.v1 inspection:
retired shortcut checks:
```

Evidence paths:

```text

```

## 8. L3 SCTL authority integration evidence

Record:

```text
proposal IDs:
proposal branches:
validation result paths:
diff paths:
blocked worker self-approval evidence:
blocked worker merge evidence:
blocked reviewer merge evidence:
blocked IC merge evidence:
Human Director merge evidence:
export artifacts:
Class D artifacts:
```

## 9. L4 live in-loop validation evidence

Record one nonce chain:

```text
assignment_id:
agent_id:
role:
session_name:
nonce:
```

Ledger chain:

```text
WORK_PASSED: observed | blocked | gap_recorded
RETURN_FILE_DETECTED: observed | blocked | gap_recorded
RETURN_PACKET_CLASSIFIED: observed | blocked | gap_recorded
REPORT_LEDGERED: observed | blocked | gap_recorded
ROUTED_TO_REVIEWER: observed | blocked | gap_recorded
```

Evidence paths:

```text
backend_loop_ledger.jsonl:
backend_loop_ledger.md:
Worker Return Packet:
report file:
return classification:
report ledger:
raw runtime evidence:
```

## 10. Director communication placeholder status

```text
Tool present:
Tool id:
IC authorization observed:
BOC authorization observed:
Coder path behavior:
A/B/C mutation check:
Gap artifact path:
```

## 11. Acceptance matrix summary

Paste or attach completed `ACCEPTANCE_MATRIX.md`.

```text
pass:
fail:
blocked:
gap_recorded:
not_applicable:
```

## 12. Gaps and blocked states

| Gap/blocker | Layer | Evidence path | Impact | Recommended next action |
| --- | --- | --- | --- | --- |
|  |  |  |  |  |

## 13. Suspected architecture drift or legacy bypasses

Record any path where runtime behavior differs from ADR0601/ADR-0602/ADR-0603 or the immutable parsed operating inputs.

```text

```

## 14. Final recommendation

Choose one:

```text
accept
accept_with_gaps
reject
rerun_required
```

Reason:

```text

```
