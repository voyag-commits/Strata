# Acceptance Matrix

Status: required tester artifact

Use this matrix to map architecture decisions to test layers and evidence.

| ID | Requirement | Source | Layer | Action/Command | Expected behavior | Evidence path | Status | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A01 | Built package installs cleanly | package baseline | L0 | `npm ci` | exits 0 | `.strata/evidence/live_runs/<run_id>/commands/L0_npm_ci.log` | pending |  |
| A02 | Build passes | package baseline | L0 | `npm run build` | exits 0 | `commands/L0_npm_run_build.log` | pending |  |
| A03 | Unit/regression tests pass | package baseline | L1 | `npm test` | exits 0 | `commands/L1_npm_test.log` | pending | unit/regression only |
| A04 | Secret scan passes | package baseline | L0 | `npm run secret-scan` | exits 0 | `commands/L0_secret_scan.log` | pending | if present |
| A05 | Context repo path is configured/discoverable | ADR-0603-D19 | L2 | `strata context repo-status` | returns resolved context repo path | `commands/L2_context_repo_status.json` | pending |  |
| A06 | Tool registry is available | ADR-0602-D03, ADR-0603-D12 | L2 | `strata tools list` | expected indexed tools present | `commands/L2_tools_list.json` | pending |  |
| A07 | Context export Markdown tool is registered | ADR-0603-D10 | L2 | `tools inspect context.export_markdown.v1` | tool contract returned | `commands/L2_tool_context_export_markdown.json` | pending |  |
| A08 | Context export PDF tool is registered | ADR-0603-D10 | L2 | `tools inspect context.export_pdf.v1` | tool contract returned | `commands/L2_tool_context_export_pdf.json` | pending |  |
| A09 | Class D PDF export tool is registered | ADR-0602-D11/D12, ADR-0603-D17 | L2 | `tools inspect classd.export_pdf.v1` | tool contract returned | `commands/L2_tool_classd_export_pdf.json` | pending |  |
| A10 | Worker can propose A/B/C change | ADR-0603-D03/D06/D08 | L3 | `context propose` | proposal branch created, authoritative context unchanged | `context_repo/propose_*.json` | pending |  |
| A11 | Validator rejects malformed schema/path | ADR-0603-D05 | L3 | invalid proposal validation | returns `ok=false`, writes validation result | `context_repo/invalid_schema_*.json` | pending |  |
| A12 | Worker self-approval is blocked | ADR-0603-D06 | L3 | `context approve` as same worker | blocked result/error | `context_repo/blocked_worker_self_approve.json` | pending |  |
| A13 | Worker final merge is blocked | ADR-0603-D06/D21 | L3 | `context merge` as worker | blocked result/error | `context_repo/blocked_worker_merge.json` | pending |  |
| A14 | Reviewer final merge is blocked | ADR-0603-D20/D21 | L3 | `context merge` as reviewer | blocked result/error | `context_repo/blocked_reviewer_merge.json` | pending |  |
| A15 | IC final merge is blocked | ADR-0603-D20/D21 | L3 | `context merge` as IC | blocked result/error | `context_repo/blocked_ic_merge.json` | pending |  |
| A16 | Human Director final merge succeeds | ADR-0603-D21 | L3 | `context merge` as `human_director` | authoritative A/B/C updated | `context_repo/merge_*.json` | pending |  |
| A17 | Approval and merge are separate | ADR-0603-D20 | L3 | approve then inspect before merge | approval state only, no authoritative write until merge | `context_repo/approve_*.json` | pending |  |
| A18 | Rejected outcome dispatches fixed message | ADR-0603-D16 | L3 | `context reject` | fixed rejection message to channel or warning artifact | `context_repo/reject_result.json` | pending |  |
| A19 | Needs-revision outcome dispatches fixed message | ADR-0603-D16 | L3 | `context request-revision` | fixed revision message to channel or warning artifact | `context_repo/request_revision_result.json` | pending |  |
| A20 | Markdown export order is A, C, B | ADR-0603-D10/D11 | L3 | `context export-markdown` | sections ordered A -> C -> B | `exports/context_md/context.md` | pending |  |
| A21 | PDF export produced without authoritative mutation | ADR-0603-D09/D10 | L3 | `context export-pdf` and repo diff/status | PDF exists, context repo unchanged by export | `exports/context_pdf/context.pdf` | pending |  |
| A22 | Class D register/export verifies checksums | ADR-0602-D09-D13, ADR-0603-D17 | L3 | classd commands | raw source preserved, checksum passes | `classd/*` | pending |  |
| A23 | Class D cannot auto-promote to Class B | ADR-0602-D14, ADR-0603-D17 | L3 | classd export then context list | no Class B entry appears | `classd/inspect.json`, `context_repo/authoritative_list_after_merge.json` | pending |  |
| A24 | Runtime topology recorded | operating input B | L4 | topology inventory | runtime inventory files exist | `runtime/topology_inventory.*` | pending |  |
| A25 | Role sessions bootstrapped | operating input B/C | L4 | first messages sent/saved | IC/Coder/Reviewer/BOC assignments recorded | `role_bootstrap/*` | pending |  |
| A26 | Dispatch reaches selected session | ADR0601 M1 | L4 | packet dispatch/send/manual verification | `WORK_PASSED` or precise blocked state | `backend_loop_ledger.*` | pending |  |
| A27 | Worker return file detected | ADR0601 M2 | L4 | return packet write + scan/watch | `RETURN_FILE_DETECTED` | `returns/*`, `backend_loop_ledger.*` | pending |  |
| A28 | Return packet classified | ADR0601 M3 | L4 | `returns scan` or classify | `RETURN_PACKET_CLASSIFIED` | `returns/returns_scan_result.json` | pending |  |
| A29 | REPORT_READY ledgers report candidate | ADR0601 M3 | L4 | `report list` | `REPORT_LEDGERED` or artifact/gap recorded | `reports/report_list_after_scan.json` | pending |  |
| A30 | Report routed to reviewer | ADR0601 M3 | L4 | classifier/routing | `ROUTED_TO_REVIEWER` or artifact/gap recorded | `backend_loop_ledger.*` | pending |  |
| A31 | Director communication placeholder status recorded | operating input D | L2/L4 | `tools inspect` or gap artifact | implemented behavior or explicit gap | `gaps/director_communication_*` | pending |  |
| A32 | Retired Mutation Gate/shortcut paths disabled for authority | ADR-0603-D04 | L2/L3 | `context add`, `classb import`, `gate evaluate` | retired/blocked result | `commands/retired_shortcut_*.json` | pending |  |

Allowed status values:

```text
pass
fail
blocked
gap_recorded
not_applicable
pending
```
