# ADR0601 Immutable Live Windows UI Accessibility Milestones

**Document status:** Immutable test-control baseline  
**Project:** Harness/Strata ADR-HS-2026-06-0601 live GUI-worker path  
**Scope:** Windows UI Accessibility layer dispatch, worker file return, backend routing, and state-ledger presentation  
**Operator for current phase:** Backend Operations Coordinator (BOC)  
**Date:** 2026-06-07

## 1. Purpose

This document defines the live test milestones for the ADR0601 Windows UI Accessibility layer.

The objective is to test whether the backend can route work into a selected visible GUI application session, receive a worker return file from the monitored backend folder, and route that return to the correct backend owner: IC, reviewer, ClassD diagnostics, or ClassB admission flow.

This document is intentionally narrow. It does not replace the ADR, the governance kernel, the ClassB admission contract, or raw evidence files. It defines the operational milestone sequence and the required state-ledger presentation for human review.

## 2. Fixed Language

Use the following terms consistently.

| Term | Definition |
| --- | --- |
| Human Director (HD) | Person who creates and names visible GUI sessions and provides window/session information. |
| Backend Operations Coordinator (BOC) | Current tester and backend operator. BOC performs registry setup, dispatch execution, watcher/classifier operation, evidence collection, and issue resolution. |
| Incident Commander (IC) | Assignment coordinator. IC receives worker questions, blockers, clarification needs, and routing items within assignment authority. |
| Reviewer | Role that reviews `REPORT_READY` outputs before ClassB admission. |
| Worker | The assigned GUI app session for a role and assignment. |
| Visible session name | The routing anchor in the GUI app, following `STRATA-{ROLE}-{ASSIGNMENT_ID}`. |
| Desktop UI Injection Adapter | The Windows Accessibility layer used to locate, activate, focus, paste, submit, and verify GUI dispatch. |
| Worker Return Packet | The only backend-recognized worker return file. Chat output is not a deliverable. |
| Backend Loop Ledger | Append-only control-loop record showing backend state transitions and routing decisions. |

## 3. Required Revisions from Prior Milestone Draft

### Revision 1: BOC is the tester for the current phase

For the current live Windows UI Accessibility phase, BOC is the tester and operator.

BOC owns:

- Active Agent Duty Registry write, verify, and correction.
- Desktop UI Injection Adapter execution.
- Context Load Packet or Work Dispatch Packet delivery.
- Watched return folder scan or watcher operation.
- Worker Return Packet classifier execution.
- Coordination Thread, Agent Report Ledger, ClassD, and ClassB routing observation.
- Evidence collection.
- Blocker diagnosis and local resolution where possible.

HD remains responsible for creating and naming visible GUI sessions. IC and reviewer roles remain part of backend routing, but BOC may simulate or operate the test workflow when the purpose is backend integration testing.

### Revision 2: Avoid the word "proof" in milestone status language

Milestone language must use operational terms:

- `test`
- `validate`
- `observe`
- `record`
- `route`
- `resolve`
- `acceptance state`
- `blocked state`
- `evidence`

Do not use success phrases such as:

- `works`
- `sent`
- `done`
- `passed everything`
- `live proof`
- `Reasonix works`

A milestone is complete only when the required backend state, worker/session target, artifact path, status code, and evidence path are recorded.

## 4. Live Milestones

The current live test has three mandatory milestones. They are ordered and should not be collapsed.

---

## M1_BOC_DISPATCH_TO_SELECTED_APP_SESSION

### Definition

BOC operates the backend and sends a short dispatch message into one selected application-specific GUI session.

This milestone tests backend-to-GUI routing through the Windows Accessibility layer.

### Required starting state

- HD has created a visible GUI worker session.
- The session is named with the required pattern: `STRATA-{ROLE}-{ASSIGNMENT_ID}`.
- BOC has a matching Active Agent Duty Registry entry.
- The app window is visible, on-screen, not minimized, and available to Windows UI Automation.
- The registry entry is treated as operational routing state, not as confirmation that the session is reachable.

### Test action

BOC sends a brief Context Load Packet or Work Dispatch Packet notice to the selected session.

The message must include:

- assignment id
- worker/agent id or role
- packet path
- return folder path
- nonce
- instruction that worker return must be by Worker Return Packet file

### Required acceptance state

The backend records:

- selected `target_app`
- selected `session_name`
- selected `agent_id`
- selected `assignment_id`
- dispatch packet path
- dispatch packet SHA256
- nonce
- UIA phase statuses
- dispatch ledger entry
- evidence directory

The Desktop UI Injection Adapter reaches:

- `SESSION_NAME_FOUND`
- `SESSION_ACTIVATED`
- `ACTIVE_SESSION_VERIFIED`
- `INPUT_FIELD_FOUND`
- `PASTED_AND_VERIFIED`
- `SUBMITTED_AND_VERIFIED`

If nonce verification is implemented for the target app/session, it must also record:

- `VISIBLE_NONCE_VERIFIED`

### Blocked state handling

If the milestone blocks, BOC must record one precise state:

- `SESSION_NAME_NOT_FOUND`
- `SESSION_NAME_DUPLICATE`
- `BLOCKED_APP_NOT_FOUND`
- `BLOCKED_WINDOW_NOT_FOUND`
- `BLOCKED_INPUT_NOT_FOUND`
- `BLOCKED_VERIFICATION_FAILED`
- `BLOCKED_WITH_DIAGNOSTIC`

BOC should resolve local blockers where possible, including:

- restore minimized or off-screen windows
- make the exact visible session name appear in the GUI or UIA tree
- correct duty registry data
- align process privilege level between test runner and app
- rerun the adapter after correcting visibility or focus conditions

### Backend Loop Ledger event

M1 must emit one of:

- `WORK_PASSED`
- `DISPATCH_BLOCKED`

---

## M2_WORKER_TASK_AND_FILE_RETURN

### Definition

BOC sends a brief task to a specific session. The assigned worker performs a small task and writes a Worker Return Packet into the backend-monitored folder.

This milestone tests GUI-worker task execution and file-based return discipline.

### Required starting state

- M1 completed with `WORK_PASSED`.
- The worker received a brief task notice in the selected GUI session.
- The task is intentionally small and has an exact file output requirement.

### Test action

The assigned worker creates:

- a small report file under the expected reports path
- one Worker Return Packet under `returns/{assignment_id}/{agent_id}/`

The Worker Return Packet must declare one allowed `return_kind`:

- `ACK`
- `QUESTION`
- `BLOCKED`
- `NEEDS_CLARIFICATION`
- `PARTIAL_STATUS`
- `REPORT_READY`
- `FAILED_WITH_DIAGNOSTIC`

For the primary smoke run, use `REPORT_READY`.

### Required acceptance state

BOC observes and records:

- Worker Return Packet path
- Worker Return Packet SHA256
- `assignment_id`
- `agent_id`
- `role`
- `return_kind`
- nonce
- report path when `return_kind = REPORT_READY`
- evidence path

The worker must not use chat as the deliverable channel. Chat may acknowledge receipt, but it does not satisfy return requirements.

### Blocked state handling

If no file is written, BOC should instruct the worker to write the Worker Return Packet file. BOC must not infer completion from chat.

If the file is malformed, BOC records the schema or parse failure and keeps the return out of the Agent Report Ledger and ClassB path.

### Backend Loop Ledger event

M2 must emit:

- `RETURN_FILE_DETECTED`

If the expected file is absent after the test window, emit:

- `RETURN_FILE_NOT_DETECTED`

---

## M3_BACKEND_CLASSIFICATION_AND_ROUTING

### Definition

The backend detects the dropped Worker Return Packet, classifies it, and routes it to the correct backend destination.

This milestone tests the backend return loop after file drop.

### Required starting state

- M2 produced a Worker Return Packet or a precise absence/error state.
- The return folder follows `returns/{assignment_id}/{agent_id}/`.
- The backend watcher or deterministic scan/classify command is active.

### Test action

BOC runs or observes backend classification for the Worker Return Packet.

### Required routing table

| Return kind | Required backend route |
| --- | --- |
| `ACK` | Dispatch Ledger update. |
| `QUESTION` | Coordination Thread routed to IC. |
| `BLOCKED` | Coordination Thread routed to IC or HD. |
| `NEEDS_CLARIFICATION` | Coordination Thread routed to IC. |
| `PARTIAL_STATUS` | Coordination Thread or diagnostics. |
| `FAILED_WITH_DIAGNOSTIC` | ClassD/diagnostics and IC. |
| `REPORT_READY` | Agent Report Ledger candidate. |

Only `REPORT_READY` may create an Agent Report Ledger entry.

Only a reviewed and accepted report may enter ClassB.

### Required acceptance state

For `REPORT_READY`, the backend records:

- `WORKER_RETURN_PACKET_CLASSIFIED`
- `REPORT_READY_LEDGERED`
- Agent Report Ledger entry
- `validated_status = pending_review`
- no ClassB import before review acceptance

For non-final returns, the backend records the correct Coordination Thread or diagnostic route and does not create ClassB material.

### Blocked state handling

If watcher behavior is inconsistent on Windows, BOC may use deterministic scan/classify commands. The Backend Loop Ledger must record whether the event came from watcher or manual scan.

### Backend Loop Ledger events

M3 must emit one or more of:

- `RETURN_PACKET_CLASSIFIED`
- `ROUTED_TO_IC`
- `ROUTED_TO_REVIEWER`
- `ROUTED_TO_CLASSD`
- `REPORT_LEDGERED`
- `REVIEW_ACCEPTED`
- `CLASSB_IMPORTED`

## 5. Backend Loop Ledger Standard

### Required files

Every live run must produce both files:

```text
backend_loop_ledger.jsonl
backend_loop_ledger.md
```

The JSONL file is the authoritative control-loop record. The Markdown file is the human-readable mirror.

### Purpose

The Backend Loop Ledger answers these questions without requiring raw log review:

- What did the backend observe?
- Which worker received the work?
- Which session was targeted?
- Was the GUI dispatch submitted and verified?
- Did the worker return by file?
- How did the backend classify the return?
- Was the return routed to IC, reviewer, ClassD, or ClassB admission flow?

### Event format

Each ledger line must be one backend state transition.

Required fields:

| Field | Requirement |
| --- | --- |
| `ts` | ISO timestamp. |
| `loop_id` | Monotonic loop event id, for example `0001`. |
| `assignment_id` | Assignment id, for example `A017`. |
| `event` | Controlled event name. |
| `actor` | Backend actor or role that caused the transition. |
| `from` | Source role/component when applicable. |
| `to` | Destination worker/role/component when applicable. |
| `agent_id` | Worker id when applicable. |
| `role` | Worker role when applicable. |
| `target_app` | GUI app when applicable. |
| `session_name` | Visible session name when applicable. |
| `nonce` | Dispatch or return nonce when applicable. |
| `status` | Controlled ADR/backend status. |
| `artifact` | Primary file path affected by the event. |
| `evidence` | Evidence directory or evidence file path. |
| `note` | Short reason when blocked or exceptional. |

### Controlled event names

Use these event names unless an ADR update adds more:

- `DUTY_REGISTERED`
- `DUTY_VERIFIED`
- `WORK_PACKET_CREATED`
- `WORK_PASSED`
- `DISPATCH_BLOCKED`
- `RETURN_FILE_DETECTED`
- `RETURN_FILE_NOT_DETECTED`
- `RETURN_PACKET_CLASSIFIED`
- `ROUTED_TO_IC`
- `ROUTED_TO_REVIEWER`
- `ROUTED_TO_CLASSD`
- `REPORT_LEDGERED`
- `REVIEW_ACCEPTED`
- `REVIEW_REWORK_REQUIRED`
- `CLASSB_IMPORTED`
- `CLASSB_REJECTED_OR_BLOCKED`

### JSONL example

```jsonl
{"ts":"2026-06-07T13:12:44Z","loop_id":"0001","assignment_id":"A017","event":"DUTY_REGISTERED","actor":"BOC","agent_id":"coder_017","role":"coder","target_app":"Reasonix","session_name":"STRATA-CODER-A017","status":"on_duty","artifact":"state/duty_registry.json","evidence":"runs/A017/duty/"}
{"ts":"2026-06-07T13:14:31Z","loop_id":"0002","assignment_id":"A017","event":"WORK_PASSED","actor":"desktop_ui_injection_adapter.v1","from":"BOC","to":"coder_017","agent_id":"coder_017","role":"coder","target_app":"Reasonix","session_name":"STRATA-CODER-A017","nonce":"STRATA_NONCE_A017_D004","status":"SUBMITTED_AND_VERIFIED","artifact":"packets/A017/smoke_task_004.md","evidence":"runs/A017/dispatch/D004/"}
{"ts":"2026-06-07T13:17:55Z","loop_id":"0003","assignment_id":"A017","event":"RETURN_FILE_DETECTED","actor":"return_watcher","agent_id":"coder_017","role":"coder","nonce":"STRATA_NONCE_A017_D004","status":"detected","artifact":"returns/A017/coder_017/RETURN_004.report_ready.json","evidence":"runs/A017/returns/RETURN_004/"}
{"ts":"2026-06-07T13:17:56Z","loop_id":"0004","assignment_id":"A017","event":"RETURN_PACKET_CLASSIFIED","actor":"worker_return_classifier","agent_id":"coder_017","role":"coder","nonce":"STRATA_NONCE_A017_D004","status":"REPORT_READY","artifact":"returns/A017/coder_017/RETURN_004.report_ready.json","evidence":"runs/A017/returns/RETURN_004/"}
{"ts":"2026-06-07T13:17:57Z","loop_id":"0005","assignment_id":"A017","event":"ROUTED_TO_REVIEWER","actor":"agent_report_ledger","from":"worker_return_classifier","to":"reviewer","agent_id":"coder_017","role":"coder","nonce":"STRATA_NONCE_A017_D004","status":"pending_review","artifact":"reports/A017/coder_smoke_report_004.md","evidence":"runs/A017/reports/report_A017_coder_004/"}
```

### Markdown mirror example

```text
2026-06-07T13:12:44Z loop=0001 event=DUTY_REGISTERED assignment=A017 actor=BOC worker=coder_017 role=coder session=STRATA-CODER-A017 status=on_duty evidence=runs/A017/duty/
2026-06-07T13:14:31Z loop=0002 event=WORK_PASSED assignment=A017 from=BOC to=coder_017 session=STRATA-CODER-A017 nonce=STRATA_NONCE_A017_D004 status=SUBMITTED_AND_VERIFIED evidence=runs/A017/dispatch/D004/
2026-06-07T13:17:55Z loop=0003 event=RETURN_FILE_DETECTED assignment=A017 worker=coder_017 artifact=returns/A017/coder_017/RETURN_004.report_ready.json status=detected evidence=runs/A017/returns/RETURN_004/
2026-06-07T13:17:56Z loop=0004 event=RETURN_PACKET_CLASSIFIED assignment=A017 worker=coder_017 return_kind=REPORT_READY status=valid route=agent_report_ledger evidence=runs/A017/returns/RETURN_004/
2026-06-07T13:17:57Z loop=0005 event=ROUTED_TO_REVIEWER assignment=A017 worker=coder_017 report=reports/A017/coder_smoke_report_004.md status=pending_review evidence=runs/A017/reports/report_A017_coder_004/
```

## 6. Raw Log Policy

Raw logs remain required, but they are not the first review surface.

Raw logs belong under evidence folders and may include:

- PowerShell UIA stdout/stderr
- UIA tree snapshots
- screenshots
- dispatch adapter diagnostics
- watcher events
- classifier output
- Mutation Gate records
- ClassB/ClassD materialization output

The Backend Loop Ledger is the required first review surface for HD and IC. Raw logs are opened only when a ledger line is blocked, inconsistent, or under dispute.

## 7. Package Acceptance Rule

A live test package is not ready for review unless it contains:

- this immutable milestone file or a newer HD-approved version
- `backend_loop_ledger.jsonl`
- `backend_loop_ledger.md`
- dispatch ledger entries
- Worker Return Packet files used in the run
- Agent Report Ledger or Coordination Thread output
- ClassB/ClassD output when applicable
- raw evidence folders

The package must label partial runs precisely. If dispatch and worker return use different nonces, the package must not describe the run as one complete dispatch-to-return chain.

## 8. Current Phase Completion Criteria

The current phase is complete only when one single nonce chain records:

```text
WORK_PASSED
-> RETURN_FILE_DETECTED
-> RETURN_PACKET_CLASSIFIED
-> ROUTED_TO_REVIEWER or ROUTED_TO_IC/CLASSD according to return_kind
```

For the primary smoke test using `REPORT_READY`, the complete chain is:

```text
WORK_PASSED
-> RETURN_FILE_DETECTED
-> RETURN_PACKET_CLASSIFIED
-> REPORT_LEDGERED
-> ROUTED_TO_REVIEWER
```

ClassB import is a separate governance continuation and requires accepted review.
