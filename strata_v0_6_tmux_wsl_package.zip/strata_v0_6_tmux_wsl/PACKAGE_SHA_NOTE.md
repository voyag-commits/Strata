# Package integrity note

The zip package SHA256 is provided next to the downloadable artifact by the assistant response. Recompute locally with:

```bash
sha256sum strata_v0_6_tmux_wsl_package.zip
```
