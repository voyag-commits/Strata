# Coder tasks for v0.6 live implementation

These tasks are ordered. Do not replace a live milestone with a mock/preflight victory script.

## Task 1: WSL bridge placement check

Record where the copied portable CodexCLI + DeepSeek bridge module lives inside WSL.

Definition of done:

```text
.env.local or shell exports point Codex CLI to the bridge URL.
No raw API key is written to repo files.
strata bridge gate --format json shows redacted configuration.
```

## Task 2: Launch one named tmux worker

Use `strata sessions create` to launch Codex CLI in tmux.

Definition of done:

```text
.strata/sessions/<session>.json exists.
tmux attach -t <session> shows the Codex CLI session.
.strata/ledgers/backend_loop_ledger.jsonl contains SESSION_LAUNCHED.
```

## Task 3: Dispatch one real packet

Use `strata dispatch create` and `strata dispatch send`.

Definition of done:

```text
packet file exists under .strata/dispatches/work_dispatch_packets/<assignment>/
tmux pane receives the packet notice
backend_loop_ledger.jsonl contains WORK_PACKET_CREATED and WORK_PASSED
```

## Task 4: Worker returns by file

The worker must create a report file and a Worker Return Packet JSON file under `.strata/returns/<assignment>/<agent>/`.

Definition of done:

```text
Worker Return Packet validates
return_kind is REPORT_READY for the smoke chain
same nonce as dispatch
chat text alone is not accepted
```

## Task 5: Classify and route

Run `strata returns scan`.

Definition of done:

```text
RETURN_FILE_DETECTED
RETURN_PACKET_CLASSIFIED
REPORT_LEDGERED
ROUTED_TO_REVIEWER
```

## Task 6: Review and ClassB import

Run `strata report review --report-id <report_id> --reviewer-id <reviewer_id> --decision accepted` only after inspecting the report.

Definition of done:

```text
review record exists
validation record exists
ClassB entry exists
backend_loop_ledger.jsonl contains REVIEW_ACCEPTED and CLASSB_IMPORTED
```

## Forbidden shortcuts

```text
Do not add mock tmux acceptance tests.
Do not reintroduce ConPTY as active path.
Do not reintroduce Windows GUI/UIA injection as active path.
Do not describe a run as complete unless the same assignment/agent/nonce chain reaches the required ledger events.
```
