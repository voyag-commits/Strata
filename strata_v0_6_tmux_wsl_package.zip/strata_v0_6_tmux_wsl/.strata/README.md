# .strata runtime root

This project-local directory is the v0.6 runtime/evidence root.

```text
.strata/
  sessions/     tmux session records
  dispatches/   Context Load and Work Dispatch Packet records
  returns/      Worker Return Packet drop folders
  ledgers/      backend JSONL, ClassB, dispatch, review, mutation records
  evidence/     pane captures and runtime diagnostics
  quarantine/   invalid reports, blocked diagnostics, excluded runtime artifacts
```

The package ships only this skeleton. Live VS Code/tmux runs will populate the folders.
