# Strata v0.6 contracts

## File-first communication

Chat/session text is not a deliverable. Work is complete only when a valid file appears in the expected folder and the backend records its classification.

## Packet contracts

```text
context_load_packet.v1
work_dispatch_packet.v1
worker_return_packet.v1
agent_report_ledger.entry.v1
backend_loop_ledger.event.v0_6
governance_mutation_gate.v1
```

## Worker Return Packet kinds

```text
ACK
QUESTION
BLOCKED
NEEDS_CLARIFICATION
PARTIAL_STATUS
REPORT_READY
FAILED_WITH_DIAGNOSTIC
```

Only `REPORT_READY` may create an Agent Report Ledger candidate. Only reviewed `accepted` reports may enter ClassB.

## Reviewed ClassB report frontmatter

A `REPORT_READY` Worker Return Packet must point to a report file. For review acceptance and ClassB admission, that report file must start with locked frontmatter:

```markdown
---
template_id: worker_class_b_final_report
template_version: 1.1
assignment_id: <assignment_id>
run_id: <run_id>
progress_comment: <short summary for ClassB index>
worker_role: <role>
---

# Report title

Report body.
```

Reports without this frontmatter can still be detected and ledgered, but reviewer acceptance will not import them into ClassB.

## Required .strata layout

```text
.strata/
  sessions/
  dispatches/
  returns/
  ledgers/
  evidence/
  quarantine/
```

## Backend Loop Ledger

The JSONL ledger is the authoritative first review surface:

```text
.strata/ledgers/backend_loop_ledger.jsonl
```

The Markdown mirror is for human reading:

```text
.strata/ledgers/backend_loop_ledger.md
```
