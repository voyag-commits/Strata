# M1 goal: one governed tmux dispatch-return-review loop

M1 is intentionally narrow. It proves one live path, not the whole Strata architecture.

## Required chain

```text
BOC creates or records named tmux worker session
BOC creates Work Dispatch Packet
BOC sends packet notice into Codex CLI through tmux
worker writes Worker Return Packet file
backend detects and classifies return
REPORT_READY becomes Agent Report Ledger candidate
reviewer accepts or rejects
accepted report enters ClassB
all major steps append .strata/ledgers/backend_loop_ledger.jsonl
```

## Non-goals for v0.6 M1

```text
Windows ConPTY
Windows GUI/UIA injection
mock tmux proof scripts
synthetic acceptance runs
multi-worker scheduler
full autonomous IC/BOC replacement
```

## Completion standard

M1 is complete only when the tmux session, backend ledger, Worker Return Packet, Agent Report Ledger entry, review record, and ClassB entry refer to the same assignment/agent/nonce chain.
