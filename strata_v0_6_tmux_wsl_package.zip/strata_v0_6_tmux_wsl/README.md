# Strata v0.6 tmux/WSL live implementation package

This is the clean v0.6 starting worktree for the confirmed Strata runtime path:

```text
VS Code Remote-WSL
-> Strata backend CLI
-> named tmux sessions
-> Codex CLI inside tmux
-> copied portable CodexCLI + DeepSeek API bridge inside WSL
-> file-backed Worker Return Packet
-> backend classification
-> reviewed ClassB admission
```

The package intentionally excludes active Windows ConPTY and GUI/UIA injection implementations.

## What is included

```text
src/config.ts, src/server.ts, src/mapper.ts, src/log.ts, src/types.ts
  OpenAI-compatible DeepSeek bridge kernel.

src/backend/tmux_dispatch/
  tmux launcher/sender for live WSL sessions.

src/backend/packets/
  Context Load Packet, Work Dispatch Packet, Worker Return Packet template creation.

src/backend/worker_returns/
  Worker Return Packet validation, classification, and routing.

src/backend/agent_report_ledger/
  REPORT_READY candidate ledger and reviewer-gated ClassB import.

src/backend/backend_loop_ledger/
  Authoritative JSONL and Markdown control-loop ledger writer.

.strata/
  Project-local runtime/evidence root.
```

## What is excluded

```text
Windows ConPTY active implementation
Windows GUI/UIA injection implementation
mock tmux acceptance tests
proof scripts
node_modules
dist
old evidence packages
old live Windows GUI workspace
```

## First live loop

Run from VS Code Remote-WSL.

```bash
npm install
npm run build
# Optional, for direct `strata ...` commands from this worktree:
npm link
strata init --workspace .
strata context bootstrap --workspace .
```

Without `npm link`, use `npm run strata -- <command>`, for example `npm run strata -- init --workspace .`.

Start the copied portable DeepSeek bridge inside WSL according to its own module instructions. Then launch a Codex CLI worker inside tmux:

```bash
strata sessions create \
  --workspace . \
  --session STRATA-CODER-A001 \
  --assignment-id A001 \
  --agent-id coder_001 \
  --role coder \
  --cwd . \
  --command codex
```

Create and send a work packet:

```bash
strata dispatch create \
  --workspace . \
  --assignment-id A001 \
  --agent-id coder_001 \
  --role coder \
  --kind task \
  --action "Create a small REPORT_READY Worker Return Packet and report file."

strata dispatch send \
  --workspace . \
  --session STRATA-CODER-A001 \
  --packet .strata/dispatches/work_dispatch_packets/A001/<packet>.md
```

Observe live state:

```bash
tmux attach -t STRATA-CODER-A001
tail -f .strata/ledgers/backend_loop_ledger.jsonl
```

Classify returns:

```bash
strata returns scan --workspace . --assignment-id A001 --agent-id coder_001
strata report list --workspace .
strata report review --workspace . --report-id <report_id> --reviewer-id reviewer_001 --decision accepted
```

## Acceptance rule

A run is not accepted because a mock script passes. A run is accepted only by live observation in VS Code/tmux plus backend JSONL state:

```text
WORK_PASSED
-> RETURN_FILE_DETECTED
-> RETURN_PACKET_CLASSIFIED
-> REPORT_LEDGERED or ROUTED_TO_IC/CLASSD
-> ROUTED_TO_REVIEWER when REPORT_READY
-> REVIEW_ACCEPTED
-> CLASSB_IMPORTED
```
