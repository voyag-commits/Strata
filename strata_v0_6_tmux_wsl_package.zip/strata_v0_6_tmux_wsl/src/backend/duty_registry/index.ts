import fs from "node:fs";
import path from "node:path";
import { ensureGovernanceLayout, fileExists, isoStamp, readJson, type CommandContext, writeJson } from "../common.js";
import { gatedMutation } from "../mutation_gate/index.js";

export type DutyStatus = "on_duty" | "off_duty" | "blocked" | "manual";
export type DutyVerificationStatus =
  | "UNVERIFIED"
  | "TMUX_SESSION_FOUND"
  | "TMUX_SESSION_NOT_FOUND"
  | "TMUX_SESSION_DUPLICATE"
  | "TMUX_PANE_CAPTURED"
  | "ACTIVE_SESSION_VERIFIED"
  | "ACTIVE_SESSION_MISMATCH"
  | "BLOCKED_WITH_DIAGNOSTIC";

export interface ActiveAgentDutyRecord {
  contract_id: "duty_registry.record.v0_6_tmux";
  duty_id: string;
  agent_id: string;
  role: string;
  assignment_id: string;
  status: DutyStatus;
  session_name: string;
  tmux_session_name: string;
  tmux_pane_target: string;
  cwd: string | null;
  launch_command: string | null;
  bridge_profile: string | null;
  codex_profile: string | null;
  verification_status: DutyVerificationStatus;
  last_verified_at: string | null;
  last_nonce: string | null;
  evidence_dir: string;
  source_authority: string;
  created_at: string;
  updated_at: string;
  gate_record_path: string;
}

export interface DutyRegistryIndex {
  contract_id: "duty_registry.index.v1";
  records: string[];
  updated_at: string | null;
}

export interface UpsertDutyRecordInput {
  dutyId?: string;
  agentId: string;
  role: string;
  assignmentId: string;
  sessionName: string;
  tmuxPaneTarget?: string | null;
  cwd?: string | null;
  launchCommand?: string | null;
  bridgeProfile?: string | null;
  codexProfile?: string | null;
  status?: DutyStatus;
  evidenceDir?: string | null;
  sourceAuthority?: string;
  actor?: string;
}

export interface DutyVerificationUpdate {
  verificationStatus: DutyVerificationStatus;
  tmuxPaneTarget?: string | null;
  lastNonce?: string | null;
  evidenceDir?: string | null;
  status?: DutyStatus;
  actor?: string;
}

function safe(v: string): string {
  return v.replace(/[^A-Za-z0-9_.-]+/g, "-").replace(/^-+|-+$/g, "") || "item";
}

function rpath(ctx: CommandContext, id: string): string {
  return path.join(ensureGovernanceLayout(ctx.workspaceRoot).dutyRegistry, `${safe(id)}.json`);
}

function assertReq(name: string, value: string): void {
  if (!value.trim()) throw new Error(`${name} is required.`);
}

export function expectedSessionName(role: string, assignmentId: string): string {
  return `strata-${safe(role).toLowerCase()}-${safe(assignmentId).toLowerCase()}`;
}

export function upsertDutyRecord(ctx: CommandContext, input: UpsertDutyRecordInput): { record: ActiveAgentDutyRecord; record_path: string; index_path: string } {
  const layout = ensureGovernanceLayout(ctx.workspaceRoot);
  assertReq("agentId", input.agentId);
  assertReq("role", input.role);
  assertReq("assignmentId", input.assignmentId);
  assertReq("sessionName", input.sessionName);

  const dutyId = input.dutyId ?? `duty_${safe(input.assignmentId)}_${safe(input.role).toLowerCase()}_${safe(input.sessionName).toLowerCase()}`;
  const target = rpath(ctx, dutyId);
  const prior = fileExists(target) ? readJson<ActiveAgentDutyRecord>(target) : null;
  const tmuxPaneTarget = input.tmuxPaneTarget ?? prior?.tmux_pane_target ?? `${input.sessionName}:0.0`;

  const gate = gatedMutation(ctx, {
    actor: input.actor ?? "backend_ops",
    action: prior ? "duty_registry.update" : "duty_registry.write",
    resourceType: "duty_registry",
    resourceId: dutyId,
    reason: "record Human Director-provided tmux worker session routing data",
    beforePath: prior ? target : null,
    afterPath: target,
    metadata: {
      assignment_id: input.assignmentId,
      agent_id: input.agentId,
      role: input.role,
      tmux_session_name: input.sessionName,
      tmux_pane_target: tmuxPaneTarget,
      source_authority: input.sourceAuthority ?? "human_director",
    },
  });

  const record: ActiveAgentDutyRecord = {
    contract_id: "duty_registry.record.v0_6_tmux",
    duty_id: dutyId,
    agent_id: input.agentId,
    role: input.role,
    assignment_id: input.assignmentId,
    status: input.status ?? prior?.status ?? "on_duty",
    session_name: input.sessionName,
    tmux_session_name: input.sessionName,
    tmux_pane_target: tmuxPaneTarget,
    cwd: input.cwd ?? prior?.cwd ?? null,
    launch_command: input.launchCommand ?? prior?.launch_command ?? null,
    bridge_profile: input.bridgeProfile ?? prior?.bridge_profile ?? null,
    codex_profile: input.codexProfile ?? prior?.codex_profile ?? null,
    verification_status: prior?.verification_status ?? "UNVERIFIED",
    last_verified_at: prior?.last_verified_at ?? null,
    last_nonce: prior?.last_nonce ?? null,
    evidence_dir: input.evidenceDir ?? prior?.evidence_dir ?? path.join(layout.evidenceRoot, "duty_registry", safe(input.assignmentId), safe(input.agentId)),
    source_authority: input.sourceAuthority ?? prior?.source_authority ?? "human_director",
    created_at: prior?.created_at ?? isoStamp(ctx.now),
    updated_at: isoStamp(ctx.now),
    gate_record_path: gate.gate_record_path,
  };

  const record_path = writeJson(target, record);
  const index = readJson<DutyRegistryIndex>(layout.dutyRegistryIndexPath);
  const records = Array.from(new Set([...index.records, record_path])).sort();
  const index_path = writeJson(layout.dutyRegistryIndexPath, { ...index, records, updated_at: isoStamp(ctx.now) });
  return { record, record_path, index_path };
}

export function readDutyRecord(ctx: CommandContext, dutyId: string): ActiveAgentDutyRecord {
  return readJson<ActiveAgentDutyRecord>(rpath(ctx, dutyId));
}

export function listDutyRecords(ctx: CommandContext): ActiveAgentDutyRecord[] {
  const layout = ensureGovernanceLayout(ctx.workspaceRoot);
  return fs
    .readdirSync(layout.dutyRegistry)
    .filter((name) => name.endsWith(".json") && name !== "index.json")
    .map((name) => readJson<ActiveAgentDutyRecord>(path.join(layout.dutyRegistry, name)))
    .sort((a, b) => a.assignment_id.localeCompare(b.assignment_id) || a.role.localeCompare(b.role));
}

export function updateDutyVerification(ctx: CommandContext, dutyId: string, update: DutyVerificationUpdate): { record: ActiveAgentDutyRecord; record_path: string } {
  const target = rpath(ctx, dutyId);
  const record = readJson<ActiveAgentDutyRecord>(target);
  const gate = gatedMutation(ctx, {
    actor: update.actor ?? "backend_ops",
    action: "duty_registry.verify",
    resourceType: "duty_registry",
    resourceId: dutyId,
    reason: "update tmux worker duty verification state from session evidence",
    beforePath: target,
    afterPath: target,
    evidencePath: update.evidenceDir ?? record.evidence_dir,
    metadata: {
      verification_status: update.verificationStatus,
      tmux_session_name: record.tmux_session_name,
      tmux_pane_target: update.tmuxPaneTarget ?? record.tmux_pane_target,
    },
  });

  const next: ActiveAgentDutyRecord = {
    ...record,
    status: update.status ?? record.status,
    tmux_pane_target: update.tmuxPaneTarget ?? record.tmux_pane_target,
    verification_status: update.verificationStatus,
    last_verified_at: isoStamp(ctx.now),
    last_nonce: update.lastNonce ?? record.last_nonce,
    evidence_dir: update.evidenceDir ?? record.evidence_dir,
    updated_at: isoStamp(ctx.now),
    gate_record_path: gate.gate_record_path,
  };
  return { record: next, record_path: writeJson(target, next) };
}

export function dutyRegistryReport(ctx: CommandContext): Record<string, unknown> {
  const records = listDutyRecords(ctx);
  return {
    contract_id: "duty_registry.report.v0_6_tmux",
    generated_at: isoStamp(ctx.now),
    on_duty_count: records.filter((record) => record.status === "on_duty").length,
    records,
  };
}
