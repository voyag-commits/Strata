import path from "node:path";
import { ensureDir, ensureGovernanceLayout, hashText, isoStamp, readText, shortId, type CommandContext, writeJson, writeText } from "../common.js";
import { appendBackendLoopEvent } from "../backend_loop_ledger/index.js";
import { returnFolderFor, type WorkerReturnKind, workerReturnTemplate, type WorkerReturnPacket } from "../worker_returns/index.js";
import { gatedMutation } from "../mutation_gate/index.js";

export type PacketType = "context_load_packet.v1" | "work_dispatch_packet.v1";
export type WorkDispatchKind = "task" | "question" | "rework" | "review" | "status_request" | "stop" | string;

export interface PacketWriteResult {
  contract_id: PacketType;
  packet_id: string;
  assignment_id: string;
  agent_id: string;
  role: string;
  packet_path: string;
  packet_sha256: string;
  record_path: string;
  return_folder: string;
  nonce: string;
  tmux_message: string;
  created_at: string;
  gate_record_path: string;
}

export interface CreateContextLoadPacketInput {
  assignmentId: string;
  agentId: string;
  role: string;
  sessionName?: string;
  roleContract?: string;
  assignmentFrame?: string;
  contextHeaderPath?: string;
  actor?: string;
  nonce?: string;
}

export interface CreateWorkDispatchPacketInput {
  assignmentId: string;
  agentId: string;
  role: string;
  dispatchKind: WorkDispatchKind;
  action: string;
  body?: string;
  referencedFiles?: string[];
  fromRole?: string;
  actor?: string;
  nonce?: string;
}

function safe(value: string): string {
  return value.replace(/[^A-Za-z0-9_.-]+/g, "-").replace(/^-+|-+$/g, "") || "item";
}

function sha(filePath: string): string {
  return hashText(readText(filePath));
}

function refs(items: string[]): string[] {
  return items.length > 0 ? items.map((item) => `- ${item}`) : ["- not_applicable"];
}

function returnProtocol(returnFolder: string): string {
  return [
    "## Required return protocol",
    "",
    "Chat/session text is not a deliverable.",
    "When work is complete, write one Worker Return Packet JSON file into:",
    "",
    "```text",
    returnFolder,
    "```",
    "",
    "Allowed return_kind values:",
    "- ACK",
    "- QUESTION",
    "- BLOCKED",
    "- NEEDS_CLARIFICATION",
    "- PARTIAL_STATUS",
    "- REPORT_READY",
    "- FAILED_WITH_DIAGNOSTIC",
    "",
    "For REPORT_READY, the packet must reference a report_path. Only a reviewed and accepted report may enter ClassB.",
  ].join("\n");
}

export function createContextLoadPacket(ctx: CommandContext, input: CreateContextLoadPacketInput): PacketWriteResult {
  const layout = ensureGovernanceLayout(ctx.workspaceRoot);
  const packetId = shortId(`ctx_packet_${safe(input.assignmentId)}_${safe(input.agentId)}`, ctx.now);
  const nonce = input.nonce ?? `STRATA_NONCE_${safe(input.assignmentId).toUpperCase()}_CTX_${safe(packetId).slice(-12)}`;
  const dir = ensureDir(path.join(layout.contextLoadPackets, safe(input.assignmentId)));
  const packetPath = path.join(dir, `${safe(packetId)}.md`);
  const recordPath = path.join(dir, `${safe(packetId)}.json`);
  const returnFolder = returnFolderFor(ctx, input.assignmentId, input.agentId);
  const packetBody = [
    "---",
    "contract_id: context_load_packet.v1",
    `packet_id: ${packetId}`,
    `assignment_id: ${input.assignmentId}`,
    `agent_id: ${input.agentId}`,
    `role: ${input.role}`,
    `session_name: ${input.sessionName ?? "not_assigned"}`,
    `nonce: ${nonce}`,
    "---",
    "",
    "# STRATA Context Load Packet v1",
    "",
    "This packet is the stable context header for a tmux-hosted Codex CLI worker.",
    "",
    "## Runtime boundary",
    "",
    "- Active runtime: WSL/Linux tmux session.",
    "- Worker engine: Codex CLI configured to use the copied portable DeepSeek bridge.",
    "- Backend authority: files, ledgers, and reviewed Worker Return Packets.",
    "- Chat/session text: operational control surface only, not a deliverable.",
    "",
    "## Role contract",
    "",
    input.roleContract ?? "Follow the assignment packet, preserve evidence, and return only through Worker Return Packet files.",
    "",
    "## Assignment frame",
    "",
    input.assignmentFrame ?? "Use ClassA and ClassC as stable context headers. Treat ClassB as the runtime delta ledger.",
    "",
    "## Context header path",
    "",
    input.contextHeaderPath ?? "not_applicable",
    "",
    returnProtocol(returnFolder),
  ].join("\n");
  writeText(packetPath, `${packetBody}\n`);
  const gate = gatedMutation(ctx, {
    actor: input.actor ?? "backend_ops",
    action: "context_load_packet.write",
    resourceType: "context_load_packet",
    resourceId: packetId,
    reason: "write file-backed tmux worker context load packet",
    afterPath: packetPath,
    metadata: { assignment_id: input.assignmentId, agent_id: input.agentId, nonce },
  });
  const tmuxMessage = [
    "STRATA CONTEXT LOAD v1",
    "",
    `Read this context packet: ${packetPath}`,
    `Return folder: ${returnFolder}`,
    `Nonce: ${nonce}`,
    "",
    "Chat/session text is not a deliverable. Return only by Worker Return Packet file.",
  ].join("\n");
  const result: PacketWriteResult = {
    contract_id: "context_load_packet.v1",
    packet_id: packetId,
    assignment_id: input.assignmentId,
    agent_id: input.agentId,
    role: input.role,
    packet_path: packetPath,
    packet_sha256: sha(packetPath),
    record_path: recordPath,
    return_folder: returnFolder,
    nonce,
    tmux_message: tmuxMessage,
    created_at: isoStamp(ctx.now),
    gate_record_path: gate.gate_record_path,
  };
  writeJson(recordPath, result);
  return result;
}

export function createWorkDispatchPacket(ctx: CommandContext, input: CreateWorkDispatchPacketInput): PacketWriteResult {
  const layout = ensureGovernanceLayout(ctx.workspaceRoot);
  const packetId = shortId(`disp_packet_${safe(input.assignmentId)}_${safe(input.agentId)}`, ctx.now);
  const nonce = input.nonce ?? `STRATA_NONCE_${safe(input.assignmentId).toUpperCase()}_D_${safe(packetId).slice(-12)}`;
  const dir = ensureDir(path.join(layout.workDispatchPackets, safe(input.assignmentId)));
  const packetPath = path.join(dir, `${safe(packetId)}.md`);
  const recordPath = path.join(dir, `${safe(packetId)}.json`);
  const returnFolder = returnFolderFor(ctx, input.assignmentId, input.agentId);
  const packetBody = [
    "---",
    "contract_id: work_dispatch_packet.v1",
    `packet_id: ${packetId}`,
    `assignment_id: ${input.assignmentId}`,
    `agent_id: ${input.agentId}`,
    `role: ${input.role}`,
    `dispatch_kind: ${input.dispatchKind}`,
    `nonce: ${nonce}`,
    "---",
    "",
    "# STRATA Work Dispatch Packet v1",
    "",
    `From role: ${input.fromRole ?? "IC"}`,
    `Dispatch kind: ${input.dispatchKind}`,
    `Assignment: ${input.assignmentId}`,
    `Agent: ${input.agentId}`,
    "",
    "## Action",
    "",
    input.action,
    "",
    "## Referenced files",
    ...refs(input.referencedFiles ?? []),
    "",
    "## Body",
    "",
    input.body ?? "not_applicable",
    "",
    returnProtocol(returnFolder),
  ].join("\n");
  writeText(packetPath, `${packetBody}\n`);
  const gate = gatedMutation(ctx, {
    actor: input.actor ?? "backend_ops",
    action: "work_dispatch_packet.write",
    resourceType: "work_dispatch_packet",
    resourceId: packetId,
    reason: "write file-backed tmux worker work dispatch packet",
    afterPath: packetPath,
    metadata: { assignment_id: input.assignmentId, agent_id: input.agentId, dispatch_kind: input.dispatchKind, nonce },
  });
  const tmuxMessage = [
    "STRATA WORK DISPATCH v1",
    "",
    `Assignment: ${input.assignmentId}`,
    `Agent: ${input.agentId}`,
    `Read packet: ${packetPath}`,
    `Action: ${input.action}`,
    `Return folder: ${returnFolder}`,
    `Nonce: ${nonce}`,
    "",
    "When done, write a Worker Return Packet JSON file. Chat/session text is not a deliverable.",
  ].join("\n");
  const result: PacketWriteResult = {
    contract_id: "work_dispatch_packet.v1",
    packet_id: packetId,
    assignment_id: input.assignmentId,
    agent_id: input.agentId,
    role: input.role,
    packet_path: packetPath,
    packet_sha256: sha(packetPath),
    record_path: recordPath,
    return_folder: returnFolder,
    nonce,
    tmux_message: tmuxMessage,
    created_at: isoStamp(ctx.now),
    gate_record_path: gate.gate_record_path,
  };
  writeJson(recordPath, result);
  appendBackendLoopEvent(ctx, {
    event: "WORK_PACKET_CREATED",
    actor: input.actor ?? "backend_ops",
    from: input.fromRole ?? "IC",
    to: input.agentId,
    assignment_id: input.assignmentId,
    agent_id: input.agentId,
    role: input.role,
    target_runtime: "tmux",
    nonce,
    status: "created",
    artifact: packetPath,
    evidence: recordPath,
  });
  return result;
}

export function writeWorkerReturnPacketTemplate(ctx: CommandContext, input: {
  assignmentId: string;
  agentId: string;
  role: string;
  returnKind: WorkerReturnKind;
  nonce: string;
  returnId?: string;
  reportPath?: string | null;
  questionPath?: string | null;
  messagePath?: string | null;
  diagnosticPath?: string | null;
  evidencePath?: string | null;
}): { packet: WorkerReturnPacket; packet_path: string } {
  const folder = returnFolderFor(ctx, input.assignmentId, input.agentId);
  const returnId = input.returnId ?? shortId(`ret_${safe(input.assignmentId)}_${safe(input.agentId)}`, ctx.now);
  const packet = workerReturnTemplate({
    returnId,
    assignmentId: input.assignmentId,
    agentId: input.agentId,
    role: input.role,
    returnKind: input.returnKind,
    nonce: input.nonce,
    reportPath: input.reportPath ?? null,
    questionPath: input.questionPath ?? null,
    messagePath: input.messagePath ?? null,
    diagnosticPath: input.diagnosticPath ?? null,
    evidencePath: input.evidencePath ?? null,
    createdAt: isoStamp(ctx.now),
  });
  const packetPath = path.join(folder, `${safe(returnId)}.${input.returnKind.toLowerCase()}.json`);
  writeJson(packetPath, packet);
  return { packet, packet_path: packetPath };
}
