import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";
import {
  ensureDir,
  ensureGovernanceLayout,
  fileExists,
  fileStamp,
  hashText,
  isoStamp,
  readJson,
  readText,
  shortId,
  type CommandContext,
  writeJson,
  writeText,
} from "../common.js";
import { appendBackendLoopEvent } from "../backend_loop_ledger/index.js";
import { recordDispatch, type PacketType } from "../dispatch_ledger/index.js";
import { gatedMutation } from "../mutation_gate/index.js";

export interface TmuxSessionRecord {
  contract_id: "tmux_session.record.v0_6";
  session_record_id: string;
  session_name: string;
  assignment_id: string;
  agent_id: string;
  role: string;
  cwd: string;
  command: string;
  bridge_base_url: string | null;
  bridge_module_note: string;
  created_at: string;
  updated_at: string;
  status: "created" | "observed_alive" | "not_found" | "launch_failed";
  tmux_status: string;
  evidence_dir: string;
  gate_record_path: string;
}

export interface TmuxLaunchInput {
  sessionName: string;
  assignmentId: string;
  agentId: string;
  role: string;
  cwd?: string;
  command?: string;
  bridgeBaseUrl?: string | null;
  replace?: boolean;
  actor?: string;
}

export interface TmuxSendInput {
  sessionName: string;
  packetPath: string;
  message?: string;
  messagePath?: string;
  submit?: boolean;
  fromRole?: string;
  actor?: string;
}

export interface TmuxCommandResult {
  ok: boolean;
  status: number | null;
  stdout: string;
  stderr: string;
}

export interface TmuxSendResult {
  ok: boolean;
  dispatch_id: string | null;
  dispatch_entry_path: string | null;
  packet_path: string;
  packet_type: PacketType;
  assignment_id: string;
  agent_id: string;
  role: string;
  nonce: string;
  session_name: string;
  evidence_dir: string;
  message_path: string;
  pane_capture_path: string | null;
  tmux_results: Record<string, TmuxCommandResult>;
}

function safe(value: string): string {
  return value.replace(/[^A-Za-z0-9_.-]+/g, "-").replace(/^-+|-+$/g, "") || "item";
}

function runTmux(args: string[], cwd?: string): TmuxCommandResult {
  const result = spawnSync("tmux", args, { cwd, encoding: "utf8" });
  return {
    ok: result.status === 0,
    status: result.status,
    stdout: result.stdout ?? "",
    stderr: result.stderr ?? (result.error ? result.error.message : ""),
  };
}

function requireTmux(): void {
  const result = runTmux(["-V"]);
  if (!result.ok) {
    throw new Error(`tmux is not available in this environment. Install tmux inside WSL. stderr=${result.stderr || "not_found"}`);
  }
}

function recordPath(ctx: CommandContext, sessionName: string): string {
  const layout = ensureGovernanceLayout(ctx.workspaceRoot);
  return path.join(layout.sessionsRoot, `${safe(sessionName)}.json`);
}

function readPacketMetadata(ctx: CommandContext, packetPathInput: string): {
  packetType: PacketType;
  assignmentId: string;
  agentId: string;
  role: string;
  nonce: string;
  message: string | null;
} {
  const packetPath = path.resolve(packetPathInput);
  const text = readText(packetPath);
  const adjacentJson = packetPath.replace(/\.md$/i, ".json");
  if (fileExists(adjacentJson)) {
    const record = readJson<Record<string, unknown>>(adjacentJson);
    const contract = String(record.contract_id ?? "");
    if (contract === "context_load_packet.v1" || contract === "work_dispatch_packet.v1") {
      return {
        packetType: contract,
        assignmentId: String(record.assignment_id ?? ""),
        agentId: String(record.agent_id ?? ""),
        role: String(record.role ?? "worker"),
        nonce: String(record.nonce ?? ""),
        message: typeof record.tmux_message === "string" ? record.tmux_message : null,
      };
    }
  }
  const field = (name: string): string => {
    const match = text.match(new RegExp(`^${name}:\\s*(.+)$`, "mi"));
    return match?.[1]?.trim() ?? "";
  };
  const contract = field("contract_id");
  if (contract !== "context_load_packet.v1" && contract !== "work_dispatch_packet.v1") {
    throw new Error(`Packet ${packetPath} is missing contract_id context_load_packet.v1 or work_dispatch_packet.v1.`);
  }
  return {
    packetType: contract,
    assignmentId: field("assignment_id"),
    agentId: field("agent_id"),
    role: field("role") || "worker",
    nonce: field("nonce"),
    message: null,
  };
}

function capturePane(ctx: CommandContext, sessionName: string, evidenceDir: string): { result: TmuxCommandResult; path: string | null } {
  const result = runTmux(["capture-pane", "-p", "-t", sessionName, "-S", "-200"]);
  if (!result.ok) return { result, path: null };
  const capturePath = path.join(evidenceDir, "tmux_pane_capture.txt");
  writeText(capturePath, result.stdout);
  return { result, path: capturePath };
}

export function launchTmuxSession(ctx: CommandContext, input: TmuxLaunchInput): { record: TmuxSessionRecord; record_path: string; tmux: TmuxCommandResult } {
  requireTmux();
  const layout = ensureGovernanceLayout(ctx.workspaceRoot);
  const cwd = path.resolve(input.cwd ?? ctx.workspaceRoot);
  const command = input.command ?? process.env.CODEX_EXE ?? "codex";
  const sessionName = input.sessionName;
  const evidenceDir = ensureDir(path.join(layout.evidenceRoot, "tmux_sessions", safe(sessionName), fileStamp(ctx.now)));
  const exists = runTmux(["has-session", "-t", sessionName]);
  if (exists.ok && input.replace) runTmux(["kill-session", "-t", sessionName]);
  if (exists.ok && !input.replace) throw new Error(`tmux session already exists: ${sessionName}. Use --replace to kill and recreate.`);
  const tmux = runTmux(["new-session", "-d", "-s", sessionName, "-c", cwd, command], cwd);
  const target = recordPath(ctx, sessionName);
  const gate = gatedMutation(ctx, {
    actor: input.actor ?? "BOC",
    action: "tmux_session.launch",
    resourceType: "tmux_session",
    resourceId: sessionName,
    reason: "launch or record WSL tmux Codex CLI worker session",
    afterPath: target,
    evidencePath: evidenceDir,
    metadata: { assignment_id: input.assignmentId, agent_id: input.agentId, role: input.role, command, cwd },
  });
  const status: TmuxSessionRecord["status"] = tmux.ok ? "created" : "launch_failed";
  const record: TmuxSessionRecord = {
    contract_id: "tmux_session.record.v0_6",
    session_record_id: shortId(`tmux_session_${safe(sessionName)}`, ctx.now),
    session_name: sessionName,
    assignment_id: input.assignmentId,
    agent_id: input.agentId,
    role: input.role,
    cwd,
    command,
    bridge_base_url: input.bridgeBaseUrl ?? process.env.DEEPSEEK_BRIDGE_BASE_URL ?? process.env.OPENAI_BASE_URL ?? null,
    bridge_module_note: "The Codex CLI + DeepSeek API bridge is a portable module copied into WSL from the stable Windows-native setup; Strata records its URL/config but does not vendor the module in this package.",
    created_at: isoStamp(ctx.now),
    updated_at: isoStamp(ctx.now),
    status,
    tmux_status: tmux.ok ? "SESSION_LAUNCHED" : "LAUNCH_FAILED",
    evidence_dir: evidenceDir,
    gate_record_path: gate.gate_record_path,
  };
  const record_path = writeJson(target, record);
  writeJson(path.join(evidenceDir, "launch_result.json"), { contract_id: "tmux_launch_result.v0_6", tmux, record_path, created_at: isoStamp(ctx.now) });
  appendBackendLoopEvent(ctx, {
    event: tmux.ok ? "SESSION_LAUNCHED" : "DISPATCH_BLOCKED",
    actor: input.actor ?? "BOC",
    assignment_id: input.assignmentId,
    agent_id: input.agentId,
    role: input.role,
    target_runtime: "tmux",
    session_name: sessionName,
    status: record.tmux_status,
    artifact: record_path,
    evidence: evidenceDir,
    note: tmux.ok ? null : tmux.stderr,
  });
  return { record, record_path, tmux };
}

export function listTmuxSessionRecords(ctx: CommandContext): TmuxSessionRecord[] {
  const layout = ensureGovernanceLayout(ctx.workspaceRoot);
  return fs
    .readdirSync(layout.sessionsRoot)
    .filter((name) => name.endsWith(".json"))
    .map((name) => readJson<TmuxSessionRecord>(path.join(layout.sessionsRoot, name)))
    .sort((a, b) => a.session_name.localeCompare(b.session_name));
}

export function observeTmuxSession(ctx: CommandContext, sessionName: string): { exists: boolean; record: TmuxSessionRecord | null; evidence_dir: string; pane_capture_path: string | null; tmux_results: Record<string, TmuxCommandResult> } {
  requireTmux();
  const layout = ensureGovernanceLayout(ctx.workspaceRoot);
  const evidenceDir = ensureDir(path.join(layout.evidenceRoot, "tmux_sessions", safe(sessionName), `status_${fileStamp(ctx.now)}`));
  const has = runTmux(["has-session", "-t", sessionName]);
  const capture = has.ok ? capturePane(ctx, sessionName, evidenceDir) : { result: has, path: null };
  const p = recordPath(ctx, sessionName);
  let record: TmuxSessionRecord | null = fileExists(p) ? readJson<TmuxSessionRecord>(p) : null;
  if (record) {
    record = { ...record, status: has.ok ? "observed_alive" : "not_found", updated_at: isoStamp(ctx.now), tmux_status: has.ok ? "SESSION_PRESENT" : "SESSION_NOT_FOUND" };
    writeJson(p, record);
  }
  writeJson(path.join(evidenceDir, "status_result.json"), { contract_id: "tmux_status_result.v0_6", session_name: sessionName, has_session: has, capture: capture.result, created_at: isoStamp(ctx.now) });
  appendBackendLoopEvent(ctx, {
    event: "SESSION_STATUS_OBSERVED",
    actor: "BOC",
    assignment_id: record?.assignment_id ?? null,
    agent_id: record?.agent_id ?? null,
    role: record?.role ?? null,
    target_runtime: "tmux",
    session_name: sessionName,
    status: has.ok ? "SESSION_PRESENT" : "SESSION_NOT_FOUND",
    artifact: p,
    evidence: evidenceDir,
  });
  return { exists: has.ok, record, evidence_dir: evidenceDir, pane_capture_path: capture.path, tmux_results: { has_session: has, capture_pane: capture.result } };
}

export function sendPacketToTmux(ctx: CommandContext, input: TmuxSendInput): TmuxSendResult {
  requireTmux();
  const layout = ensureGovernanceLayout(ctx.workspaceRoot);
  const packetPath = path.resolve(input.packetPath);
  const metadata = readPacketMetadata(ctx, packetPath);
  if (!metadata.assignmentId || !metadata.agentId || !metadata.nonce) throw new Error(`Packet ${packetPath} is missing assignment_id, agent_id, or nonce.`);
  const evidenceDir = ensureDir(path.join(layout.evidenceRoot, "tmux_dispatch", safe(metadata.assignmentId), safe(metadata.agentId), fileStamp(ctx.now)));
  const message = input.messagePath ? readText(path.resolve(input.messagePath)) : input.message ?? metadata.message ?? [
    metadata.packetType === "context_load_packet.v1" ? "STRATA CONTEXT LOAD v1" : "STRATA WORK DISPATCH v1",
    "",
    `Read packet: ${packetPath}`,
    `Assignment: ${metadata.assignmentId}`,
    `Agent: ${metadata.agentId}`,
    `Nonce: ${metadata.nonce}`,
    "",
    "Return by Worker Return Packet file. Chat/session text is not a deliverable.",
  ].join("\n");
  const messagePath = writeText(path.join(evidenceDir, "tmux_message.txt"), message.endsWith("\n") ? message : `${message}\n`);
  const bufferName = `strata_${safe(metadata.assignmentId)}_${safe(metadata.agentId)}_${Date.now()}`;
  const has = runTmux(["has-session", "-t", input.sessionName]);
  const load = has.ok ? runTmux(["load-buffer", "-b", bufferName, messagePath]) : { ok: false, status: has.status, stdout: "", stderr: has.stderr || "tmux session not found" };
  const paste = load.ok ? runTmux(["paste-buffer", "-t", input.sessionName, "-b", bufferName]) : { ok: false, status: load.status, stdout: "", stderr: load.stderr };
  const enter = paste.ok && input.submit !== false ? runTmux(["send-keys", "-t", input.sessionName, "Enter"]) : { ok: input.submit === false && paste.ok, status: input.submit === false && paste.ok ? 0 : paste.status, stdout: "", stderr: input.submit === false ? "submit disabled" : paste.stderr };
  const capture = paste.ok ? capturePane(ctx, input.sessionName, evidenceDir) : { result: paste, path: null };
  const ok = has.ok && load.ok && paste.ok && enter.ok;
  writeJson(path.join(evidenceDir, "tmux_dispatch_result.json"), {
    contract_id: "tmux_dispatch_result.v0_6",
    session_name: input.sessionName,
    packet_path: packetPath,
    packet_sha256: hashText(readText(packetPath)),
    message_path: messagePath,
    nonce: metadata.nonce,
    tmux_results: { has_session: has, load_buffer: load, paste_buffer: paste, send_enter: enter, capture_pane: capture.result },
    created_at: isoStamp(ctx.now),
  });
  let dispatchId: string | null = null;
  let dispatchEntryPath: string | null = null;
  if (ok) {
    const dispatch = recordDispatch(ctx, {
      assignmentId: metadata.assignmentId,
      fromRole: input.fromRole ?? "BOC",
      toAgentId: metadata.agentId,
      targetApp: "tmux",
      sessionName: input.sessionName,
      packetType: metadata.packetType,
      packetPath,
      nonce: metadata.nonce,
      pasteStatus: "TMUX_BUFFER_PASTED",
      submitStatus: input.submit === false ? "NOT_SUBMITTED" : "TMUX_ENTER_SENT",
      verificationStatus: capture.path ? "TMUX_PANE_CAPTURED" : "LIVE_OBSERVATION_REQUIRED",
      evidenceDir,
      diagnosticPath: path.join(evidenceDir, "tmux_dispatch_result.json"),
      actor: input.actor ?? "BOC",
    });
    dispatchId = dispatch.entry.dispatch_id;
    dispatchEntryPath = dispatch.entry_path;
  }
  appendBackendLoopEvent(ctx, {
    event: ok ? "WORK_PASSED" : "DISPATCH_BLOCKED",
    actor: input.actor ?? "BOC",
    from: input.fromRole ?? "BOC",
    to: metadata.agentId,
    assignment_id: metadata.assignmentId,
    agent_id: metadata.agentId,
    role: metadata.role,
    target_runtime: "tmux",
    session_name: input.sessionName,
    nonce: metadata.nonce,
    status: ok ? (input.submit === false ? "TMUX_BUFFER_PASTED_NOT_SUBMITTED" : "TMUX_MESSAGE_INJECTED_ENTER_SENT") : "TMUX_DISPATCH_BLOCKED",
    artifact: packetPath,
    evidence: evidenceDir,
    note: ok ? null : [has.stderr, load.stderr, paste.stderr, enter.stderr].filter(Boolean).join(" | "),
  });
  return {
    ok,
    dispatch_id: dispatchId,
    dispatch_entry_path: dispatchEntryPath,
    packet_path: packetPath,
    packet_type: metadata.packetType,
    assignment_id: metadata.assignmentId,
    agent_id: metadata.agentId,
    role: metadata.role,
    nonce: metadata.nonce,
    session_name: input.sessionName,
    evidence_dir: evidenceDir,
    message_path: messagePath,
    pane_capture_path: capture.path,
    tmux_results: { has_session: has, load_buffer: load, paste_buffer: paste, send_enter: enter, capture_pane: capture.result },
  };
}
