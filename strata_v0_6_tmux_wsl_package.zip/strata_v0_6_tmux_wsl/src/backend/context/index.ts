import fs from "node:fs";
import path from "node:path";
import {
  ensureGovernanceLayout,
  fileExists,
  hashText,
  isoStamp,
  readJson,
  readText,
  shortId,
  type CommandContext,
  writeJson,
  writeText,
} from "../common.js";
import { gatedMutation, type MutationGateRecord } from "../mutation_gate/index.js";

export type ContextClass = "A" | "B" | "C" | "D";

export interface ContextRecord {
  context_record_id: string;
  class: ContextClass;
  title: string;
  kind: string;
  body_path: string;
  body_sha256: string;
  source_path: string | null;
  created_at: string;
  updated_at: string;
  actor: string;
  gate_record_path: string;
  tags: string[];
}

export interface ContextBootstrapResult {
  ok: boolean;
  class_a_records: ContextRecord[];
  class_c_records: ContextRecord[];
  gate_records: MutationGateRecord[];
}

function safeFilePart(value: string): string {
  return value.replace(/[^A-Za-z0-9_.-]+/g, "-").replace(/^-+|-+$/g, "") || "item";
}

function classDir(context: CommandContext, klass: ContextClass): string {
  const layout = ensureGovernanceLayout(context.workspaceRoot);
  if (klass === "A") return layout.classA;
  if (klass === "B") return layout.classBEntries;
  if (klass === "C") return layout.classC;
  return layout.classD;
}

function recordDir(context: CommandContext, klass: ContextClass): string {
  const root = classDir(context, klass);
  const records = path.join(root, "records");
  fs.mkdirSync(records, { recursive: true });
  return records;
}

function bodyDir(context: CommandContext, klass: ContextClass): string {
  const root = classDir(context, klass);
  const bodies = path.join(root, "bodies");
  fs.mkdirSync(bodies, { recursive: true });
  return bodies;
}

function writeContextRecord(context: CommandContext, input: {
  klass: ContextClass;
  title: string;
  kind: string;
  body: string;
  actor: string;
  sourcePath?: string | null;
  tags?: string[];
  approvedByDirector?: boolean;
}): ContextRecord {
  const recordId = shortId(`class${input.klass}_${safeFilePart(input.title)}`, context.now);
  const bodyPath = path.join(bodyDir(context, input.klass), `${safeFilePart(recordId)}.md`);
  writeText(bodyPath, input.body.endsWith("\n") ? input.body : `${input.body}\n`);
  const gate = gatedMutation(context, {
    actor: input.actor,
    action: "context.record.write",
    resourceType: `Class${input.klass}`,
    resourceId: recordId,
    reason: `write ${input.kind} context record: ${input.title}`,
    afterPath: bodyPath,
    requiresDirector: input.klass === "A",
    approvedByDirector: input.approvedByDirector ?? input.actor.toLowerCase() === "director",
    metadata: { title: input.title, kind: input.kind, tags: input.tags ?? [] },
  });
  const record: ContextRecord = {
    context_record_id: recordId,
    class: input.klass,
    title: input.title,
    kind: input.kind,
    body_path: bodyPath,
    body_sha256: hashText(readText(bodyPath)),
    source_path: input.sourcePath ? path.resolve(input.sourcePath) : null,
    created_at: isoStamp(context.now),
    updated_at: isoStamp(context.now),
    actor: input.actor,
    gate_record_path: gate.gate_record_path,
    tags: input.tags ?? [],
  };
  writeJson(path.join(recordDir(context, input.klass), `${safeFilePart(recordId)}.json`), record);
  return record;
}

export function bootstrapContext(context: CommandContext): ContextBootstrapResult {
  ensureGovernanceLayout(context.workspaceRoot);
  const classARecords: ContextRecord[] = [];
  const classCRecords: ContextRecord[] = [];
  const gateRecords: MutationGateRecord[] = [];

  const specs = [
    {
      klass: "A" as const,
      title: "governance_policy_v1",
      kind: "policy",
      tags: ["authority", "mutation-gate"],
      body: [
        "# Governance Policy v1",
        "",
        "All authoritative state writes must pass through the Governance Mutation Gate.",
        "ClassA policy/template changes require Director approval.",
        "ClassB is validated operational memory only.",
        "ClassC is source/reference material only.",
        "tmux worker orchestration uses named WSL tmux sessions, file-backed dispatch packets, Backend Loop Ledger evidence, and file-backed Worker Return Packets.",
        "Chat messages are a control surface only; they are not deliverables and cannot trigger completion or ClassB admission.",
        "Only REPORT_READY Worker Return Packets can create Agent Report Ledger candidates, and only accepted reviewed reports can enter ClassB.",
      ].join("\n"),
    },
    {
      klass: "A" as const,
      title: "tmux_worker_orchestration_contract_v0_6",
      kind: "runtime-boundary-contract",
      tags: ["authority", "tmux-worker", "adr-0601"],
      body: [
        "# tmux Worker Orchestration Contract v0.6",
        "",
        "Operations:",
        "- duty_registry.write",
        "- tmux.sessions.find_by_name",
        "- tmux.sessions.observe_by_name",
        "- tmux.sessions.paste_message",
        "- tmux.sessions.submit_enter",
        "- worker_return_packet.classify",
        "- agent_report_ledger.review",
        "",
        "Human Director creates or approves named tmux worker sessions. Backend Operations Coordinator records session state and executes tmux dispatch mechanics.",
        "Incident Commander coordinates assignment questions and rework. Reviewer validates REPORT_READY outputs.",
        "Windows ConPTY and GUI/UIA routes are archived for v0.6. The active route is Codex CLI inside WSL tmux using the copied portable DeepSeek bridge.",
      ].join("\n"),
    },
    {
      klass: "A" as const,
      title: "worker_report_template_v1_1",
      kind: "template",
      tags: ["authority", "classB"],
      body: [
        "# Worker ClassB Final Report Template v1.1",
        "",
        "Required YAML frontmatter:",
        "- template_id",
        "- template_version: 1.1",
        "- assignment_id",
        "- run_id",
        "- worker_role",
        "- progress_comment",
        "",
        "Also accepted after review: B_CLASS_REPORT_BASE template_version 1.0.0 with source_role.",
        "No report enters ClassB until Agent Report Ledger status is accepted by review.",
      ].join("\n"),
    },
    {
      klass: "C" as const,
      title: "tmux_worker_source_note",
      kind: "source-note",
      tags: ["reference", "tmux-worker", "adr-0601"],
      body: [
        "# tmux Worker Source Note",
        "",
        "ADR0601 v0.6 supersedes Windows GUI/UIA control for active work.",
        "Codex CLI through WSL tmux is the active worker path. The DeepSeek bridge is copied into WSL as a portable module and is not driven from Windows for v0.6.",
        "This backend package implements file-backed packets, ledgers, classifier routing, and evidence-gated tmux dispatch statuses.",
      ].join("\n"),
    },
  ];

  for (const spec of specs) {
    const record = writeContextRecord(context, {
      klass: spec.klass,
      title: spec.title,
      kind: spec.kind,
      body: spec.body,
      actor: spec.klass === "A" ? "director" : "backend",
      tags: spec.tags,
      approvedByDirector: spec.klass === "A",
    });
    const gate = readJson<MutationGateRecord>(record.gate_record_path);
    gateRecords.push(gate);
    if (record.class === "A") classARecords.push(record);
    if (record.class === "C") classCRecords.push(record);
  }

  return { ok: true, class_a_records: classARecords, class_c_records: classCRecords, gate_records: gateRecords };
}

export function addContextRecord(context: CommandContext, input: {
  klass: ContextClass;
  title: string;
  kind?: string;
  body?: string;
  sourcePath?: string;
  actor?: string;
  tags?: string[];
  approvedByDirector?: boolean;
}): ContextRecord {
  const body = input.body ?? (input.sourcePath ? readText(path.resolve(input.sourcePath)) : "");
  if (!body.trim()) throw new Error("Context record body is required. Provide --body or --source-file.");
  return writeContextRecord(context, {
    klass: input.klass,
    title: input.title,
    kind: input.kind ?? "note",
    body,
    sourcePath: input.sourcePath ?? null,
    actor: input.actor ?? (input.klass === "A" ? "director" : "backend"),
    tags: input.tags ?? [],
    approvedByDirector: input.approvedByDirector,
  });
}

export function listContextRecords(context: CommandContext, klass?: ContextClass): ContextRecord[] {
  const classes: ContextClass[] = klass ? [klass] : ["A", "B", "C", "D"];
  const records: ContextRecord[] = [];
  for (const item of classes) {
    const dir = recordDir(context, item);
    if (!fileExists(dir)) continue;
    for (const name of fs.readdirSync(dir)) {
      if (name.endsWith(".json")) records.push(readJson<ContextRecord>(path.join(dir, name)));
    }
  }
  return records.sort((a, b) => a.class.localeCompare(b.class) || a.created_at.localeCompare(b.created_at));
}

export function contextSummary(context: CommandContext): Record<string, unknown> {
  const layout = ensureGovernanceLayout(context.workspaceRoot);
  const classBIndex = fileExists(layout.classBIndexPath) ? readJson<Record<string, unknown>>(layout.classBIndexPath) : null;
  const records = listContextRecords(context);
  return {
    generated_at: isoStamp(context.now),
    classA: records.filter((record) => record.class === "A"),
    classB_index: classBIndex,
    classC: records.filter((record) => record.class === "C"),
    classD_record_count: records.filter((record) => record.class === "D").length,
  };
}
