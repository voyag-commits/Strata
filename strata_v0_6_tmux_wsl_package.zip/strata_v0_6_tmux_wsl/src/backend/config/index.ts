import os from "node:os";
import path from "node:path";
import { execFileSync } from "node:child_process";

export interface RuntimeConfig {
  codexExe: string;
  codexConfigPath: string;
  bridgeBaseUrl: string;
  bridgePort: number;
  bridgeModuleRoot: string | null;
  model: string;
  modelProvider: string;
  modelReasoningEffort: string;
  modelContextWindow: number;
  modelMaxOutputTokens: number;
}

function detectCodexFromPath(): string {
  try {
    return execFileSync("which", ["codex"], { encoding: "utf8" }).trim();
  } catch {
    return "codex";
  }
}

export function loadRuntimeConfig(_projectRoot: string, overrides?: Partial<RuntimeConfig>): RuntimeConfig {
  const port = Number(process.env.PORT ?? overrides?.bridgePort ?? 38441);
  const bridgeBaseUrl = overrides?.bridgeBaseUrl ?? process.env.DEEPSEEK_BRIDGE_BASE_URL ?? process.env.OPENAI_BASE_URL ?? `http://127.0.0.1:${port}/v1`;
  return {
    codexExe: overrides?.codexExe ?? process.env.CODEX_EXE ?? detectCodexFromPath(),
    codexConfigPath: overrides?.codexConfigPath ?? process.env.CODEX_CONFIG_PATH ?? path.join(os.homedir(), ".codex", "config.toml"),
    bridgeBaseUrl,
    bridgePort: port,
    bridgeModuleRoot: overrides?.bridgeModuleRoot ?? process.env.DEEPSEEK_BRIDGE_ROOT ?? null,
    model: overrides?.model ?? process.env.DEEPSEEK_MODEL ?? "deepseek-v4-pro",
    modelProvider: overrides?.modelProvider ?? "deepseek_bridge",
    modelReasoningEffort: overrides?.modelReasoningEffort ?? process.env.MODEL_REASONING_EFFORT ?? process.env.DEEPSEEK_REASONING_EFFORT ?? "high",
    modelContextWindow: overrides?.modelContextWindow ?? Number(process.env.DEEPSEEK_MODEL_CONTEXT_WINDOW ?? 1000000),
    modelMaxOutputTokens: overrides?.modelMaxOutputTokens ?? Number(process.env.DEEPSEEK_MAX_OUTPUT_TOKENS ?? 32768),
  };
}
