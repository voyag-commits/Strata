import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";

export interface BridgeGateOptions {
  apiKeyFile?: string;
  apiKeyEnv?: string;
  proxy?: string;
  noProxy?: string;
  proxyAuthKey?: string;
  enableThinking?: boolean;
  reasoningEffort?: string;
  maxOutputTokens?: number;
  modelContextWindow?: number;
  port?: number;
  format?: "json" | "powershell";
}

export interface BridgeGateResult {
  ok: boolean;
  errors: string[];
  warnings: string[];
  env: Record<string, string>;
  redactedEnv: Record<string, string>;
  apiKeySource: "file" | "env";
  proxyConfigured: boolean;
  thinking: {
    enabled: boolean;
    reasoningEffort: "medium" | "high" | "max";
    maxOutputTokens: number;
    modelContextWindow: number;
  };
}

const DEFAULT_NO_PROXY = "127.0.0.1,localhost,::1";

function positiveInt(value: number | undefined, fallback: number): number {
  return typeof value === "number" && Number.isInteger(value) && value > 0 ? value : fallback;
}

function normalizeReasoningEffort(value: string | undefined): "medium" | "high" | "max" {
  if (value === "medium") return "medium";
  return value === "max" || value === "xhigh" ? "max" : "high";
}

function quotePowerShell(value: string): string {
  return `'${value.replace(/'/g, "''")}'`;
}

function readApiKeyFile(file: string): string {
  return fs.readFileSync(path.resolve(file), "utf8").trim();
}

export function buildBridgeGate(options: BridgeGateOptions = {}, env: NodeJS.ProcessEnv = process.env): BridgeGateResult {
  const errors: string[] = [];
  const warnings: string[] = [];
  const apiKeyEnv = options.apiKeyEnv || "DEEPSEEK_API_KEY";
  const apiKeyFile = options.apiKeyFile ? path.resolve(options.apiKeyFile) : undefined;
  const proxy = options.proxy || env.HTTPS_PROXY || env.HTTP_PROXY || env.ALL_PROXY || "";
  const noProxy = options.noProxy || env.NO_PROXY || env.no_proxy || DEFAULT_NO_PROXY;
  const reasoningEffort = normalizeReasoningEffort(options.reasoningEffort || env.DEEPSEEK_REASONING_EFFORT);
  const maxOutputTokens = positiveInt(options.maxOutputTokens ?? Number(env.DEEPSEEK_MAX_OUTPUT_TOKENS), 32768);
  const modelContextWindow = positiveInt(options.modelContextWindow ?? Number(env.DEEPSEEK_MODEL_CONTEXT_WINDOW), 1000000);
  const port = positiveInt(options.port ?? Number(env.PORT), 38441);

  let apiKeySource: "file" | "env" = "env";
  let apiKey = env[apiKeyEnv]?.trim() ?? "";
  if (apiKeyFile) {
    apiKeySource = "file";
    if (!fs.existsSync(apiKeyFile)) {
      errors.push(`API key file does not exist: ${apiKeyFile}`);
    } else {
      apiKey = readApiKeyFile(apiKeyFile);
    }
  }
  if (!apiKey) errors.push(`DeepSeek API key missing. Provide --api-key-file or set ${apiKeyEnv}.`);

  let proxyAuthKey = options.proxyAuthKey || env.PROXY_AUTH_KEY || "";
  if (!proxyAuthKey || proxyAuthKey === "auto") {
    proxyAuthKey = `local-proxy-${crypto.randomUUID().replace(/-/g, "")}`;
  }

  if (proxy && !/^https?:\/\//.test(proxy)) {
    errors.push(`Proxy must include http:// or https:// scheme: ${proxy}`);
  }
  const enableThinking = options.enableThinking ?? env.DEEPSEEK_ENABLE_THINKING !== "0";
  const outputEnv: Record<string, string> = {
    PORT: String(port),
    DEEPSEEK_MODEL: env.DEEPSEEK_MODEL || "deepseek-v4-pro",
    DEEPSEEK_MODELS: env.DEEPSEEK_MODELS || "deepseek-v4-pro,deepseek-v4-flash",
    DEEPSEEK_ENABLE_THINKING: enableThinking ? "1" : "0",
    DEEPSEEK_REASONING_EFFORT: reasoningEffort,
    DEEPSEEK_MAX_OUTPUT_TOKENS: String(maxOutputTokens),
    DEEPSEEK_MODEL_CONTEXT_WINDOW: String(modelContextWindow),
    PROXY_AUTH_KEY: proxyAuthKey,
    NO_PROXY: noProxy,
    no_proxy: noProxy,
  };
  if (apiKey) outputEnv.DEEPSEEK_API_KEY = apiKey;
  if (proxy) {
    outputEnv.HTTPS_PROXY = proxy;
    outputEnv.HTTP_PROXY = proxy;
    outputEnv.ALL_PROXY = proxy;
  }

  const redactedEnv = { ...outputEnv };
  if (redactedEnv.DEEPSEEK_API_KEY) redactedEnv.DEEPSEEK_API_KEY = "<redacted>";
  if (redactedEnv.PROXY_AUTH_KEY) redactedEnv.PROXY_AUTH_KEY = "<redacted>";

  return {
    ok: errors.length === 0,
    errors,
    warnings,
    env: outputEnv,
    redactedEnv,
    apiKeySource,
    proxyConfigured: Boolean(proxy),
    thinking: {
      enabled: enableThinking,
      reasoningEffort,
      maxOutputTokens,
      modelContextWindow,
    },
  };
}

export function renderBridgeGatePowerShell(result: BridgeGateResult, options: BridgeGateOptions = {}): string {
  const lines = [
    "# Bridge environment gate for Codex CLI + DeepSeek API.",
    "# Secrets are loaded into process environment only and are not printed.",
  ];
  if (options.apiKeyFile) {
    lines.push(`$env:DEEPSEEK_API_KEY = (Get-Content -Raw ${quotePowerShell(path.resolve(options.apiKeyFile))}).Trim()`);
  } else if (result.env.DEEPSEEK_API_KEY) {
    lines.push("# DEEPSEEK_API_KEY already provided by caller environment.");
  }
  for (const [key, value] of Object.entries(result.env)) {
    if (key === "DEEPSEEK_API_KEY") continue;
    if (key === "PROXY_AUTH_KEY" && options.proxyAuthKey === "auto") {
      lines.push(`if (!$env:PROXY_AUTH_KEY) { $env:PROXY_AUTH_KEY = 'local-proxy-' + [Guid]::NewGuid().ToString('N') }`);
      continue;
    }
    lines.push(`$env:${key} = ${quotePowerShell(value)}`);
  }
  return `${lines.join("\n")}\n`;
}
