import path from "node:path";
import {
  ensureGovernanceLayout,
  readJson,
  readText,
  shortId,
  type CommandContext,
  writeJson,
  writeText,
} from "../common.js";

export type ValidationStatus = "valid" | "invalid";

export interface ValidationRecord {
  validation_id: string;
  assignment_id: string;
  run_id: string;
  raw_report_path: string;
  validator_version: string;
  status: ValidationStatus;
  errors: string[];
  created_at: string;
  quarantine_path_if_failed: string | null;
  parsed_frontmatter: Record<string, string>;
}

export interface ClassBEntry {
  b_index: number;
  file_path: string;
  entry_type: "worker_final_report";
  source_role: string;
  source_agent_id: string;
  source_run_id: string;
  assignment_id: string;
  milestone_id: string | null;
  progress_comment: string;
  template_id: string;
  template_version: string;
  created_at: string;
  status: "active" | "superseded" | "obsolete" | "outdated";
  superseded_by: number | null;
  marked_by: string | null;
  marked_at: string | null;
  status_reason: string | null;
  relevance_tags: string[];
}

export interface ClassBIndex {
  index_format: string;
  latest_b_index: number;
  ordered_entries: ClassBEntry[];
  active_entries: number[];
  superseded_entries: number[];
  obsolete_entries: number[];
  outdated_entries: number[];
}

function safeFilePart(value: string): string {
  return value.replace(/[^A-Za-z0-9_.-]+/g, "-").replace(/^-+|-+$/g, "") || "item";
}

function slug(value: string): string {
  return safeFilePart(value.toLowerCase()).slice(0, 64) || "progress";
}

function now(context: CommandContext): string {
  return context.now.toISOString();
}

function recordPath(dir: string, id: string): string {
  return path.join(dir, `${safeFilePart(id)}.json`);
}

export function parseFrontmatter(text: string): { ok: boolean; data: Record<string, string>; body: string; errors: string[] } {
  if (!text.startsWith("---\n") && !text.startsWith("---\r\n")) {
    return { ok: false, data: {}, body: text, errors: ["missing YAML frontmatter fence"] };
  }
  const normalized = text.replace(/\r\n/g, "\n");
  const end = normalized.indexOf("\n---\n", 4);
  if (end < 0) return { ok: false, data: {}, body: text, errors: ["missing closing YAML frontmatter fence"] };
  const frontmatter = normalized.slice(4, end).trim();
  const body = normalized.slice(end + 5);
  const data: Record<string, string> = {};
  const errors: string[] = [];
  for (const line of frontmatter.split("\n")) {
    const match = /^([A-Za-z0-9_-]+):\s*(.*)$/.exec(line);
    if (!match) {
      errors.push(`malformed frontmatter line: ${line}`);
      continue;
    }
    data[match[1]] = match[2].trim();
  }
  return { ok: errors.length === 0, data, body, errors };
}

export function validateRawReport(
  context: CommandContext,
  assignmentId: string,
  runId: string,
  rawReportPath: string,
): { validation: ValidationRecord; validation_record_path: string; quarantine_path: string | null } {
  const layout = ensureGovernanceLayout(context.workspaceRoot);
  const text = readText(rawReportPath);
  const parsed = parseFrontmatter(text);
  const errors = [...parsed.errors];
  const templateId = parsed.data.template_id;
  const templateVersion = parsed.data.template_version;
  for (const key of ["template_id", "template_version", "assignment_id", "run_id", "progress_comment"]) {
    if (!parsed.data[key]) errors.push(`missing required frontmatter field: ${key}`);
  }
  const workerReport = templateId === "worker_class_b_final_report" && templateVersion === "1.1";
  const bundleReport = templateId === "B_CLASS_REPORT_BASE" && templateVersion === "1.0.0";
  if (!workerReport && !bundleReport && templateId && templateVersion) {
    errors.push("template_id/template_version must match a locked ClassB report template");
  }
  if (workerReport && !parsed.data.worker_role) errors.push("missing required frontmatter field: worker_role");
  if (bundleReport && !parsed.data.source_role) errors.push("missing required frontmatter field: source_role");
  if (parsed.data.assignment_id && parsed.data.assignment_id !== assignmentId) errors.push("frontmatter assignment_id mismatch");
  if (parsed.data.run_id && parsed.data.run_id !== runId) errors.push("frontmatter run_id mismatch");
  if (/\{[A-Za-z0-9_ -]+\}/.test(text)) errors.push("unresolved template placeholder remains in submitted report");
  const validationId = shortId(`validation_${safeFilePart(assignmentId)}`, context.now);
  let quarantinePath: string | null = null;
  if (errors.length > 0) {
    quarantinePath = path.join(layout.classBQuarantine, `${safeFilePart(validationId)}__${path.basename(rawReportPath)}`);
    writeText(quarantinePath, text);
  }
  const validation: ValidationRecord = {
    validation_id: validationId,
    assignment_id: assignmentId,
    run_id: runId,
    raw_report_path: rawReportPath,
    validator_version: "classb_report_validator.v0_6_tmux",
    status: errors.length > 0 ? "invalid" : "valid",
    errors,
    created_at: now(context),
    quarantine_path_if_failed: quarantinePath,
    parsed_frontmatter: parsed.data,
  };
  return { validation, validation_record_path: writeJson(recordPath(layout.validations, validationId), validation), quarantine_path: quarantinePath };
}

export function materializeClassBEntry(
  context: CommandContext,
  rawReportPath: string,
  validation: ValidationRecord,
  agentId: string,
  relevanceTags: string[] = ["tmux-worker", "report-ready", "reviewed"],
): { class_b_entry: ClassBEntry; class_b_entry_path: string } {
  if (validation.status !== "valid") throw new Error("Cannot materialize invalid report as ClassB.");
  const layout = ensureGovernanceLayout(context.workspaceRoot);
  const index = readJson<ClassBIndex>(layout.classBIndexPath);
  if (index.ordered_entries.some((entry) => entry.assignment_id === validation.assignment_id && entry.source_run_id === validation.run_id)) {
    throw new Error(`ClassB entry already exists for assignment ${validation.assignment_id} run ${validation.run_id}.`);
  }
  const nextIndex = index.latest_b_index + 1;
  const templateVersion = validation.parsed_frontmatter.template_version;
  const progressComment = validation.parsed_frontmatter.progress_comment;
  const role = validation.parsed_frontmatter.worker_role ?? validation.parsed_frontmatter.source_role;
  if (!role) throw new Error("Cannot materialize ClassB entry without worker_role or source_role.");
  const fileName = `B-${String(nextIndex).padStart(6, "0")}__assignment-${safeFilePart(validation.assignment_id)}__progress-${slug(progressComment)}__role-${safeFilePart(role)}__v${safeFilePart(templateVersion)}.md`;
  const entryPath = path.join(layout.classBEntries, fileName);
  writeText(entryPath, readText(rawReportPath));
  const entry: ClassBEntry = {
    b_index: nextIndex,
    file_path: entryPath,
    entry_type: "worker_final_report",
    source_role: role,
    source_agent_id: agentId,
    source_run_id: validation.run_id,
    assignment_id: validation.assignment_id,
    milestone_id: null,
    progress_comment: progressComment,
    template_id: validation.parsed_frontmatter.template_id,
    template_version: templateVersion,
    created_at: now(context),
    status: "active",
    superseded_by: null,
    marked_by: null,
    marked_at: null,
    status_reason: null,
    relevance_tags: relevanceTags,
  };
  const updated: ClassBIndex = { ...index, latest_b_index: nextIndex, ordered_entries: [...index.ordered_entries, entry], active_entries: [...index.active_entries, nextIndex] };
  writeJson(layout.classBIndexPath, updated);
  return { class_b_entry: entry, class_b_entry_path: entryPath };
}
