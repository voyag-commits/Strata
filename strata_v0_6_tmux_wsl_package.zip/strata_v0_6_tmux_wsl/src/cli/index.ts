#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { buildBridgeGate, renderBridgeGatePowerShell } from "../backend/bridge_gate/index.js";
import { appendBackendLoopEvent, ledgerPaths, writeLedgerSnapshot } from "../backend/backend_loop_ledger/index.js";
import { addContextRecord, bootstrapContext, contextSummary, listContextRecords, type ContextClass } from "../backend/context/index.js";
import { createCommandContext, formatTable, readText } from "../backend/common.js";
import { createContextLoadPacket, createWorkDispatchPacket, writeWorkerReturnPacketTemplate, type WorkDispatchKind } from "../backend/packets/index.js";
import { classifyWorkerReturnPacket, scanWatchedReturnFolders, type ClassifyWorkerReturnResult, type WorkerReturnKind } from "../backend/worker_returns/index.js";
import { launchTmuxSession, listTmuxSessionRecords, observeTmuxSession, sendPacketToTmux } from "../backend/tmux_dispatch/index.js";
import { listAgentReports, reviewAgentReport, type AgentReportValidatedStatus } from "../backend/agent_report_ledger/index.js";
import { latestGateDigest, listGateRecords, gateMutation } from "../backend/mutation_gate/index.js";
import { initWorkspace } from "../backend/workspace/index.js";
import { runSecretScan } from "../backend/secret_scan/index.js";

interface ParsedArgs {
  positionals: string[];
  flags: Record<string, string | boolean>;
}

function parseArgs(argv: string[]): ParsedArgs {
  const positionals: string[] = [];
  const flags: Record<string, string | boolean> = {};
  for (let index = 0; index < argv.length; index += 1) {
    const token = argv[index];
    if (!token.startsWith("--")) {
      positionals.push(token);
      continue;
    }
    const key = token.slice(2);
    const next = argv[index + 1];
    if (!next || next.startsWith("--")) {
      flags[key] = true;
      continue;
    }
    flags[key] = next;
    index += 1;
  }
  return { positionals, flags };
}

function optionalString(value: string | boolean | undefined): string | undefined {
  return typeof value === "string" ? value : undefined;
}

function splitList(value: string | boolean | undefined): string[] {
  if (!value || typeof value !== "string") return [];
  return value.split(";").map((item) => item.trim()).filter(Boolean);
}

function requireString(flags: Record<string, string | boolean>, key: string): string {
  const value = flags[key];
  if (typeof value !== "string" || !value.trim()) throw new Error(`Missing --${key}.`);
  return value;
}

function parseContextClass(value: string | boolean | undefined): ContextClass {
  if (value === "A" || value === "B" || value === "C" || value === "D") return value;
  throw new Error("--class must be one of A, B, C, or D.");
}

function parseReturnKind(value: string | boolean | undefined): WorkerReturnKind {
  const allowed: WorkerReturnKind[] = ["ACK", "QUESTION", "BLOCKED", "NEEDS_CLARIFICATION", "PARTIAL_STATUS", "REPORT_READY", "FAILED_WITH_DIAGNOSTIC"];
  if (typeof value === "string" && allowed.includes(value as WorkerReturnKind)) return value as WorkerReturnKind;
  throw new Error(`--kind must be one of ${allowed.join(", ")}.`);
}

function parseReviewDecision(value: string | boolean | undefined): AgentReportValidatedStatus {
  const allowed: AgentReportValidatedStatus[] = ["accepted", "rework_required", "quarantined", "invalid_return_packet"];
  if (typeof value === "string" && allowed.includes(value as AgentReportValidatedStatus)) return value as AgentReportValidatedStatus;
  throw new Error(`--decision must be one of ${allowed.join(", ")}.`);
}

function helpText(): string {
  return [
    "Strata v0.6 WSL/tmux CLI",
    "",
    "Usage:",
    "  strata init [--workspace <path>]",
    "  strata context bootstrap [--workspace <path>]",
    "  strata context add --class A|B|C|D --title <text> (--body <text>|--source-file <path>) [--director-approved]",
    "  strata context list [--class A|B|C|D] [--workspace <path>]",
    "  strata context summary [--workspace <path>]",
    "",
    "  strata sessions create --session <name> --assignment-id <id> --agent-id <id> --role <role> [--cwd <path>] [--command <cmd>] [--bridge-base-url <url>] [--replace]",
    "  strata sessions list [--workspace <path>]",
    "  strata sessions status --session <name> [--workspace <path>]",
    "",
    "  strata packet context-load --assignment-id <id> --agent-id <id> --role <role> [--session <name>]",
    "  strata packet work-dispatch --assignment-id <id> --agent-id <id> --role <role> --kind <kind> --action <text> [--body <text>] [--files <a;b>]",
    "  strata packet return-template --assignment-id <id> --agent-id <id> --role <role> --kind <kind> --nonce <nonce>",
    "  strata dispatch create --assignment-id <id> --agent-id <id> --role <role> --kind <kind> --action <text> [--body <text>]",
    "  strata dispatch send --session <name> --packet <path> [--message <text>|--message-file <path>] [--no-submit]",
    "",
    "  strata returns classify --packet <path> [--workspace <path>]",
    "  strata returns scan [--assignment-id <id>] [--agent-id <id>] [--workspace <path>]",
    "  strata returns watch [--assignment-id <id>] [--agent-id <id>] [--workspace <path>]",
    "",
    "  strata report list [--workspace <path>]",
    "  strata report review --report-id <id> --reviewer-id <id> --decision accepted|rework_required|quarantined|invalid_return_packet [--notes <text>]",
    "  strata classb import --report-id <id> --reviewer-id <id> [--notes <text>]",
    "",
    "  strata evidence inspect [--workspace <path>] [--tail <n>]",
    "  strata bridge gate [--api-key-file <path>] [--format json|bash|powershell]",
    "  strata gate list [--workspace <path>] [--limit <n>]",
    "  strata gate digest [--workspace <path>]",
    "  strata secret-scan [--workspace <path>] [--secret-file <path>]",
    "",
    "Acceptance is live tmux/VS Code observation plus .strata/ledgers/backend_loop_ledger.jsonl. No mock tmux proof script is provided.",
  ].join("\n");
}

function renderBridgeGateBash(env: Record<string, string>): string {
  const quote = (value: string) => `'${value.replace(/'/g, `'"'"'`)}'`;
  return Object.entries(env)
    .filter(([key]) => key !== "DEEPSEEK_API_KEY")
    .map(([key, value]) => `export ${key}=${quote(value)}`)
    .join("\n") + "\n";
}

function appendReturnLedgerEvents(ctx: ReturnType<typeof createCommandContext>, result: ClassifyWorkerReturnResult): void {
  const c = result.classification;
  const p = result.packet;
  appendBackendLoopEvent(ctx, {
    event: "RETURN_FILE_DETECTED",
    actor: "return_watcher",
    assignment_id: c.assignment_id,
    agent_id: c.agent_id,
    role: c.role,
    nonce: p?.nonce ?? null,
    status: "detected",
    artifact: c.packet_path,
    evidence: c.event_record_path,
  });
  appendBackendLoopEvent(ctx, {
    event: "RETURN_PACKET_CLASSIFIED",
    actor: "worker_return_classifier",
    assignment_id: c.assignment_id,
    agent_id: c.agent_id,
    role: c.role,
    nonce: p?.nonce ?? null,
    status: c.return_kind ?? "INVALID_RETURN_PACKET",
    artifact: result.classification_record_path,
    evidence: c.event_record_path,
    note: c.routing_decision,
  });
  if (c.return_kind === "REPORT_READY") {
    appendBackendLoopEvent(ctx, {
      event: "REPORT_LEDGERED",
      actor: "agent_report_ledger",
      assignment_id: c.assignment_id,
      agent_id: c.agent_id,
      role: c.role,
      nonce: p?.nonce ?? null,
      status: "pending_review",
      artifact: c.agent_report_ledger_path,
      evidence: result.classification_record_path,
    });
    appendBackendLoopEvent(ctx, {
      event: "ROUTED_TO_REVIEWER",
      actor: "agent_report_ledger",
      from: "worker_return_classifier",
      to: "reviewer",
      assignment_id: c.assignment_id,
      agent_id: c.agent_id,
      role: c.role,
      nonce: p?.nonce ?? null,
      status: "pending_review",
      artifact: c.agent_report_ledger_path,
      evidence: result.classification_record_path,
    });
  } else if (c.routing_decision.includes("CLASSD") || !c.valid_packet || c.return_kind === "FAILED_WITH_DIAGNOSTIC") {
    appendBackendLoopEvent(ctx, {
      event: "ROUTED_TO_CLASSD",
      actor: "worker_return_classifier",
      assignment_id: c.assignment_id,
      agent_id: c.agent_id,
      role: c.role,
      nonce: p?.nonce ?? null,
      status: c.return_kind ?? "INVALID_RETURN_PACKET",
      artifact: c.class_d_diagnostic_path ?? c.diagnostic_path,
      evidence: result.classification_record_path,
    });
  } else if (c.coordination_thread_path) {
    appendBackendLoopEvent(ctx, {
      event: "ROUTED_TO_IC",
      actor: "worker_return_classifier",
      from: "worker_return_classifier",
      to: "IC",
      assignment_id: c.assignment_id,
      agent_id: c.agent_id,
      role: c.role,
      nonce: p?.nonce ?? null,
      status: c.return_kind ?? "COORDINATION",
      artifact: c.coordination_thread_path,
      evidence: result.classification_record_path,
    });
  }
}

async function main(): Promise<void> {
  const { positionals, flags } = parseArgs(process.argv.slice(2));
  if (positionals.length === 0 || flags.help || positionals.includes("help")) {
    console.log(helpText());
    return;
  }

  const workspace = optionalString(flags.workspace) ?? process.cwd();
  const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..", "..", "..");
  const context = createCommandContext(projectRoot, workspace);
  const [command, subcommand] = positionals;

  if (command === "init") {
    console.log(JSON.stringify(initWorkspace(context), null, 2));
    return;
  }

  if (command === "context" && subcommand === "bootstrap") {
    console.log(JSON.stringify(bootstrapContext(context), null, 2));
    return;
  }

  if (command === "context" && subcommand === "add") {
    const title = requireString(flags, "title");
    const bodyPath = optionalString(flags["source-file"]);
    const body = optionalString(flags.body);
    if (!bodyPath && !body) throw new Error("Missing --body or --source-file.");
    console.log(JSON.stringify(addContextRecord(context, {
      klass: parseContextClass(flags.class),
      title,
      kind: optionalString(flags.kind),
      body,
      sourcePath: bodyPath,
      actor: optionalString(flags.actor),
      tags: splitList(flags.tags),
      approvedByDirector: Boolean(flags["director-approved"]),
    }), null, 2));
    return;
  }

  if (command === "context" && subcommand === "list") {
    const klass = flags.class ? parseContextClass(flags.class) : undefined;
    console.log(JSON.stringify(listContextRecords(context, klass), null, 2));
    return;
  }

  if (command === "context" && subcommand === "summary") {
    console.log(JSON.stringify(contextSummary(context), null, 2));
    return;
  }

  if (command === "sessions" && subcommand === "create") {
    const result = launchTmuxSession(context, {
      sessionName: requireString(flags, "session"),
      assignmentId: requireString(flags, "assignment-id"),
      agentId: requireString(flags, "agent-id"),
      role: requireString(flags, "role"),
      cwd: optionalString(flags.cwd),
      command: optionalString(flags.command),
      bridgeBaseUrl: optionalString(flags["bridge-base-url"]),
      replace: Boolean(flags.replace),
    });
    console.log(JSON.stringify(result, null, 2));
    if (!result.tmux.ok) process.exitCode = 1;
    return;
  }

  if (command === "sessions" && subcommand === "list") {
    const rows = [["session", "assignment", "agent", "role", "status", "command"]];
    for (const r of listTmuxSessionRecords(context)) rows.push([r.session_name, r.assignment_id, r.agent_id, r.role, r.status, r.command]);
    console.log(formatTable(rows));
    return;
  }

  if (command === "sessions" && subcommand === "status") {
    console.log(JSON.stringify(observeTmuxSession(context, requireString(flags, "session")), null, 2));
    return;
  }

  if (command === "packet" && subcommand === "context-load") {
    console.log(JSON.stringify(createContextLoadPacket(context, {
      assignmentId: requireString(flags, "assignment-id"),
      agentId: requireString(flags, "agent-id"),
      role: requireString(flags, "role"),
      sessionName: optionalString(flags.session),
      roleContract: optionalString(flags["role-contract"]),
      assignmentFrame: optionalString(flags["assignment-frame"]),
      contextHeaderPath: optionalString(flags["context-header"]),
    }), null, 2));
    return;
  }

  if ((command === "packet" && subcommand === "work-dispatch") || (command === "dispatch" && subcommand === "create")) {
    console.log(JSON.stringify(createWorkDispatchPacket(context, {
      assignmentId: requireString(flags, "assignment-id"),
      agentId: requireString(flags, "agent-id"),
      role: requireString(flags, "role"),
      dispatchKind: requireString(flags, "kind") as WorkDispatchKind,
      action: requireString(flags, "action"),
      body: optionalString(flags.body),
      referencedFiles: splitList(flags.files),
      fromRole: optionalString(flags["from-role"]),
    }), null, 2));
    return;
  }

  if (command === "packet" && subcommand === "return-template") {
    console.log(JSON.stringify(writeWorkerReturnPacketTemplate(context, {
      assignmentId: requireString(flags, "assignment-id"),
      agentId: requireString(flags, "agent-id"),
      role: requireString(flags, "role"),
      returnKind: parseReturnKind(flags.kind),
      nonce: requireString(flags, "nonce"),
      reportPath: optionalString(flags["report-path"]),
      questionPath: optionalString(flags["question-path"]),
      messagePath: optionalString(flags["message-path"]),
      diagnosticPath: optionalString(flags["diagnostic-path"]),
      evidencePath: optionalString(flags["evidence-path"]),
    }), null, 2));
    return;
  }

  if (command === "dispatch" && subcommand === "send") {
    const result = sendPacketToTmux(context, {
      sessionName: requireString(flags, "session"),
      packetPath: requireString(flags, "packet"),
      message: optionalString(flags.message),
      messagePath: optionalString(flags["message-file"]),
      submit: !flags["no-submit"],
      fromRole: optionalString(flags["from-role"]),
    });
    console.log(JSON.stringify(result, null, 2));
    if (!result.ok) process.exitCode = 1;
    return;
  }

  if (command === "returns" && subcommand === "classify") {
    const result = classifyWorkerReturnPacket(context, requireString(flags, "packet"));
    appendReturnLedgerEvents(context, result);
    console.log(JSON.stringify(result, null, 2));
    return;
  }

  if (command === "returns" && (subcommand === "scan" || subcommand === "watch")) {
    const results = scanWatchedReturnFolders(context, { assignmentId: optionalString(flags["assignment-id"]), agentId: optionalString(flags["agent-id"]) });
    if (results.length === 0) {
      appendBackendLoopEvent(context, {
        event: "RETURN_FILE_NOT_DETECTED",
        actor: subcommand === "watch" ? "return_watcher" : "manual_scan",
        assignment_id: optionalString(flags["assignment-id"]),
        agent_id: optionalString(flags["agent-id"]),
        status: "not_detected",
        evidence: ledgerPaths(context).jsonl,
      });
    }
    for (const result of results) appendReturnLedgerEvents(context, result);
    console.log(JSON.stringify({ count: results.length, results }, null, 2));
    return;
  }

  if (command === "report" && subcommand === "list") {
    console.log(JSON.stringify(listAgentReports(context), null, 2));
    return;
  }

  if (command === "report" && subcommand === "review") {
    const result = reviewAgentReport(context, {
      reportId: requireString(flags, "report-id"),
      reviewerId: requireString(flags, "reviewer-id"),
      decision: parseReviewDecision(flags.decision),
      notes: optionalString(flags.notes),
    });
    appendBackendLoopEvent(context, {
      event: result.review.decision === "accepted" ? "REVIEW_ACCEPTED" : "REVIEW_REWORK_REQUIRED",
      actor: result.review.reviewer_id,
      assignment_id: result.review.assignment_id,
      agent_id: result.review.agent_id,
      status: result.review.decision,
      artifact: result.review_path,
      evidence: result.review.validation_record_path,
      note: result.review.notes,
    });
    appendBackendLoopEvent(context, {
      event: result.review.class_b_entry_path ? "CLASSB_IMPORTED" : "CLASSB_REJECTED_OR_BLOCKED",
      actor: "agent_report_ledger",
      assignment_id: result.review.assignment_id,
      agent_id: result.review.agent_id,
      status: result.review.class_b_entry_path ? "imported" : result.review.decision,
      artifact: result.review.class_b_entry_path,
      evidence: result.review_path,
    });
    console.log(JSON.stringify(result, null, 2));
    return;
  }

  if (command === "classb" && subcommand === "import") {
    const result = reviewAgentReport(context, {
      reportId: requireString(flags, "report-id"),
      reviewerId: requireString(flags, "reviewer-id"),
      decision: "accepted",
      notes: optionalString(flags.notes) ?? "Accepted through classb import command after reviewer validation.",
    });
    appendBackendLoopEvent(context, {
      event: result.review.class_b_entry_path ? "CLASSB_IMPORTED" : "CLASSB_REJECTED_OR_BLOCKED",
      actor: result.review.reviewer_id,
      assignment_id: result.review.assignment_id,
      agent_id: result.review.agent_id,
      status: result.review.class_b_entry_path ? "imported" : result.review.decision,
      artifact: result.review.class_b_entry_path,
      evidence: result.review_path,
    });
    console.log(JSON.stringify(result, null, 2));
    return;
  }

  if (command === "evidence" && subcommand === "inspect") {
    const paths = ledgerPaths(context);
    const tail = typeof flags.tail === "string" ? Number(flags.tail) : 20;
    const jsonlTail = fs.existsSync(paths.jsonl) ? readText(paths.jsonl).split(/\r?\n/).filter(Boolean).slice(-tail) : [];
    console.log(JSON.stringify({
      contract_id: "strata_evidence_inspection.v0_6",
      workspace: context.workspaceRoot,
      strata_root: path.join(context.workspaceRoot, ".strata"),
      backend_loop_ledger_jsonl: paths.jsonl,
      backend_loop_ledger_markdown: paths.markdown,
      snapshot: writeLedgerSnapshot(context),
      tail: jsonlTail,
    }, null, 2));
    return;
  }

  if (command === "bridge" && subcommand === "gate") {
    const result = buildBridgeGate({
      apiKeyFile: optionalString(flags["api-key-file"]),
      apiKeyEnv: optionalString(flags["api-key-env"]),
      proxy: optionalString(flags.proxy),
      noProxy: optionalString(flags["no-proxy"]),
      proxyAuthKey: optionalString(flags["proxy-auth-key"]),
      enableThinking: flags["disable-thinking"] ? false : flags["enable-thinking"] ? true : undefined,
      reasoningEffort: optionalString(flags["reasoning-effort"]),
      maxOutputTokens: typeof flags["max-output-tokens"] === "string" ? Number(flags["max-output-tokens"]) : undefined,
      modelContextWindow: typeof flags["model-context-window"] === "string" ? Number(flags["model-context-window"]) : undefined,
      port: typeof flags.port === "string" ? Number(flags.port) : undefined,
    });
    const format = flags.format === "bash" ? "bash" : flags.format === "powershell" ? "powershell" : "json";
    if (format === "bash") console.log(renderBridgeGateBash(result.env));
    else if (format === "powershell") console.log(renderBridgeGatePowerShell(result, { apiKeyFile: optionalString(flags["api-key-file"]), proxyAuthKey: optionalString(flags["proxy-auth-key"]) }));
    else console.log(JSON.stringify({ ...result, env: result.redactedEnv }, null, 2));
    if (!result.ok) process.exitCode = 1;
    return;
  }

  if (command === "gate" && subcommand === "list") {
    console.log(JSON.stringify(listGateRecords(context, typeof flags.limit === "string" ? Number(flags.limit) : 50), null, 2));
    return;
  }

  if (command === "gate" && subcommand === "digest") {
    console.log(JSON.stringify(latestGateDigest(context), null, 2));
    return;
  }

  if (command === "gate" && subcommand === "evaluate") {
    console.log(JSON.stringify(gateMutation(context, {
      actor: requireString(flags, "actor"),
      action: requireString(flags, "action"),
      resourceType: requireString(flags, "resource-type"),
      resourceId: optionalString(flags["resource-id"]),
      reason: requireString(flags, "reason"),
      evidencePath: optionalString(flags["evidence-path"]),
      approvedByDirector: Boolean(flags["director-approved"]),
      requiresDirector: Boolean(flags["requires-director"]),
    }), null, 2));
    return;
  }

  if (command === "secret-scan") {
    const result = runSecretScan(context, { secretFile: optionalString(flags["secret-file"]) });
    console.log(JSON.stringify(result, null, 2));
    if (result.status === "FAIL") process.exitCode = 1;
    return;
  }

  console.log(helpText());
}

main().catch((error) => {
  console.error(error instanceof Error ? error.message : String(error));
  process.exit(1);
});
