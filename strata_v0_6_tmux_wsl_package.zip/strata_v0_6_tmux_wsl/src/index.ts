#!/usr/bin/env node
import { ProxyAgent, setGlobalDispatcher } from "undici";
import { loadConfig } from "./config.js";
import { createApp } from "./server.js";
import { safeLog } from "./log.js";

const upstreamProxy = process.env.HTTPS_PROXY || process.env.HTTP_PROXY || process.env.ALL_PROXY;
if (upstreamProxy) {
  setGlobalDispatcher(new ProxyAgent(upstreamProxy));
}

const config = loadConfig();
const app = createApp({ config, enableRequestLogs: true });

try {
  await app.listen({ host: "127.0.0.1", port: config.port });
  safeLog("server.start", {
    address: `http://127.0.0.1:${config.port}`,
    responses_url: `http://127.0.0.1:${config.port}/v1/responses`,
    model: config.deepSeekModel,
    auth_enabled: Boolean(config.proxyAuthKey),
    upstream_proxy_enabled: Boolean(upstreamProxy),
  });
} catch (error) {
  safeLog("server.failed", { error: error instanceof Error ? error.message : String(error) });
  process.exit(1);
}
