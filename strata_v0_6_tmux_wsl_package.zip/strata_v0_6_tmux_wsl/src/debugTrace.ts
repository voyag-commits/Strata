import fs from "node:fs";
import path from "node:path";
import type { BridgeConfig } from "./types.js";
import { redact } from "./log.js";

let sequence = 0;

function safeStamp(): string {
  return new Date().toISOString().replace(/[:.]/g, "-");
}

function redactConfiguredSecrets(value: unknown, config: BridgeConfig): unknown {
  const firstPass = redact(value);
  const secrets = [config.deepSeekApiKey, config.proxyAuthKey].filter(
    (secret): secret is string => typeof secret === "string" && secret.length > 0,
  );
  if (secrets.length === 0) return firstPass;
  let text = JSON.stringify(firstPass, null, 2);
  for (const secret of secrets) {
    text = text.split(secret).join("[REDACTED]");
  }
  return JSON.parse(text) as unknown;
}

export function bridgeDebugEnabled(config: BridgeConfig): boolean {
  return Boolean(config.debugTraceDir);
}

export function makeTraceBase(config: BridgeConfig, label: string): string | null {
  if (!config.debugTraceDir) return null;
  fs.mkdirSync(config.debugTraceDir, { recursive: true });
  sequence += 1;
  const safeLabel = label.replace(/[^A-Za-z0-9_.-]/g, "_").slice(0, 80) || "trace";
  return path.join(config.debugTraceDir, `${safeStamp()}_${String(sequence).padStart(4, "0")}_${safeLabel}`);
}

export function writeDebugJson(config: BridgeConfig, filePath: string | null, payload: unknown): void {
  if (!filePath) return;
  const safePayload = redactConfiguredSecrets(payload, config);
  fs.writeFileSync(filePath, `${JSON.stringify(safePayload, null, 2)}\n`, "utf8");
}

export async function writeResponseTextTrace(config: BridgeConfig, filePath: string | null, response: Response): Promise<void> {
  if (!filePath) return;
  try {
    const text = await response.text();
    const safePayload = redactConfiguredSecrets(
      {
        status: response.status,
        statusText: response.statusText,
        headers: Object.fromEntries(response.headers.entries()),
        body: text,
      },
      config,
    );
    fs.writeFileSync(filePath, `${JSON.stringify(safePayload, null, 2)}\n`, "utf8");
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    writeDebugJson(config, filePath, { trace_error: message });
  }
}
