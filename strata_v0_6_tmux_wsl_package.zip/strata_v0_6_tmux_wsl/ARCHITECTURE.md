# Strata v0.6 architecture

## Active runtime

```text
Human Director
  -> BOC operating Strata CLI in VS Code Remote-WSL
  -> tmux_dispatch launcher/sender
  -> named tmux session
  -> Codex CLI
  -> copied portable DeepSeek bridge in WSL
  -> DeepSeek API
```

## Runtime boundary

Strata does not treat chat text as a deliverable. The tmux session is a control surface. The backend trusts only files and ledgers.

```text
Dispatch authority: .strata/dispatches/
Return authority:   .strata/returns/
Runtime evidence:   .strata/evidence/
State ledgers:      .strata/ledgers/
Quarantine:         .strata/quarantine/
```

## Active roles

```text
Human Director: final authority and session approval.
BOC: backend operator; launches/records sessions, dispatches packets, observes ledgers.
IC: assignment coordinator; receives questions, blockers, clarification needs.
Worker: Codex CLI agent inside tmux.
Reviewer: accepts/rejects REPORT_READY outputs before ClassB import.
```

## Context model

```text
ClassA: stable authority and policy header.
ClassB: reviewed operational runtime delta.
ClassC: stable source/reference header.
ClassD: diagnostics, raw evidence, failed returns, traces.
```

For v0.6, ClassB is the primary runtime delta. ClassA and ClassC are mostly stable context headers.

## Bridge ownership

The CodexCLI + DeepSeek bridge is a portable module copied into WSL from the stable Windows setup. Strata records bridge URL/configuration and provides a bridge gate, but this package does not vendor the bridge module.
