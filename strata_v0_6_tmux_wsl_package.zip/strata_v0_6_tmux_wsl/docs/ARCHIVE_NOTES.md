# Archive notes

## ConPTY

ConPTY is not active in v0.6. It was attempted and rejected for this package because of native observation problems. Do not wire ConPTY into the active tmux path.

## Windows GUI/UIA

Windows GUI/UIA injection is excluded from v0.6 active implementation. The current confirmed route is Codex CLI with the portable DeepSeek bridge inside WSL.

## v0.5 ADR bundle

The v0.5 ADR bundle is treated as historical context. v0.6 is represented by the tmux/WSL addendum and the surgically revised milestone document.

## Placeholder Codex boundary

The older placeholder boundary is not the selected runtime. The active runtime is real Codex CLI inside tmux.
