# Portable CodexCLI + DeepSeek bridge note

The bridge module is not vendored in this package.

The confirmed operational decision is to copy the stable Windows-native CodexCLI + DeepSeek API bridge module into WSL and run it locally there. This avoids Windows/WSL boundary issues observed when the bridge remained on Windows.

Strata v0.6 expects:

```text
Codex CLI runs inside WSL tmux.
The DeepSeek bridge runs inside WSL.
Codex CLI config points to the bridge URL.
Secrets stay in shell/session environment or local secret files.
The Strata package records redacted bridge configuration only.
```

Useful checks:

```bash
strata bridge gate --format json
strata bridge gate --format bash
```
