# ADR0601 v0.6 tmux/WSL addendum

## Decision

ADR0601 v0.6 confirms the active live implementation path as:

```text
VS Code Remote-WSL
-> Strata CLI/backend
-> tmux_dispatch launcher/sender
-> Codex CLI inside tmux
-> copied portable CodexCLI + DeepSeek API bridge in WSL
-> Worker Return Packet files
-> Backend Loop Ledger and ClassB review gate
```

## Superseded active paths

```text
Windows ConPTY: archived for v0.6 because it created native observation limitations.
Windows GUI/UIA injection: excluded from v0.6 implementation because the desktop GUI app path was more brittle than Codex CLI + DeepSeek bridge.
```

These paths may remain as historical references only. They must not appear as active runtime code in the v0.6 package.

## Roadmap candidates after v0.6

```text
1. VS Code approach.
2. GUI/UIA injection as a future candidate only, excluding v0.6 implementations.
```

## Acceptance override

Mock tmux tests, preflight scripts, and synthetic proof scripts are not acceptance artifacts for v0.6. Acceptance requires live VS Code/tmux observation and backend JSONL ledger evidence following the ADR0601 milestone sequence.
