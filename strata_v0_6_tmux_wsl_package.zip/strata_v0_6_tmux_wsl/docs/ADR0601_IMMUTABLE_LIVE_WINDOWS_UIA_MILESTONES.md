# ADR0601 Immutable Live WSL tmux Milestones

**Document status:** v0.6 surgical revision of the prior immutable live Windows UIA milestone file. Historical filename retained for continuity.  
**Project:** Harness/Strata ADR-HS-2026-06-0601 live worker path  
**Scope:** WSL tmux dispatch, Codex CLI worker session, worker file return, backend routing, and state-ledger presentation  
**Operator for current phase:** Backend Operations Coordinator (BOC)  
**Date:** 2026-06-08

## 1. Purpose

This document defines the live test milestones for the ADR0601 v0.6 WSL tmux path.

The objective is unchanged from the prior major milestone structure: test whether the backend can route work into one selected worker session, receive a worker return file from the monitored backend folder, and route that return to the correct backend owner: IC, reviewer, ClassD diagnostics, or ClassB admission flow.

The runtime surface is changed:

```text
old active surface: Windows GUI/UIA injection
new active surface: WSL tmux session running Codex CLI
model route: Codex CLI -> copied portable DeepSeek bridge in WSL -> DeepSeek API
```

This document remains intentionally narrow. It does not replace the ADR, governance kernel, ClassB admission contract, or raw evidence files. It defines the operational milestone sequence and required state-ledger presentation for human review.

## 2. Fixed Language

| Term | Definition |
| --- | --- |
| Human Director (HD) | Person who approves runtime direction and worker/session authority. |
| Backend Operations Coordinator (BOC) | Current tester and backend operator. BOC performs session launch/recording, dispatch execution, watcher/classifier operation, evidence collection, and issue resolution. |
| Incident Commander (IC) | Assignment coordinator. IC receives worker questions, blockers, clarification needs, and routing items within assignment authority. |
| Reviewer | Role that reviews `REPORT_READY` outputs before ClassB admission. |
| Worker | The assigned Codex CLI session running inside tmux for a role and assignment. |
| Named tmux session | The routing anchor in WSL, following `STRATA-{ROLE}-{ASSIGNMENT_ID}`. |
| tmux_dispatch launcher/sender | The WSL tmux mechanism used to create/record sessions, paste a packet notice, send Enter, capture pane state, and write evidence. |
| Worker Return Packet | The only backend-recognized worker return file. Chat/session output is not a deliverable. |
| Backend Loop Ledger | Append-only control-loop record showing backend state transitions and routing decisions. |

## 3. Required Revisions from Prior Milestone Draft

### Revision 1: BOC is the tester for the current phase

For the current live WSL tmux phase, BOC is the tester and operator.

BOC owns:

- tmux session creation or recording.
- Work Dispatch Packet or Context Load Packet creation.
- tmux_dispatch launch/send operation.
- Watched return folder scan or watcher operation.
- Worker Return Packet classifier execution.
- Coordination Thread, Agent Report Ledger, ClassD, and ClassB routing observation.
- Evidence collection.
- Blocker diagnosis and local resolution where possible.

HD remains responsible for approving the runtime direction and session authority. IC and reviewer roles remain part of backend routing, but BOC may operate the test workflow when the purpose is backend integration testing.

### Revision 2: Avoid false acceptance language

Milestone language must use operational terms:

- `test`
- `validate`
- `observe`
- `record`
- `route`
- `resolve`
- `acceptance state`
- `blocked state`
- `evidence`

Do not use success phrases such as:

- `works`
- `done`
- `passed everything`
- `live proof`
- `tmux works`
- `mock passed`

A milestone is complete only when the required backend state, worker/session target, artifact path, status code, and evidence path are recorded.

### Revision 3: No mock/preflight acceptance

Mock tmux tests and preflight scripts are not acceptance artifacts. Acceptance is live VS Code/tmux observation plus Backend Loop Ledger records.

## 4. Live Milestones

The current live test has three mandatory milestones. They are ordered and should not be collapsed. Their major definitions are unchanged in intent and order: M1 dispatch, M2 worker file return, M3 backend classification/routing.

---

## M1_BOC_DISPATCH_TO_SELECTED_TMUX_SESSION

### Definition

BOC operates the backend and sends a short dispatch message into one selected named tmux session running Codex CLI.

This milestone tests backend-to-worker routing through WSL tmux.

### Required starting state

- The DeepSeek bridge module has been copied into WSL and started according to its own module instructions.
- Codex CLI inside WSL is configured to use that local bridge.
- BOC has created or recorded a named tmux worker session.
- The session follows the required pattern: `STRATA-{ROLE}-{ASSIGNMENT_ID}`.
- The session is visible in tmux and can be attached from VS Code terminal.
- The registry/session record is treated as operational routing state, not confirmation that the worker processed the task.

### Test action

BOC sends a brief Context Load Packet or Work Dispatch Packet notice to the selected tmux session.

The message must include:

- assignment id
- worker/agent id or role
- packet path
- return folder path
- nonce
- instruction that worker return must be by Worker Return Packet file

### Required acceptance state

The backend records:

- selected `target_runtime = tmux`
- selected `session_name`
- selected `agent_id`
- selected `assignment_id`
- dispatch packet path
- dispatch packet SHA256
- nonce
- tmux command statuses
- dispatch ledger entry
- evidence directory
- tmux pane capture path when available

The tmux_dispatch sender reaches:

- `TMUX_BUFFER_PASTED`
- `TMUX_ENTER_SENT` when submit is enabled
- `TMUX_PANE_CAPTURED` when capture is available

This does not claim that the model completed work. It only records that the packet notice reached the tmux session control surface.

### Blocked state handling

If the milestone blocks, BOC must record one precise state:

- `TMUX_NOT_INSTALLED`
- `SESSION_NOT_FOUND`
- `SESSION_ALREADY_EXISTS`
- `TMUX_BUFFER_LOAD_FAILED`
- `TMUX_PASTE_FAILED`
- `TMUX_ENTER_FAILED`
- `TMUX_CAPTURE_FAILED`
- `BRIDGE_NOT_READY`
- `CODEX_CLI_NOT_READY`
- `BLOCKED_WITH_DIAGNOSTIC`

BOC should resolve local blockers where possible, including:

- install tmux inside WSL
- start or attach the named session
- correct session name
- confirm Codex CLI prompt state
- confirm bridge process is running inside WSL
- rerun the sender after correcting session or bridge state

### Backend Loop Ledger event

M1 must emit one of:

- `WORK_PASSED`
- `DISPATCH_BLOCKED`

---

## M2_WORKER_TASK_AND_FILE_RETURN

### Definition

BOC sends a brief task to a specific tmux session. The assigned worker performs a small task and writes a Worker Return Packet into the backend-monitored folder.

This milestone tests Codex CLI worker task execution and file-based return discipline.

### Required starting state

- M1 completed with `WORK_PASSED`.
- The worker received a brief task notice in the selected tmux session.
- The task is intentionally small and has an exact file output requirement.

### Test action

The assigned worker creates:

- a small report file under the expected reports path
- one Worker Return Packet under `.strata/returns/{assignment_id}/{agent_id}/`

The Worker Return Packet must declare one allowed `return_kind`:

- `ACK`
- `QUESTION`
- `BLOCKED`
- `NEEDS_CLARIFICATION`
- `PARTIAL_STATUS`
- `REPORT_READY`
- `FAILED_WITH_DIAGNOSTIC`

For the primary smoke run, use `REPORT_READY`.

### Required acceptance state

BOC observes and records:

- Worker Return Packet path
- Worker Return Packet SHA256
- `assignment_id`
- `agent_id`
- `role`
- `return_kind`
- nonce
- report path when `return_kind = REPORT_READY`
- evidence path

The worker must not use chat/session text as the deliverable channel. Chat may acknowledge receipt, but it does not satisfy return requirements.

### Blocked state handling

If no file is written, BOC instructs the worker to write the Worker Return Packet file. BOC must not infer completion from chat/session text.

If the file is malformed, BOC records the schema or parse failure and keeps the return out of the Agent Report Ledger and ClassB path.

### Backend Loop Ledger event

M2 must emit:

- `RETURN_FILE_DETECTED`

If the expected file is absent after the test window, emit:

- `RETURN_FILE_NOT_DETECTED`

---

## M3_BACKEND_CLASSIFICATION_AND_ROUTING

### Definition

The backend detects the dropped Worker Return Packet, classifies it, and routes it to the correct backend destination.

This milestone tests the backend return loop after file drop.

### Required starting state

- M2 produced a Worker Return Packet or a precise absence/error state.
- The return folder follows `.strata/returns/{assignment_id}/{agent_id}/`.
- The backend deterministic scan/classify command is run from VS Code terminal.

### Test action

BOC runs or observes backend classification for the Worker Return Packet.

### Required routing table

| Return kind | Required backend route |
| --- | --- |
| `ACK` | Dispatch Ledger update. |
| `QUESTION` | Coordination Thread routed to IC. |
| `BLOCKED` | Coordination Thread routed to IC or HD. |
| `NEEDS_CLARIFICATION` | Coordination Thread routed to IC. |
| `PARTIAL_STATUS` | Coordination Thread or diagnostics. |
| `FAILED_WITH_DIAGNOSTIC` | ClassD/diagnostics and IC. |
| `REPORT_READY` | Agent Report Ledger candidate. |

Only `REPORT_READY` may create an Agent Report Ledger entry.

Only a reviewed and accepted report may enter ClassB.

### Required acceptance state

For `REPORT_READY`, the backend records:

- `RETURN_PACKET_CLASSIFIED`
- `REPORT_LEDGERED`
- Agent Report Ledger entry
- `validated_status = pending_review`
- no ClassB import before review acceptance

For non-final returns, the backend records the correct Coordination Thread or diagnostic route and does not create ClassB material.

### Blocked state handling

If watcher behavior is inconsistent, BOC uses deterministic scan/classify commands. The Backend Loop Ledger must record whether the event came from watcher or manual scan.

### Backend Loop Ledger events

M3 must emit one or more of:

- `RETURN_PACKET_CLASSIFIED`
- `ROUTED_TO_IC`
- `ROUTED_TO_REVIEWER`
- `ROUTED_TO_CLASSD`
- `REPORT_LEDGERED`
- `REVIEW_ACCEPTED`
- `CLASSB_IMPORTED`

## 5. Backend Loop Ledger Standard

### Required files

Every live run must produce both files:

```text
.strata/ledgers/backend_loop_ledger.jsonl
.strata/ledgers/backend_loop_ledger.md
```

The JSONL file is the authoritative control-loop record. The Markdown file is the human-readable mirror.

### Purpose

The Backend Loop Ledger answers these questions without requiring raw log review:

- What did the backend observe?
- Which worker received the work?
- Which tmux session was targeted?
- Was the dispatch injected into the tmux session?
- Did the worker return by file?
- How did the backend classify the return?
- Was the return routed to IC, reviewer, ClassD, or ClassB admission flow?

### Event format

Each ledger line must be one backend state transition.

Required fields:

| Field | Requirement |
| --- | --- |
| `ts` | ISO timestamp. |
| `loop_id` | Monotonic loop event id, for example `0001`. |
| `assignment_id` | Assignment id, for example `A017`. |
| `event` | Controlled event name. |
| `actor` | Backend actor or role that caused the transition. |
| `from` | Source role/component when applicable. |
| `to` | Destination worker/role/component when applicable. |
| `agent_id` | Worker id when applicable. |
| `role` | Worker role when applicable. |
| `target_runtime` | Runtime surface, normally `tmux`. |
| `session_name` | Named tmux session when applicable. |
| `nonce` | Dispatch or return nonce when applicable. |
| `status` | Controlled ADR/backend status. |
| `artifact` | Primary file path affected by the event. |
| `evidence` | Evidence directory or evidence file path. |
| `note` | Short reason when blocked or exceptional. |

### Controlled event names

Use these event names unless an ADR update adds more:

- `DUTY_REGISTERED`
- `DUTY_VERIFIED`
- `SESSION_LAUNCHED`
- `SESSION_STATUS_OBSERVED`
- `WORK_PACKET_CREATED`
- `WORK_PASSED`
- `DISPATCH_BLOCKED`
- `RETURN_FILE_DETECTED`
- `RETURN_FILE_NOT_DETECTED`
- `RETURN_PACKET_CLASSIFIED`
- `ROUTED_TO_IC`
- `ROUTED_TO_REVIEWER`
- `ROUTED_TO_CLASSD`
- `REPORT_LEDGERED`
- `REVIEW_ACCEPTED`
- `REVIEW_REWORK_REQUIRED`
- `CLASSB_IMPORTED`
- `CLASSB_REJECTED_OR_BLOCKED`

### JSONL example

```jsonl
{"ts":"2026-06-08T13:14:31Z","loop_id":"0001","assignment_id":"A017","event":"SESSION_LAUNCHED","actor":"BOC","agent_id":"coder_017","role":"coder","target_runtime":"tmux","session_name":"STRATA-CODER-A017","status":"SESSION_LAUNCHED","artifact":".strata/sessions/STRATA-CODER-A017.json","evidence":".strata/evidence/tmux_sessions/STRATA-CODER-A017/"}
{"ts":"2026-06-08T13:15:04Z","loop_id":"0002","assignment_id":"A017","event":"WORK_PACKET_CREATED","actor":"backend_ops","from":"IC","to":"coder_017","agent_id":"coder_017","role":"coder","target_runtime":"tmux","nonce":"STRATA_NONCE_A017_D001","status":"created","artifact":".strata/dispatches/work_dispatch_packets/A017/packet.md","evidence":".strata/dispatches/work_dispatch_packets/A017/packet.json"}
{"ts":"2026-06-08T13:15:31Z","loop_id":"0003","assignment_id":"A017","event":"WORK_PASSED","actor":"BOC","from":"BOC","to":"coder_017","agent_id":"coder_017","role":"coder","target_runtime":"tmux","session_name":"STRATA-CODER-A017","nonce":"STRATA_NONCE_A017_D001","status":"TMUX_MESSAGE_INJECTED_ENTER_SENT","artifact":".strata/dispatches/work_dispatch_packets/A017/packet.md","evidence":".strata/evidence/tmux_dispatch/A017/coder_017/"}
```

## 6. Raw Log Policy

Raw logs remain required, but they are not the first review surface.

Raw logs belong under evidence folders and may include:

- tmux pane captures
- tmux command result JSON
- dispatch sender diagnostics
- watcher/classifier output
- Mutation Gate records
- ClassB/ClassD materialization output

The Backend Loop Ledger is the required first review surface for HD and IC. Raw logs are opened only when a ledger line is blocked, inconsistent, or under dispute.

## 7. Package Acceptance Rule

A live test package is not ready for review unless it contains:

- this milestone file or a newer HD-approved version
- `.strata/ledgers/backend_loop_ledger.jsonl`
- `.strata/ledgers/backend_loop_ledger.md`
- dispatch ledger entries
- Worker Return Packet files used in the run
- Agent Report Ledger or Coordination Thread output
- ClassB/ClassD output when applicable
- raw evidence folders

The package must label partial runs precisely. If dispatch and worker return use different nonces, the package must not describe the run as one complete dispatch-to-return chain.

## 8. Current Phase Completion Criteria

The current phase is complete only when one single nonce chain records:

```text
WORK_PASSED
-> RETURN_FILE_DETECTED
-> RETURN_PACKET_CLASSIFIED
-> ROUTED_TO_REVIEWER or ROUTED_TO_IC/CLASSD according to return_kind
```

For the primary smoke test using `REPORT_READY`, the complete chain is:

```text
WORK_PASSED
-> RETURN_FILE_DETECTED
-> RETURN_PACKET_CLASSIFIED
-> REPORT_LEDGERED
-> ROUTED_TO_REVIEWER
```

ClassB import is a separate governance continuation and requires accepted review.
