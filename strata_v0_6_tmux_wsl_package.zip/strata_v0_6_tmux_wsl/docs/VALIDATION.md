# Validation notes

Validation performed during package preparation on Linux container:

```text
npm run build: PASS
npm test: PASS, 23/23 bridge/mapper/server sanity tests
secret-scan: PASS, no hits
```

A deterministic CLI contract smoke was also run without tmux runtime:

```text
strata init
strata context bootstrap
strata packet work-dispatch
strata packet return-template
strata returns scan
strata report list
strata report review --report-id <id> --reviewer-id smoke-reviewer --decision accepted
```

The CLI smoke used a valid `REPORT_READY` Worker Return Packet and a valid ClassB report frontmatter block. It reached:

```text
WORK_PACKET_CREATED
RETURN_FILE_DETECTED
RETURN_PACKET_CLASSIFIED
REPORT_LEDGERED
ROUTED_TO_REVIEWER
REVIEW_ACCEPTED
CLASSB_IMPORTED
```

Important limitation:

```text
No live tmux/Codex/DeepSeek session was executed in this container.
No mock tmux proof script was added.
This deterministic CLI smoke is not ADR0601 live acceptance.
The live acceptance target remains VS Code Remote-WSL with real tmux sessions and backend JSONL logs.
```
