# Worktree distillation notes

## Base used

The stable bridge/governance kernel was distilled from `operational_code_evidence_package_20260607_1900`.

## Direction changed for v0.6

The active route is no longer Windows GUI/UIA and no longer ConPTY. The confirmed route is:

```text
Codex CLI + DeepSeek API bridge copied into WSL
Codex CLI launched inside named tmux sessions
Strata dispatches through tmux
Worker returns through files
Backend validates and routes by ledgers
```

## Removed from active package

```text
src/backend/desktop_ui_injection_adapter/
scripts/windows_accessibility_executor.ps1
ConPTY dispatch implementation and scripts
placeholder Codex boundary active path
old live_windows_gui_test_workspace
review_evidence folders
node_modules
dist
nested zip evidence bundles
```

## Replaced or revised

```text
gui_packets -> packets
desktop dispatch -> tmux_dispatch launcher/sender
.harness/governance -> .strata project-local runtime root
adapter gate wording -> bridge gate wording for DeepSeek bridge config
offline proof acceptance -> live VS Code/tmux observation + JSONL ledger
```

## Deliberate retention

```text
DeepSeek bridge server mapper/kernel
Worker Return Packet classifier
Agent Report Ledger
ClassB validation/materialization
Mutation Gate
ClassA/ClassB/ClassC/ClassD context model
Backend Loop Ledger concept
```
