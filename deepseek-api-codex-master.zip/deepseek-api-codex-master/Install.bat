@echo off
setlocal enabledelayedexpansion
title Codex x DeepSeek - Installer

echo.
echo   ============================================
echo     Codex CLI x DeepSeek Bridge - Installer
echo   ============================================
echo.

:: ---- Check Node.js --------------------------------------------------
where node >nul 2>&1
if %errorlevel% neq 0 (
    echo   [X] Node.js not found.
    echo.
    echo   This bridge requires Node.js 22+.
    echo   Download and install it from: https://nodejs.org
    echo   (Choose the LTS version, then re-run this installer.)
    echo.
    pause
    exit /b 1
)
for /f "tokens=1 delims=." %%v in ('node -v') do set NODE_MAJOR=%%v
set NODE_MAJOR=%NODE_MAJOR:~0,1%%NODE_MAJOR:~1,2%
if %NODE_MAJOR% LSS 22 (
    echo   [!] Node.js %NODE_MAJOR% found, but 22+ is recommended.
    echo   Download: https://nodejs.org
    echo.
    choice /c yn /m "Continue anyway"
    if errorlevel 2 exit /b 1
)
echo   [OK] Node.js found.

:: ---- Check Codex CLI -------------------------------------------------
where codex >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo   [X] Codex CLI not found on PATH.
    echo.
    echo   Install Codex CLI with one of these:
    echo     a^) OpenAI Codex desktop app: https://openai.com/codex
    echo     b^) npm:  npm install -g @openai/codex
    echo.
    echo   After installing Codex, re-run this installer.
    echo.
    pause
    exit /b 1
)
echo   [OK] Codex CLI found.

:: ---- Run the PowerShell installer ------------------------------------
echo.
echo   Launching setup (prompts for your DeepSeek API key)...
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install\Install.ps1" -FullAuto
set INSTALL_RESULT=%errorlevel%

if %INSTALL_RESULT% neq 0 (
    echo.
    echo   [X] Installer reported an error. Check the output above.
    echo   You can re-run this file to try again.
    pause
    exit /b %INSTALL_RESULT%
)

:: ---- Done ------------------------------------------------------------
echo.
echo   ============================================
echo     All set! Desktop shortcuts created:
echo.
echo       Codex ^(DeepSeek^)        - thinking max + 2000 token budget
echo       Codex DeepSeek ^(High^)   - thinking effort: high
echo       Codex DeepSeek ^(Max^)    - thinking effort: max
echo.
echo     Double-click any shortcut to launch Codex on DeepSeek.
echo   ============================================
echo.
pause
