# DeepSeek API in Codex

**Run the OpenAI Codex CLI on DeepSeek models — with full control over reasoning
effort and token budget. Cut your Codex costs by 5–10× without losing the
sophisticated harness.**

> Codex CLI is a powerful coding agent: it reads your codebase, plans edits,
> runs tools, and iterates. But OpenAI API pricing scales with every reasoning
> token. This bridge swaps in DeepSeek — you keep the harness, you control the
> spend.

## What this solves

| Problem | Solution |
|---|---|
| **High API costs** running Codex on OpenAI models | Route Codex through DeepSeek at a fraction of the price |
| **No control** over reasoning depth vs. speed | Toggle thinking mode, set effort (`high` / `max`), and pin a token budget |
| **API key exposure** risk in configs | DeepSeek key lives only in a local bridge process — never committed, never sent to Codex |
| **Proxy interference** (VPN / Clash / V2Ray) | Launcher auto-sets `NO_PROXY` so loopback calls stay local |

## Thinking mode & token budget

DeepSeek V4 is a reasoning model. You control how much it thinks — and how much
that costs — with three knobs:

| Knob | Env var | Options | Effect |
|---|---|---|---|
| **Thinking on/off** | `DEEPSEEK_ENABLE_THINKING` | `true` / `false` | Fast path vs. deep reasoning |
| **Reasoning effort** | `DEEPSEEK_REASONING_EFFORT` | `high` / `max` | Depth of reasoning per turn |
| **Token budget** | `DEEPSEEK_THINKING_BUDGET` | e.g. `2000` | Soft cap on reasoning tokens (direct cost lever) |

Three desktop shortcuts ship with sensible presets so you can switch instantly:

- **Codex (DeepSeek)** — thinking on, max effort, 2000 token budget (best coding)
- **Codex DeepSeek (High)** — thinking on, high effort (lighter reasoning)
- **Codex DeepSeek (Max)** — thinking on, max effort (deepest reasoning)

## Architecture

```
  +-----------+     Responses API     +----------------+   chat/completions   +-----------+
  | Codex CLI | --------------------> |  local bridge   | -------------------> | DeepSeek  |
  |(--profile)|    127.0.0.1:38441    | (Fastify, Node) |    api.deepseek.com  |    API    |
  +-----------+ <-------------------- +----------------+ <------------------- +-----------+
             streamed SSE (response.*)       streamed tool calls + text
```

A tiny local bridge translates Codex's Responses API into DeepSeek chat
completions. Codex thinks it's talking to an OpenAI-compatible provider. You
keep the full Codex CLI experience — workspace awareness, tool orchestration,
planning — while DeepSeek handles the model inference at a fraction of the cost.

## Quick start

1. **Download & extract** this repo (or clone it)
2. **Double-click `Install.bat`** — checks Node.js 22+, installs deps, builds the bridge
3. **Paste your DeepSeek API key** when prompted (https://platform.deepseek.com)
4. **Done.** Three desktop shortcuts appear. Double-click any to launch.

Or from the terminal:
```powershell
powershell -ExecutionPolicy Bypass -File .\install\Install.ps1
```

## Prerequisites

- **Windows 10/11** (installer + launcher are PowerShell; the bridge is plain Node)
- **Node.js 22+**
- **Codex CLI** ([desktop app](https://openai.com/codex) or `npm i -g @openai/codex`), v0.137+
- **DeepSeek API key** — https://platform.deepseek.com

## Configuration

Settings live in `~/.codex-deepseek/bridge.env` (created by the installer).
Documented in [`bridge/.env.example`](bridge/.env.example):

| Key | Default | Purpose |
|---|---|---|
| `DEEPSEEK_API_KEY` | — | Your DeepSeek key. Local only. |
| `DEEPSEEK_MODEL` | `deepseek-v4-pro` | Model sent upstream |
| `DEEPSEEK_ENABLE_THINKING` | `true` | Thinking on/off |
| `DEEPSEEK_REASONING_EFFORT` | `max` | `high` or `max` |
| `DEEPSEEK_THINKING_BUDGET` | `2000` | Soft token cap on reasoning |
| `PORT` | `38441` | Local bridge port |
| `UPSTREAM_TIMEOUT_MS` | `120000` | DeepSeek timeout (ms) |

## Security

- DeepSeek key stored in `~/.codex-deepseek/bridge.env`, **never** in the repo
- Codex authenticates to the bridge with a separate local token (`BRIDGE_AUTH_KEY`)
- Bridge binds to `127.0.0.1` only
- `.gitignore` blocks `.env`, `*.key`, `*.log`, `dist/`, `node_modules/`

## Manual / other platforms

The bridge runs on macOS/Linux too:
```bash
cd bridge && npm ci && npm run build
DEEPSEEK_API_KEY=sk-... BRIDGE_AUTH_KEY=$(uuidgen) PORT=38441 node dist/src/index.js
```

Then point Codex at `http://127.0.0.1:38441/v1` (`wire_api` = `responses`,
`env_key` = `BRIDGE_AUTH_KEY`). The PowerShell launcher/installer is
Windows-only.

## License

MIT — see [LICENSE](LICENSE).

---

*Not affiliated with OpenAI or DeepSeek.*
