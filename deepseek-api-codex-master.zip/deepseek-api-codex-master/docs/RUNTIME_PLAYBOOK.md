# RUNTIME_PLAYBOOK

This playbook operates the Harness Runtime Adapter Baseline.

## Install, Build, Test

```bash
npm ci
npm run build
npm test
npm run secret-scan
npm run strata -- help
```

Expected:

- install succeeds
- TypeScript build succeeds
- unit and mocked runtime tests pass
- source package secret scan passes
- CLI help displays the frozen entry points

## Start The DeepSeek Bridge

Use environment variables only. Do not write API keys into source files, `.env`, assignments, logs, traces, or reports.

PowerShell:

```powershell
$env:DEEPSEEK_API_KEY="<local-secret>"
$env:BRIDGE_AUTH_KEY="<local-random-dev-token>"
$env:PORT="38441"
$env:UPSTREAM_TIMEOUT_MS="120000"
$env:STRATA_BRIDGE_DEBUG_TRACE_DIR="<controller-workspace>\context\D_trace\bridge_debug"
npm start
```

Bash:

```bash
export DEEPSEEK_API_KEY="<local-secret>"
export BRIDGE_AUTH_KEY="<local-random-dev-token>"
export PORT=38441
export UPSTREAM_TIMEOUT_MS=120000
export STRATA_BRIDGE_DEBUG_TRACE_DIR="<controller-workspace>/context/D_trace/bridge_debug"
npm start
```

Verify:

```bash
curl http://127.0.0.1:38441/health
curl -H "Authorization: Bearer <local-random-dev-token>" http://127.0.0.1:38441/v1/models
```

## Configure Codex Provider

Codex config must point to the local bridge as a Responses-compatible provider.

Logical config:

```toml
[model_providers.deepseek_bridge]
name = "DeepSeek via local Responses bridge"
base_url = "http://127.0.0.1:38441/v1"
wire_api = "responses"
env_key = "BRIDGE_AUTH_KEY"

[profiles.deepseek_bridge]
model_provider = "deepseek_bridge"
model = "deepseek-v4-pro"
approval_policy = "never"
sandbox_mode = "danger-full-access"
```

Do not package unredacted Codex config.

## Initialize Workspace

```bash
npm run strata -- init --workspace live_validation_workspace
```

The workspace is the controller workspace. It stores assignments, results, traces, indexes, and secret scan reports.

## Create Target Workspace

Use a separate target workspace for worker file access.

```bash
mkdir live_target_workspace
```

The target workspace is the Codex worker working directory.

## Doctor

```bash
npm run strata -- doctor --workspace live_validation_workspace
```

Expected:

- Node PASS
- npm PASS
- Codex CLI PASS
- model/provider config PASS
- workspace folders PASS
- write permissions PASS
- bridge health PASS

If doctor fails, fix local runtime configuration before live validation.

## Create Assignment

```bash
npm run strata -- assignment create \
  --workspace live_validation_workspace \
  --target-workspace live_target_workspace \
  --title "Run command" \
  --objective "Run node math_check.js in the target workspace and report the result." \
  --expected-output "math_check PASS" \
  --allowed-files "math_check.js"
```

The command prints the assignment JSON and prompt paths.

## Run Assignment

```bash
npm run strata -- assignment run \
  --workspace live_validation_workspace \
  --assignment live_validation_workspace/context/B_ledger/assignments/<assignment>.json
```

Expected artifacts:

- raw App Server events JSONL
- stderr log
- run summary JSON
- Class B result markdown and JSON
- Class D trace index markdown
- secret scan report
- run index entry

## Inspect Result

```bash
npm run strata -- result show --workspace live_validation_workspace --run <run-id>
```

## Inspect Trace

```bash
npm run strata -- trace show --workspace live_validation_workspace --run <run-id>
```

## List Runs

```bash
npm run strata -- runs list --workspace live_validation_workspace
```

## Run Secret Scan

```bash
npm run strata -- secret-scan --workspace live_validation_workspace
npm run secret-scan
```

## Failure Diagnosis Flow

1. Run `npm run strata -- doctor --workspace <workspace>`.
2. If Codex fails, verify `CODEX_EXE` points to a runnable Codex binary.
3. If bridge health fails, start or restart the local bridge on port `38441`.
4. If authenticated `/v1/models` fails, verify `BRIDGE_AUTH_KEY` is set in both the bridge process and Codex worker environment.
5. If upstream fails, verify `DEEPSEEK_API_KEY` is set only in the bridge process.
6. Inspect `run.summary.json`.
7. Inspect Class B result for user-facing failure text.
8. Inspect Class D trace for raw events, stderr, and summary paths.
9. Inspect bridge debug traces if enabled.
10. Run secret scan before packaging any evidence.
