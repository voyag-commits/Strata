# ADAPTER_BOUNDARIES

This document defines the frozen boundaries of the Harness Runtime Adapter Baseline.

## Harness Layer

Harness is the controller layer. It owns:

- CLI entry points
- controller workspace creation
- assignment package creation
- worker run initiation
- run summaries
- Class B result artifacts
- Class D operational traces
- run indexing
- diagnostics
- secret scanning

Harness does not implement model reasoning, Codex internals, or DeepSeek protocol behavior directly.

## Codex Worker Layer

Codex CLI/App Server is the worker runtime.

The adapter starts a fresh App Server worker for assignment execution and communicates over stdio. Codex is responsible for:

- interpreting the bounded assignment prompt
- deciding when tools are needed
- reading or editing target workspace files through its own tool runtime
- running commands through its own tool runtime
- emitting App Server protocol events

Harness captures and indexes the worker outputs; it does not scrape terminal UI.

## DeepSeek Bridge Layer

The local bridge is the provider compatibility layer.

It owns:

- `/health`
- `/v1/models`
- `/v1/responses`
- Responses-style request conversion to DeepSeek chat completions
- streamed response conversion
- tool-call conversion
- upstream error mapping
- redacted bridge debug traces

The raw DeepSeek API key belongs only in the bridge process environment.

## Controller Workspace

The controller workspace is the Harness-owned state tree.

It contains:

- assignments
- prompt markdown
- Class B results
- Class D traces
- raw App Server events
- stderr logs
- secret scan reports
- run index

Workers should not treat the controller workspace as their general edit target unless an assignment explicitly says so.

## Target Workspace

The target workspace is the Codex worker working directory and edit area.

Assignments may allow the worker to read, edit, and run commands in this workspace. The target workspace is distinct from the controller workspace.

## Class B Result

Class B is the user-facing result artifact.

It should contain:

- run status
- run ID
- assignment ID
- final useful worker message

Future Harness layers may rely on Class B as the progress feed surface.

## Class D Trace

Class D is the operational trace layer.

It points to:

- raw App Server event JSONL
- stderr log
- run summary JSON

Future Harness layers may use Class D for diagnostics and replay-style review, but it should not be exposed as the primary user-facing progress surface.

## Future Harness Layers May Rely On

- The frozen CLI command names and core arguments.
- Controller/target workspace separation.
- Assignment JSON and prompt markdown creation.
- Run summary, Class B, Class D, events, stderr, secret scan, and run index artifacts.
- Nonzero exits for failed assignment runs and failed secret scans.
- Buffered App Server event handling.
- Bridge-level redaction for configured secrets.

Future layers should not rely on:

- raw local user Codex config paths
- raw API keys
- generated `dist/`
- `node_modules/`
- historical evidence folders as authority
- undocumented runtime modes
