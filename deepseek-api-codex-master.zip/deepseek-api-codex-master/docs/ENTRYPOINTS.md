# ENTRYPOINTS

This file freezes the CLI surface for the Harness Runtime Adapter Baseline.

## Exit Codes

- Success: exit 0
- Doctor FAIL: exit 1
- Secret scan FAIL: exit 1
- Assignment run FAIL/BLOCKED: exit 1
- Invalid CLI usage: exit 1 in the current implementation

## `strata init`

Syntax:

```bash
npm run strata -- init [--workspace <path>]
```

Required inputs:

- optional `--workspace`; defaults to current working directory

Outputs:

- Creates controller workspace context folders:
  - `context/A_contract/`
  - `context/B_ledger/assignments/`
  - `context/B_ledger/results/`
  - `context/B_ledger/test_reports/`
  - `context/C_pool/`
  - `context/D_trace/appserver_events/`
  - `context/D_trace/worker_logs/`
  - `context/D_trace/secret_scans/`
- Writes `strata-workspace.md`
- Prints JSON with paths

Example:

```bash
npm run strata -- init --workspace live_validation_workspace
```

## `strata doctor`

Syntax:

```bash
npm run strata -- doctor [--workspace <path>]
```

Required inputs:

- Codex executable available through `CODEX_EXE`, evidence file, or PATH
- Codex config at `CODEX_CONFIG_PATH` or default user config
- local bridge expected at `PORT`, default `38441`

Outputs:

- Text readiness table
- Exit 0 when no FAIL checks exist
- Exit 1 on FAIL

Example:

```bash
CODEX_EXE=/path/to/codex npm run strata -- doctor --workspace live_validation_workspace
```

## `strata assignment create`

Syntax:

```bash
npm run strata -- assignment create --objective <text> [--workspace <control-path>] [--target-workspace <target-path>] [--allowed-files a;b] [--forbidden-files x;y] [--expected-output <text>] [--stop-conditions a;b] [--runtime-mode appserver] [--title <text>] [--id <id>]
```

Required inputs:

- `--objective`

Outputs:

- Assignment JSON under `context/B_ledger/assignments/`
- Assignment prompt markdown under `context/B_ledger/assignments/`
- JSON response containing assignment paths

Exit behavior:

- Exit 0 on success
- Nonzero on missing objective or unsupported runtime mode

Example:

```bash
npm run strata -- assignment create --workspace controller --target-workspace target --objective "Run node math_check.js and report the result."
```

## `strata assignment run`

Syntax:

```bash
npm run strata -- assignment run --assignment <path> [--workspace <path>] [--secret-file <path>]
```

Required inputs:

- `--assignment` path to assignment JSON
- Codex App Server runtime configured
- local bridge and provider config for live runs

Outputs:

- `context/D_trace/appserver_events/<run>.events.jsonl`
- `context/D_trace/worker_logs/<run>.stderr.log`
- `context/D_trace/worker_logs/<run>.summary.json`
- `context/B_ledger/results/<result>.md`
- `context/B_ledger/results/<result>.json`
- `context/D_trace/worker_logs/<trace>.md`
- `context/D_trace/runs_index.json`
- secret scan report

Exit behavior:

- Exit 0 when turn completes and secret scan passes
- Exit 1 when turn fails, blocks, times out, or secret scan fails

Example:

```bash
npm run strata -- assignment run --workspace controller --assignment controller/context/B_ledger/assignments/example.json
```

## `strata runs list`

Syntax:

```bash
npm run strata -- runs list [--workspace <path>]
```

Outputs:

- Table of run IDs, assignment IDs, statuses, timestamps, result paths, and trace paths.

Example:

```bash
npm run strata -- runs list --workspace controller
```

## `strata result show`

Syntax:

```bash
npm run strata -- result show --run <run-id|assignment-id> [--workspace <path>]
```

Required inputs:

- `--run` with either run ID or assignment ID

Outputs:

- Class B result markdown to stdout

Example:

```bash
npm run strata -- result show --workspace controller --run run_2026-05-27_13-54-09-967Z
```

## `strata trace show`

Syntax:

```bash
npm run strata -- trace show --run <run-id|assignment-id> [--workspace <path>]
```

Required inputs:

- `--run` with either run ID or assignment ID

Outputs:

- Class D trace index markdown to stdout

Example:

```bash
npm run strata -- trace show --workspace controller --run run_2026-05-27_13-54-09-967Z
```

## `strata secret-scan`

Syntax:

```bash
npm run strata -- secret-scan [--workspace <path>] [--secret-file <path>]
```

Outputs:

- Secret scan report under `context/D_trace/secret_scans/`
- JSON response containing status and report path

Exit behavior:

- Exit 0 on PASS
- Exit 1 on FAIL

Example:

```bash
npm run strata -- secret-scan --workspace controller
```
