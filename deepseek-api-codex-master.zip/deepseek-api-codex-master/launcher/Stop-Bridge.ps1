<#
.SYNOPSIS
    Stop the local DeepSeek bridge (frees the port). Safe to run anytime.
#>
$ErrorActionPreference = "Stop"
. "$PSScriptRoot\bridge.lib.ps1"

$cfg  = Get-BridgeConfig
$port = if ($cfg -and $cfg["PORT"]) { [int]$cfg["PORT"] } else { 38441 }

if (Get-PortOwnerPid -Port $port) {
    Stop-PortOwner -Port $port
    if (Get-PortOwnerPid -Port $port) { Write-Err2 "Port $port still in use." }
    else { Write-Ok "DeepSeek bridge stopped (port $port freed)." }
} else {
    Write-Info "No bridge is running on port $port."
}
