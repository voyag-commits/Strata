# bridge.lib.ps1 - shared helpers for the Codex + DeepSeek launcher.
# Dot-source this from the launcher scripts:  . "$PSScriptRoot\bridge.lib.ps1"
# ASCII-only on purpose so Windows PowerShell 5.1 parses it regardless of encoding.

$ErrorActionPreference = "Stop"

# Resolve well-known paths relative to this library.
$script:RepoRoot    = Split-Path -Parent $PSScriptRoot              # ...\CodexCLI_by_DeepseekAPI
$script:BridgeDir   = Join-Path $script:RepoRoot "bridge"
$script:BridgeEntry = Join-Path $script:BridgeDir "dist\src\index.js"
$script:SecretDir   = Join-Path $env:USERPROFILE ".codex-deepseek"
$script:EnvFile     = Join-Path $script:SecretDir "bridge.env"
$script:BridgeLog   = Join-Path $script:SecretDir "bridge.log"
$script:ProfileName = "deepseek_bridge"

function Write-Info  { param($m) Write-Host "[*] $m"  -ForegroundColor Cyan }
function Write-Ok    { param($m) Write-Host "[OK] $m" -ForegroundColor Green }
function Write-Warn2 { param($m) Write-Host "[!] $m"  -ForegroundColor Yellow }
function Write-Err2  { param($m) Write-Host "[X] $m"  -ForegroundColor Red }

# --- Secret store -----------------------------------------------------------

function Get-BridgeConfig {
    # Reads bridge.env into an ordered hashtable. Returns $null if missing.
    if (-not (Test-Path $script:EnvFile)) { return $null }
    $cfg = [ordered]@{}
    foreach ($line in Get-Content $script:EnvFile) {
        $l = $line.Trim()
        if (-not $l -or $l.StartsWith("#") -or -not $l.Contains("=")) { continue }
        $parts = $l.Split("=", 2)
        $cfg[$parts[0].Trim()] = $parts[1].Trim()
    }
    return $cfg
}

function Import-BridgeEnv {
    # Loads bridge.env values into the current process environment.
    $cfg = Get-BridgeConfig
    if (-not $cfg) { throw "Secret store not found: $script:EnvFile. Run Set-DeepSeek-Key.ps1 first." }
    foreach ($k in $cfg.Keys) { Set-Item -Path ("Env:" + $k) -Value $cfg[$k] }
    return $cfg
}

# --- Codex executable resolution -------------------------------------------

function Resolve-CodexExe {
    # Prefer the newest versioned OpenAI Codex install, then PATH.
    $base = Join-Path $env:LOCALAPPDATA "OpenAI\Codex\bin"
    if (Test-Path $base) {
        $exe = Get-ChildItem -Path $base -Recurse -Filter "codex.exe" -ErrorAction SilentlyContinue |
               Sort-Object LastWriteTime -Descending | Select-Object -First 1
        if ($exe) { return $exe.FullName }
    }
    $cmd = Get-Command codex -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    return $null
}

# --- Bridge health / lifecycle ---------------------------------------------

function Test-BridgeHealth {
    param([int]$Port, [int]$TimeoutSec = 3)
    try {
        $r = Invoke-RestMethod "http://127.0.0.1:$Port/health" -TimeoutSec $TimeoutSec
        return ($r.status -eq "ok")
    } catch { return $false }
}

function Test-BridgeAuth {
    # Returns 'match' (our token works), 'mismatch' (401), or 'down'.
    param([int]$Port, [string]$Token)
    try {
        Invoke-RestMethod "http://127.0.0.1:$Port/v1/models" -Headers @{ Authorization = "Bearer $Token" } -TimeoutSec 4 | Out-Null
        return "match"
    } catch {
        $code = $null
        try { $code = $_.Exception.Response.StatusCode.value__ } catch {}
        if ($code -eq 401) { return "mismatch" }
        return "down"
    }
}

function Get-PortOwnerPid {
    param([int]$Port)
    $c = Get-NetTCPConnection -State Listen -LocalPort $Port -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($c) { return $c.OwningProcess } else { return $null }
}

function Stop-PortOwner {
    param([int]$Port)
    $procId = Get-PortOwnerPid -Port $Port
    if ($procId) {
        Write-Warn2 "Stopping process holding port $Port (PID $procId)..."
        Stop-Process -Id $procId -Force -ErrorAction SilentlyContinue
        Start-Sleep -Milliseconds 700
    }
}

function Start-Bridge {
    # Starts the bridge hidden, env already loaded into this process. Returns the Process.
    param([int]$Port)
    if (-not (Test-Path $script:BridgeEntry)) {
        Write-Info "Bridge not built - running npm ci + build (first run only)..."
        Push-Location $script:BridgeDir
        try {
            if (-not (Test-Path (Join-Path $script:BridgeDir "node_modules"))) { & npm ci | Out-Null }
            & npm run build | Out-Null
        } finally { Pop-Location }
    }
    if (Test-Path $script:BridgeLog) { Remove-Item $script:BridgeLog -Force -ErrorAction SilentlyContinue }
    $startArgs = @{
        FilePath               = "node"
        ArgumentList           = @($script:BridgeEntry)
        WindowStyle            = "Hidden"
        PassThru               = $true
        RedirectStandardOutput = $script:BridgeLog
        RedirectStandardError  = ($script:BridgeLog + ".err")
    }
    return (Start-Process @startArgs)
}

function Wait-BridgeReady {
    param([int]$Port, [int]$TimeoutSec = 25)
    $deadline = (Get-Date).AddSeconds($TimeoutSec)
    while ((Get-Date) -lt $deadline) {
        if (Test-BridgeHealth -Port $Port -TimeoutSec 2) { return $true }
        Start-Sleep -Milliseconds 500
    }
    return $false
}

# Reads the reasoning effort the running bridge was started with ("" = default).
function Get-BridgeEffort {
    param([int]$Port)
    try {
        $r = Invoke-RestMethod "http://127.0.0.1:$Port/health" -TimeoutSec 3
        if ($null -eq $r.reasoning_effort) { return "" } else { return [string]$r.reasoning_effort }
    } catch { return $null }
}

# Ensures a usable bridge is running on $Port using token $Token at thinking
# $Effort ("", "high", "max"). Restarts the shared bridge if the effort differs.
# Returns @{ Ready=$bool; Started=$bool }  (Started=$true if WE launched it).
function Ensure-Bridge {
    param([int]$Port, [string]$Token, [string]$Effort = "")
    if (Test-BridgeHealth -Port $Port) {
        $auth = Test-BridgeAuth -Port $Port -Token $Token
        if ($auth -eq "match") {
            $current = Get-BridgeEffort -Port $Port
            if (-not $Effort -or $current -eq $Effort) {
                $lbl = if ($current) { $current } else { "default" }
                Write-Ok "Reusing existing bridge on port $Port (effort: $lbl)."
                return @{ Ready = $true; Started = $false }
            }
            $cl = if ($current) { $current } else { "default" }
            Write-Info "Bridge effort '$cl' != requested '$Effort' - restarting bridge."
            Stop-PortOwner -Port $Port
        }
        else {
            Write-Warn2 "A different/stale bridge occupies port $Port (token mismatch) - replacing it."
            Stop-PortOwner -Port $Port
        }
    }
    elseif (Get-PortOwnerPid -Port $Port) {
        Write-Warn2 "Port $Port is held by a non-responsive process - clearing it."
        Stop-PortOwner -Port $Port
    }
    Write-Info "Starting DeepSeek bridge on port $Port ..."
    $proc = Start-Bridge -Port $Port
    if (Wait-BridgeReady -Port $Port -TimeoutSec 25) {
        Write-Ok "Bridge is healthy on http://127.0.0.1:$Port"
        return @{ Ready = $true; Started = $true; Process = $proc }
    }
    Write-Err2 "Bridge failed to become healthy. Last log lines:"
    if (Test-Path $script:BridgeLog) { Get-Content $script:BridgeLog -Tail 15 | Write-Host }
    $errLog = $script:BridgeLog + ".err"
    if (Test-Path $errLog) { Get-Content $errLog -Tail 15 | Write-Host }
    return @{ Ready = $false; Started = $true; Process = $proc }
}
