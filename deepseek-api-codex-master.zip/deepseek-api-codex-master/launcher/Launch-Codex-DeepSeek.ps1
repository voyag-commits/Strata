<#
.SYNOPSIS
    One-click launcher: starts the local DeepSeek bridge (if needed) and opens
    an interactive Codex CLI session bound to DeepSeek.

.PARAMETER WorkDir
    Directory Codex opens as the project. Defaults to your user profile.
    You can pass any path, e.g.  Launch-Codex-DeepSeek.ps1 -WorkDir C:\code\myproj

.PARAMETER Effort
    DeepSeek thinking effort for this session: "high" or "max". Empty uses the
    bridge/DeepSeek default. Changing it restarts the shared bridge.
#>
param(
    [string]$WorkDir = $env:USERPROFILE,
    [ValidateSet("", "high", "max")]
    [string]$Effort = ""
)

$ErrorActionPreference = "Stop"
. "$PSScriptRoot\bridge.lib.ps1"

# CRITICAL for machines behind a VPN / system proxy (e.g. Clash, V2Ray):
# Codex honours the Windows system (WinINET) proxy and will route its request to
# the LOCAL bridge (127.0.0.1) THROUGH that proxy, which cannot forward to
# localhost and returns "502 Bad Gateway". Force a direct loopback connection by
# putting loopback in NO_PROXY. The bridge itself reaches DeepSeek on its own
# (Node's fetch ignores the proxy and the VPN routes egress transparently).
$loopbackBypass = @("localhost", "127.0.0.1", "::1")
$existingNoProxy = [Environment]::GetEnvironmentVariable("NO_PROXY", "Process")
if ($existingNoProxy) {
    $loopbackBypass = @($loopbackBypass + ($existingNoProxy -split ",")) |
        ForEach-Object { $_.Trim() } | Where-Object { $_ } | Select-Object -Unique
}
$env:NO_PROXY = ($loopbackBypass -join ",")

$Host.UI.RawUI.WindowTitle = "Codex - DeepSeek"
Write-Host ""
Write-Host "  Codex CLI  x  DeepSeek" -ForegroundColor Magenta
Write-Host "  --------------------------------------------" -ForegroundColor DarkGray

try {
    # 1) Secrets ------------------------------------------------------------
    $cfg = Get-BridgeConfig
    if (-not $cfg -or [string]::IsNullOrWhiteSpace($cfg["DEEPSEEK_API_KEY"])) {
        Write-Warn2 "No DeepSeek API key configured yet. Launching setup..."
        & "$PSScriptRoot\Set-DeepSeek-Key.ps1"
        $cfg = Get-BridgeConfig
        if (-not $cfg -or [string]::IsNullOrWhiteSpace($cfg["DEEPSEEK_API_KEY"])) {
            throw "Setup did not produce a DeepSeek API key. Aborting."
        }
    }
    Import-BridgeEnv | Out-Null
    $port  = if ($cfg["PORT"]) { [int]$cfg["PORT"] } else { 38441 }
    $token = $cfg["BRIDGE_AUTH_KEY"]
    # Per-launch thinking effort overrides any default; the bridge reads it at start.
    if ($Effort) { $env:DEEPSEEK_REASONING_EFFORT = $Effort }
    else { [Environment]::SetEnvironmentVariable("DEEPSEEK_REASONING_EFFORT", $null, "Process") }

    # 2) Codex executable ---------------------------------------------------
    $codex = Resolve-CodexExe
    if (-not $codex) {
        Write-Err2 "Codex CLI not found."
        Write-Host  "    Install it (e.g. 'npm i -g @openai/codex' or the Codex desktop app) and re-launch." -ForegroundColor Yellow
        Read-Host "Press Enter to close"; return
    }
    Write-Ok ("Codex: " + $codex)

    # 3) Bridge (self-healing) ---------------------------------------------
    $state = Ensure-Bridge -Port $port -Token $token -Effort $Effort
    if (-not $state.Ready) {
        Write-Err2 "Could not start the DeepSeek bridge. See log: $script:BridgeLog"
        Read-Host "Press Enter to close"; return
    }

    # 4) Launch interactive Codex on the DeepSeek profile -------------------
    if (-not (Test-Path $WorkDir)) { $WorkDir = $env:USERPROFILE }
    $effortLabel = if ($Effort) { $Effort } else { "default" }
    Write-Info ("Opening Codex in: " + $WorkDir)
    Write-Host  "    Model: deepseek-v4-pro  thinking: on  effort: $effortLabel  (profile: $script:ProfileName, port $port)" -ForegroundColor DarkGray
    Write-Host  "    Type /quit or press Ctrl+C twice to exit Codex." -ForegroundColor DarkGray
    Write-Host ""

    Push-Location $WorkDir
    try {
        # Codex drives the console directly; don't let a stray stderr line abort us.
        $ErrorActionPreference = "Continue"
        & $codex --profile $script:ProfileName
    } finally {
        Pop-Location
        $ErrorActionPreference = "Stop"
    }

    Write-Host ""
    Write-Ok "Codex session ended."
    Write-Host "    The DeepSeek bridge is left running for fast re-launch." -ForegroundColor DarkGray
    Write-Host "    To stop it:  launcher\Stop-Bridge.ps1" -ForegroundColor DarkGray
}
catch {
    Write-Err2 $_.Exception.Message
}
finally {
    Write-Host ""
    Read-Host "Press Enter to close"
}
