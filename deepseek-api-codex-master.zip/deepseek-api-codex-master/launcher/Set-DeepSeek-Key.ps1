<#
.SYNOPSIS
    Create or update the local secret store (~/.codex-deepseek/bridge.env) that
    the bridge reads at launch. Your DeepSeek API key never leaves this machine.
#>
$ErrorActionPreference = "Stop"

$secretDir = Join-Path $env:USERPROFILE ".codex-deepseek"
$envFile   = Join-Path $secretDir "bridge.env"
if (-not (Test-Path $secretDir)) { New-Item -ItemType Directory -Path $secretDir | Out-Null }

# Preserve existing values where possible.
$existing = [ordered]@{}
if (Test-Path $envFile) {
    foreach ($line in Get-Content $envFile) {
        $l = $line.Trim()
        if (-not $l -or $l.StartsWith("#") -or -not $l.Contains("=")) { continue }
        $parts = $l.Split("=", 2); $existing[$parts[0].Trim()] = $parts[1].Trim()
    }
}

Write-Host ""
Write-Host "  DeepSeek bridge setup" -ForegroundColor Magenta
Write-Host "  ---------------------" -ForegroundColor DarkGray
if ($existing["DEEPSEEK_API_KEY"]) {
    Write-Host "  A DeepSeek API key is already stored. Press Enter to keep it," -ForegroundColor DarkGray
    Write-Host "  or paste a new key to replace it." -ForegroundColor DarkGray
}
$secure = Read-Host "  DeepSeek API key (sk-...)" -AsSecureString
$bstr   = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
$plain  = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)

$apiKey = if ([string]::IsNullOrWhiteSpace($plain)) { $existing["DEEPSEEK_API_KEY"] } else { $plain.Trim() }
if ([string]::IsNullOrWhiteSpace($apiKey)) { Write-Host "  No key provided; aborting." -ForegroundColor Red; return }

# Stable local proxy token (Codex<->bridge bearer). Keep across runs.
$bridgeToken = if ($existing["BRIDGE_AUTH_KEY"]) { $existing["BRIDGE_AUTH_KEY"] } else { "dsk-" + ([guid]::NewGuid().ToString("N")) }
$model      = if ($existing["DEEPSEEK_MODEL"])  { $existing["DEEPSEEK_MODEL"]  } else { "deepseek-v4-pro" }
$models     = if ($existing["DEEPSEEK_MODELS"]) { $existing["DEEPSEEK_MODELS"] } else { "deepseek-v4-pro,deepseek-v4-flash" }
$baseUrl    = if ($existing["DEEPSEEK_BASE_URL"]) { $existing["DEEPSEEK_BASE_URL"] } else { "https://api.deepseek.com" }
$port       = if ($existing["PORT"]) { $existing["PORT"] } else { "38441" }
$timeout    = if ($existing["UPSTREAM_TIMEOUT_MS"]) { $existing["UPSTREAM_TIMEOUT_MS"] } else { "120000" }
$errorLog   = if ($existing["BRIDGE_ERROR_LOG"]) { $existing["BRIDGE_ERROR_LOG"] } else { Join-Path $secretDir "upstream-errors.log" }
$enableThk  = if ($existing.Contains("DEEPSEEK_ENABLE_THINKING")) { $existing["DEEPSEEK_ENABLE_THINKING"] } else { "true" }
$thkBudget  = if ($existing.Contains("DEEPSEEK_THINKING_BUDGET")) { $existing["DEEPSEEK_THINKING_BUDGET"] } else { "2000" }
$effort     = if ($existing.Contains("DEEPSEEK_REASONING_EFFORT")) { $existing["DEEPSEEK_REASONING_EFFORT"] } else { "max" }

$lines = @(
    "# Local secrets + runtime config for the Codex<->DeepSeek bridge.",
    "# Holds your real DeepSeek key. Keep this file private; it stays on this machine.",
    "DEEPSEEK_API_KEY=$apiKey",
    "BRIDGE_AUTH_KEY=$bridgeToken",
    "DEEPSEEK_BASE_URL=$baseUrl",
    "DEEPSEEK_MODEL=$model",
    "DEEPSEEK_MODELS=$models",
    "PORT=$port",
    "UPSTREAM_TIMEOUT_MS=$timeout",
    "# Thinking is ON by default. Set false for the fast non-thinking path.",
    "DEEPSEEK_ENABLE_THINKING=$enableThk",
    "# Optional numeric reasoning-token budget (soft hint to DeepSeek). Default 2000.",
    "DEEPSEEK_THINKING_BUDGET=$thkBudget",
    "# Default effort is max for best reasoning depth. High/Max shortcuts override per-launch.",
    "DEEPSEEK_REASONING_EFFORT=$effort",
    "# One JSON line per upstream failure (self-diagnoses any 502).",
    "BRIDGE_ERROR_LOG=$errorLog"
)
Set-Content -Path $envFile -Value $lines -Encoding utf8
Write-Host ""
Write-Host "  Saved: $envFile" -ForegroundColor Green
Write-Host "  Model: $model   Port: $port" -ForegroundColor DarkGray
