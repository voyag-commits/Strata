@echo off
rem One-click entry point: start the DeepSeek bridge and open Codex.
rem Double-click this, or use the desktop shortcut that points at it.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0launcher\Launch-Codex-DeepSeek.ps1" %*
