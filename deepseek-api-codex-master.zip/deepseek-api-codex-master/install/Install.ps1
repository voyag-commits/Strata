<#
.SYNOPSIS
    One-shot setup for the Codex + DeepSeek bridge on Windows.

    Does everything a fresh machine needs:
      1. Builds the local bridge (npm ci + npm run build).
      2. Prompts for your DeepSeek API key and stores it locally (never in the repo).
      3. Writes the Codex profile  ~/.codex/deepseek_bridge.config.toml  (v0.137+).
      4. Creates a "Codex (DeepSeek)" desktop shortcut for one-click launch.

    Re-runnable: safe to run again to update the key or repair the setup.

.PARAMETER FullAuto
    Write the profile with approval_policy="never" / sandbox_mode="danger-full-access"
    (Codex runs commands and edits files without asking). Omit for the safer default
    (on-request / workspace-write).
#>
param([switch]$FullAuto)

$ErrorActionPreference = "Stop"
$repoRoot   = Split-Path -Parent $PSScriptRoot
$launcher   = Join-Path $repoRoot "launcher"
. (Join-Path $launcher "bridge.lib.ps1")

Write-Host ""
Write-Host "  Codex x DeepSeek - installer" -ForegroundColor Magenta
Write-Host "  ===========================" -ForegroundColor DarkGray

# --- 0) Prerequisites ------------------------------------------------------
$node = Get-Command node -ErrorAction SilentlyContinue
if (-not $node) { Write-Err2 "Node.js 22+ is required and was not found on PATH. Install it from https://nodejs.org and re-run."; return }
$codex = Resolve-CodexExe
if ($codex) { Write-Ok ("Codex CLI: " + $codex) }
else { Write-Warn2 "Codex CLI not found yet. Install it (the OpenAI Codex app, or 'npm i -g @openai/codex') before launching. Continuing setup." }

# --- 1) Build the bridge ---------------------------------------------------
$bridgeDir = Join-Path $repoRoot "bridge"
Write-Info "Building the bridge (npm ci + build)..."
Push-Location $bridgeDir
try {
    if (-not (Test-Path (Join-Path $bridgeDir "node_modules"))) { & npm ci }
    & npm run build
} finally { Pop-Location }
if (-not (Test-Path (Join-Path $bridgeDir "dist\src\index.js"))) { Write-Err2 "Build did not produce dist\src\index.js. Aborting."; return }
Write-Ok "Bridge built."

# --- 2) DeepSeek API key (local secret store) ------------------------------
& (Join-Path $launcher "Set-DeepSeek-Key.ps1")
$cfg = Get-BridgeConfig
if (-not $cfg -or [string]::IsNullOrWhiteSpace($cfg["DEEPSEEK_API_KEY"])) { Write-Err2 "No API key stored; aborting."; return }

# --- 3) Codex profile (v0.137+ per-file profile) ---------------------------
$codexHome = Join-Path $env:USERPROFILE ".codex"
if (-not (Test-Path $codexHome)) { New-Item -ItemType Directory -Path $codexHome | Out-Null }
$profilePath = Join-Path $codexHome "deepseek_bridge.config.toml"
$model = if ($cfg["DEEPSEEK_MODEL"]) { $cfg["DEEPSEEK_MODEL"] } else { "deepseek-v4-pro" }
$port  = if ($cfg["PORT"]) { $cfg["PORT"] } else { "38441" }
if ($FullAuto) { $approval = "never"; $sandbox = "danger-full-access" } else { $approval = "on-request"; $sandbox = "workspace-write" }

$profile = @"
# Codex CLI profile: DeepSeek via the local Responses bridge (v0.137+).
# Select with:  codex --profile deepseek_bridge
# Managed by the codex-deepseek-bridge installer.

model = "$model"
model_provider = "deepseek_bridge"
approval_policy = "$approval"
sandbox_mode = "$sandbox"
model_context_window = 128000
model_max_output_tokens = 32768
model_reasoning_effort = "xhigh"

[model_providers.deepseek_bridge]
name = "DeepSeek via local Responses bridge"
base_url = "http://127.0.0.1:$port/v1"
wire_api = "responses"
env_key = "BRIDGE_AUTH_KEY"
"@
[System.IO.File]::WriteAllText($profilePath, $profile, (New-Object System.Text.UTF8Encoding($false)))
Write-Ok ("Codex profile written: " + $profilePath + "  (approval=$approval, sandbox=$sandbox)")

# Warn if a legacy profile table exists in config.toml (would conflict with --profile).
$configToml = Join-Path $codexHome "config.toml"
if ((Test-Path $configToml) -and ((Get-Content $configToml -Raw) -match '\[profiles\.deepseek_bridge\]')) {
    Write-Warn2 "Your config.toml contains a legacy [profiles.deepseek_bridge] table."
    Write-Host  "    Codex v0.134+ requires you to REMOVE that table (and any 'profile =' selector)" -ForegroundColor Yellow
    Write-Host  "    from $configToml - the per-file profile above replaces it." -ForegroundColor Yellow
}

# --- 4) Desktop shortcuts (default + High + Max thinking) ------------------
$desk = [Environment]::GetFolderPath('Desktop')
$ws = New-Object -ComObject WScript.Shell
$launcherPs1 = Join-Path $launcher 'Launch-Codex-DeepSeek.ps1'
$icon = if ($codex) { "$codex,0" } else { "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe,0" }
$shortcuts = @(
    @{ Name = "Codex (DeepSeek).lnk";     Effort = "";     Desc = "Codex on DeepSeek (thinking on, default effort)" },
    @{ Name = "Codex DeepSeek (High).lnk"; Effort = "high"; Desc = "Codex on DeepSeek (thinking effort: high)" },
    @{ Name = "Codex DeepSeek (Max).lnk";  Effort = "max";  Desc = "Codex on DeepSeek (thinking effort: max)" }
)
foreach ($sc in $shortcuts) {
    $argline = "-NoProfile -ExecutionPolicy Bypass -File `"$launcherPs1`""
    if ($sc.Effort) { $argline += " -Effort " + $sc.Effort }
    $lnk = $ws.CreateShortcut((Join-Path $desk $sc.Name))
    $lnk.TargetPath       = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
    $lnk.Arguments        = $argline
    $lnk.WorkingDirectory = $repoRoot
    $lnk.WindowStyle      = 1
    $lnk.Description       = $sc.Desc
    $lnk.IconLocation     = $icon
    $lnk.Save()
    Write-Ok ("Shortcut created: " + $sc.Name)
}

Write-Host ""
Write-Host "  Done. Desktop shortcuts:" -ForegroundColor Green
Write-Host "    Codex (DeepSeek)        - thinking on, default effort" -ForegroundColor DarkGray
Write-Host "    Codex DeepSeek (High)   - thinking effort: high" -ForegroundColor DarkGray
Write-Host "    Codex DeepSeek (Max)    - thinking effort: max" -ForegroundColor DarkGray
