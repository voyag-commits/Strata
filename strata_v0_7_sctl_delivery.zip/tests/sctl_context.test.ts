import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import test from "node:test";
import { createCommandContext, hashText, readJson, readText, type CommandContext } from "../src/backend/common.js";
import {
  approveProposal,
  createContextProposal,
  listAuthoritativeContext,
  mergeProposal,
  repoStatus,
  validateProposalTool,
  writeManualInvalidProposalForTests,
} from "../src/backend/context_git/index.js";
import { exportContextMarkdown, exportContextPdf } from "../src/backend/context_export/index.js";
import { registerClassDSession, exportClassDPdf, verifyClassDChecksums } from "../src/backend/classd/index.js";
import { listTools } from "../src/backend/tool_registry/index.js";

function tempContext(name: string): CommandContext {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), `${name}-`));
  return createCommandContext(process.cwd(), root);
}

function approveAndMerge(ctx: CommandContext, proposalId: string): void {
  const approved = approveProposal(ctx, { proposalId, reviewerId: `rev-${proposalId}`, reviewerRole: "reviewer" });
  assert.equal(approved.ok, true);
  const merged = mergeProposal(ctx, { proposalId, callerId: "hd", callerRole: "human_director" });
  assert.equal(merged.ok, true);
}

test("Git-backed proposal workflow enforces authority boundaries", () => {
  const ctx = tempContext("strata-authority");
  const status = repoStatus(ctx);
  assert.equal(status.ok, true);
  assert.match(String(status.context_repo_path), /context_repo$/);

  const proposal = createContextProposal(ctx, {
    proposalId: "p-authority",
    callerId: "worker1",
    callerRole: "worker",
    klass: "B",
    semanticId: "B-AUTH-001",
    title: "Authority Test",
    body: "Reviewed operational context only.",
    originDispatchChannel: "file:./worker1_review_message.md",
  });
  assert.equal(proposal.ok, true);

  assert.throws(() => approveProposal(ctx, { proposalId: "p-authority", reviewerId: "worker1", reviewerRole: "worker" }), /Worker callers cannot approve/);
  const approved = approveProposal(ctx, { proposalId: "p-authority", reviewerId: "reviewer1", reviewerRole: "reviewer" });
  assert.equal(approved.ok, true);
  assert.throws(() => mergeProposal(ctx, { proposalId: "p-authority", callerId: "reviewer1", callerRole: "reviewer" }), /Only the Human Director/);

  const merged = mergeProposal(ctx, { proposalId: "p-authority", callerId: "director1", callerRole: "human_director" });
  assert.equal(merged.ok, true);
  const listing = listAuthoritativeContext(ctx);
  assert.deepEqual((listing.files as string[]).includes("class_b/entries/B-AUTH-001.md"), true);
});

test("validator rejects invalid schema and disallowed paths", () => {
  const ctx = tempContext("strata-validation");
  repoStatus(ctx);
  assert.throws(() => createContextProposal(ctx, {
    proposalId: "p-bad-path",
    callerId: "worker1",
    callerRole: "worker",
    klass: "B",
    semanticId: "B-BAD-PATH",
    targetPath: "../outside.md",
    body: "bad",
  }), /escapes repository root|Disallowed/);

  writeManualInvalidProposalForTests(ctx, {
    proposalId: "p-invalid-schema",
    callerId: "worker1",
    callerRole: "worker",
    targetPath: "class_b/entries/bad.md",
    content: "# Missing Class B frontmatter\n",
  });
  const validation = validateProposalTool(ctx, { proposalId: "p-invalid-schema" });
  assert.equal(validation.ok, false);
  assert.match((validation.errors as string[]).join("\n"), /Class B Markdown frontmatter/);
  assert.equal(fs.existsSync(String(validation.result_path)), true);
});

test("A/B/C export renders A, then C file pins, then B timing index without mutating context", () => {
  const ctx = tempContext("strata-export");
  repoStatus(ctx);
  createContextProposal(ctx, { proposalId: "p-a", callerId: "workerA", callerRole: "worker", klass: "A", semanticId: "A-ORDER", title: "A Order", body: "# A comes first" });
  approveAndMerge(ctx, "p-a");

  const pinnedFile = path.join(ctx.workspaceRoot, "pinned.txt");
  fs.writeFileSync(pinnedFile, "pin source\n", "utf8");
  createContextProposal(ctx, { proposalId: "p-c", callerId: "workerC", callerRole: "worker", klass: "C", semanticId: "C-ORDER", pinnedPath: pinnedFile, checksumSha256: hashText(readText(pinnedFile)) });
  approveAndMerge(ctx, "p-c");

  createContextProposal(ctx, { proposalId: "p-b", callerId: "workerB", callerRole: "worker", klass: "B", semanticId: "B-ORDER", title: "B Order", body: "B comes after timing index." });
  approveAndMerge(ctx, "p-b");

  const before = listAuthoritativeContext(ctx).files as string[];
  const md = exportContextMarkdown(ctx, { out: path.join(ctx.workspaceRoot, "exports", "md") });
  assert.equal(md.ok, true);
  const content = fs.readFileSync(String(md.context_markdown_path), "utf8");
  const aPos = content.indexOf("## 1. Class A context");
  const cPos = content.indexOf("## 2. Class C context for file pins");
  const bPos = content.indexOf("## 3. Class B context with timing index");
  assert.ok(aPos >= 0 && cPos > aPos && bPos > cPos);
  assert.match(content, /class_b\/timing_index\.json/);
  const pdf = exportContextPdf(ctx, { out: path.join(ctx.workspaceRoot, "exports", "pdf") });
  assert.equal(pdf.ok, true);
  assert.equal(fs.readFileSync(String(pdf.context_pdf_path), "utf8").startsWith("%PDF-1.4"), true);
  const after = listAuthoritativeContext(ctx).files as string[];
  assert.deepEqual(after, before);
});

test("Class D transcript tools remain outside A/B/C and verify checksums", () => {
  const ctx = tempContext("strata-classd");
  repoStatus(ctx);
  const source = path.join(ctx.workspaceRoot, "codex-session.jsonl");
  fs.writeFileSync(source, '{"role":"user","content":"hello"}\n', "utf8");
  const registered = registerClassDSession(ctx, { sessionId: "session-1", source });
  assert.equal(registered.ok, true);
  const pdf = exportClassDPdf(ctx, { sessionId: "session-1" });
  assert.equal(pdf.ok, true);
  const verified = verifyClassDChecksums(ctx, { sessionId: "session-1" });
  assert.equal(verified.ok, true);
  const listing = listAuthoritativeContext(ctx).files as string[];
  assert.equal(listing.some((item) => item.includes("class_d")), false);
});

test("tool registry contains unified context export tools and Class D tools", () => {
  const ctx = tempContext("strata-tools");
  const result = listTools(ctx);
  assert.equal(result.ok, true);
  const toolIds = (result.tools as Array<{ tool_id: string }>).map((tool) => tool.tool_id);
  assert.ok(toolIds.includes("context.export_markdown.v1"));
  assert.ok(toolIds.includes("context.export_pdf.v1"));
  assert.ok(toolIds.includes("classd.export_pdf.v1"));
  const registry = readJson<{ tools: Array<{ tool_id: string; mutation_gate_policy: string }> }>(String(result.registry_path));
  assert.equal(registry.tools.find((tool) => tool.tool_id === "context.export_pdf.v1")?.mutation_gate_policy, "retired_not_applicable");
});
