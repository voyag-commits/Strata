# tmux Worker Orchestration Contract v0.6

Operations:
- duty_registry.write
- tmux.sessions.find_by_name
- tmux.sessions.observe_by_name
- tmux.sessions.paste_message
- tmux.sessions.submit_enter
- worker_return_packet.classify
- agent_report_ledger.review

Human Director creates or approves named tmux worker sessions. Backend Operations Coordinator records session state and executes tmux dispatch mechanics.
Incident Commander coordinates assignment questions and rework. Reviewer validates REPORT_READY outputs.
Windows ConPTY and GUI/UIA routes are archived for v0.6. The active route is Codex CLI inside WSL tmux using the copied portable DeepSeek bridge.
