# Worker ClassB Final Report Template v1.1

Required YAML frontmatter:
- template_id
- template_version: 1.1
- assignment_id
- run_id
- worker_role
- progress_comment

Also accepted after review: B_CLASS_REPORT_BASE template_version 1.0.0 with source_role.
No report enters ClassB until Agent Report Ledger status is accepted by review.
