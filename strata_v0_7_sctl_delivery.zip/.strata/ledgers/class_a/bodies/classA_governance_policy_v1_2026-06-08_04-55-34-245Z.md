# Governance Policy v1

All authoritative state writes must pass through the Governance Mutation Gate.
ClassA policy/template changes require Director approval.
ClassB is validated operational memory only.
ClassC is source/reference material only.
tmux worker orchestration uses named WSL tmux sessions, file-backed dispatch packets, Backend Loop Ledger evidence, and file-backed Worker Return Packets.
Chat messages are a control surface only; they are not deliverables and cannot trigger completion or ClassB admission.
Only REPORT_READY Worker Return Packets can create Agent Report Ledger candidates, and only accepted reviewed reports can enter ClassB.
