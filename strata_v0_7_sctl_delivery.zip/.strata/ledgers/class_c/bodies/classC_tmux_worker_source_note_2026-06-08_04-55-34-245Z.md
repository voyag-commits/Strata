# tmux Worker Source Note

ADR0601 v0.6 supersedes Windows GUI/UIA control for active work.
Codex CLI through WSL tmux is the active worker path. The DeepSeek bridge is copied into WSL as a portable module and is not driven from Windows for v0.6.
This backend package implements file-backed packets, ledgers, classifier routing, and evidence-gated tmux dispatch statuses.
