﻿# Bridge Placement Record
created_at: 2026-06-08T12:56:08Z

## Location
- Windows path: C:\Users\hou16\Downloads\Development_06_08\extracted\strata\strata_v0_6_tmux_wsl\bridge\bridge\
- WSL path (when copied): /mnt/c/Users/hou16/Downloads/Development_06_08/extracted/strata/strata_v0_6_tmux_wsl/bridge/bridge/
- Bridge URL: http://127.0.0.1:38441/v1

## Configuration
- API key source: bridge/bridge/.env (file-backed, not in repo)
- Model: deepseek-v4-pro
- Thinking: enabled, max effort, 2000 token budget
- Port: 38441
- Auth: BRIDGE_AUTH_KEY set, repo-only reference is .env.local

## Codex CLI bridge pointer
- .env.local at workspace root: OPENAI_BASE_URL=http://127.0.0.1:38441/v1

## Verification
- strata bridge gate --format json: ok, all secrets redacted
- secret-scan: PASS, zero hits
- bridge health check: 200 OK
