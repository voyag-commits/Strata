﻿import { spawnSync } from "node:child_process";
import path from "node:path";
import { ensureGovernanceLayout, ensureDir, isoStamp, writeJson, writeText, type CommandContext } from "../common.js";
import { appendBackendLoopEvent } from "../backend_loop_ledger/index.js";
import { findDispatchByNonce, type DispatchLedgerEntry } from "../dispatch_ledger/index.js";

export interface WorkerDenialRecord {
  contract_id: "worker_denial.record.v1";
  denial_id: string;
  assignment_id: string;
  agent_id: string;
  role: string;
  nonce: string | null;
  session_name: string;
  reason_category: "INVALID_RETURN_PACKET" | "REVIEW_REJECTED" | "REWORK_REQUIRED" | "QUARANTINED" | "VALIDATION_FAILED";
  reason_detail: string;
  errors: string[];
  sent_to_tmux: boolean;
  tmux_status: string;
  evidence_dir: string;
  created_at: string;
}

export interface WorkerDenialEvidence {
  contract_id: "worker_denial.evidence.v1";
  denial_id: string;
  message_injected: string;
  tmux_has_session: boolean;
  tmux_load_buffer: { ok: boolean; status: number | null; stderr: string };
  tmux_paste_buffer: { ok: boolean; status: number | null; stderr: string };
  tmux_send_enter: { ok: boolean; status: number | null; stderr: string };
  created_at: string;
}

function safe(value: string): string {
  return value.replace(/[^A-Za-z0-9_.-]+/g, "-").replace(/^-+|-+$/g, "") || "item";
}

function runTmux(args: string[]): { ok: boolean; status: number | null; stdout: string; stderr: string } {
  const result = spawnSync("tmux", args, { encoding: "utf8" });
  return {
    ok: result.status === 0,
    status: result.status,
    stdout: result.stdout ?? "",
    stderr: result.stderr ?? (result.error ? result.error.message : ""),
  };
}

function tmuxAvailable(): boolean {
  return runTmux(["-V"]).ok;
}

function findSessionForDispatch(ctx: CommandContext, nonce: string | null): DispatchLedgerEntry | null {
  if (!nonce) return null;
  try { return findDispatchByNonce(ctx, nonce); } catch { return null; }
}

function formatDenialMessage(
  category: WorkerDenialRecord["reason_category"],
  assignmentId: string, agentId: string, nonce: string | null,
  detail: string, errors: string[],
): string {
  const border = "=".repeat(60);
  let reasonLabel: string;
  switch (category) {
    case "INVALID_RETURN_PACKET": reasonLabel = "RETURN PACKET INVALID -- RESUBMIT REQUIRED"; break;
    case "REVIEW_REJECTED": reasonLabel = "REPORT REVIEW REJECTED -- REWORK REQUIRED"; break;
    case "REWORK_REQUIRED": reasonLabel = "REPORT REVIEW: REWORK REQUIRED"; break;
    case "QUARANTINED": reasonLabel = "REPORT QUARANTINED -- CORRECT AND RESUBMIT"; break;
    case "VALIDATION_FAILED": reasonLabel = "REPORT VALIDATION FAILED -- FIX AND RESUBMIT"; break;
  }
  const lines = [
    "",
    border,
    "  STRATA BACKEND: " + reasonLabel,
    border,
    "",
    "  Assignment: " + assignmentId,
    "  Agent:      " + agentId,
    "  Nonce:      " + (nonce ?? "N/A"),
    "",
    "  Reason: " + detail,
    "",
  ];
  if (errors.length > 0) {
    lines.push("  Validation errors:");
    for (const e of errors) lines.push("    - " + e);
    lines.push("");
  }
  lines.push("  Action required:");
  lines.push("    1. Read the errors above and fix the return packet or report.");
  lines.push('    2. Re-write a corrected Worker Return Packet JSON to the return folder:');
  lines.push("       .strata/returns/" + safe(assignmentId) + "/" + safe(agentId) + "/");
  lines.push("    3. Chat/session text is NOT a deliverable. Only files in the return folder count.");
  lines.push("");
  lines.push(border);
  return lines.join("\n");
}

export function sendDenialToWorker(
  ctx: CommandContext,
  input: {
    assignmentId: string;
    agentId: string;
    role: string;
    nonce: string | null;
    reasonCategory: WorkerDenialRecord["reason_category"];
    reasonDetail: string;
    errors?: string[];
    sessionNameOverride?: string;
  },
): WorkerDenialRecord | null {
  const layout = ensureGovernanceLayout(ctx.workspaceRoot);
  const errorList = input.errors ?? [];

  let sessionName = input.sessionNameOverride ?? null;
  const dispatch = sessionName ? null : findSessionForDispatch(ctx, input.nonce);
  if (!sessionName && dispatch) sessionName = dispatch.session_name;

  const denialId = "denial_" + safe(input.assignmentId) + "_" + safe(input.agentId) + "_" + Date.now();
  const evidenceDir = ensureDir(path.join(layout.evidenceRoot, "denials", safe(input.assignmentId), safe(input.agentId), denialId));

  const message = formatDenialMessage(input.reasonCategory, input.assignmentId, input.agentId, input.nonce, input.reasonDetail, errorList);

  let sentToTmux = false;
  let tmuxStatus = "tmux_not_available";
  const evidence: WorkerDenialEvidence = {
    contract_id: "worker_denial.evidence.v1", denial_id: denialId, message_injected: message,
    tmux_has_session: false,
    tmux_load_buffer: { ok: false, status: null, stderr: "tmux not available" },
    tmux_paste_buffer: { ok: false, status: null, stderr: "tmux not available" },
    tmux_send_enter: { ok: false, status: null, stderr: "tmux not available" },
    created_at: isoStamp(ctx.now),
  };

  if (tmuxAvailable() && sessionName) {
    const has = runTmux(["has-session", "-t", sessionName]);
    evidence.tmux_has_session = has.ok;
    if (has.ok) {
      const bufferName = "strata_denial_" + safe(input.assignmentId) + "_" + Date.now();
      const messagePath = writeText(path.join(evidenceDir, "denial_message.txt"), message);
      const load = runTmux(["load-buffer", "-b", bufferName, messagePath]);
      evidence.tmux_load_buffer = { ok: load.ok, status: load.status, stderr: load.stderr };
      const paste = load.ok ? runTmux(["paste-buffer", "-t", sessionName, "-b", bufferName]) : { ok: false, status: load.status, stdout: "", stderr: load.stderr };
      evidence.tmux_paste_buffer = { ok: paste.ok, status: paste.status, stderr: paste.stderr };
      const enter = paste.ok ? runTmux(["send-keys", "-t", sessionName, "Enter"]) : { ok: false, status: paste.status, stdout: "", stderr: paste.stderr };
      evidence.tmux_send_enter = { ok: enter.ok, status: enter.status, stderr: enter.stderr };
      sentToTmux = has.ok && load.ok && paste.ok && enter.ok;
      tmuxStatus = sentToTmux ? "DENIAL_INJECTED_INTO_TMUX" : "TMUX_DENIAL_DELIVERY_FAILED";
    } else { tmuxStatus = "TMUX_SESSION_NOT_FOUND"; }
  } else if (tmuxAvailable() && !sessionName) { tmuxStatus = "NO_TMUX_SESSION_FOUND_FOR_DISPATCH"; }

  writeJson(path.join(evidenceDir, "denial_evidence.json"), evidence);

  const record: WorkerDenialRecord = {
    contract_id: "worker_denial.record.v1", denial_id: denialId,
    assignment_id: input.assignmentId, agent_id: input.agentId, role: input.role,
    nonce: input.nonce, session_name: sessionName ?? "unknown",
    reason_category: input.reasonCategory, reason_detail: input.reasonDetail,
    errors: errorList, sent_to_tmux: sentToTmux, tmux_status: tmuxStatus,
    evidence_dir: evidenceDir, created_at: isoStamp(ctx.now),
  };

  writeJson(path.join(layout.evidenceRoot, "denials", safe(denialId) + ".json"), record);

  appendBackendLoopEvent(ctx, {
    event: sentToTmux ? "WORKER_DENIAL_SENT" : "WORKER_DENIAL_FAILED",
    actor: "worker_denial_module",
    assignment_id: input.assignmentId, agent_id: input.agentId, role: input.role,
    nonce: input.nonce, status: tmuxStatus,
    artifact: path.join(layout.evidenceRoot, "denials", safe(denialId) + ".json"),
    evidence: evidenceDir,
    note: input.reasonCategory + ": " + input.reasonDetail,
  });

  return record;
}