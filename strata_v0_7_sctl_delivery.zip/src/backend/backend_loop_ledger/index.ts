import fs from "node:fs";
import path from "node:path";
import { ensureDir, ensureGovernanceLayout, isoStamp, type CommandContext, writeJson } from "../common.js";

export type BackendLoopEventName =
  | "DUTY_REGISTERED"
  | "DUTY_VERIFIED"
  | "SESSION_LAUNCHED"
  | "SESSION_STATUS_OBSERVED"
  | "WORK_PACKET_CREATED"
  | "WORK_PASSED"
  | "DISPATCH_BLOCKED"
  | "RETURN_FILE_DETECTED"
  | "RETURN_FILE_NOT_DETECTED"
  | "RETURN_PACKET_CLASSIFIED"
  | "ROUTED_TO_IC"
  | "ROUTED_TO_REVIEWER"
  | "ROUTED_TO_CLASSD"
  | "REPORT_LEDGERED"
  | "REVIEW_ACCEPTED"
  | "REVIEW_REWORK_REQUIRED"
  | "CLASSB_IMPORTED"
  | "CLASSB_REJECTED_OR_BLOCKED"
  | "WORKER_DENIAL_SENT"
  | "WORKER_DENIAL_FAILED";

export interface BackendLoopEventInput {
  assignment_id?: string | null;
  event: BackendLoopEventName;
  actor?: string | null;
  from?: string | null;
  to?: string | null;
  agent_id?: string | null;
  role?: string | null;
  target_runtime?: string | null;
  session_name?: string | null;
  nonce?: string | null;
  status?: string | null;
  artifact?: string | null;
  evidence?: string | null;
  note?: string | null;
  metadata?: Record<string, unknown>;
}

export interface BackendLoopEventRecord extends BackendLoopEventInput {
  ts: string;
  loop_id: string;
  contract_id: "backend_loop_ledger.event.v0_6";
}

function nextLoopId(jsonlPath: string): string {
  if (!fs.existsSync(jsonlPath)) return "0001";
  const count = fs.readFileSync(jsonlPath, "utf8").split(/\r?\n/).filter((line) => line.trim()).length;
  return String(count + 1).padStart(4, "0");
}

function rel(ctx: CommandContext, value?: string | null): string | null {
  if (!value) return null;
  const resolved = path.resolve(value);
  const relative = path.relative(ctx.workspaceRoot, resolved);
  return relative && !relative.startsWith("..") ? relative : value;
}

function markdownLine(record: BackendLoopEventRecord): string {
  const parts = [
    record.ts,
    `loop=${record.loop_id}`,
    `event=${record.event}`,
    record.assignment_id ? `assignment=${record.assignment_id}` : null,
    record.actor ? `actor=${record.actor}` : null,
    record.from ? `from=${record.from}` : null,
    record.to ? `to=${record.to}` : null,
    record.agent_id ? `worker=${record.agent_id}` : null,
    record.role ? `role=${record.role}` : null,
    record.target_runtime ? `runtime=${record.target_runtime}` : null,
    record.session_name ? `session=${record.session_name}` : null,
    record.nonce ? `nonce=${record.nonce}` : null,
    record.status ? `status=${record.status}` : null,
    record.artifact ? `artifact=${record.artifact}` : null,
    record.evidence ? `evidence=${record.evidence}` : null,
    record.note ? `note=${JSON.stringify(record.note)}` : null,
  ].filter(Boolean);
  return parts.join(" ");
}

export function appendBackendLoopEvent(ctx: CommandContext, input: BackendLoopEventInput): BackendLoopEventRecord {
  const layout = ensureGovernanceLayout(ctx.workspaceRoot);
  const record: BackendLoopEventRecord = {
    contract_id: "backend_loop_ledger.event.v0_6",
    ts: isoStamp(ctx.now),
    loop_id: nextLoopId(layout.backendLoopLedgerJsonlPath),
    ...input,
    artifact: rel(ctx, input.artifact),
    evidence: rel(ctx, input.evidence),
  };
  ensureDir(path.dirname(layout.backendLoopLedgerJsonlPath));
  fs.appendFileSync(layout.backendLoopLedgerJsonlPath, `${JSON.stringify(record)}\n`, "utf8");
  fs.appendFileSync(layout.backendLoopLedgerMarkdownPath, `${markdownLine(record)}\n`, "utf8");
  return record;
}

export function ledgerPaths(ctx: CommandContext): { jsonl: string; markdown: string } {
  const layout = ensureGovernanceLayout(ctx.workspaceRoot);
  return { jsonl: layout.backendLoopLedgerJsonlPath, markdown: layout.backendLoopLedgerMarkdownPath };
}

export function writeLedgerSnapshot(ctx: CommandContext): { snapshot_path: string; jsonl: string; markdown: string } {
  const layout = ensureGovernanceLayout(ctx.workspaceRoot);
  const snapshotPath = path.join(layout.evidenceRoot, "ledger_snapshots", `backend_loop_ledger_snapshot_${Date.now()}.json`);
  return {
    snapshot_path: writeJson(snapshotPath, {
      contract_id: "backend_loop_ledger.snapshot.v0_6",
      generated_at: isoStamp(ctx.now),
      jsonl: layout.backendLoopLedgerJsonlPath,
      markdown: layout.backendLoopLedgerMarkdownPath,
    }),
    jsonl: layout.backendLoopLedgerJsonlPath,
    markdown: layout.backendLoopLedgerMarkdownPath,
  };
}
