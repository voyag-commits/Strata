import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import crypto from "node:crypto";
import { ensureDir, fileExists, fileStamp, hashText, isoStamp, readJson, readText, type CommandContext, writeJson, writeText } from "../common.js";
import { writeSimplePdf } from "../render/pdf.js";
import { writeToolRun, type ToolRunEnvelope } from "../tool_runs/index.js";

export interface ClassDInput {
  sessionId?: string;
  source?: string;
  sessionsRoot?: string;
  out?: string;
}

interface ClassDMetadata {
  contract_id: "classd.local_transcript.metadata.v1";
  session_id: string;
  source_path: string;
  copied_source_path: string;
  native_extension: string;
  source_sha256: string;
  registered_at: string;
  class_authority: "D_only_not_ABC";
}

function safePart(value: string): string {
  return value.replace(/[^A-Za-z0-9_.-]+/g, "-").replace(/^-+|-+$/g, "") || "session";
}

function shaFile(targetPath: string): string {
  return crypto.createHash("sha256").update(fs.readFileSync(targetPath)).digest("hex");
}

function classDRoot(context: CommandContext, sessionId: string): string {
  return ensureDir(path.join(context.workspaceRoot, ".strata", "class_d", "local_transcripts", safePart(sessionId)));
}

function metadataPath(context: CommandContext, sessionId: string): string {
  return path.join(classDRoot(context, sessionId), "metadata.json");
}

function readMetadata(context: CommandContext, sessionId: string): ClassDMetadata {
  return readJson<ClassDMetadata>(metadataPath(context, sessionId));
}

function renderTranscriptMarkdown(metadata: ClassDMetadata, sourceText: string): string {
  const lines = [
    `# Class D Local Transcript: ${metadata.session_id}`,
    "",
    "Class D is raw local transcript evidence. It is not Class B and cannot auto-promote into A/B/C context.",
    "",
    `Source checksum: ${metadata.source_sha256}`,
    `Copied source: ${metadata.copied_source_path}`,
    "",
    "```",
    sourceText.trimEnd(),
    "```",
    "",
  ];
  return lines.join("\n");
}

function writeChecksums(dir: string, paths: string[]): string {
  const lines = paths.map((item) => `${shaFile(item)}  ${path.basename(item)}`);
  return writeText(path.join(dir, "checksums.sha256"), `${lines.join("\n")}\n`);
}

export function locateCodexSessions(context: CommandContext, input: ClassDInput = {}): ToolRunEnvelope & Record<string, unknown> {
  const root = path.resolve(input.sessionsRoot ?? path.join(os.homedir(), ".codex", "sessions"));
  const candidates: string[] = [];
  if (fileExists(root)) {
    const stack = [root];
    while (stack.length > 0) {
      const current = stack.pop()!;
      for (const entry of fs.readdirSync(current, { withFileTypes: true })) {
        const full = path.join(current, entry.name);
        if (entry.isDirectory()) stack.push(full);
        else if (entry.isFile() && /\.(jsonl|json|txt|md)$/i.test(entry.name)) candidates.push(full);
      }
    }
  }
  candidates.sort();
  return writeToolRun(context, { ok: true, toolId: "classd.locate_codex_sessions.v1", payload: { sessions_root: root, count: candidates.length, session_files: candidates } });
}

export function registerClassDSession(context: CommandContext, input: ClassDInput): ToolRunEnvelope & Record<string, unknown> {
  if (!input.source) throw new Error("Missing Class D source path.");
  const sourcePath = path.resolve(input.source);
  if (!fileExists(sourcePath)) throw new Error(`Class D source does not exist: ${sourcePath}`);
  const sessionId = input.sessionId ?? path.basename(sourcePath, path.extname(sourcePath));
  const dir = classDRoot(context, sessionId);
  const extension = path.extname(sourcePath) || ".source";
  const copiedSourcePath = path.join(dir, extension.toLowerCase() === ".jsonl" ? "codex_source.jsonl" : `codex_source${extension}`);
  const checksum = shaFile(sourcePath);
  if (fileExists(metadataPath(context, sessionId))) {
    const existing = readMetadata(context, sessionId);
    if (existing.source_sha256 !== checksum) {
      throw new Error(`Class D session ${sessionId} already registered with a different source checksum.`);
    }
  }
  fs.copyFileSync(sourcePath, copiedSourcePath);
  const metadata: ClassDMetadata = {
    contract_id: "classd.local_transcript.metadata.v1",
    session_id: sessionId,
    source_path: sourcePath,
    copied_source_path: copiedSourcePath,
    native_extension: extension,
    source_sha256: checksum,
    registered_at: isoStamp(context.now),
    class_authority: "D_only_not_ABC",
  };
  const metadataFile = writeJson(metadataPath(context, sessionId), metadata);
  const checksumsPath = writeChecksums(dir, [copiedSourcePath, metadataFile]);
  return writeToolRun(context, {
    ok: true,
    toolId: "classd.register_session.v1",
    evidencePaths: [copiedSourcePath, metadataFile, checksumsPath],
    payload: { session_id: sessionId, class_d_dir: dir, copied_source_path: copiedSourcePath, metadata_path: metadataFile, checksums_path: checksumsPath },
  });
}

export function exportClassDMarkdown(context: CommandContext, input: ClassDInput): ToolRunEnvelope & Record<string, unknown> {
  if (!input.sessionId) throw new Error("Missing Class D --session-id.");
  const metadata = readMetadata(context, input.sessionId);
  const dir = classDRoot(context, input.sessionId);
  const sourceText = readText(metadata.copied_source_path);
  const target = input.out ? path.resolve(context.workspaceRoot, input.out) : path.join(dir, "transcript.md");
  const transcriptPath = writeText(target, renderTranscriptMarkdown(metadata, sourceText));
  const checksumsPath = writeChecksums(dir, [metadata.copied_source_path, metadataPath(context, input.sessionId), transcriptPath]);
  return writeToolRun(context, {
    ok: true,
    toolId: "classd.export_markdown.v1",
    evidencePaths: [transcriptPath, checksumsPath],
    payload: { session_id: input.sessionId, transcript_markdown_path: transcriptPath, checksums_path: checksumsPath, class_authority: "D_only_not_ABC" },
  });
}

export function exportClassDPdf(context: CommandContext, input: ClassDInput): ToolRunEnvelope & Record<string, unknown> {
  if (!input.sessionId) throw new Error("Missing Class D --session-id.");
  const metadata = readMetadata(context, input.sessionId);
  const dir = classDRoot(context, input.sessionId);
  const sourceText = readText(metadata.copied_source_path);
  const markdown = renderTranscriptMarkdown(metadata, sourceText);
  const markdownPath = writeText(path.join(dir, "transcript.md"), markdown);
  const target = input.out ? path.resolve(context.workspaceRoot, input.out) : path.join(dir, "transcript.pdf");
  const pdfPath = writeSimplePdf(target, markdown);
  const checksumsPath = writeChecksums(dir, [metadata.copied_source_path, metadataPath(context, input.sessionId), markdownPath, pdfPath]);
  return writeToolRun(context, {
    ok: true,
    toolId: "classd.export_pdf.v1",
    evidencePaths: [markdownPath, pdfPath, checksumsPath],
    payload: { session_id: input.sessionId, transcript_markdown_path: markdownPath, transcript_pdf_path: pdfPath, checksums_path: checksumsPath, class_authority: "D_only_not_ABC" },
  });
}

export function verifyClassDChecksums(context: CommandContext, input: ClassDInput): ToolRunEnvelope & Record<string, unknown> {
  if (!input.sessionId) throw new Error("Missing Class D --session-id.");
  const metadata = readMetadata(context, input.sessionId);
  const actual = shaFile(metadata.copied_source_path);
  const ok = actual === metadata.source_sha256;
  return writeToolRun(context, {
    ok,
    toolId: "classd.verify_checksums.v1",
    errors: ok ? [] : [`Checksum mismatch for ${metadata.copied_source_path}`],
    payload: { session_id: input.sessionId, expected_source_sha256: metadata.source_sha256, actual_source_sha256: actual, metadata_path: metadataPath(context, input.sessionId) },
  });
}

export function inspectClassDSession(context: CommandContext, input: ClassDInput): ToolRunEnvelope & Record<string, unknown> {
  if (!input.sessionId) throw new Error("Missing Class D --session-id.");
  const metadata = readMetadata(context, input.sessionId);
  const sourceText = readText(metadata.copied_source_path);
  return writeToolRun(context, {
    ok: true,
    toolId: "classd.inspect.v1",
    evidencePaths: [metadata.copied_source_path, metadataPath(context, input.sessionId)],
    payload: { metadata, byte_length: Buffer.byteLength(sourceText, "utf8"), preview: sourceText.slice(0, 1000) },
  });
}
