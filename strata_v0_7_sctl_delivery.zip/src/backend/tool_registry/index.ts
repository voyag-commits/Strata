import path from "node:path";
import { ensureDir, isoStamp, readJson, type CommandContext, writeJson } from "../common.js";
import { exportContextMarkdown, exportContextPdf } from "../context_export/index.js";
import { exportClassDMarkdown, exportClassDPdf, inspectClassDSession, locateCodexSessions, registerClassDSession, verifyClassDChecksums } from "../classd/index.js";
import { writeToolRun, type ToolRunEnvelope } from "../tool_runs/index.js";

export interface ToolRegistryEntry {
  tool_id: string;
  catalog_index: string;
  version: string;
  cli_command: string;
  input_schema: string;
  output_schema: string;
  read_paths: string[];
  write_paths: string[];
  evidence_paths: string[];
  stable_rendering_behavior: string;
  permission_labels: string[];
  authority_policy: string;
  mutation_gate_policy: "retired_not_applicable" | "not_applicable";
  idempotency_policy: string;
}

export interface ToolRegistryIndex {
  contract_id: "sctl.tool_registry.index.v1";
  generated_at: string;
  registry_path: string;
  tools: ToolRegistryEntry[];
}

const schema = (toolId: string, kind: "input" | "output") => `.strata/backend/tool_registry/schemas/${toolId}.${kind}.schema.json`;

export function builtinToolEntries(): ToolRegistryEntry[] {
  return [
    {
      tool_id: "context.export_markdown.v1",
      catalog_index: "CTX-001",
      version: "v1",
      cli_command: "strata context export-markdown --scope <scope> --out <path>",
      input_schema: schema("context.export_markdown.v1", "input"),
      output_schema: schema("context.export_markdown.v1", "output"),
      read_paths: ["<context_repo_path>/class_a/**", "<context_repo_path>/class_c/file_pins/**", "<context_repo_path>/class_b/**"],
      write_paths: [".strata/exports/context/<export_id>/**"],
      evidence_paths: ["context.md", "manifest.json", "source_index.json", "checksums.sha256"],
      stable_rendering_behavior: "Renders Class A, then Class C file pins, then Class B timing index and entries without summarizing.",
      permission_labels: ["read_context", "render_export"],
      authority_policy: "read/render only; cannot mutate authoritative A/B/C stores",
      mutation_gate_policy: "retired_not_applicable",
      idempotency_policy: "Export reruns are allowed when export_id differs; no semantic context record is created.",
    },
    {
      tool_id: "context.export_pdf.v1",
      catalog_index: "CTX-002",
      version: "v1",
      cli_command: "strata context export-pdf --scope <scope> --out <path>",
      input_schema: schema("context.export_pdf.v1", "input"),
      output_schema: schema("context.export_pdf.v1", "output"),
      read_paths: ["<context_repo_path>/class_a/**", "<context_repo_path>/class_c/file_pins/**", "<context_repo_path>/class_b/**"],
      write_paths: [".strata/exports/context/<export_id>/**"],
      evidence_paths: ["context.pdf", "context.md", "manifest.json", "source_index.json", "checksums.sha256"],
      stable_rendering_behavior: "Renders the same ordered A/C/B export into PDF plus Markdown companion and manifest.",
      permission_labels: ["read_context", "render_export"],
      authority_policy: "read/render only; cannot mutate authoritative A/B/C stores",
      mutation_gate_policy: "retired_not_applicable",
      idempotency_policy: "Export reruns are allowed when export_id differs; no semantic context record is created.",
    },
    {
      tool_id: "classd.locate_codex_sessions.v1",
      catalog_index: "D-001",
      version: "v1",
      cli_command: "strata classd locate",
      input_schema: schema("classd.locate_codex_sessions.v1", "input"),
      output_schema: schema("classd.locate_codex_sessions.v1", "output"),
      read_paths: ["~/.codex/sessions/**"],
      write_paths: [".strata/backend/tool_runs/<tool_run_id>/**"],
      evidence_paths: ["result.json"],
      stable_rendering_behavior: "Lists candidate local Codex session files without copying or rewriting them.",
      permission_labels: ["class_d_read"],
      authority_policy: "Class D only; no A/B/C authority",
      mutation_gate_policy: "retired_not_applicable",
      idempotency_policy: "Read-only reruns are allowed.",
    },
    {
      tool_id: "classd.register_session.v1",
      catalog_index: "D-002",
      version: "v1",
      cli_command: "strata classd register-session --source <path> --session-id <id>",
      input_schema: schema("classd.register_session.v1", "input"),
      output_schema: schema("classd.register_session.v1", "output"),
      read_paths: ["<source_codex_session_file>"],
      write_paths: [".strata/class_d/local_transcripts/<session_id>/**"],
      evidence_paths: ["codex_source.*", "metadata.json", "checksums.sha256"],
      stable_rendering_behavior: "Copies raw local transcript source and records checksum metadata without semantic rewriting.",
      permission_labels: ["class_d_register"],
      authority_policy: "Class D only; no Class B promotion",
      mutation_gate_policy: "retired_not_applicable",
      idempotency_policy: "Same session id with same source checksum is stable; conflicting checksum is blocked.",
    },
    {
      tool_id: "classd.export_markdown.v1",
      catalog_index: "D-003",
      version: "v1",
      cli_command: "strata classd export-markdown --session-id <id>",
      input_schema: schema("classd.export_markdown.v1", "input"),
      output_schema: schema("classd.export_markdown.v1", "output"),
      read_paths: [".strata/class_d/local_transcripts/<session_id>/codex_source.*"],
      write_paths: [".strata/class_d/local_transcripts/<session_id>/transcript.md"],
      evidence_paths: ["transcript.md", "checksums.sha256"],
      stable_rendering_behavior: "Renders raw transcript source into Markdown view artifact.",
      permission_labels: ["class_d_export"],
      authority_policy: "Class D only; cannot auto-promote into Class B",
      mutation_gate_policy: "retired_not_applicable",
      idempotency_policy: "View artifact reruns are allowed.",
    },
    {
      tool_id: "classd.export_pdf.v1",
      catalog_index: "D-004",
      version: "v1",
      cli_command: "strata classd export-pdf --session-id <id>",
      input_schema: schema("classd.export_pdf.v1", "input"),
      output_schema: schema("classd.export_pdf.v1", "output"),
      read_paths: [".strata/class_d/local_transcripts/<session_id>/codex_source.*"],
      write_paths: [".strata/class_d/local_transcripts/<session_id>/transcript.pdf"],
      evidence_paths: ["transcript.pdf", "transcript.md", "checksums.sha256"],
      stable_rendering_behavior: "Renders raw transcript source into PDF view artifact.",
      permission_labels: ["class_d_export"],
      authority_policy: "Class D only; cannot auto-promote into Class B",
      mutation_gate_policy: "retired_not_applicable",
      idempotency_policy: "View artifact reruns are allowed.",
    },
    {
      tool_id: "classd.verify_checksums.v1",
      catalog_index: "D-005",
      version: "v1",
      cli_command: "strata classd verify-checksums --session-id <id>",
      input_schema: schema("classd.verify_checksums.v1", "input"),
      output_schema: schema("classd.verify_checksums.v1", "output"),
      read_paths: [".strata/class_d/local_transcripts/<session_id>/**"],
      write_paths: [".strata/backend/tool_runs/<tool_run_id>/**"],
      evidence_paths: ["result.json"],
      stable_rendering_behavior: "Verifies copied transcript checksum against metadata.",
      permission_labels: ["class_d_verify"],
      authority_policy: "Class D only",
      mutation_gate_policy: "retired_not_applicable",
      idempotency_policy: "Read-only reruns are allowed.",
    },
    {
      tool_id: "classd.inspect.v1",
      catalog_index: "D-006",
      version: "v1",
      cli_command: "strata classd inspect --session-id <id>",
      input_schema: schema("classd.inspect.v1", "input"),
      output_schema: schema("classd.inspect.v1", "output"),
      read_paths: [".strata/class_d/local_transcripts/<session_id>/**"],
      write_paths: [".strata/backend/tool_runs/<tool_run_id>/**"],
      evidence_paths: ["result.json"],
      stable_rendering_behavior: "Returns metadata and a bounded preview of raw transcript source.",
      permission_labels: ["class_d_read"],
      authority_policy: "Class D only",
      mutation_gate_policy: "retired_not_applicable",
      idempotency_policy: "Read-only reruns are allowed.",
    },
    {
      tool_id: "session.launch_codex_tmux.v1",
      catalog_index: "RT-001",
      version: "v1",
      cli_command: "strata sessions create --session <name> ...",
      input_schema: schema("session.launch_codex_tmux.v1", "input"),
      output_schema: schema("session.launch_codex_tmux.v1", "output"),
      read_paths: ["<workspace>"],
      write_paths: [".strata/sessions/<strata_session_id>.json", ".strata/evidence/tmux_sessions/**"],
      evidence_paths: ["launch_result.json", "result.json"],
      stable_rendering_behavior: "Launches tmux/Codex runtime and records minimal session metadata.",
      permission_labels: ["runtime_adapter"],
      authority_policy: "Runtime tool; no A/B/C authority unless separate context action is used.",
      mutation_gate_policy: "retired_not_applicable",
      idempotency_policy: "Session id is primary key; replacement requires explicit replace flag.",
    },
    {
      tool_id: "returns.scan.v1",
      catalog_index: "RT-002",
      version: "v1",
      cli_command: "strata returns scan",
      input_schema: schema("returns.scan.v1", "input"),
      output_schema: schema("returns.scan.v1", "output"),
      read_paths: [".strata/returns/**"],
      write_paths: [".strata/ledgers/worker_returns/**", ".strata/backend/tool_runs/<tool_run_id>/**"],
      evidence_paths: ["result.json"],
      stable_rendering_behavior: "One-shot deterministic scan of worker return packets.",
      permission_labels: ["runtime_adapter", "returns_scan"],
      authority_policy: "Runtime evidence route; no automatic Class B promotion.",
      mutation_gate_policy: "retired_not_applicable",
      idempotency_policy: "Same Worker Return Packet must not create duplicate report candidates.",
    },
    {
      tool_id: "returns.watch.v1",
      catalog_index: "RT-003",
      version: "v1",
      cli_command: "strata returns watch",
      input_schema: schema("returns.watch.v1", "input"),
      output_schema: schema("returns.watch.v1", "output"),
      read_paths: [".strata/returns/**"],
      write_paths: [".strata/ledgers/worker_returns/**", ".strata/backend/tool_runs/<tool_run_id>/**"],
      evidence_paths: ["result.json"],
      stable_rendering_behavior: "Persistent polling loop contract; implementation may run one poll per CLI invocation unless daemonized by caller.",
      permission_labels: ["runtime_adapter", "returns_watch"],
      authority_policy: "Runtime evidence route; no automatic Class B promotion.",
      mutation_gate_policy: "retired_not_applicable",
      idempotency_policy: "Same Worker Return Packet must not create duplicate report candidates.",
    },
  ];
}

function minimalSchema(toolId: string, kind: "input" | "output"): Record<string, unknown> {
  if (kind === "output") {
    return {
      $schema: "https://json-schema.org/draft/2020-12/schema",
      title: `${toolId} output`,
      type: "object",
      required: ["ok", "tool_id", "tool_run_id", "result_path", "evidence_paths", "errors"],
      properties: {
        ok: { type: "boolean" },
        tool_id: { const: toolId },
        tool_run_id: { type: "string" },
        result_path: { type: "string" },
        evidence_paths: { type: "array", items: { type: "string" } },
        errors: { type: "array", items: { type: "string" } },
      },
      additionalProperties: true,
    };
  }
  return {
    $schema: "https://json-schema.org/draft/2020-12/schema",
    title: `${toolId} input`,
    type: "object",
    additionalProperties: true,
  };
}

export function ensureToolRegistry(context: CommandContext): ToolRegistryIndex {
  const root = ensureDir(path.join(context.workspaceRoot, ".strata", "backend", "tool_registry"));
  const schemas = ensureDir(path.join(root, "schemas"));
  const tools = builtinToolEntries();
  for (const entry of tools) {
    writeJson(path.join(schemas, `${entry.tool_id}.input.schema.json`), minimalSchema(entry.tool_id, "input"));
    writeJson(path.join(schemas, `${entry.tool_id}.output.schema.json`), minimalSchema(entry.tool_id, "output"));
  }
  const index: ToolRegistryIndex = { contract_id: "sctl.tool_registry.index.v1", generated_at: isoStamp(context.now), registry_path: path.join(root, "tool_index.json"), tools };
  writeJson(index.registry_path, index);
  return index;
}

export function listTools(context: CommandContext): ToolRunEnvelope & Record<string, unknown> {
  const index = ensureToolRegistry(context);
  return writeToolRun(context, { ok: true, toolId: "tools.list.v1", evidencePaths: [index.registry_path], payload: { registry_path: index.registry_path, tools: index.tools } });
}

export function inspectTool(context: CommandContext, toolId: string): ToolRunEnvelope & Record<string, unknown> {
  const index = ensureToolRegistry(context);
  const entry = index.tools.find((tool) => tool.tool_id === toolId);
  if (!entry) return writeToolRun(context, { ok: false, toolId: "tools.inspect.v1", errors: [`Unknown tool_id: ${toolId}`], evidencePaths: [index.registry_path] });
  return writeToolRun(context, { ok: true, toolId: "tools.inspect.v1", evidencePaths: [index.registry_path], payload: { registry_path: index.registry_path, tool: entry } });
}

export function runRegisteredTool(context: CommandContext, toolId: string, input: Record<string, unknown>): ToolRunEnvelope & Record<string, unknown> {
  ensureToolRegistry(context);
  const text = (key: string): string | undefined => typeof input[key] === "string" ? input[key] as string : undefined;
  switch (toolId) {
    case "context.export_markdown.v1":
      return exportContextMarkdown(context, { scope: text("scope"), out: text("out"), exportId: text("export_id"), contextRepoPath: text("context_repo_path") });
    case "context.export_pdf.v1":
      return exportContextPdf(context, { scope: text("scope"), out: text("out"), exportId: text("export_id"), contextRepoPath: text("context_repo_path") });
    case "classd.locate_codex_sessions.v1":
      return locateCodexSessions(context, { sessionsRoot: text("sessions_root") });
    case "classd.register_session.v1":
      return registerClassDSession(context, { source: text("source"), sessionId: text("session_id") });
    case "classd.export_markdown.v1":
      return exportClassDMarkdown(context, { sessionId: text("session_id"), out: text("out") });
    case "classd.export_pdf.v1":
      return exportClassDPdf(context, { sessionId: text("session_id"), out: text("out") });
    case "classd.verify_checksums.v1":
      return verifyClassDChecksums(context, { sessionId: text("session_id") });
    case "classd.inspect.v1":
      return inspectClassDSession(context, { sessionId: text("session_id") });
    default:
      return writeToolRun(context, { ok: false, toolId: "tools.run.v1", errors: [`Tool cannot be run through the generic registry dispatcher or is unknown: ${toolId}`] });
  }
}

export function readToolInput(inputPath?: string): Record<string, unknown> {
  if (!inputPath) return {};
  return readJson<Record<string, unknown>>(path.resolve(inputPath));
}
