import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import {
  ensureGovernanceLayout,
  fileStamp,
  hashText,
  isoStamp,
  readJson,
  shortId,
  type CommandContext,
  writeJson,
} from "../common.js";

export type MutationDecision = "allowed" | "denied";

export interface MutationGateRequest {
  actor: string;
  action: string;
  resourceType: string;
  resourceId?: string | null;
  reason: string;
  beforePath?: string | null;
  afterPath?: string | null;
  evidencePath?: string | null;
  requiresDirector?: boolean;
  approvedByDirector?: boolean;
  metadata?: Record<string, unknown>;
}

export interface MutationGateRecord extends MutationGateRequest {
  gate_id: string;
  contract_id: "governance_mutation_gate.v1";
  decision: MutationDecision;
  decision_reason: string;
  created_at: string;
  request_sha256: string;
  gate_record_path: string;
}

function safeFilePart(value: string): string {
  return value.replace(/[^A-Za-z0-9_.-]+/g, "-").replace(/^-+|-+$/g, "") || "item";
}

function decisionFor(request: MutationGateRequest): { decision: MutationDecision; reason: string } {
  const actor = request.actor.trim();
  const action = request.action.trim();
  const resourceType = request.resourceType.trim();

  if (!actor) return { decision: "allowed", reason: "retired compatibility audit only; actor missing recorded in evidence" };
  if (!action) return { decision: "allowed", reason: "retired compatibility audit only; action missing recorded in evidence" };
  if (!resourceType) return { decision: "allowed", reason: "retired compatibility audit only; resourceType missing recorded in evidence" };

  return { decision: "allowed", reason: "broad Mutation Gate retired by ADR-0603; compatibility audit does not authorize A/B/C context" };
}

export function gateMutation(context: CommandContext, request: MutationGateRequest): MutationGateRecord {
  const layout = ensureGovernanceLayout(context.workspaceRoot);
  const gateId = `${shortId(`gate_${safeFilePart(request.resourceType)}_${safeFilePart(request.action)}`, context.now)}_${crypto.randomUUID().slice(0, 8)}`;
  const coreRequest = {
    actor: request.actor,
    action: request.action,
    resourceType: request.resourceType,
    resourceId: request.resourceId ?? null,
    reason: request.reason,
    beforePath: request.beforePath ?? null,
    afterPath: request.afterPath ?? null,
    evidencePath: request.evidencePath ?? null,
    requiresDirector: request.requiresDirector ?? false,
    approvedByDirector: request.approvedByDirector ?? false,
    metadata: request.metadata ?? {},
  };
  const decision = decisionFor(request);
  const gatePath = path.join(layout.mutationGate, `${safeFilePart(gateId)}.json`);
  const record: MutationGateRecord = {
    ...coreRequest,
    gate_id: gateId,
    contract_id: "governance_mutation_gate.v1",
    decision: decision.decision,
    decision_reason: decision.reason,
    created_at: isoStamp(context.now),
    request_sha256: hashText(JSON.stringify(coreRequest)),
    gate_record_path: gatePath,
  };
  writeJson(gatePath, record);
  fs.appendFileSync(path.join(layout.mutationGate, "index.jsonl"), `${JSON.stringify(record)}\n`, "utf8");
  return record;
}

export function assertGateAllowed(record: MutationGateRecord): MutationGateRecord {
  if (record.decision !== "allowed") {
    throw new Error(`Mutation denied by governance gate ${record.gate_id}: ${record.decision_reason}`);
  }
  return record;
}

export function gatedMutation(context: CommandContext, request: MutationGateRequest): MutationGateRecord {
  return assertGateAllowed(gateMutation(context, request));
}

export function listGateRecords(context: CommandContext, limit = 50): MutationGateRecord[] {
  const layout = ensureGovernanceLayout(context.workspaceRoot);
  return fs
    .readdirSync(layout.mutationGate)
    .filter((name) => name.endsWith(".json"))
    .map((name) => readJson<MutationGateRecord>(path.join(layout.mutationGate, name)))
    .filter((record) => typeof record.gate_id === "string" && typeof record.created_at === "string")
    .sort((a, b) => b.created_at.localeCompare(a.created_at))
    .slice(0, limit);
}

export function latestGateDigest(context: CommandContext): { generated_at: string; count: number; latest: MutationGateRecord[]; digest_path: string } {
  const layout = ensureGovernanceLayout(context.workspaceRoot);
  const latest = listGateRecords(context, 100);
  const digest = {
    generated_at: isoStamp(context.now),
    count: latest.length,
    latest,
    digest_path: path.join(layout.mutationGate, `digest_${fileStamp(context.now)}_${crypto.randomUUID().slice(0, 8)}.json`),
  };
  writeJson(digest.digest_path, digest);
  return digest;
}


export interface CompatibilityGateRequest {
  operation: string;
  actor: string;
  subjectType: string;
  subjectId: string;
  reason: string;
  evidencePath?: string | null;
  requestedWrites?: string[];
  metadata?: Record<string, unknown>;
}

export function evaluateMutationGate(context: CommandContext, request: CompatibilityGateRequest): MutationGateRecord {
  return gateMutation(context, {
    actor: request.actor,
    action: request.operation,
    resourceType: request.subjectType,
    resourceId: request.subjectId,
    reason: request.reason,
    evidencePath: request.evidencePath ?? null,
    afterPath: request.requestedWrites?.[0] ?? null,
    metadata: request.metadata ?? {},
    requiresDirector: request.subjectType === "class_a" && !request.operation.startsWith("context.bootstrap"),
    approvedByDirector: request.actor.toLowerCase() === "director" || request.metadata?.director_approved === true,
  });
}

export function requireAuthorizedGate(context: CommandContext, request: CompatibilityGateRequest): MutationGateRecord {
  return assertGateAllowed(evaluateMutationGate(context, request));
}
