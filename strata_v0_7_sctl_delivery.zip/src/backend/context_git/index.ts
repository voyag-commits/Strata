import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";
import {
  ensureDir,
  fileExists,
  fileStamp,
  hashText,
  isoStamp,
  readJson,
  readText,
  type CommandContext,
  writeJson,
  writeText,
} from "../common.js";
import { assertActionAllowed, evaluateAction } from "../action_filter/index.js";
import { resolveSctlConfig, writeDiscoverableSctlConfig, type SctlConfig, type SctlConfigInput } from "../sctl_config/index.js";
import { writeToolRun, type ToolRunEnvelope } from "../tool_runs/index.js";

export type ContextClassABC = "A" | "B" | "C";
export type ProposalReviewStatus = "draft" | "review_requested" | "approved" | "rejected" | "needs_revision" | "merged" | "reverted";

export interface GitResult {
  ok: boolean;
  status: number | null;
  stdout: string;
  stderr: string;
  args: string[];
}

export interface ContextProposalMetadata {
  proposal_id: string;
  proposal_branch: string;
  assigned_worktree: string | null;
  caller_id: string;
  caller_role: string;
  origin_worker_id: string;
  origin_worker_session_id: string | null;
  origin_dispatch_channel: string | null;
  created_at: string;
  updated_at: string;
  base_commit: string;
  changed_paths: string[];
  context_classes_touched: ContextClassABC[];
  intended_action: string;
  review_status: ProposalReviewStatus;
  reviewer_id: string | null;
  reviewed_at: string | null;
  reason_file: string | null;
  validation_result_path: string | null;
  merge_commit: string | null;
}

export interface ValidationResult {
  ok: boolean;
  proposal_id: string;
  proposal_branch: string;
  base_branch: string;
  changed_paths: string[];
  context_paths: string[];
  errors: string[];
  warnings: string[];
  validated_at: string;
  metadata_path: string | null;
}

export interface ProposalInput extends SctlConfigInput {
  proposalId: string;
  callerId: string;
  callerRole: string;
  klass?: ContextClassABC;
  semanticId?: string;
  title?: string;
  targetPath?: string;
  body?: string;
  sourceFile?: string;
  intendedAction?: string;
  originWorkerId?: string;
  originWorkerSessionId?: string;
  originDispatchChannel?: string;
  assignedWorktree?: string;
  pinnedPath?: string;
  checksumSha256?: string;
  commitMessage?: string;
}

export interface ReviewInput extends SctlConfigInput {
  proposalId: string;
  reviewerId: string;
  reviewerRole: string;
  reasonFile?: string;
}

export interface MergeInput extends SctlConfigInput {
  proposalId: string;
  callerId: string;
  callerRole: string;
  message?: string;
}

export interface DiffInput extends SctlConfigInput {
  proposalId: string;
}

function safePart(value: string): string {
  return value.replace(/[^A-Za-z0-9_.-]+/g, "-").replace(/^-+|-+$/g, "") || "item";
}

function toPosix(value: string): string {
  return value.replace(/\\/g, "/");
}

function unique<T>(items: T[]): T[] {
  return Array.from(new Set(items));
}

export function runGit(repoPath: string, args: string[], input?: string): GitResult {
  const result = spawnSync("git", args, {
    cwd: repoPath,
    input,
    encoding: "utf8",
    env: { ...process.env, GIT_TERMINAL_PROMPT: "0" },
  });
  return {
    ok: result.status === 0,
    status: result.status,
    stdout: result.stdout ?? "",
    stderr: result.stderr ?? (result.error ? result.error.message : ""),
    args,
  };
}

function assertGit(repoPath: string, args: string[], input?: string): GitResult {
  const result = runGit(repoPath, args, input);
  if (!result.ok) throw new Error(`git ${args.join(" ")} failed: ${result.stderr || result.stdout || result.status}`);
  return result;
}

function hasCommit(repoPath: string): boolean {
  return runGit(repoPath, ["rev-parse", "--verify", "HEAD"]).ok;
}

function branchExists(repoPath: string, branch: string): boolean {
  return runGit(repoPath, ["rev-parse", "--verify", branch]).ok;
}

function currentBranch(repoPath: string): string | null {
  const result = runGit(repoPath, ["branch", "--show-current"]);
  return result.ok ? result.stdout.trim() || null : null;
}

function ensureGitIdentity(repoPath: string): void {
  if (!runGit(repoPath, ["config", "user.email"]).stdout.trim()) {
    assertGit(repoPath, ["config", "user.email", "strata-sctl@example.invalid"]);
  }
  if (!runGit(repoPath, ["config", "user.name"]).stdout.trim()) {
    assertGit(repoPath, ["config", "user.name", "Strata SCTL"]);
  }
}

function ensureBaseFiles(repoPath: string): void {
  ensureDir(path.join(repoPath, "class_a"));
  ensureDir(path.join(repoPath, "class_b", "entries"));
  ensureDir(path.join(repoPath, "class_c", "file_pins"));
  ensureDir(path.join(repoPath, "proposals"));
  const timingIndex = path.join(repoPath, "class_b", "timing_index.json");
  if (!fileExists(timingIndex)) {
    writeJson(timingIndex, { contract_id: "class_b.timing_index.v1", entries: [] });
  }
  const readme = path.join(repoPath, "README.md");
  if (!fileExists(readme)) {
    writeText(readme, "# Strata Git-backed A/B/C context store\n\nAuthoritative A/B/C context lives on the configured authoritative branch.\n");
  }
}

export function ensureContextRepo(context: CommandContext, input: SctlConfigInput = {}): SctlConfig {
  const config = resolveSctlConfig(context, input);
  ensureDir(config.context_repo_path);
  if (!fileExists(path.join(config.context_repo_path, ".git"))) {
    const init = runGit(config.context_repo_path, ["init", "-b", config.authoritative_branch]);
    if (!init.ok) {
      assertGit(config.context_repo_path, ["init"]);
    }
  }
  ensureGitIdentity(config.context_repo_path);
  if (!hasCommit(config.context_repo_path)) {
    ensureBaseFiles(config.context_repo_path);
    assertGit(config.context_repo_path, ["add", "."]);
    assertGit(config.context_repo_path, ["commit", "-m", "Initialize Strata A/B/C context store"]);
  }
  if (!branchExists(config.context_repo_path, config.authoritative_branch)) {
    const current = currentBranch(config.context_repo_path);
    if (current) assertGit(config.context_repo_path, ["branch", "-M", config.authoritative_branch]);
    else assertGit(config.context_repo_path, ["checkout", "-B", config.authoritative_branch]);
  }
  assertGit(config.context_repo_path, ["checkout", config.authoritative_branch]);
  ensureBaseFiles(config.context_repo_path);
  const porcelain = runGit(config.context_repo_path, ["status", "--porcelain"]).stdout.trim();
  if (porcelain) {
    assertGit(config.context_repo_path, ["add", "."]);
    assertGit(config.context_repo_path, ["commit", "-m", "Maintain Strata A/B/C context base layout"]);
  }
  writeDiscoverableSctlConfig(context, input);
  return config;
}

export function proposalBranch(config: SctlConfig, callerId: string, proposalId: string): string {
  return `${config.proposal_branch_prefix}/${safePart(callerId)}/${safePart(proposalId)}`;
}

function proposalMetadataPath(proposalId: string): string {
  return `proposals/${safePart(proposalId)}/proposal.json`;
}

function normalizeRepoPath(candidate: string): string {
  if (!candidate.trim()) throw new Error("Target path is required.");
  if (path.isAbsolute(candidate)) throw new Error(`Context path must be repository-relative, not absolute: ${candidate}`);
  const normalized = path.posix.normalize(toPosix(candidate).replace(/^\/+/, ""));
  if (normalized === "." || normalized.startsWith("../") || normalized.includes("/../") || normalized === "..") {
    throw new Error(`Context path escapes repository root: ${candidate}`);
  }
  if (normalized === ".git" || normalized.startsWith(".git/")) throw new Error("Context path may not target .git.");
  return normalized;
}

function classForPath(repoPath: string): ContextClassABC | null {
  const normalized = normalizeRepoPath(repoPath);
  if (normalized.startsWith("class_a/")) return "A";
  if (normalized.startsWith("class_b/")) return "B";
  if (normalized.startsWith("class_c/")) return "C";
  return null;
}

function isAllowedContextPath(repoPath: string): boolean {
  const normalized = normalizeRepoPath(repoPath);
  if (normalized.startsWith("class_a/") && !normalized.endsWith("/")) return true;
  if (normalized === "class_b/timing_index.json") return true;
  if (normalized.startsWith("class_b/entries/") && !normalized.endsWith("/")) return true;
  if (normalized.startsWith("class_c/file_pins/") && normalized.endsWith(".json")) return true;
  return false;
}

function isAllowedProposalMetadataPath(repoPath: string, proposalId: string): boolean {
  return normalizeRepoPath(repoPath) === proposalMetadataPath(proposalId);
}

function readGitFile(repoPath: string, branch: string, repoFilePath: string): string | null {
  const result = runGit(repoPath, ["show", `${branch}:${repoFilePath}`]);
  return result.ok ? result.stdout : null;
}

function listGitFiles(repoPath: string, branch: string, prefix: string): string[] {
  const result = runGit(repoPath, ["ls-tree", "-r", "--name-only", branch, prefix]);
  if (!result.ok || !result.stdout.trim()) return [];
  return result.stdout.split(/\r?\n/).map((item) => item.trim()).filter(Boolean).sort();
}

function parseFrontmatter(text: string): Record<string, string> {
  const lines = text.split(/\r?\n/);
  if (lines[0]?.trim() !== "---") return {};
  const data: Record<string, string> = {};
  for (let i = 1; i < lines.length; i += 1) {
    const line = lines[i];
    if (line.trim() === "---") break;
    const idx = line.indexOf(":");
    if (idx > 0) data[line.slice(0, idx).trim()] = line.slice(idx + 1).trim().replace(/^['"]|['"]$/g, "");
  }
  return data;
}

function parseJsonObject(text: string): Record<string, unknown> | null {
  try {
    const parsed = JSON.parse(text) as unknown;
    return typeof parsed === "object" && parsed !== null && !Array.isArray(parsed) ? parsed as Record<string, unknown> : null;
  } catch {
    return null;
  }
}

function semanticIdForContent(repoFilePath: string, text: string): string | null {
  const normalized = normalizeRepoPath(repoFilePath);
  const json = parseJsonObject(text);
  if (json) {
    const id = json.id ?? json.entry_id ?? json.file_pin_id ?? json.semantic_id;
    return typeof id === "string" && id.trim() ? id.trim() : null;
  }
  const frontmatter = parseFrontmatter(text);
  return frontmatter.id || frontmatter.entry_id || frontmatter.file_pin_id || null;
}

function validateSha256(value: string): boolean {
  return /^[a-f0-9]{64}$/i.test(value);
}

function validateClassFile(repoFilePath: string, text: string): string[] {
  const errors: string[] = [];
  const normalized = normalizeRepoPath(repoFilePath);
  if (!text.trim()) return [`${normalized}: file is empty.`];
  if (normalized.startsWith("class_a/")) {
    const json = parseJsonObject(text);
    const frontmatter = parseFrontmatter(text);
    if (json) {
      const klass = json.class ?? json.context_class;
      if (klass !== "A") errors.push(`${normalized}: Class A JSON must declare class/context_class A.`);
      if (typeof (json.id ?? json.title) !== "string") errors.push(`${normalized}: Class A JSON must include id or title.`);
    } else if (Object.keys(frontmatter).length > 0) {
      if (frontmatter.class !== "A" && frontmatter.context_class !== "A") errors.push(`${normalized}: Class A Markdown frontmatter must declare class A.`);
      if (!frontmatter.id && !frontmatter.title) errors.push(`${normalized}: Class A Markdown frontmatter must include id or title.`);
    } else if (!text.trim().startsWith("#")) {
      errors.push(`${normalized}: Class A Markdown must include frontmatter or a heading.`);
    }
  } else if (normalized === "class_b/timing_index.json") {
    const json = parseJsonObject(text);
    if (!json) errors.push(`${normalized}: timing index must be JSON object.`);
    else if (!Array.isArray(json.entries)) errors.push(`${normalized}: timing index must contain entries array.`);
    else {
      for (const [index, entry] of json.entries.entries()) {
        if (typeof entry !== "object" || entry === null || Array.isArray(entry)) {
          errors.push(`${normalized}: entries[${index}] must be an object.`);
          continue;
        }
        const item = entry as Record<string, unknown>;
        if (typeof item.id !== "string" || !item.id.trim()) errors.push(`${normalized}: entries[${index}].id is required.`);
        if (typeof item.path !== "string" || !item.path.startsWith("class_b/entries/")) errors.push(`${normalized}: entries[${index}].path must target class_b/entries/.`);
        if (typeof item.created_at !== "string" || !item.created_at.trim()) errors.push(`${normalized}: entries[${index}].created_at is required.`);
      }
    }
  } else if (normalized.startsWith("class_b/entries/")) {
    const json = parseJsonObject(text);
    const frontmatter = parseFrontmatter(text);
    if (json) {
      const klass = json.class ?? json.context_class;
      if (klass !== "B") errors.push(`${normalized}: Class B JSON must declare class/context_class B.`);
      if (typeof (json.id ?? json.entry_id) !== "string") errors.push(`${normalized}: Class B JSON must include id or entry_id.`);
      if (typeof (json.created_at ?? json.accepted_at ?? json.timing) !== "string") errors.push(`${normalized}: Class B JSON must include created_at/accepted_at/timing metadata.`);
    } else {
      if (frontmatter.class !== "B" && frontmatter.context_class !== "B") errors.push(`${normalized}: Class B Markdown frontmatter must declare class B.`);
      if (!frontmatter.id && !frontmatter.entry_id) errors.push(`${normalized}: Class B Markdown frontmatter must include id or entry_id.`);
      if (!frontmatter.created_at && !frontmatter.accepted_at && !frontmatter.timing) errors.push(`${normalized}: Class B Markdown frontmatter must include timing metadata.`);
    }
  } else if (normalized.startsWith("class_c/file_pins/")) {
    const json = parseJsonObject(text);
    if (!json) errors.push(`${normalized}: Class C file pin must be JSON.`);
    else {
      const klass = json.class ?? json.context_class;
      if (klass !== "C") errors.push(`${normalized}: Class C file pin must declare class/context_class C.`);
      if (typeof (json.file_pin_id ?? json.id) !== "string") errors.push(`${normalized}: Class C file pin must include file_pin_id or id.`);
      if (typeof (json.path ?? json.file_path) !== "string") errors.push(`${normalized}: Class C file pin must include path or file_path.`);
      const checksum = json.checksum_sha256 ?? json.sha256;
      if (typeof checksum !== "string" || !validateSha256(checksum)) errors.push(`${normalized}: Class C file pin must include valid checksum_sha256/sha256.`);
    }
  }
  return errors;
}

function idsInBranch(repoPath: string, branch: string, prefix: string): Map<string, string> {
  const ids = new Map<string, string>();
  for (const file of listGitFiles(repoPath, branch, prefix)) {
    const text = readGitFile(repoPath, branch, file);
    if (!text) continue;
    const id = semanticIdForContent(file, text);
    if (id) ids.set(id, file);
  }
  return ids;
}

function changedPaths(repoPath: string, baseBranch: string, proposalBranchName: string): string[] {
  const result = runGit(repoPath, ["diff", "--name-only", `${baseBranch}...${proposalBranchName}`]);
  if (!result.ok) throw new Error(`Unable to diff proposal branch: ${result.stderr || result.stdout}`);
  return result.stdout.split(/\r?\n/).map((item) => item.trim()).filter(Boolean).sort();
}

function changedContextPaths(paths: string[], proposalId: string): string[] {
  return paths.filter((item) => !isAllowedProposalMetadataPath(item, proposalId));
}

function classesTouched(paths: string[]): ContextClassABC[] {
  return unique(paths.map((item) => classForPath(item)).filter((item): item is ContextClassABC => item !== null)).sort();
}

function loadProposalMetadata(repoPath: string, branch: string, proposalId: string): ContextProposalMetadata {
  const metadataPath = proposalMetadataPath(proposalId);
  const text = readGitFile(repoPath, branch, metadataPath);
  if (!text) throw new Error(`Proposal metadata not found on ${branch}: ${metadataPath}`);
  return JSON.parse(text) as ContextProposalMetadata;
}

function writeProposalMetadataFile(repoPath: string, metadata: ContextProposalMetadata): string {
  const target = path.join(repoPath, proposalMetadataPath(metadata.proposal_id));
  writeJson(target, metadata);
  return target;
}

function commitIfNeeded(repoPath: string, message: string): string | null {
  const status = runGit(repoPath, ["status", "--porcelain"]).stdout.trim();
  if (!status) return null;
  assertGit(repoPath, ["add", "."]);
  assertGit(repoPath, ["commit", "-m", message]);
  return assertGit(repoPath, ["rev-parse", "HEAD"]).stdout.trim();
}

function defaultPathFor(klass: ContextClassABC, semanticId: string): string {
  const safeId = safePart(semanticId);
  if (klass === "A") return `class_a/${safeId}.md`;
  if (klass === "B") return `class_b/entries/${safeId}.md`;
  return `class_c/file_pins/${safeId}.json`;
}

function buildContent(input: ProposalInput, repoFilePath: string, now: Date): string {
  if (input.sourceFile) return readText(path.resolve(input.sourceFile));
  if (input.klass === "C" || normalizeRepoPath(repoFilePath).startsWith("class_c/file_pins/")) {
    const id = input.semanticId ?? safePart(path.basename(repoFilePath, path.extname(repoFilePath)));
    let checksum = input.checksumSha256;
    const pinnedPath = input.pinnedPath ?? input.targetPath ?? "";
    if (!checksum && pinnedPath && fileExists(path.resolve(pinnedPath))) checksum = hashText(readText(path.resolve(pinnedPath)));
    checksum = checksum ?? "0".repeat(64);
    return `${JSON.stringify({
      contract_id: "class_c.file_pin.v1",
      class: "C",
      file_pin_id: id,
      path: pinnedPath || input.title || id,
      checksum_sha256: checksum,
      created_at: isoStamp(now),
    }, null, 2)}\n`;
  }
  const body = input.body ?? "";
  const klass = input.klass ?? classForPath(repoFilePath);
  if (!klass) throw new Error(`Cannot infer context class for ${repoFilePath}.`);
  const id = input.semanticId ?? safePart(path.basename(repoFilePath, path.extname(repoFilePath)));
  const title = input.title ?? id;
  if (klass === "A") {
    return [
      "---",
      "class: A",
      `id: ${id}`,
      `title: ${title}`,
      `created_at: ${isoStamp(now)}`,
      "---",
      "",
      body.trim() || `# ${title}`,
      "",
    ].join("\n");
  }
  return [
    "---",
    "class: B",
    `id: ${id}`,
    `title: ${title}`,
    `created_at: ${isoStamp(now)}`,
    "---",
    "",
    body.trim() || `# ${title}`,
    "",
  ].join("\n");
}

function updateTimingIndex(repoPath: string, entryPath: string, entryId: string, now: Date): void {
  const target = path.join(repoPath, "class_b", "timing_index.json");
  const existing = fileExists(target) ? readJson<Record<string, unknown>>(target) : { contract_id: "class_b.timing_index.v1", entries: [] };
  const entriesRaw = Array.isArray(existing.entries) ? existing.entries : [];
  const entries = entriesRaw.filter((entry) => {
    if (typeof entry !== "object" || entry === null || Array.isArray(entry)) return false;
    return (entry as Record<string, unknown>).id !== entryId;
  });
  entries.push({ id: entryId, path: entryPath, created_at: isoStamp(now), sequence: entries.length + 1 });
  writeJson(target, { contract_id: "class_b.timing_index.v1", entries });
}

function validationArtifactPath(context: CommandContext, proposalId: string): string {
  return path.join(context.workspaceRoot, ".strata", "context_proposals", safePart(proposalId), "validation.json");
}

function diffArtifactPath(context: CommandContext, proposalId: string): string {
  return path.join(context.workspaceRoot, ".strata", "context_proposals", safePart(proposalId), "diff.patch");
}

export function repoStatus(context: CommandContext, input: SctlConfigInput = {}): ToolRunEnvelope & Record<string, unknown> {
  const config = ensureContextRepo(context, input);
  const head = assertGit(config.context_repo_path, ["rev-parse", "HEAD"]).stdout.trim();
  const branch = currentBranch(config.context_repo_path);
  const status = runGit(config.context_repo_path, ["status", "--short", "--branch"]).stdout;
  return writeToolRun(context, {
    ok: true,
    toolId: "context.repo_status.v1",
    payload: {
      context_repo_path: config.context_repo_path,
      authoritative_branch: config.authoritative_branch,
      proposal_branch_prefix: config.proposal_branch_prefix,
      current_branch: branch,
      head,
      git_status: status,
      sctl_name: "Strata Context Tool Layer",
    },
  });
}

export function createContextProposal(context: CommandContext, input: ProposalInput): ToolRunEnvelope & Record<string, unknown> {
  const config = ensureContextRepo(context, input);
  const branch = proposalBranch(config, input.callerId, input.proposalId);
  assertActionAllowed({
    action: "context.propose",
    caller_id: input.callerId,
    caller_role: input.callerRole,
    target_branch: branch,
    authoritative_branch: config.authoritative_branch,
    proposal_id: input.proposalId,
  });
  assertGit(config.context_repo_path, ["checkout", config.authoritative_branch]);
  const baseCommit = assertGit(config.context_repo_path, ["rev-parse", config.authoritative_branch]).stdout.trim();
  if (branchExists(config.context_repo_path, branch)) {
    assertGit(config.context_repo_path, ["checkout", branch]);
  } else {
    assertGit(config.context_repo_path, ["checkout", "-b", branch, config.authoritative_branch]);
  }
  const semanticId = input.semanticId ?? input.proposalId;
  const repoFilePath = normalizeRepoPath(input.targetPath ?? defaultPathFor(input.klass ?? "B", semanticId));
  if (!isAllowedContextPath(repoFilePath)) throw new Error(`Disallowed A/B/C proposal target path: ${repoFilePath}`);
  const klass = input.klass ?? classForPath(repoFilePath);
  if (!klass) throw new Error(`Target path does not map to Class A/B/C context: ${repoFilePath}`);
  const content = buildContent({ ...input, klass, semanticId }, repoFilePath, context.now);
  const fileErrors = validateClassFile(repoFilePath, content);
  if (fileErrors.length > 0) throw new Error(`Invalid proposed context schema: ${fileErrors.join("; ")}`);
  writeText(path.join(config.context_repo_path, repoFilePath), content);
  if (klass === "B" && repoFilePath.startsWith("class_b/entries/")) updateTimingIndex(config.context_repo_path, repoFilePath, semanticId, context.now);
  const allChangedBeforeMetadata = unique([repoFilePath, ...(klass === "B" ? ["class_b/timing_index.json"] : [])]);
  const metadata: ContextProposalMetadata = {
    proposal_id: input.proposalId,
    proposal_branch: branch,
    assigned_worktree: input.assignedWorktree ?? null,
    caller_id: input.callerId,
    caller_role: input.callerRole,
    origin_worker_id: input.originWorkerId ?? input.callerId,
    origin_worker_session_id: input.originWorkerSessionId ?? null,
    origin_dispatch_channel: input.originDispatchChannel ?? null,
    created_at: isoStamp(context.now),
    updated_at: isoStamp(context.now),
    base_commit: baseCommit,
    changed_paths: allChangedBeforeMetadata,
    context_classes_touched: classesTouched(allChangedBeforeMetadata),
    intended_action: input.intendedAction ?? "propose_context_change",
    review_status: "draft",
    reviewer_id: null,
    reviewed_at: null,
    reason_file: null,
    validation_result_path: null,
    merge_commit: null,
  };
  writeProposalMetadataFile(config.context_repo_path, metadata);
  const commit = commitIfNeeded(config.context_repo_path, input.commitMessage ?? `Propose Strata context change ${input.proposalId}`);
  const validation = validateProposal(context, { proposalId: input.proposalId, contextRepoPath: config.context_repo_path });
  return writeToolRun(context, {
    ok: Boolean(validation.ok),
    toolId: "context.propose.v1",
    evidencePaths: [validation.result_path],
    errors: validation.ok ? [] : validation.errors,
    payload: {
      proposal_id: input.proposalId,
      proposal_branch: branch,
      base_commit: baseCommit,
      proposal_commit: commit,
      changed_paths: allChangedBeforeMetadata,
      validation_result_path: validation.result_path,
    },
  });
}

export function validateProposal(context: CommandContext, input: { proposalId: string } & SctlConfigInput): ValidationResult & { result_path: string } {
  const config = ensureContextRepo(context, input);
  const branches = runGit(config.context_repo_path, ["for-each-ref", "--format=%(refname:short)", "refs/heads"]);
  const branch = branches.stdout.split(/\r?\n/).find((item) => item.endsWith(`/${safePart(input.proposalId)}`))
    ?? proposalBranch(config, "unknown", input.proposalId);
  const errors: string[] = [];
  const warnings: string[] = [];
  let paths: string[] = [];
  let metadata: ContextProposalMetadata | null = null;
  let metadataPath: string | null = null;
  if (!branchExists(config.context_repo_path, branch)) {
    errors.push(`Proposal branch does not exist: ${branch}`);
  } else {
    try {
      metadata = loadProposalMetadata(config.context_repo_path, branch, input.proposalId);
      metadataPath = proposalMetadataPath(input.proposalId);
      if (metadata.proposal_branch !== branch) errors.push(`Metadata proposal_branch ${metadata.proposal_branch} does not match branch ${branch}.`);
      if (!metadata.proposal_id) errors.push("Proposal metadata missing proposal_id.");
      if (!metadata.caller_id) errors.push("Proposal metadata missing caller_id.");
      if (!metadata.caller_role) errors.push("Proposal metadata missing caller_role.");
      if (!metadata.origin_worker_id) errors.push("Proposal metadata missing origin_worker_id.");
      if (!metadata.base_commit) errors.push("Proposal metadata missing base_commit.");
      const actionDecision = evaluateAction({
        action: "context.propose",
        caller_id: metadata.caller_id,
        caller_role: metadata.caller_role,
        target_branch: branch,
        authoritative_branch: config.authoritative_branch,
        proposal_id: metadata.proposal_id,
      });
      if (!actionDecision.ok) errors.push(actionDecision.reason);
    } catch (error) {
      errors.push(error instanceof Error ? error.message : String(error));
    }
    try {
      paths = changedPaths(config.context_repo_path, config.authoritative_branch, branch);
    } catch (error) {
      errors.push(error instanceof Error ? error.message : String(error));
    }
  }

  const contextPaths = changedContextPaths(paths, input.proposalId);
  if (contextPaths.length === 0 && errors.length === 0) warnings.push("Proposal contains no A/B/C context path changes.");
  for (const changed of paths) {
    try {
      const normalized = normalizeRepoPath(changed);
      if (!isAllowedContextPath(normalized) && !isAllowedProposalMetadataPath(normalized, input.proposalId)) {
        errors.push(`Disallowed proposal path: ${changed}`);
        continue;
      }
      if (normalized.startsWith("class_d/") || normalized.includes("class_d")) {
        errors.push(`Class D may not be written into authoritative A/B/C context: ${changed}`);
      }
      if (isAllowedContextPath(normalized)) {
        const text = readGitFile(config.context_repo_path, branch, normalized);
        if (text === null) errors.push(`Changed path is not readable on proposal branch: ${normalized}`);
        else errors.push(...validateClassFile(normalized, text));
      }
    } catch (error) {
      errors.push(error instanceof Error ? error.message : String(error));
    }
  }

  const mainBIds = idsInBranch(config.context_repo_path, config.authoritative_branch, "class_b/entries");
  const mainCIds = idsInBranch(config.context_repo_path, config.authoritative_branch, "class_c/file_pins");
  for (const changed of contextPaths) {
    const text = readGitFile(config.context_repo_path, branch, changed);
    if (text === null) continue;
    const id = semanticIdForContent(changed, text);
    if (!id) continue;
    if (changed.startsWith("class_b/entries/") && mainBIds.has(id)) errors.push(`Duplicate Class B semantic id already exists in authoritative context: ${id}`);
    if (changed.startsWith("class_c/file_pins/") && mainCIds.has(id)) errors.push(`Duplicate Class C file pin id already exists in authoritative context: ${id}`);
  }

  const mergedMarker = readGitFile(config.context_repo_path, config.authoritative_branch, `proposals/merged/${safePart(input.proposalId)}.json`);
  if (mergedMarker) errors.push(`Proposal has already been merged: ${input.proposalId}`);

  const result: ValidationResult & { result_path: string } = {
    ok: errors.length === 0,
    proposal_id: input.proposalId,
    proposal_branch: metadata?.proposal_branch ?? branch,
    base_branch: config.authoritative_branch,
    changed_paths: paths,
    context_paths: contextPaths,
    errors,
    warnings,
    validated_at: isoStamp(context.now),
    metadata_path: metadataPath,
    result_path: validationArtifactPath(context, input.proposalId),
  };
  writeJson(result.result_path, result);
  if (metadata && branchExists(config.context_repo_path, branch)) {
    assertGit(config.context_repo_path, ["checkout", branch]);
    const updated = { ...metadata, validation_result_path: result.result_path, updated_at: isoStamp(context.now) };
    writeProposalMetadataFile(config.context_repo_path, updated);
    commitIfNeeded(config.context_repo_path, `Record validation for proposal ${input.proposalId}`);
  }
  return result;
}

export function validateProposalTool(context: CommandContext, input: { proposalId: string; callerId?: string; callerRole?: string } & SctlConfigInput): ToolRunEnvelope & Record<string, unknown> {
  const validation = validateProposal(context, input);
  return writeToolRun(context, {
    ok: validation.ok,
    toolId: "context.validate.v1",
    evidencePaths: [validation.result_path],
    errors: validation.errors,
    warnings: validation.warnings,
    payload: { ...validation },
  });
}

export function diffProposal(context: CommandContext, input: DiffInput): ToolRunEnvelope & Record<string, unknown> {
  const config = ensureContextRepo(context, input);
  const validation = validateProposal(context, input);
  const branch = validation.proposal_branch;
  const diff = assertGit(config.context_repo_path, ["diff", `${config.authoritative_branch}...${branch}`]).stdout;
  const diffPath = diffArtifactPath(context, input.proposalId);
  writeText(diffPath, diff);
  return writeToolRun(context, {
    ok: true,
    toolId: "context.diff.v1",
    evidencePaths: [diffPath, validation.result_path],
    payload: { proposal_id: input.proposalId, proposal_branch: branch, diff_path: diffPath, validation_result_path: validation.result_path },
  });
}

function updateReviewStatus(context: CommandContext, input: ReviewInput, status: ProposalReviewStatus, action: "context.approve" | "context.reject" | "context.request_revision"): { metadata: ContextProposalMetadata; branch: string; dispatchPath?: string; warnings: string[] } {
  const config = ensureContextRepo(context, input);
  const validation = validateProposal(context, input);
  const branch = validation.proposal_branch;
  const metadata = loadProposalMetadata(config.context_repo_path, branch, input.proposalId);
  assertActionAllowed({
    action,
    caller_id: input.reviewerId,
    caller_role: input.reviewerRole,
    target_branch: branch,
    authoritative_branch: config.authoritative_branch,
    origin_worker_id: metadata.origin_worker_id,
    proposal_caller_id: metadata.caller_id,
    proposal_id: metadata.proposal_id,
  });
  if (!validation.ok && action === "context.approve") throw new Error(`Cannot approve invalid proposal ${input.proposalId}: ${validation.errors.join("; ")}`);
  assertGit(config.context_repo_path, ["checkout", branch]);
  const updated: ContextProposalMetadata = {
    ...metadata,
    review_status: status,
    reviewer_id: input.reviewerId,
    reviewed_at: isoStamp(context.now),
    reason_file: input.reasonFile ? path.resolve(input.reasonFile) : null,
    validation_result_path: validation.result_path,
    updated_at: isoStamp(context.now),
  };
  writeProposalMetadataFile(config.context_repo_path, updated);
  commitIfNeeded(config.context_repo_path, `Record ${status} review outcome for proposal ${input.proposalId}`);
  const warnings: string[] = [];
  let dispatchPath: string | undefined;
  if (status === "rejected" || status === "needs_revision") {
    const dispatch = dispatchReviewDecision(context, updated, status, input.reasonFile ? path.resolve(input.reasonFile) : null);
    dispatchPath = dispatch.dispatchPath;
    warnings.push(...dispatch.warnings);
  }
  return { metadata: updated, branch, dispatchPath, warnings };
}

export function reviewRequest(context: CommandContext, input: { proposalId: string; callerId: string; callerRole: string } & SctlConfigInput): ToolRunEnvelope & Record<string, unknown> {
  const config = ensureContextRepo(context, input);
  const validation = validateProposal(context, input);
  const branch = validation.proposal_branch;
  const metadata = loadProposalMetadata(config.context_repo_path, branch, input.proposalId);
  assertActionAllowed({ action: "context.review_request", caller_id: input.callerId, caller_role: input.callerRole, target_branch: branch, authoritative_branch: config.authoritative_branch });
  assertGit(config.context_repo_path, ["checkout", branch]);
  const updated: ContextProposalMetadata = { ...metadata, review_status: "review_requested", validation_result_path: validation.result_path, updated_at: isoStamp(context.now) };
  writeProposalMetadataFile(config.context_repo_path, updated);
  commitIfNeeded(config.context_repo_path, `Mark proposal ${input.proposalId} review requested`);
  return writeToolRun(context, {
    ok: validation.ok,
    toolId: "context.review_request.v1",
    evidencePaths: [validation.result_path],
    errors: validation.errors,
    warnings: validation.warnings,
    payload: { proposal_id: input.proposalId, proposal_branch: branch, review_status: updated.review_status, validation_result_path: validation.result_path },
  });
}

export function approveProposal(context: CommandContext, input: ReviewInput): ToolRunEnvelope & Record<string, unknown> {
  const result = updateReviewStatus(context, input, "approved", "context.approve");
  return writeToolRun(context, {
    ok: true,
    toolId: "context.approve.v1",
    evidencePaths: [validationArtifactPath(context, input.proposalId)],
    warnings: result.warnings,
    payload: { proposal_id: input.proposalId, proposal_branch: result.branch, review_status: result.metadata.review_status, reviewer_id: input.reviewerId },
  });
}

export function rejectProposal(context: CommandContext, input: ReviewInput): ToolRunEnvelope & Record<string, unknown> {
  const result = updateReviewStatus(context, input, "rejected", "context.reject");
  return writeToolRun(context, {
    ok: true,
    toolId: "context.reject.v1",
    evidencePaths: [result.dispatchPath, validationArtifactPath(context, input.proposalId)].filter((item): item is string => Boolean(item)),
    warnings: result.warnings,
    payload: { proposal_id: input.proposalId, proposal_branch: result.branch, review_status: result.metadata.review_status, reviewer_id: input.reviewerId, dispatch_path: result.dispatchPath ?? null },
  });
}

export function requestRevision(context: CommandContext, input: ReviewInput): ToolRunEnvelope & Record<string, unknown> {
  const result = updateReviewStatus(context, input, "needs_revision", "context.request_revision");
  return writeToolRun(context, {
    ok: true,
    toolId: "context.request_revision.v1",
    evidencePaths: [result.dispatchPath, validationArtifactPath(context, input.proposalId)].filter((item): item is string => Boolean(item)),
    warnings: result.warnings,
    payload: { proposal_id: input.proposalId, proposal_branch: result.branch, review_status: result.metadata.review_status, reviewer_id: input.reviewerId, dispatch_path: result.dispatchPath ?? null },
  });
}

function dispatchReviewDecision(context: CommandContext, metadata: ContextProposalMetadata, status: "rejected" | "needs_revision", reasonFile: string | null): { dispatchPath: string; warnings: string[] } {
  const dir = ensureDir(path.join(context.workspaceRoot, ".strata", "dispatches", "review_decisions", safePart(metadata.proposal_id)));
  const affected = metadata.changed_paths.join(", ");
  const reason = reasonFile ?? "<none>";
  const message = status === "needs_revision"
    ? [
      "REVIEW_DECISION: NEEDS_REVISION",
      "",
      `Proposal: ${metadata.proposal_id}`,
      `Affected file(s): ${affected}`,
      `Reviewer note: ${reason}`,
      "Required action: revise the proposal and resubmit through the assigned return/proposal path.",
      "Do not treat this chat message as the deliverable. Return revised files through the assigned path.",
      "",
    ].join("\n")
    : [
      "REVIEW_DECISION: REJECTED",
      "",
      `Proposal: ${metadata.proposal_id}`,
      `Affected file(s): ${affected}`,
      `Reviewer note: ${reason}`,
      "Required action: stop work on this proposal unless a new dispatch is issued.",
      "Do not treat this chat message as the deliverable.",
      "",
    ].join("\n");
  const dispatchPath = writeText(path.join(dir, `${status}_message.md`), message);
  const warnings: string[] = [];
  if (metadata.origin_dispatch_channel) {
    writeJson(path.join(dir, "dispatch_target.json"), {
      proposal_id: metadata.proposal_id,
      origin_worker_id: metadata.origin_worker_id,
      origin_worker_session_id: metadata.origin_worker_session_id,
      origin_dispatch_channel: metadata.origin_dispatch_channel,
      message_path: dispatchPath,
      created_at: isoStamp(context.now),
    });
    const channel = metadata.origin_dispatch_channel;
    const maybeFile = channel.startsWith("file:") ? channel.slice(5) : channel;
    if (maybeFile.startsWith("/") || maybeFile.startsWith(".")) {
      const target = path.resolve(context.workspaceRoot, maybeFile);
      writeText(target, message);
    }
  } else {
    const needed = path.join(dir, "dispatch_needed.json");
    writeJson(needed, {
      proposal_id: metadata.proposal_id,
      origin_worker_id: metadata.origin_worker_id,
      warning: "origin_dispatch_channel was not present in proposal metadata; manual dispatch is required.",
      message_path: dispatchPath,
      created_at: isoStamp(context.now),
    });
    warnings.push(`Dispatch channel unknown for proposal ${metadata.proposal_id}; wrote dispatch-needed artifact: ${needed}`);
  }
  return { dispatchPath, warnings };
}

export function mergeProposal(context: CommandContext, input: MergeInput): ToolRunEnvelope & Record<string, unknown> {
  const config = ensureContextRepo(context, input);
  const validation = validateProposal(context, input);
  const branch = validation.proposal_branch;
  const metadata = loadProposalMetadata(config.context_repo_path, branch, input.proposalId);
  assertActionAllowed({
    action: "context.merge",
    caller_id: input.callerId,
    caller_role: input.callerRole,
    target_branch: config.authoritative_branch,
    authoritative_branch: config.authoritative_branch,
    proposal_branch: branch,
    proposal_id: input.proposalId,
  });
  if (!validation.ok) throw new Error(`Cannot merge invalid proposal ${input.proposalId}: ${validation.errors.join("; ")}`);
  if (metadata.review_status !== "approved") throw new Error(`Cannot merge proposal ${input.proposalId}; review_status must be approved, not ${metadata.review_status}.`);
  assertGit(config.context_repo_path, ["checkout", config.authoritative_branch]);
  const merge = runGit(config.context_repo_path, ["merge", "--no-ff", branch, "-m", input.message ?? `Merge Strata context proposal ${input.proposalId}`]);
  if (!merge.ok) {
    runGit(config.context_repo_path, ["merge", "--abort"]);
    throw new Error(`Git merge failed for proposal ${input.proposalId}: ${merge.stderr || merge.stdout}`);
  }
  const mergeCommit = assertGit(config.context_repo_path, ["rev-parse", "HEAD"]).stdout.trim();
  const markerPath = path.join(config.context_repo_path, "proposals", "merged", `${safePart(input.proposalId)}.json`);
  writeJson(markerPath, { proposal_id: input.proposalId, proposal_branch: branch, merged_by: input.callerId, merged_role: input.callerRole, merged_at: isoStamp(context.now), merge_commit: mergeCommit });
  commitIfNeeded(config.context_repo_path, `Record merged proposal marker ${input.proposalId}`);
  return writeToolRun(context, {
    ok: true,
    toolId: "context.merge.v1",
    evidencePaths: [validation.result_path],
    payload: { proposal_id: input.proposalId, proposal_branch: branch, authoritative_branch: config.authoritative_branch, merge_commit: mergeCommit, validation_result_path: validation.result_path },
  });
}

export function revertContext(context: CommandContext, input: { commit: string; callerId: string; callerRole: string } & SctlConfigInput): ToolRunEnvelope & Record<string, unknown> {
  const config = ensureContextRepo(context, input);
  assertActionAllowed({ action: "context.revert", caller_id: input.callerId, caller_role: input.callerRole, target_branch: config.authoritative_branch, authoritative_branch: config.authoritative_branch });
  assertGit(config.context_repo_path, ["checkout", config.authoritative_branch]);
  const revert = runGit(config.context_repo_path, ["revert", "--no-edit", input.commit]);
  if (!revert.ok) {
    runGit(config.context_repo_path, ["revert", "--abort"]);
    throw new Error(`Git revert failed: ${revert.stderr || revert.stdout}`);
  }
  const head = assertGit(config.context_repo_path, ["rev-parse", "HEAD"]).stdout.trim();
  return writeToolRun(context, { ok: true, toolId: "context.revert.v1", payload: { reverted_commit: input.commit, head } });
}

export function listAuthoritativeContext(context: CommandContext, input: SctlConfigInput = {}): ToolRunEnvelope & Record<string, unknown> {
  const config = ensureContextRepo(context, input);
  const files = [
    ...listGitFiles(config.context_repo_path, config.authoritative_branch, "class_a"),
    ...listGitFiles(config.context_repo_path, config.authoritative_branch, "class_c/file_pins"),
    ...listGitFiles(config.context_repo_path, config.authoritative_branch, "class_b"),
  ].filter((file) => !file.endsWith(".gitkeep"));
  return writeToolRun(context, { ok: true, toolId: "context.list.v1", payload: { context_repo_path: config.context_repo_path, branch: config.authoritative_branch, files } });
}

export function contextSummaryGit(context: CommandContext, input: SctlConfigInput = {}): ToolRunEnvelope & Record<string, unknown> {
  const config = ensureContextRepo(context, input);
  const classA = listGitFiles(config.context_repo_path, config.authoritative_branch, "class_a");
  const classC = listGitFiles(config.context_repo_path, config.authoritative_branch, "class_c/file_pins");
  const classB = listGitFiles(config.context_repo_path, config.authoritative_branch, "class_b/entries");
  const timing = readGitFile(config.context_repo_path, config.authoritative_branch, "class_b/timing_index.json");
  return writeToolRun(context, {
    ok: true,
    toolId: "context.summary.v1",
    payload: {
      generated_at: isoStamp(context.now),
      context_repo_path: config.context_repo_path,
      branch: config.authoritative_branch,
      class_a_count: classA.length,
      class_c_file_pin_count: classC.length,
      class_b_entry_count: classB.length,
      timing_index_present: Boolean(timing),
    },
  });
}

export function writeManualInvalidProposalForTests(context: CommandContext, input: { proposalId: string; callerId: string; callerRole: string; targetPath: string; content: string } & SctlConfigInput): string {
  const config = ensureContextRepo(context, input);
  const branch = proposalBranch(config, input.callerId, input.proposalId);
  assertGit(config.context_repo_path, ["checkout", "-B", branch, config.authoritative_branch]);
  const normalized = normalizeRepoPath(input.targetPath);
  writeText(path.join(config.context_repo_path, normalized), input.content);
  const metadata: ContextProposalMetadata = {
    proposal_id: input.proposalId,
    proposal_branch: branch,
    assigned_worktree: null,
    caller_id: input.callerId,
    caller_role: input.callerRole,
    origin_worker_id: input.callerId,
    origin_worker_session_id: null,
    origin_dispatch_channel: null,
    created_at: isoStamp(context.now),
    updated_at: isoStamp(context.now),
    base_commit: assertGit(config.context_repo_path, ["rev-parse", config.authoritative_branch]).stdout.trim(),
    changed_paths: [normalized],
    context_classes_touched: classesTouched([normalized]),
    intended_action: "test_invalid_proposal",
    review_status: "draft",
    reviewer_id: null,
    reviewed_at: null,
    reason_file: null,
    validation_result_path: null,
    merge_commit: null,
  };
  writeProposalMetadataFile(config.context_repo_path, metadata);
  commitIfNeeded(config.context_repo_path, `Write invalid test proposal ${input.proposalId}`);
  return branch;
}
