import path from "node:path";
import { ensureDir, fileExists, readJson, type CommandContext, writeJson } from "../common.js";

export interface SctlConfig {
  context_repo_path: string;
  authoritative_branch: string;
  proposal_branch_prefix: string;
}

export interface SctlConfigInput {
  contextRepoPath?: string;
  authoritativeBranch?: string;
  proposalBranchPrefix?: string;
}

function readConfigFile(configPath: string): Partial<SctlConfig> {
  if (!fileExists(configPath)) return {};
  const parsed = readJson<Record<string, unknown>>(configPath);
  const nested = typeof parsed.sctl === "object" && parsed.sctl !== null ? (parsed.sctl as Record<string, unknown>) : parsed;
  return {
    context_repo_path: typeof nested.context_repo_path === "string" ? nested.context_repo_path : undefined,
    authoritative_branch: typeof nested.authoritative_branch === "string" ? nested.authoritative_branch : undefined,
    proposal_branch_prefix: typeof nested.proposal_branch_prefix === "string" ? nested.proposal_branch_prefix : undefined,
  };
}

export function sctlConfigPath(context: CommandContext): string {
  return path.join(context.workspaceRoot, ".strata", "sctl_config.json");
}

export function resolveSctlConfig(context: CommandContext, input: SctlConfigInput = {}): SctlConfig {
  const strataRoot = ensureDir(path.join(context.workspaceRoot, ".strata"));
  const explicitConfig = readConfigFile(path.join(strataRoot, "sctl_config.json"));
  const legacyConfig = readConfigFile(path.join(strataRoot, "config.json"));
  const contextRepoPath = input.contextRepoPath
    ?? process.env.STRATA_CONTEXT_REPO_PATH
    ?? explicitConfig.context_repo_path
    ?? legacyConfig.context_repo_path
    ?? path.join(strataRoot, "context_repo");
  const authoritativeBranch = input.authoritativeBranch
    ?? process.env.STRATA_CONTEXT_AUTHORITATIVE_BRANCH
    ?? explicitConfig.authoritative_branch
    ?? legacyConfig.authoritative_branch
    ?? "context/main";
  const proposalBranchPrefix = input.proposalBranchPrefix
    ?? process.env.STRATA_CONTEXT_PROPOSAL_PREFIX
    ?? explicitConfig.proposal_branch_prefix
    ?? legacyConfig.proposal_branch_prefix
    ?? "proposal";
  return {
    context_repo_path: path.resolve(context.workspaceRoot, contextRepoPath),
    authoritative_branch: authoritativeBranch,
    proposal_branch_prefix: proposalBranchPrefix.replace(/\/+$/g, "") || "proposal",
  };
}

export function writeDiscoverableSctlConfig(context: CommandContext, input: SctlConfigInput = {}): string {
  const resolved = resolveSctlConfig(context, input);
  const target = sctlConfigPath(context);
  writeJson(target, resolved);
  return target;
}
