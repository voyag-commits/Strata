import path from "node:path";
import { ensureDir, fileStamp, isoStamp, type CommandContext, writeJson, writeText } from "../common.js";

export interface ToolRunEnvelope {
  ok: boolean;
  tool_id: string;
  tool_run_id: string;
  result_path: string;
  evidence_paths: string[];
  errors: string[];
  warnings?: string[];
}

export interface ToolRunWriteOptions {
  ok: boolean;
  toolId: string;
  toolRunId?: string;
  evidencePaths?: string[];
  errors?: string[];
  warnings?: string[];
  payload?: Record<string, unknown>;
  stdout?: string;
  stderr?: string;
  diagnostics?: Record<string, unknown>;
}

function safePart(value: string): string {
  return value.replace(/[^A-Za-z0-9_.-]+/g, "-").replace(/^-+|-+$/g, "") || "tool";
}

export function makeToolRunId(toolId: string, date = new Date()): string {
  return `${safePart(toolId)}_${fileStamp(date)}`;
}

export function toolRunDir(context: CommandContext, toolRunId: string): string {
  return ensureDir(path.join(context.workspaceRoot, ".strata", "backend", "tool_runs", safePart(toolRunId)));
}

export function writeToolRun(context: CommandContext, options: ToolRunWriteOptions): ToolRunEnvelope & Record<string, unknown> {
  const toolRunId = options.toolRunId ?? makeToolRunId(options.toolId, context.now);
  const dir = toolRunDir(context, toolRunId);
  const resultPath = path.join(dir, "result.json");
  const evidencePaths = options.evidencePaths ?? [];
  if (options.stdout !== undefined) writeText(path.join(dir, "stdout.txt"), options.stdout);
  if (options.stderr !== undefined) writeText(path.join(dir, "stderr.txt"), options.stderr);
  if (options.diagnostics !== undefined) writeJson(path.join(dir, "diagnostics.json"), options.diagnostics);
  const envelope: ToolRunEnvelope & Record<string, unknown> = {
    ok: options.ok,
    tool_id: options.toolId,
    tool_run_id: toolRunId,
    result_path: resultPath,
    evidence_paths: evidencePaths,
    errors: options.errors ?? [],
    ...(options.warnings && options.warnings.length > 0 ? { warnings: options.warnings } : {}),
    ...(options.payload ?? {}),
    completed_at: isoStamp(context.now),
  };
  writeJson(resultPath, envelope);
  return envelope;
}

export function writeFailedToolRun(context: CommandContext, toolId: string, error: unknown, diagnostics?: Record<string, unknown>): ToolRunEnvelope & Record<string, unknown> {
  const message = error instanceof Error ? error.message : String(error);
  return writeToolRun(context, {
    ok: false,
    toolId,
    errors: [message],
    stderr: `${message}\n`,
    diagnostics,
  });
}
