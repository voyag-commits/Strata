export type SctlAction =
  | "context.propose"
  | "context.validate"
  | "context.diff"
  | "context.review_request"
  | "context.approve"
  | "context.reject"
  | "context.request_revision"
  | "context.merge"
  | "context.revert"
  | "context.export"
  | "tool.run";

export interface CallerIdentity {
  caller_id: string;
  caller_role: string;
}

export interface ActionFilterInput extends CallerIdentity {
  action: SctlAction;
  target_branch?: string | null;
  target_path?: string | null;
  authoritative_branch?: string | null;
  proposal_branch?: string | null;
  proposal_id?: string | null;
  origin_worker_id?: string | null;
  proposal_caller_id?: string | null;
  review_status?: string | null;
}

export interface ActionFilterDecision {
  ok: boolean;
  code: string;
  reason: string;
}

export function normalizeRole(role: string | null | undefined): string {
  return String(role ?? "").trim().toLowerCase().replace(/[\s-]+/g, "_");
}

export function isHumanDirector(role: string | null | undefined): boolean {
  return ["human_director", "director", "human", "hd"].includes(normalizeRole(role));
}

export function isReviewer(role: string | null | undefined): boolean {
  return ["reviewer", "review", "ic_reviewer"].includes(normalizeRole(role));
}

export function isIncidentCommander(role: string | null | undefined): boolean {
  return ["ic", "incident_commander", "incident_commander_role"].includes(normalizeRole(role));
}

export function isWorker(role: string | null | undefined): boolean {
  return ["worker", "coder", "researcher", "agent_worker"].includes(normalizeRole(role));
}

function allowed(code: string, reason: string): ActionFilterDecision {
  return { ok: true, code, reason };
}

function denied(code: string, reason: string): ActionFilterDecision {
  return { ok: false, code, reason };
}

function sameIdentity(a: string | null | undefined, b: string | null | undefined): boolean {
  return Boolean(a && b && a.trim().toLowerCase() === b.trim().toLowerCase());
}

export function evaluateAction(input: ActionFilterInput): ActionFilterDecision {
  const role = normalizeRole(input.caller_role);
  const branch = input.target_branch ?? input.proposal_branch ?? "";
  const authoritativeBranch = input.authoritative_branch ?? "context/main";
  const isProposalBranch = branch.startsWith("proposal/") || branch.startsWith("refs/heads/proposal/");

  if (input.action === "context.merge") {
    if (!isHumanDirector(role)) {
      return denied("FINAL_MERGE_RESERVED_FOR_HUMAN_DIRECTOR", "Only the Human Director may final-merge into authoritative A/B/C context.");
    }
    return allowed("HUMAN_DIRECTOR_FINAL_MERGE", "Human Director may final-merge reviewed A/B/C proposals.");
  }

  if (input.action === "context.revert") {
    if (!isHumanDirector(role)) {
      return denied("REVERT_RESERVED_FOR_HUMAN_DIRECTOR", "Only the Human Director may revert authoritative A/B/C context.");
    }
    return allowed("HUMAN_DIRECTOR_REVERT", "Human Director may revert authoritative A/B/C context.");
  }

  if (input.target_branch === authoritativeBranch && !["context.validate", "context.diff", "context.export", "tool.run"].includes(input.action)) {
    return denied("NO_DIRECT_AUTHORITATIVE_WRITE", "Agents may not write directly to the authoritative A/B/C context branch.");
  }

  if (input.action === "context.propose") {
    if (!isProposalBranch) return denied("PROPOSAL_BRANCH_REQUIRED", "A/B/C writes must target an assigned proposal branch or worktree.");
    return allowed("PROPOSAL_WRITE_ALLOWED", "Caller may author proposed context changes inside the proposal area.");
  }

  if (input.action === "context.validate" || input.action === "context.diff" || input.action === "context.export" || input.action === "tool.run") {
    return allowed("READ_OR_VALIDATION_ALLOWED", "Read, validation, export, and indexed non-authority tool calls are allowed.");
  }

  if (input.action === "context.review_request") {
    if (!isProposalBranch) return denied("PROPOSAL_BRANCH_REQUIRED", "Review request must refer to a proposal branch.");
    return allowed("REVIEW_REQUEST_ALLOWED", "Caller may mark a proposal review-ready inside the proposal workflow.");
  }

  if (input.action === "context.approve") {
    if (isWorker(role)) {
      return denied("WORKER_APPROVAL_BLOCKED", "Worker callers cannot approve proposals.");
    }
    if (sameIdentity(input.caller_id, input.origin_worker_id) || sameIdentity(input.caller_id, input.proposal_caller_id)) {
      return denied("SELF_APPROVAL_BLOCKED", "A caller cannot approve its own proposed work.");
    }
    if (isReviewer(role) || isIncidentCommander(role) || isHumanDirector(role)) {
      return allowed("REVIEW_APPROVAL_ALLOWED", "Reviewer, IC, or Human Director may record review approval without final merge authority.");
    }
    return denied("APPROVAL_ROLE_BLOCKED", "Only reviewer, IC, or Human Director roles may approve/review-ready a proposal.");
  }

  if (input.action === "context.reject" || input.action === "context.request_revision") {
    if (isReviewer(role) || isIncidentCommander(role) || isHumanDirector(role)) {
      return allowed("REVIEW_OUTCOME_ALLOWED", "Reviewer, IC, or Human Director may reject or request revision.");
    }
    return denied("REVIEW_OUTCOME_ROLE_BLOCKED", "Only reviewer, IC, or Human Director roles may reject or request revision.");
  }

  return denied("UNKNOWN_ACTION", `Unknown SCTL action: ${input.action}`);
}

export function assertActionAllowed(input: ActionFilterInput): ActionFilterDecision {
  const decision = evaluateAction(input);
  if (!decision.ok) throw new Error(`${decision.code}: ${decision.reason}`);
  return decision;
}
