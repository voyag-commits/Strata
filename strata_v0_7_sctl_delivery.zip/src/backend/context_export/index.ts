import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { ensureDir, fileExists, fileStamp, hashText, isoStamp, readText, type CommandContext, writeJson, writeText } from "../common.js";
import { ensureContextRepo, runGit } from "../context_git/index.js";
import { resolveSctlConfig, type SctlConfigInput } from "../sctl_config/index.js";
import { writeSimplePdf } from "../render/pdf.js";
import { writeToolRun, type ToolRunEnvelope } from "../tool_runs/index.js";

export interface ContextExportInput extends SctlConfigInput {
  scope?: string;
  out?: string;
  exportId?: string;
}

interface SourceItem {
  section: "A" | "C" | "B";
  path: string;
  sha256: string;
  order: number;
}

function safePart(value: string): string {
  return value.replace(/[^A-Za-z0-9_.-]+/g, "-").replace(/^-+|-+$/g, "") || "export";
}

function gitShow(repoPath: string, branch: string, filePath: string): string | null {
  const result = runGit(repoPath, ["show", `${branch}:${filePath}`]);
  return result.ok ? result.stdout : null;
}

function gitFiles(repoPath: string, branch: string, prefix: string): string[] {
  const result = runGit(repoPath, ["ls-tree", "-r", "--name-only", branch, prefix]);
  if (!result.ok || !result.stdout.trim()) return [];
  return result.stdout.split(/\r?\n/).map((item) => item.trim()).filter(Boolean).sort();
}

function resolveBranch(repoPath: string, authoritativeBranch: string, scope?: string): string {
  if (!scope || scope === "authoritative" || scope === "main" || scope === "merged") return authoritativeBranch;
  if (scope.startsWith("proposal:")) {
    const proposalId = scope.slice("proposal:".length);
    const refs = runGit(repoPath, ["for-each-ref", "--format=%(refname:short)", "refs/heads/proposal"]);
    const found = refs.stdout.split(/\r?\n/).find((item) => item.endsWith(`/${safePart(proposalId)}`));
    if (found) return found;
  }
  return scope;
}

function parseTimingOrder(repoPath: string, branch: string): string[] {
  const timing = gitShow(repoPath, branch, "class_b/timing_index.json");
  if (!timing) return [];
  try {
    const parsed = JSON.parse(timing) as { entries?: unknown };
    if (!Array.isArray(parsed.entries)) return [];
    return parsed.entries
      .map((entry) => (typeof entry === "object" && entry !== null && !Array.isArray(entry) ? (entry as Record<string, unknown>).path : null))
      .filter((item): item is string => typeof item === "string" && item.startsWith("class_b/entries/"));
  } catch {
    return [];
  }
}

function resolveExportDir(context: CommandContext, input: ContextExportInput, extension: ".md" | ".pdf"): { exportDir: string; artifactPath: string; exportId: string } {
  const exportId = input.exportId ?? `context_${fileStamp(context.now)}`;
  if (input.out) {
    const resolved = path.resolve(context.workspaceRoot, input.out);
    if (path.extname(resolved).toLowerCase() === extension) return { exportDir: ensureDir(path.dirname(resolved)), artifactPath: resolved, exportId };
    return { exportDir: ensureDir(resolved), artifactPath: path.join(resolved, extension === ".md" ? "context.md" : "context.pdf"), exportId };
  }
  const exportDir = ensureDir(path.join(context.workspaceRoot, ".strata", "exports", "context", safePart(exportId)));
  return { exportDir, artifactPath: path.join(exportDir, extension === ".md" ? "context.md" : "context.pdf"), exportId };
}

function assertExportOutsideAuthoritative(repoPath: string, exportDir: string): void {
  const relative = path.relative(repoPath, exportDir);
  if (relative && !relative.startsWith("..") && !path.isAbsolute(relative)) {
    const first = relative.split(path.sep)[0];
    if (["class_a", "class_b", "class_c"].includes(first)) {
      throw new Error(`Export directory must not be inside authoritative A/B/C context stores: ${exportDir}`);
    }
  }
}

function renderMarkdown(context: CommandContext, input: ContextExportInput): { markdown: string; branch: string; sourceIndex: SourceItem[]; configPath: string; repoPath: string } {
  const config = ensureContextRepo(context, input);
  const branch = resolveBranch(config.context_repo_path, config.authoritative_branch, input.scope);
  const branchCheck = runGit(config.context_repo_path, ["rev-parse", "--verify", branch]);
  if (!branchCheck.ok) throw new Error(`Context export scope branch does not exist: ${branch}`);
  const sourceIndex: SourceItem[] = [];
  const sections: string[] = [];
  let order = 1;
  sections.push("# Strata A/B/C Context Export", "", `Generated: ${isoStamp(context.now)}`, `Scope: ${input.scope ?? "authoritative"}`, `Git branch: ${branch}`, "", "Export order: Class A context, Class C file pins, Class B context with timing index.", "");

  sections.push("## 1. Class A context", "");
  const classAFiles = gitFiles(config.context_repo_path, branch, "class_a").filter((file) => !file.endsWith(".gitkeep"));
  for (const file of classAFiles) {
    const content = gitShow(config.context_repo_path, branch, file) ?? "";
    sourceIndex.push({ section: "A", path: file, sha256: hashText(content), order: order++ });
    sections.push(`### ${file}`, "", content.trimEnd(), "");
  }
  if (classAFiles.length === 0) sections.push("_No Class A context files._", "");

  sections.push("## 2. Class C context for file pins", "");
  const classCFiles = gitFiles(config.context_repo_path, branch, "class_c/file_pins").filter((file) => file.endsWith(".json"));
  for (const file of classCFiles) {
    const content = gitShow(config.context_repo_path, branch, file) ?? "";
    sourceIndex.push({ section: "C", path: file, sha256: hashText(content), order: order++ });
    sections.push(`### ${file}`, "", "```json", content.trimEnd(), "```", "");
  }
  if (classCFiles.length === 0) sections.push("_No Class C file pins._", "");

  sections.push("## 3. Class B context with timing index", "");
  const timing = gitShow(config.context_repo_path, branch, "class_b/timing_index.json");
  if (timing) {
    sourceIndex.push({ section: "B", path: "class_b/timing_index.json", sha256: hashText(timing), order: order++ });
    sections.push("### class_b/timing_index.json", "", "```json", timing.trimEnd(), "```", "");
  }
  const ordered = parseTimingOrder(config.context_repo_path, branch);
  const allB = gitFiles(config.context_repo_path, branch, "class_b/entries").filter((file) => !file.endsWith(".gitkeep"));
  const orderedSet = new Set(ordered);
  const bFiles = [...ordered.filter((file) => allB.includes(file)), ...allB.filter((file) => !orderedSet.has(file)).sort()];
  for (const file of bFiles) {
    const content = gitShow(config.context_repo_path, branch, file) ?? "";
    sourceIndex.push({ section: "B", path: file, sha256: hashText(content), order: order++ });
    sections.push(`### ${file}`, "", content.trimEnd(), "");
  }
  if (!timing && bFiles.length === 0) sections.push("_No Class B context entries._", "");

  return { markdown: `${sections.join("\n").trimEnd()}\n`, branch, sourceIndex, configPath: path.join(context.workspaceRoot, ".strata", "sctl_config.json"), repoPath: config.context_repo_path };
}

function writeChecksums(exportDir: string, paths: string[]): string {
  const lines = paths.map((filePath) => {
    const hash = crypto.createHash("sha256").update(fs.readFileSync(filePath)).digest("hex");
    return `${hash}  ${path.basename(filePath)}`;
  });
  return writeText(path.join(exportDir, "checksums.sha256"), `${lines.join("\n")}\n`);
}

function writeManifest(context: CommandContext, exportDir: string, input: ContextExportInput, branch: string, repoPath: string, artifactPath: string, sourceIndexPath: string): string {
  return writeJson(path.join(exportDir, "manifest.json"), {
    contract_id: "context.export_manifest.v1",
    tool_id: path.extname(artifactPath).toLowerCase() === ".pdf" ? "context.export_pdf.v1" : "context.export_markdown.v1",
    generated_at: isoStamp(context.now),
    scope: input.scope ?? "authoritative",
    branch,
    context_repo_path: repoPath,
    artifact_path: artifactPath,
    source_index_path: sourceIndexPath,
    export_order: ["Class A context", "Class C context for file pins", "Class B context with timing index"],
    mutation: "none; read/render export only",
  });
}

export function exportContextMarkdown(context: CommandContext, input: ContextExportInput = {}): ToolRunEnvelope & Record<string, unknown> {
  const rendered = renderMarkdown(context, input);
  const { exportDir, artifactPath, exportId } = resolveExportDir(context, input, ".md");
  assertExportOutsideAuthoritative(rendered.repoPath, exportDir);
  writeText(artifactPath, rendered.markdown);
  const sourceIndexPath = writeJson(path.join(exportDir, "source_index.json"), { contract_id: "context.source_index.v1", sources: rendered.sourceIndex });
  const manifestPath = writeManifest(context, exportDir, input, rendered.branch, rendered.repoPath, artifactPath, sourceIndexPath);
  const checksumsPath = writeChecksums(exportDir, [artifactPath, sourceIndexPath, manifestPath]);
  return writeToolRun(context, {
    ok: true,
    toolId: "context.export_markdown.v1",
    evidencePaths: [artifactPath, manifestPath, sourceIndexPath, checksumsPath],
    payload: { export_id: exportId, export_dir: exportDir, context_markdown_path: artifactPath, manifest_path: manifestPath, source_index_path: sourceIndexPath, checksums_path: checksumsPath, branch: rendered.branch },
  });
}

export function exportContextPdf(context: CommandContext, input: ContextExportInput = {}): ToolRunEnvelope & Record<string, unknown> {
  const rendered = renderMarkdown(context, input);
  const { exportDir, artifactPath, exportId } = resolveExportDir(context, input, ".pdf");
  assertExportOutsideAuthoritative(rendered.repoPath, exportDir);
  const markdownPath = writeText(path.join(exportDir, "context.md"), rendered.markdown);
  writeSimplePdf(artifactPath, rendered.markdown);
  const sourceIndexPath = writeJson(path.join(exportDir, "source_index.json"), { contract_id: "context.source_index.v1", sources: rendered.sourceIndex });
  const manifestPath = writeManifest(context, exportDir, input, rendered.branch, rendered.repoPath, artifactPath, sourceIndexPath);
  const checksumsPath = writeChecksums(exportDir, [artifactPath, markdownPath, sourceIndexPath, manifestPath]);
  return writeToolRun(context, {
    ok: true,
    toolId: "context.export_pdf.v1",
    evidencePaths: [artifactPath, markdownPath, manifestPath, sourceIndexPath, checksumsPath],
    payload: { export_id: exportId, export_dir: exportDir, context_pdf_path: artifactPath, context_markdown_path: markdownPath, manifest_path: manifestPath, source_index_path: sourceIndexPath, checksums_path: checksumsPath, branch: rendered.branch },
  });
}
