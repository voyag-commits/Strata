export interface ParsedArgs {
  positionals: string[];
  flags: Record<string, string | boolean>;
}

export function parseArgs(argv: string[]): ParsedArgs {
  const positionals: string[] = [];
  const flags: Record<string, string | boolean> = {};
  for (let index = 0; index < argv.length; index += 1) {
    const token = argv[index];
    if (!token.startsWith("--")) {
      positionals.push(token);
      continue;
    }
    const key = token.slice(2);
    const next = argv[index + 1];
    if (!next || next.startsWith("--")) {
      flags[key] = true;
      continue;
    }
    flags[key] = next;
    index += 1;
  }
  return { positionals, flags };
}

export function optionalString(value: string | boolean | undefined): string | undefined {
  return typeof value === "string" && value.trim() ? value : undefined;
}

export function optionalNumber(value: string | boolean | undefined): number | undefined {
  if (typeof value !== "string" || !value.trim()) return undefined;
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) throw new Error(`Expected a number, received ${value}.`);
  return parsed;
}

export function requireString(flags: Record<string, string | boolean>, key: string): string {
  const value = optionalString(flags[key]);
  if (!value) throw new Error(`Missing --${key}.`);
  return value;
}

export function firstString(flags: Record<string, string | boolean>, keys: string[]): string | undefined {
  for (const key of keys) {
    const value = optionalString(flags[key]);
    if (value) return value;
  }
  return undefined;
}

export function requireOneString(flags: Record<string, string | boolean>, keys: string[]): string {
  const value = firstString(flags, keys);
  if (!value) throw new Error(`Missing one of: ${keys.map((key) => `--${key}`).join(", ")}.`);
  return value;
}

export function splitList(value: string | boolean | undefined, separator = ";"): string[] {
  if (!value || typeof value !== "string") return [];
  return value
    .split(separator)
    .map((item) => item.trim())
    .filter(Boolean);
}

export function booleanFlag(flags: Record<string, string | boolean>, key: string): boolean {
  return flags[key] === true || flags[key] === "true";
}
