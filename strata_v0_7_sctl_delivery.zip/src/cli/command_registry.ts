import type { CommandContext } from "../backend/common.js";
import type { ParsedArgs } from "./args.js";

export interface CliInvocation extends ParsedArgs {
  commandPath: string[];
}

export type CliHandler = (context: CommandContext, invocation: CliInvocation) => Promise<unknown> | unknown;

export interface CliCommand {
  path: string[];
  summary: string;
  handler: CliHandler;
}

export class CommandRegistry {
  private readonly commands: CliCommand[] = [];

  register(path: string[], summary: string, handler: CliHandler): void {
    if (path.length === 0) throw new Error("Cannot register an empty CLI command path.");
    const key = path.join(" ");
    if (this.commands.some((command) => command.path.join(" ") === key)) {
      throw new Error(`Duplicate CLI command registration: ${key}`);
    }
    this.commands.push({ path, summary, handler });
    this.commands.sort((a, b) => b.path.length - a.path.length || a.path.join(" ").localeCompare(b.path.join(" ")));
  }

  find(positionals: string[]): CliCommand | null {
    return this.commands.find((command) => command.path.every((part, index) => positionals[index] === part)) ?? null;
  }

  help(): string {
    const rows = this.commands
      .slice()
      .sort((a, b) => a.path.join(" ").localeCompare(b.path.join(" ")))
      .map((command) => `  strata ${command.path.join(" ").padEnd(34)} ${command.summary}`);
    return [
      "Strata Context Tool Layer (SCTL) CLI",
      "",
      "Usage:",
      ...rows,
      "",
      "Authority-changing A/B/C commands use the Git-backed proposal workflow. Runtime evidence and Class D tools remain separate.",
    ].join("\n");
  }
}

export function createCommandRegistry(): CommandRegistry {
  return new CommandRegistry();
}
