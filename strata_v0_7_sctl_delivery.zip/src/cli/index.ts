#!/usr/bin/env node
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createCommandContext } from "../backend/common.js";
import { writeFailedToolRun } from "../backend/tool_runs/index.js";
import { parseArgs, optionalString } from "./args.js";
import { createCommandRegistry } from "./command_registry.js";
import { registerSctlCommands } from "./sctl_commands.js";
import { registerLegacyRuntimeCommands } from "./legacy_commands.js";

function createRegistry() {
  const registry = createCommandRegistry();
  registerSctlCommands(registry);
  registerLegacyRuntimeCommands(registry);
  return registry;
}

function emit(result: unknown): void {
  if (result === undefined) return;
  if (typeof result === "object" && result !== null && "raw" in result && typeof (result as { raw: unknown }).raw === "string") {
    process.stdout.write((result as { raw: string }).raw);
    if ("exitOk" in result && (result as { exitOk: unknown }).exitOk === false) process.exitCode = 1;
    return;
  }
  if (typeof result === "string") {
    console.log(result);
    return;
  }
  console.log(JSON.stringify(result, null, 2));
  if (typeof result === "object" && result !== null && "ok" in result && (result as { ok?: unknown }).ok === false) process.exitCode = 1;
  if (typeof result === "object" && result !== null && "status" in result && (result as { status?: unknown }).status === "FAIL") process.exitCode = 1;
}

async function main(): Promise<void> {
  const parsed = parseArgs(process.argv.slice(2));
  const registry = createRegistry();
  if (parsed.positionals.length === 0 || parsed.flags.help || parsed.positionals.includes("help")) {
    console.log(registry.help());
    return;
  }

  const workspace = optionalString(parsed.flags.workspace) ?? process.cwd();
  const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..", "..", "..");
  const context = createCommandContext(projectRoot, workspace);
  const command = registry.find(parsed.positionals);
  if (!command) {
    console.error(`Unknown command: ${parsed.positionals.join(" ")}`);
    console.log(registry.help());
    process.exitCode = 1;
    return;
  }
  const invocation = { ...parsed, commandPath: command.path };
  const result = await command.handler(context, invocation);
  emit(result);
}

main().catch((error) => {
  const workspaceArgIndex = process.argv.indexOf("--workspace");
  const workspace = workspaceArgIndex >= 0 && process.argv[workspaceArgIndex + 1] ? process.argv[workspaceArgIndex + 1] : process.cwd();
  const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..", "..", "..");
  const context = createCommandContext(projectRoot, workspace);
  const envelope = writeFailedToolRun(context, "cli.command.v1", error, { argv: process.argv.slice(2) });
  console.error(error instanceof Error ? error.message : String(error));
  console.error(`failure_result_path=${envelope.result_path}`);
  process.exit(1);
});
