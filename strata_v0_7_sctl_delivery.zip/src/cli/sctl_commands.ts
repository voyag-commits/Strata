import fs from "node:fs";
import path from "node:path";
import type { CommandRegistry } from "./command_registry.js";
import { booleanFlag, firstString, optionalString, requireOneString, requireString } from "./args.js";
import type { ContextClassABC } from "../backend/context_git/index.js";
import {
  approveProposal,
  contextSummaryGit,
  createContextProposal,
  diffProposal,
  listAuthoritativeContext,
  mergeProposal,
  rejectProposal,
  repoStatus,
  requestRevision,
  reviewRequest,
  revertContext,
  validateProposalTool,
} from "../backend/context_git/index.js";
import { exportContextMarkdown, exportContextPdf } from "../backend/context_export/index.js";
import {
  exportClassDMarkdown,
  exportClassDPdf,
  inspectClassDSession,
  locateCodexSessions,
  registerClassDSession,
  verifyClassDChecksums,
} from "../backend/classd/index.js";
import { inspectTool, listTools, readToolInput, runRegisteredTool } from "../backend/tool_registry/index.js";
import type { SctlConfigInput } from "../backend/sctl_config/index.js";

function configFlags(flags: Record<string, string | boolean>): SctlConfigInput {
  return {
    contextRepoPath: optionalString(flags["context-repo"]),
    authoritativeBranch: optionalString(flags["authoritative-branch"]),
    proposalBranchPrefix: optionalString(flags["proposal-prefix"]),
  };
}

function parseClass(value: string | undefined): ContextClassABC | undefined {
  if (value === undefined) return undefined;
  const upper = value.toUpperCase();
  if (upper === "A" || upper === "B" || upper === "C") return upper;
  throw new Error("--class must be A, B, or C for authoritative context proposals. Class D uses strata classd tools.");
}

function callerId(flags: Record<string, string | boolean>): string {
  return requireOneString(flags, ["caller-id", "caller", "worker", "reviewer", "director"]);
}

function callerRole(flags: Record<string, string | boolean>, fallback = "worker"): string {
  return firstString(flags, ["caller-role", "role"]) ?? fallback;
}

function reviewerId(flags: Record<string, string | boolean>): string {
  return requireOneString(flags, ["reviewer-id", "reviewer", "caller-id", "caller"]);
}

function reviewerRole(flags: Record<string, string | boolean>): string {
  return firstString(flags, ["reviewer-role", "caller-role", "role"]) ?? "reviewer";
}

export function registerSctlCommands(registry: CommandRegistry): void {
  registry.register(["context", "repo-status"], "inspect configured Git-backed A/B/C context repo", (context, { flags }) => repoStatus(context, configFlags(flags)));

  registry.register(["context", "bootstrap"], "initialize Git-backed A/B/C context repo", (context, { flags }) => repoStatus(context, configFlags(flags)));

  registry.register(["context", "propose"], "write a proposed A/B/C context change on a proposal branch", (context, { flags }) => createContextProposal(context, {
    ...configFlags(flags),
    proposalId: requireOneString(flags, ["proposal", "proposal-id"]),
    callerId: callerId(flags),
    callerRole: callerRole(flags),
    klass: parseClass(optionalString(flags.class)),
    semanticId: firstString(flags, ["id", "semantic-id", "entry-id", "file-pin-id"]),
    title: optionalString(flags.title),
    targetPath: firstString(flags, ["path", "target-path"]),
    body: optionalString(flags.body),
    sourceFile: firstString(flags, ["source-file", "source"]),
    intendedAction: optionalString(flags["intended-action"]),
    originWorkerId: firstString(flags, ["origin-worker-id", "worker-id"]),
    originWorkerSessionId: optionalString(flags["origin-worker-session-id"]),
    originDispatchChannel: optionalString(flags["origin-dispatch-channel"]),
    assignedWorktree: optionalString(flags["assigned-worktree"]),
    pinnedPath: firstString(flags, ["pinned-path", "pin-path", "file"]),
    checksumSha256: firstString(flags, ["checksum-sha256", "sha256"]),
    commitMessage: optionalString(flags.message),
  }));

  registry.register(["context", "validate"], "validate proposal schema, paths, duplicates, and authority boundaries", (context, { flags }) => validateProposalTool(context, {
    ...configFlags(flags),
    proposalId: requireOneString(flags, ["proposal", "proposal-id"]),
    callerId: firstString(flags, ["caller-id", "caller"]),
    callerRole: firstString(flags, ["caller-role", "role"]),
  }));

  registry.register(["context", "diff"], "render Git diff for a proposal", (context, { flags }) => diffProposal(context, {
    ...configFlags(flags),
    proposalId: requireOneString(flags, ["proposal", "proposal-id"]),
  }));

  registry.register(["context", "review-request"], "mark a proposal ready for review", (context, { flags }) => reviewRequest(context, {
    ...configFlags(flags),
    proposalId: requireOneString(flags, ["proposal", "proposal-id"]),
    callerId: callerId(flags),
    callerRole: callerRole(flags),
  }));

  registry.register(["context", "approve"], "record review approval without merging", (context, { flags }) => approveProposal(context, {
    ...configFlags(flags),
    proposalId: requireOneString(flags, ["proposal", "proposal-id"]),
    reviewerId: reviewerId(flags),
    reviewerRole: reviewerRole(flags),
    reasonFile: optionalString(flags["reason-file"]),
  }));

  registry.register(["context", "reject"], "record rejection and dispatch fixed worker message", (context, { flags }) => rejectProposal(context, {
    ...configFlags(flags),
    proposalId: requireOneString(flags, ["proposal", "proposal-id"]),
    reviewerId: reviewerId(flags),
    reviewerRole: reviewerRole(flags),
    reasonFile: requireString(flags, "reason-file"),
  }));

  registry.register(["context", "request-revision"], "record revision request and dispatch fixed worker message", (context, { flags }) => requestRevision(context, {
    ...configFlags(flags),
    proposalId: requireOneString(flags, ["proposal", "proposal-id"]),
    reviewerId: reviewerId(flags),
    reviewerRole: reviewerRole(flags),
    reasonFile: requireString(flags, "reason-file"),
  }));

  registry.register(["context", "merge"], "Human Director final merge into authoritative A/B/C context", (context, { flags }) => mergeProposal(context, {
    ...configFlags(flags),
    proposalId: requireOneString(flags, ["proposal", "proposal-id"]),
    callerId: requireOneString(flags, ["director", "caller-id", "caller"]),
    callerRole: callerRole(flags, "human_director"),
    message: optionalString(flags.message),
  }));

  registry.register(["context", "revert"], "Human Director revert of authoritative A/B/C context commit", (context, { flags }) => revertContext(context, {
    ...configFlags(flags),
    commit: requireString(flags, "commit"),
    callerId: requireOneString(flags, ["director", "caller-id", "caller"]),
    callerRole: callerRole(flags, "human_director"),
  }));

  registry.register(["context", "export-markdown"], "run context.export_markdown.v1", (context, { flags }) => exportContextMarkdown(context, {
    ...configFlags(flags),
    scope: optionalString(flags.scope),
    out: optionalString(flags.out),
    exportId: optionalString(flags["export-id"]),
  }));

  registry.register(["context", "export-pdf"], "run context.export_pdf.v1", (context, { flags }) => exportContextPdf(context, {
    ...configFlags(flags),
    scope: optionalString(flags.scope),
    out: optionalString(flags.out),
    exportId: optionalString(flags["export-id"]),
  }));

  registry.register(["context", "list"], "list authoritative A/B/C files from Git context repo", (context, { flags }) => listAuthoritativeContext(context, configFlags(flags)));
  registry.register(["context", "summary"], "summarize authoritative A/B/C Git context", (context, { flags }) => contextSummaryGit(context, configFlags(flags)));

  registry.register(["context", "add"], "retired direct context write shortcut", () => ({ ok: false, tool_id: "context.add.retired", errors: ["Direct context add is retired. Use strata context propose, review, approve, and Human Director merge."] }));
  registry.register(["classb", "import"], "retired direct Class B import shortcut", () => ({ ok: false, tool_id: "classb.import.retired", errors: ["Direct Class B import is retired. Use reviewed Git-backed A/B/C context proposals."] }));
  registry.register(["gate", "evaluate"], "retired broad Mutation Gate command", () => ({ ok: false, tool_id: "gate.evaluate.retired", errors: ["Broad Mutation Gate evaluation is retired. SCTL uses proposal validation plus action filter."] }));
  registry.register(["gate", "list"], "retired broad Mutation Gate command", () => ({ ok: false, tool_id: "gate.list.retired", errors: ["Broad Mutation Gate records are retired for SCTL authority boundaries."] }));
  registry.register(["gate", "digest"], "retired broad Mutation Gate command", () => ({ ok: false, tool_id: "gate.digest.retired", errors: ["Broad Mutation Gate digest is retired for SCTL authority boundaries."] }));

  registry.register(["classd", "locate"], "run classd.locate_codex_sessions.v1", (context, { flags }) => locateCodexSessions(context, { sessionsRoot: optionalString(flags["sessions-root"]) }));
  registry.register(["classd", "register-session"], "run classd.register_session.v1", (context, { flags }) => registerClassDSession(context, { sessionId: firstString(flags, ["session-id", "session"]), source: requireString(flags, "source") }));
  registry.register(["classd", "export-markdown"], "run classd.export_markdown.v1", (context, { flags }) => exportClassDMarkdown(context, { sessionId: requireOneString(flags, ["session-id", "session"]), out: optionalString(flags.out) }));
  registry.register(["classd", "export-pdf"], "run classd.export_pdf.v1", (context, { flags }) => exportClassDPdf(context, { sessionId: requireOneString(flags, ["session-id", "session"]), out: optionalString(flags.out) }));
  registry.register(["classd", "verify-checksums"], "run classd.verify_checksums.v1", (context, { flags }) => verifyClassDChecksums(context, { sessionId: requireOneString(flags, ["session-id", "session"])}));
  registry.register(["classd", "inspect"], "run classd.inspect.v1", (context, { flags }) => inspectClassDSession(context, { sessionId: requireOneString(flags, ["session-id", "session"])}));

  registry.register(["tools", "list"], "list indexed SCTL tool registry", (context) => listTools(context));
  registry.register(["tools", "inspect"], "inspect one indexed tool", (context, { flags }) => inspectTool(context, requireOneString(flags, ["tool-id", "tool"])));
  registry.register(["tools", "run"], "run selected indexed tool with JSON input", (context, { flags }) => {
    const toolId = requireOneString(flags, ["tool-id", "tool"]);
    const inputPath = optionalString(flags.input);
    const input = { ...readToolInput(inputPath), ...Object.fromEntries(Object.entries(flags).filter(([key]) => !["tool-id", "tool", "input", "workspace"].includes(key))) } as Record<string, unknown>;
    return runRegisteredTool(context, toolId, input);
  });

  registry.register(["init"], "initialize SCTL workspace and context repo", (context, { flags }) => repoStatus(context, configFlags(flags)));
}
