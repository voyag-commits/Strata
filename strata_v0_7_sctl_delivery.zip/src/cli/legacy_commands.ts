import fs from "node:fs";
import { buildBridgeGate, renderBridgeGatePowerShell } from "../backend/bridge_gate/index.js";
import { appendBackendLoopEvent, ledgerPaths, writeLedgerSnapshot } from "../backend/backend_loop_ledger/index.js";
import { createCommandContext, formatTable, readJson, readText } from "../backend/common.js";
import { createContextLoadPacket, createWorkDispatchPacket, writeWorkerReturnPacketTemplate, type WorkDispatchKind } from "../backend/packets/index.js";
import { classifyWorkerReturnPacket, scanWatchedReturnFolders, type ClassifyWorkerReturnResult, type WorkerReturnKind } from "../backend/worker_returns/index.js";
import { launchTmuxSession, listTmuxSessionRecords, observeTmuxSession, sendPacketToTmux } from "../backend/tmux_dispatch/index.js";
import { listAgentReports } from "../backend/agent_report_ledger/index.js";
import { sendDenialToWorker } from "../backend/worker_denial/index.js";
import { runSecretScan } from "../backend/secret_scan/index.js";
import type { CommandRegistry } from "./command_registry.js";
import { booleanFlag, firstString, optionalString, requireString, splitList } from "./args.js";

function parseReturnKind(value: string | boolean | undefined): WorkerReturnKind {
  const allowed: WorkerReturnKind[] = ["ACK", "QUESTION", "BLOCKED", "NEEDS_CLARIFICATION", "PARTIAL_STATUS", "REPORT_READY", "FAILED_WITH_DIAGNOSTIC"];
  if (typeof value === "string" && allowed.includes(value as WorkerReturnKind)) return value as WorkerReturnKind;
  throw new Error(`--kind must be one of ${allowed.join(", ")}.`);
}

function renderBridgeGateBash(env: Record<string, string>): string {
  const quote = (value: string) => `'${value.replace(/'/g, `'"'"'`)}'`;
  return `${Object.entries(env)
    .filter(([key]) => key !== "DEEPSEEK_API_KEY")
    .map(([key, value]) => `export ${key}=${quote(value)}`)
    .join("\n")}\n`;
}

function appendReturnLedgerEvents(ctx: ReturnType<typeof createCommandContext>, result: ClassifyWorkerReturnResult): void {
  const c = result.classification;
  const p = result.packet;
  appendBackendLoopEvent(ctx, {
    event: "RETURN_FILE_DETECTED",
    actor: "return_watcher",
    assignment_id: c.assignment_id,
    agent_id: c.agent_id,
    role: c.role,
    nonce: p?.nonce ?? null,
    status: "detected",
    artifact: c.packet_path,
    evidence: c.event_record_path,
  });
  appendBackendLoopEvent(ctx, {
    event: "RETURN_PACKET_CLASSIFIED",
    actor: "worker_return_classifier",
    assignment_id: c.assignment_id,
    agent_id: c.agent_id,
    role: c.role,
    nonce: p?.nonce ?? null,
    status: c.return_kind ?? "INVALID_RETURN_PACKET",
    artifact: result.classification_record_path,
    evidence: c.event_record_path,
    note: c.routing_decision,
  });
}

export function registerLegacyRuntimeCommands(registry: CommandRegistry): void {
  registry.register(["sessions", "create"], "launch Codex in tmux and record session metadata", (context, { flags }) => {
    const result = launchTmuxSession(context, {
      sessionName: requireString(flags, "session"),
      assignmentId: requireString(flags, "assignment-id"),
      agentId: requireString(flags, "agent-id"),
      role: requireString(flags, "role"),
      cwd: optionalString(flags.cwd),
      command: optionalString(flags.command),
      bridgeBaseUrl: optionalString(flags["bridge-base-url"]),
      replace: booleanFlag(flags, "replace"),
    });
    return result;
  });

  registry.register(["sessions", "list"], "list recorded tmux sessions", (context) => ({ raw: formatTable([["session", "assignment", "agent", "role", "status", "command"], ...listTmuxSessionRecords(context).map((r) => [r.session_name, r.assignment_id, r.agent_id, r.role, r.status, r.command])]) }));
  registry.register(["sessions", "status"], "inspect tmux session status", (context, { flags }) => observeTmuxSession(context, requireString(flags, "session")));

  registry.register(["packet", "context-load"], "write a context-load packet", (context, { flags }) => createContextLoadPacket(context, {
    assignmentId: requireString(flags, "assignment-id"),
    agentId: requireString(flags, "agent-id"),
    role: requireString(flags, "role"),
    sessionName: optionalString(flags.session),
    roleContract: optionalString(flags["role-contract"]),
    assignmentFrame: optionalString(flags["assignment-frame"]),
    contextHeaderPath: optionalString(flags["context-header"]),
  }));

  registry.register(["packet", "work-dispatch"], "write a work-dispatch packet", (context, { flags }) => createWorkDispatchPacket(context, {
    assignmentId: requireString(flags, "assignment-id"),
    agentId: requireString(flags, "agent-id"),
    role: requireString(flags, "role"),
    dispatchKind: requireString(flags, "kind") as WorkDispatchKind,
    action: requireString(flags, "action"),
    body: optionalString(flags.body),
    referencedFiles: splitList(flags.files),
    fromRole: optionalString(flags["from-role"]),
  }));

  registry.register(["dispatch", "create"], "write a work-dispatch packet", (context, { flags }) => createWorkDispatchPacket(context, {
    assignmentId: requireString(flags, "assignment-id"),
    agentId: requireString(flags, "agent-id"),
    role: requireString(flags, "role"),
    dispatchKind: requireString(flags, "kind") as WorkDispatchKind,
    action: requireString(flags, "action"),
    body: optionalString(flags.body),
    referencedFiles: splitList(flags.files),
    fromRole: optionalString(flags["from-role"]),
  }));

  registry.register(["packet", "return-template"], "write a Worker Return Packet template", (context, { flags }) => writeWorkerReturnPacketTemplate(context, {
    assignmentId: requireString(flags, "assignment-id"),
    agentId: requireString(flags, "agent-id"),
    role: requireString(flags, "role"),
    returnKind: parseReturnKind(flags.kind),
    nonce: requireString(flags, "nonce"),
    reportPath: optionalString(flags["report-path"]),
    questionPath: optionalString(flags["question-path"]),
    messagePath: optionalString(flags["message-path"]),
    diagnosticPath: optionalString(flags["diagnostic-path"]),
    evidencePath: optionalString(flags["evidence-path"]),
  }));

  registry.register(["dispatch", "send"], "send a packet to a tmux session", (context, { flags }) => sendPacketToTmux(context, {
    sessionName: requireString(flags, "session"),
    packetPath: requireString(flags, "packet"),
    message: optionalString(flags.message),
    messagePath: optionalString(flags["message-file"]),
    submit: !booleanFlag(flags, "no-submit"),
    fromRole: optionalString(flags["from-role"]),
  }));

  registry.register(["returns", "classify"], "classify one Worker Return Packet", (context, { flags }) => {
    const result = classifyWorkerReturnPacket(context, requireString(flags, "packet"));
    appendReturnLedgerEvents(context, result);
    return result;
  });

  const scanHandler = (context: ReturnType<typeof createCommandContext>, flags: Record<string, string | boolean>, watch: boolean): unknown => {
    const results = scanWatchedReturnFolders(context, { assignmentId: optionalString(flags["assignment-id"]), agentId: optionalString(flags["agent-id"]) });
    if (results.length === 0) {
      appendBackendLoopEvent(context, {
        event: "RETURN_FILE_NOT_DETECTED",
        actor: watch ? "return_watcher" : "manual_scan",
        assignment_id: optionalString(flags["assignment-id"]),
        agent_id: optionalString(flags["agent-id"]),
        status: "not_detected",
        evidence: ledgerPaths(context).jsonl,
      });
    }
    for (const result of results) appendReturnLedgerEvents(context, result);
    const seenDenied = new Set<string>();
    for (const result of results) {
      if (!result.classification.valid_packet && result.classification.errors.length > 0) {
        const key = result.classification.classification_id;
        if (seenDenied.has(key)) continue;
        seenDenied.add(key);
        let rawPacket: Record<string, unknown> = {};
        try { rawPacket = readJson<Record<string, unknown>>(result.classification.packet_path); } catch {}
        sendDenialToWorker(context, {
          assignmentId: (result.classification.assignment_id ?? (typeof rawPacket.assignment_id === "string" ? rawPacket.assignment_id : null) ?? "unknown") as string,
          agentId: (result.classification.agent_id ?? (typeof rawPacket.agent_id === "string" ? rawPacket.agent_id : null) ?? "unknown") as string,
          role: (result.classification.role ?? (typeof rawPacket.role === "string" ? rawPacket.role : null) ?? "worker") as string,
          nonce: result.packet?.nonce ?? (typeof rawPacket.nonce === "string" ? rawPacket.nonce : null),
          reasonCategory: "INVALID_RETURN_PACKET",
          reasonDetail: `Worker Return Packet validation failed: ${result.classification.errors?.join("; ") ?? "no errors reported"}`,
          errors: result.classification.errors,
        });
      }
    }
    return { count: results.length, results };
  };
  registry.register(["returns", "scan"], "one-shot return packet scan", (context, { flags }) => scanHandler(context, flags, false));
  registry.register(["returns", "watch"], "return packet watch contract", (context, { flags }) => scanHandler(context, flags, true));

  registry.register(["report", "list"], "list report candidates", (context) => listAgentReports(context));
  registry.register(["report", "review"], "retired direct Class B review/import shortcut", () => ({ ok: false, tool_id: "report.review.retired", errors: ["Direct report review-to-ClassB shortcut is retired. Use Git-backed context proposals and Human Director merge."] }));

  registry.register(["evidence", "inspect"], "inspect backend loop evidence ledger", (context, { flags }) => {
    const paths = ledgerPaths(context);
    const tail = typeof flags.tail === "string" ? Number(flags.tail) : 20;
    const jsonlTail = fs.existsSync(paths.jsonl) ? readText(paths.jsonl).split(/\r?\n/).filter(Boolean).slice(-tail) : [];
    return {
      contract_id: "strata_evidence_inspection.v0_7",
      workspace: context.workspaceRoot,
      strata_root: `${context.workspaceRoot}/.strata`,
      backend_loop_ledger_jsonl: paths.jsonl,
      backend_loop_ledger_markdown: paths.markdown,
      snapshot: writeLedgerSnapshot(context),
      tail: jsonlTail,
    };
  });

  registry.register(["bridge", "gate"], "render bridge environment gate", (_context, { flags }) => {
    const result = buildBridgeGate({
      apiKeyFile: optionalString(flags["api-key-file"]),
      apiKeyEnv: optionalString(flags["api-key-env"]),
      proxy: optionalString(flags.proxy),
      noProxy: optionalString(flags["no-proxy"]),
      proxyAuthKey: optionalString(flags["proxy-auth-key"]),
      enableThinking: booleanFlag(flags, "disable-thinking") ? false : booleanFlag(flags, "enable-thinking") ? true : undefined,
      reasoningEffort: optionalString(flags["reasoning-effort"]),
      maxOutputTokens: typeof flags["max-output-tokens"] === "string" ? Number(flags["max-output-tokens"]) : undefined,
      modelContextWindow: typeof flags["model-context-window"] === "string" ? Number(flags["model-context-window"]) : undefined,
      port: typeof flags.port === "string" ? Number(flags.port) : undefined,
    });
    const format = flags.format === "bash" ? "bash" : flags.format === "powershell" ? "powershell" : "json";
    if (format === "bash") return { raw: renderBridgeGateBash(result.env), exitOk: result.ok };
    if (format === "powershell") return { raw: renderBridgeGatePowerShell(result, { apiKeyFile: optionalString(flags["api-key-file"]), proxyAuthKey: optionalString(flags["proxy-auth-key"]) }), exitOk: result.ok };
    return { ...result, env: result.redactedEnv };
  });

  registry.register(["secret-scan"], "scan workspace for obvious secret material", (context, { flags }) => runSecretScan(context, { secretFile: optionalString(flags["secret-file"]) }));
}
