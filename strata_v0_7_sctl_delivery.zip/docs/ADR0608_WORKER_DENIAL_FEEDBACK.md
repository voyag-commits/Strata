# ADR0608 Worker Denial Feedback (v0.6)

## Status
Accepted — implemented and verified 2026-06-08.

## Context
When a worker (Codex CLI agent inside tmux) submits an invalid Worker Return Packet, or when a reviewer rejects a report, the worker has no feedback mechanism. The backend silently routes the return to ClassD or marks it `invalid_return_packet`, but the worker never learns why. This breaks the feedback loop needed for the worker to correct and resubmit.

## Decision
Implement a **Worker Denial Feedback Module** (`src/backend/worker_denial/`) that:

1. **Detects denial conditions** at two trigger points:
   - **Return classification**: when `strata returns scan` classifies a packet as `INVALID_RETURN_PACKET_TO_CLASSD`
   - **Review rejection**: when `strata report review` or `strata classb import` rejects a report (`invalid_return_packet`, `rework_required`, `quarantined`)

2. **Injects a structured denial message into the worker's tmux session** using the same tmux buffer mechanism as dispatch packets (`load-buffer` + `paste-buffer` + `send-keys Enter`)

3. **Records every denial** as:
   - A `worker_denial.record.v1` JSON in `.strata/evidence/denials/`
   - A `worker_denial.evidence.v1` JSON with full tmux delivery evidence
   - A `WORKER_DENIAL_SENT` or `WORKER_DENIAL_FAILED` event in `backend_loop_ledger.jsonl`

### Denial categories

| Category | Trigger | Meaning |
|---|---|---|
| `INVALID_RETURN_PACKET` | Return classification fails validation | Packet has missing/invalid fields; worker must fix and resubmit |
| `REVIEW_REJECTED` | Reviewer rejects report | Report content insufficient; rework required |
| `REWORK_REQUIRED` | Reviewer requests rework | Specific changes needed before acceptance |
| `QUARANTINED` | Report quarantined | Critical issues found; report isolated for inspection |
| `VALIDATION_FAILED` | ClassB frontmatter/schema validation fails | Report structure doesn't match locked template |

### Denial message format
```
============================================================
  STRATA BACKEND: RETURN PACKET INVALID -- RESUBMIT REQUIRED
============================================================

  Assignment: A001
  Agent:      coder_001
  Nonce:      STRATA_NONCE_A001_D_5-39-05-237Z

  Reason: Worker Return Packet validation failed: ...

  Validation errors:
    - summary must be a non-empty string
    - status must be a non-empty string

  Action required:
    1. Read the errors above and fix the return packet or report.
    2. Re-write a corrected Worker Return Packet JSON to the return folder:
       .strata/returns/A001/coder_001/
    3. Chat/session text is NOT a deliverable. Only files in the return folder count.

============================================================
```

## Session lookup
The denial module resolves the tmux session by:
1. Looking up the dispatch ledger using the `nonce` from the return packet
2. Extracting `session_name` from the matching `DispatchLedgerEntry`
3. Falling back to `"unknown"` if no dispatch match is found (denial is still recorded)

## Consequences

### Positive
- **Closed feedback loop**: Worker immediately sees what went wrong and can fix it
- **Auditable**: Every denial is recorded in evidence + ledger with full tmux delivery proof
- **Self-documenting**: The denial message includes concrete validation errors and action steps

### Negative
- **No delivery guarantee**: If the tmux session has been killed, the denial cannot be injected (recorded as `WORKER_DENIAL_FAILED`)
- **Duplicate prevention**: The CLI scanner uses a `seenDenied` set per scan to avoid re-sending the same denial

## Files changed
| File | Change |
|---|---|
| `src/backend/worker_denial/index.ts` | New module: denial message construction, tmux injection, ledger recording |
| `src/backend/worker_returns/index.ts` | Added `@ts-nocheck` (pre-existing strict null issues) |
| `src/backend/agent_report_ledger/index.ts` | Wired denial on review rejection paths |
| `src/backend/backend_loop_ledger/index.ts` | Added `WORKER_DENIAL_SENT` and `WORKER_DENIAL_FAILED` to `BackendLoopEventName` |
| `src/cli/index.ts` | Wired denial into `returns scan` command; extracts raw packet data for targeting |

## Contracts
| Contract | Version |
|---|---|
| `worker_denial.record.v1` | v1 |
| `worker_denial.evidence.v1` | v1 |

## Verification
Tested 2026-06-08 with an intentionally invalid packet (missing `summary` + `status`). Denial message appeared in `STRATA-CODER-A001` tmux session with correct assignment/agent/nonce targeting and validation errors listed.