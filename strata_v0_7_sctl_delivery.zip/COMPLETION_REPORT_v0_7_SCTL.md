# Strata v0.7 SCTL Completion Report

Date: 2026-06-09
Package: `strata-v0-7-sctl`
Base input: Strata v0.6 engineer delivery package
Primary architecture: ADR-0603, with still-valid ADR-0602 tool registry and Class D transcript decisions preserved

## Implemented decisions

### ADR-0603 Git-backed A/B/C context authority

Implemented a Git-backed A/B/C context store under a configurable `context_repo_path` resolved from, in order:

1. CLI flag `--context-repo`
2. environment variable `STRATA_CONTEXT_REPO_PATH`
3. `.strata/sctl_config.json`
4. `.strata/config.json`
5. default `.strata/context_repo`

Evidence paths:

- `src/backend/sctl_config/index.ts`
- `src/backend/context_git/index.ts`
- CLI: `strata context repo-status`

Implemented authoritative branch and proposal branch separation:

- default authoritative branch: `context/main`
- default proposal branch prefix: `proposal`
- proposal branch pattern: `proposal/<caller_id>/<proposal_id>`

Implemented SCTL context authority commands:

- `strata context propose`
- `strata context validate`
- `strata context diff`
- `strata context review-request`
- `strata context approve`
- `strata context reject`
- `strata context request-revision`
- `strata context merge`
- `strata context revert`
- `strata context export-markdown`
- `strata context export-pdf`
- `strata context repo-status`

Evidence paths:

- `src/cli/sctl_commands.ts`
- `src/backend/context_git/index.ts`
- `src/backend/context_export/index.ts`

### Human Director-only final merge

Implemented action filter enforcement:

- worker cannot approve proposals
- caller cannot approve own work
- worker cannot final-merge
- reviewer cannot final-merge
- IC cannot final-merge
- only Human Director role can final-merge into authoritative A/B/C context

Evidence paths:

- `src/backend/action_filter/index.ts`
- `tests/sctl_context.test.ts`

### Validator scope

Implemented deterministic validation only. The validator checks:

- allowed path targets
- no path traversal
- no `.git` writes
- no Class D writes into A/B/C context
- Class A schema shape
- Class B entry metadata and timing index shape
- Class C file pin metadata and checksum shape
- duplicate Class B semantic ids in authoritative context
- duplicate Class C file pin ids in authoritative context
- proposal id already merged
- proposal metadata presence and branch consistency

The validator does not judge content quality, usefulness, importance, correctness, or intent.

Evidence paths:

- `src/backend/context_git/index.ts`
- `tests/sctl_context.test.ts`

### Unified A/B/C export tools

Implemented indexed tools:

- `context.export_markdown.v1`
- `context.export_pdf.v1`

Both render in fixed order:

1. Class A context
2. Class C context for file pins
3. Class B context with timing index

Exports are read/render actions only and write outside authoritative A/B/C stores. Required artifacts are written:

- `context.md`
- `context.pdf` for PDF export
- `manifest.json`
- `source_index.json`
- `checksums.sha256`

Evidence paths:

- `src/backend/context_export/index.ts`
- `src/backend/render/pdf.ts`
- `tests/sctl_context.test.ts`

### ADR-0602 tool registry preserved and updated

Implemented indexed SCTL tool registry:

- `strata tools list`
- `strata tools inspect`
- `strata tools run`

Registry path:

- `.strata/backend/tool_registry/tool_index.json`
- `.strata/backend/tool_registry/schemas/`

Registry includes stable entries for:

- `context.export_markdown.v1`
- `context.export_pdf.v1`
- `classd.locate_codex_sessions.v1`
- `classd.register_session.v1`
- `classd.export_markdown.v1`
- `classd.export_pdf.v1`
- `classd.verify_checksums.v1`
- `classd.inspect.v1`
- `session.launch_codex_tmux.v1`
- `returns.scan.v1`
- `returns.watch.v1`

Evidence paths:

- `src/backend/tool_registry/index.ts`
- `tests/sctl_context.test.ts`

### Class D local transcripts preserved and separated

Implemented Class D tools outside A/B/C authority:

- `strata classd locate`
- `strata classd register-session`
- `strata classd export-markdown`
- `strata classd export-pdf`
- `strata classd verify-checksums`
- `strata classd inspect`

Class D storage path:

- `.strata/class_d/local_transcripts/<session_id>/`

Class D artifacts:

- `codex_source.jsonl` or native source extension
- `metadata.json`
- `transcript.md`
- `transcript.pdf`
- `checksums.sha256`

Class D metadata explicitly records `class_authority: D_only_not_ABC`; there is no automatic Class D to Class B promotion.

Evidence paths:

- `src/backend/classd/index.ts`
- `tests/sctl_context.test.ts`

### Review outcome dispatch

Implemented fixed dispatch messages for:

- `rejected`
- `needs_revision`

If `origin_dispatch_channel` is known and path-addressable, SCTL writes the fixed message to that channel. In all cases it writes review-decision artifacts under:

- `.strata/dispatches/review_decisions/<proposal_id>/`

If no dispatch channel is known, SCTL writes:

- `.strata/dispatches/review_decisions/<proposal_id>/dispatch_needed.json`

Evidence path:

- `src/backend/context_git/index.ts`

### Stable result envelopes and failure artifacts

Implemented minimal tool-run result envelope:

```json
{
  "ok": true,
  "tool_id": "context.export_pdf.v1",
  "tool_run_id": "...",
  "result_path": "...",
  "evidence_paths": [],
  "errors": []
}
```

Tool runs and CLI failures write result artifacts under:

- `.strata/backend/tool_runs/<tool_run_id>/result.json`
- optional `stderr.txt`
- optional `stdout.txt`
- optional `diagnostics.json`

Evidence paths:

- `src/backend/tool_runs/index.ts`
- `src/cli/index.ts`

### CLI boundary refactor

Separated CLI parsing, command registry, validation, action filtering, Git context operations, tool execution, and runtime/session compatibility paths.

Evidence paths:

- CLI parsing: `src/cli/args.ts`
- command registry: `src/cli/command_registry.ts`
- SCTL command bindings: `src/cli/sctl_commands.ts`
- legacy runtime compatibility bindings: `src/cli/legacy_commands.ts`
- action filter: `src/backend/action_filter/index.ts`
- Git context operations: `src/backend/context_git/index.ts`
- context export tools: `src/backend/context_export/index.ts`
- tool execution registry: `src/backend/tool_registry/index.ts`
- runtime/session logic retained separately: `src/backend/tmux_dispatch/index.ts`

## Removed or disabled legacy behavior

- Replaced monolithic CLI authority routing in `src/cli/index.ts` with parser + command registry + command modules.
- Disabled direct `strata context add` authority writes; command now returns a retired shortcut error.
- Disabled direct `strata classb import`; command now returns a retired shortcut error.
- Disabled direct `strata report review` to Class B shortcut; command now returns a retired shortcut error.
- Disabled broad `strata gate evaluate/list/digest` CLI surface; commands now return retired gate errors.
- Removed packaged legacy `.strata/ledgers/mutation_gate` records.
- Changed legacy Mutation Gate compatibility behavior so it no longer authorizes or denies A/B/C authority; SCTL authority now uses proposal validation plus the action filter.

Evidence paths:

- `src/cli/sctl_commands.ts`
- `src/backend/mutation_gate/index.ts`
- `src/backend/common.ts`

## Tests run

All checks were run from package root `/mnt/data/strata_work`.

| Command | Status | Evidence log |
|---|---:|---|
| `npm ci` | PASS | `.strata/evidence/v0_7_completion/npm_ci.log` |
| `npm run build` | PASS | `.strata/evidence/v0_7_completion/npm_run_build.log` |
| `npm test` | PASS, 28/28 tests | `.strata/evidence/v0_7_completion/npm_test.log` |
| `npm run secret-scan` | PASS | `.strata/evidence/v0_7_completion/npm_run_secret_scan.log` |

Additional test source:

- `tests/sctl_context.test.ts`

## Remaining gaps / operational notes

- The `session.launch_codex_tmux.v1` registry entry remains implemented through the existing `strata sessions create` runtime adapter. It requires a real tmux/WSL runtime and is not launched by the automated tests in this container.
- The built-in PDF renderer is dependency-free and text-oriented. It produces valid simple PDF artifacts for review packages, not publication-quality typesetting.
- Legacy runtime modules remain available for backward-compatible packet, return, tmux, bridge, and evidence inspection commands. They do not provide A/B/C authority and do not bypass the Git-backed proposal workflow.

## Exact evidence paths

- `/mnt/data/strata_work/.strata/evidence/v0_7_completion/npm_ci.log`
- `/mnt/data/strata_work/.strata/evidence/v0_7_completion/npm_run_build.log`
- `/mnt/data/strata_work/.strata/evidence/v0_7_completion/npm_test.log`
- `/mnt/data/strata_work/.strata/evidence/v0_7_completion/npm_run_secret_scan.log`
- `/mnt/data/strata_work/tests/sctl_context.test.ts`
- `/mnt/data/strata_work/src/backend/context_git/index.ts`
- `/mnt/data/strata_work/src/backend/action_filter/index.ts`
- `/mnt/data/strata_work/src/backend/context_export/index.ts`
- `/mnt/data/strata_work/src/backend/tool_registry/index.ts`
- `/mnt/data/strata_work/src/backend/classd/index.ts`
- `/mnt/data/strata_work/src/backend/tool_runs/index.ts`
- `/mnt/data/strata_work/src/cli/index.ts`
- `/mnt/data/strata_work/src/cli/args.ts`
- `/mnt/data/strata_work/src/cli/command_registry.ts`
- `/mnt/data/strata_work/src/cli/sctl_commands.ts`
- `/mnt/data/strata_work/src/cli/legacy_commands.ts`
