﻿# WSL environment additions for Strata
export PATH="$HOME/.nvm/versions/node/v22.22.3/bin:$PATH"
export BRIDGE_AUTH_KEY="<YOUR_BRIDGE_AUTH_KEY>"
export NO_PROXY="127.0.0.1,localhost,::1"
