# Strata v0.6 — Engineer Delivery Package
**Date:** 2026-06-09
**Status:** M1 complete, Worktree clean, source + evidence + config

---

## What this is

A clean copy of the Strata v0.6 tmux/WSL worktree, distilled from
`Development_06_08/extracted/strata/strata_v0_6_tmux_wsl`,
with full .strata runtime evidence and an architecture pinmap.

**Excluded:** node_modules, dist, secrets (.env files), large zips

---

## Architecture (how it fits together)

```
Human Director (VS Code Remote-WSL)
  → Strata CLI    (TypeScript/Node, this package)
  → tmux session  (STRATA-CODER-A001)
    → Codex CLI   (v0.137+, --profile deepseek_bridge)
      → DeepSeek API bridge  (Fastify, port 38441, on Windows host)
        → DeepSeek API       (api.deepseek.com)
```

The bridge translates OpenAI Responses API → DeepSeek chat/completions.
Codex thinks it's talking to an OpenAI-compatible provider, but the model
inference runs on DeepSeek at ~5-10x lower cost.

---

## Runtime boundary (file-first)

```
.strata/
  sessions/       → tmux session records
  dispatches/     → Work Dispatch Packets (Markdown + JSON)
  returns/        → Worker Return Packets + Report files
  ledgers/        → Authoritative state (JSONL + Markdown)
  evidence/       → tmux pane captures, dispatch evidence
  quarantine/     → Failed validation reports
```

Chat/session text is NOT a deliverable. Only files in `.strata/` count.

---

## Backend modules

| Module | Purpose |
|---|---|
| `tmux_dispatch/` | Launches Codex in named tmux sesions, injects packets via buffer paste |
| `packets/` | Creates Context Load Packets + Work Dispatch Packets |
| `worker_returns/` | Scans `.strata/returns/`, validates, classifies, routes by return_kind |
| `worker_denial/` | Injects denial feedback into tmux when returns are invalid |
| `agent_report_ledger/` | REPORT_READY → review → ClassB import lifecycle |
| `backend_loop_ledger/` | Authoritative JSONL ledger + Markdown mirror |
| `dispatch_ledger/` | Dispatch-to-acknowledge chain tracking |
| `mutation_gate/` | Deterministic allow/deny on every state mutation |
| `governance/` | ClassA/B/C/D context model, validation, ClassB materialization |
| `context/` | Manages four context classes (A=policy, B=delta, C=reference, D=diagnostics) |
| `coordination_threads/` | IC/Human Director communication threads |
| `bridge_gate/` | Records bridge config (redacted), generates env exports |
| `workspace/` | `strata init` — creates `.strata/` layout |
| `secret_scan/` | Credential leak scanner |
| `duty_registry/` | Agent duty/role tracking |
| `config/` | Runtime configuration loader |

---

## Return kinds

```
ACK
QUESTION
BLOCKED
NEEDS_CLARIFICATION
PARTIAL_STATUS
REPORT_READY          ← only this can enter ClassB
FAILED_WITH_DIAGNOSTIC
```

---

## M1 acceptance chain (verified)

```
SESSION_LAUNCHED → WORK_PACKET_CREATED → WORK_PASSED
→ RETURN_FILE_DETECTED → RETURN_PACKET_CLASSIFIED (REPORT_READY)
→ REPORT_LEDGERED → ROUTED_TO_REVIEWER → CLASSB_IMPORTED (B-000001)
```

All events recorded in `.strata/ledgers/backend_loop_ledger.jsonl` (39 events, loops 0001-0039).
Every step shares the same assignment/agent/nonce chain.

---

## Key contracts

| Contract | Version |
|---|---|
| `worker_return_packet.v1` | v1 |
| `agent_report_ledger.entry.v1` | v1 |
| `report_review.record.v1` | v1 |
| `backend_loop_ledger.event.v0_6` | v0.6 |
| `governance_mutation_gate.v1` | v1 |
| `worker_denial.record.v1` | v1 (ADR0608) |
| `worker_denial.evidence.v1` | v1 |

---

## WSL reference (for the engineer)

See `wsl_reference/`:

- `deepseek_bridge.config.toml` — Codex CLI profile (model, provider, sandbox mode)
- `wsl_env_additions.bashrc` — Required environment variables

The engineer will need:
- Node.js 22+ in WSL (via nvm)
- `@openai/codex` v0.137+ globally installed
- tmux v3.4
- A DeepSeek API bridge running on the Windows host (127.0.0.1:38441)
- `BRIDGE_AUTH_KEY` and `NO_PROXY` set in the WSL environment

---

## Pointers in evidence

- `.strata/ledgers/backend_loop_ledger.jsonl` — Start here. 39 events, full M1 trace.
- `.strata/ledgers/class_b/index.json` — ClassB operational memory index (1 entry)
- `.strata/evidence/denials/` — Worker denial records (ADR0608)
- `.strata/ledgers/mutation_gate/` — Every state mutation gated + recorded

---

## Build

```bash
cd strata_v0_6_engineer_delivery
npm install
npm run build
```

---

## Quick smoke test (from WSL)

```bash
npm run build
node dist/src/cli/index.js init --workspace .
node dist/src/cli/index.js context bootstrap --workspace .
node dist/src/cli/index.js bridge gate --format json --api-key-file <path>
node dist/src/cli/index.js returns scan --workspace .
```